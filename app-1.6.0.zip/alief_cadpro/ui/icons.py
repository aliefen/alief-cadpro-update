"""Vector-drawn icon set (QPainter, 32x32 design grid) - no image files, crisp at any DPI."""
import math
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QIcon, QPixmap, QPainter, QPen, QColor, QBrush, QPainterPath, QFont, QPolygonF, QLinearGradient

W = "#E8EEF6"; CY = "#2EC5FF"; GR = "#36D399"; OR = "#FFB020"; RD = "#FF5A5F"; BL = "#4C8DFF"; PU = "#B07CFF"; GY = "#8A97A8"
_light = False


def set_light(v):
    global _light
    _light = v
    _cache.clear()


class P:
    def __init__(self, p):
        self.p = p

    def pen(self, c, w=2.0, dash=False):
        if _light and c == W:
            c = "#2B3644"
        pen = QPen(QColor(c), w); pen.setCapStyle(Qt.RoundCap); pen.setJoinStyle(Qt.RoundJoin)
        if dash:
            pen.setDashPattern([2, 2])
        self.p.setPen(pen)

    def ln(self, x1, y1, x2, y2, c=W, w=2.0, dash=False):
        self.pen(c, w, dash); self.p.setBrush(Qt.NoBrush); self.p.drawLine(QPointF(x1, y1), QPointF(x2, y2))

    def pl(self, pts, c=W, w=2.0, closed=False, fill=None, dash=False):
        self.pen(c, w, dash)
        self.p.setBrush(QBrush(QColor(fill)) if fill else Qt.NoBrush)
        poly = QPolygonF([QPointF(x, y) for x, y in pts])
        self.p.drawPolygon(poly) if closed or fill else self.p.drawPolyline(poly)

    def circ(self, x, y, r, c=W, w=2.0, fill=None, dash=False):
        self.pen(c, w, dash); self.p.setBrush(QBrush(QColor(fill)) if fill else Qt.NoBrush)
        self.p.drawEllipse(QPointF(x, y), r, r)

    def ell(self, x, y, rx, ry, c=W, w=2.0, fill=None):
        self.pen(c, w); self.p.setBrush(QBrush(QColor(fill)) if fill else Qt.NoBrush)
        self.p.drawEllipse(QPointF(x, y), rx, ry)

    def arc(self, x, y, r, a0, span, c=W, w=2.0):
        self.pen(c, w); self.p.setBrush(Qt.NoBrush)
        self.p.drawArc(QRectF(x - r, y - r, 2 * r, 2 * r), int(a0 * 16), int(span * 16))

    def rect(self, x, y, w_, h, c=W, w=2.0, fill=None, r=0):
        self.pen(c, w); self.p.setBrush(QBrush(QColor(fill)) if fill else Qt.NoBrush)
        self.p.drawRoundedRect(QRectF(x, y, w_, h), r, r)

    def dot(self, x, y, c=CY, r=2.6):
        self.p.setPen(Qt.NoPen); self.p.setBrush(QColor(c)); self.p.drawEllipse(QPointF(x, y), r, r)

    def sq(self, x, y, c=CY, s=3.2):
        self.p.setPen(QPen(QColor(c), 1.4)); self.p.setBrush(QColor("#1E232B") if not _light else QColor("white"))
        self.p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s))

    def txt(self, x, y, s, c=W, size=11, bold=True, w=30):
        if _light and c == W:
            c = "#2B3644"
        f = QFont("Segoe UI"); f.setPixelSize(size); f.setBold(bold); self.p.setFont(f); self.p.setPen(QColor(c))
        self.p.drawText(QRectF(x - w / 2, y - size, w, size * 2), Qt.AlignCenter, s)

    def cube(self, x, y, s, c=W, fill=None, w=1.8):
        a = s * 0.87; b = s * 0.5
        top = [(x, y - s), (x + a, y - b), (x, y), (x - a, y - b)]
        left = [(x - a, y - b), (x, y), (x, y + s), (x - a, y + b)]
        right = [(x, y), (x + a, y - b), (x + a, y + b), (x, y + s)]
        if fill:
            for poly, k in ((top, 1.25), (left, 0.85), (right, 1.0)):
                col = QColor(fill); col = col.lighter(int(100 * k)) if k > 1 else col.darker(int(100 / k))
                self.pl(poly, c, w, True, col.name())
        else:
            for poly in (top, left, right):
                self.pl(poly, c, w, True)

    def cyl(self, x, y, rx, h, c=W, fill=None):
        ry = rx * 0.38
        if fill:
            path = QPainterPath(); path.moveTo(x - rx, y); path.lineTo(x - rx, y + h)
            path.arcTo(QRectF(x - rx, y + h - ry, 2 * rx, 2 * ry), 180, 180); path.lineTo(x + rx, y)
            path.arcTo(QRectF(x - rx, y - ry, 2 * rx, 2 * ry), 0, -180)
            g = QLinearGradient(x - rx, 0, x + rx, 0); g.setColorAt(0, QColor(fill).darker(140)); g.setColorAt(0.45, QColor(fill).lighter(120)); g.setColorAt(1, QColor(fill).darker(160))
            self.pen(c, 1.6); self.p.setBrush(QBrush(g)); self.p.drawPath(path)
            self.ell(x, y, rx, ry, c, 1.6, QColor(fill).lighter(130).name())
        else:
            self.ell(x, y, rx, ry, c, 1.8); self.ln(x - rx, y, x - rx, y + h, c, 1.8); self.ln(x + rx, y, x + rx, y + h, c, 1.8)
            self.arc(x, y + h, rx, 180, 180, c, 1.8) if False else self.p.drawArc(QRectF(x - rx, y + h - ry, 2 * rx, 2 * ry), 180 * 16, 180 * 16)

    def arrow(self, x1, y1, x2, y2, c=OR, w=2.0):
        self.ln(x1, y1, x2, y2, c, w)
        a = math.atan2(y2 - y1, x2 - x1); s = 5
        self.pl([(x2, y2), (x2 - s * math.cos(a - 0.5), y2 - s * math.sin(a - 0.5)), (x2 - s * math.cos(a + 0.5), y2 - s * math.sin(a + 0.5))], c, 1, True, c)


def _bowtie(d, x=16, y=16, c=W, fill=None):
    d.pl([(x - 11, y - 7), (x - 11, y + 7), (x, y)], c, 1.8, True, fill)
    d.pl([(x + 11, y - 7), (x + 11, y + 7), (x, y)], c, 1.8, True)


DRAW = {}


def ico(name):
    def deco(fn):
        DRAW[name] = fn
        return fn
    return deco


# ----------------------------------------------------------------------------- file / app
@ico("new")
def _(d):
    d.pl([(8, 3), (20, 3), (26, 9), (26, 29), (8, 29)], W, 1.8, True); d.pl([(20, 3), (20, 9), (26, 9)], W, 1.8); d.ln(17, 15, 17, 25, CY, 2.4); d.ln(12, 20, 22, 20, CY, 2.4)


@ico("open")
def _(d):
    d.pl([(3, 8), (12, 8), (15, 11), (27, 11), (27, 26), (3, 26)], W, 1.8, True, "#3A4B60"); d.pl([(3, 26), (8, 15), (30, 15), (27, 26)], OR, 1.8, True, "#5A4520")


@ico("save")
def _(d):
    d.rect(4, 4, 24, 24, W, 1.8, None, 3); d.rect(9, 4, 13, 8, CY, 1.8); d.rect(8, 17, 16, 11, W, 1.6, "#2D3C50"); d.ln(18, 6, 18, 10, CY, 2)


@ico("saveas")
def _(d):
    DRAW["save"](d); d.dot(26, 26, OR, 5); d.ln(23.5, 26, 28.5, 26, "#1E232B", 1.6); d.ln(26, 23.5, 26, 28.5, "#1E232B", 1.6)


@ico("import")
def _(d):
    d.rect(4, 12, 18, 16, W, 1.8, None, 2); d.arrow(28, 4, 14, 18, CY, 2.4)


@ico("export")
def _(d):
    d.rect(4, 12, 18, 16, W, 1.8, None, 2); d.arrow(13, 19, 28, 4, GR, 2.4)


@ico("plot")
def _(d):
    d.rect(8, 3, 16, 9, W, 1.6); d.rect(3, 11, 26, 11, W, 1.8, "#2D3C50", 3); d.rect(8, 18, 16, 11, W, 1.6, "#E8EEF6"); d.ln(11, 22, 21, 22, CY, 1.5); d.ln(11, 25, 18, 25, CY, 1.5); d.dot(25, 15, GR, 1.6)


@ico("png")
def _(d):
    d.rect(3, 5, 26, 22, W, 1.8, None, 3); d.pl([(5, 25), (12, 15), (18, 22), (22, 17), (28, 25)], GR, 1.8); d.dot(22, 11, OR, 3)


@ico("undo")
def _(d):
    path = QPainterPath(); path.moveTo(9, 13); path.cubicTo(14, 6, 27, 8, 27, 19); d.pen(CY, 2.6); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    d.pl([(4, 12), (12, 7), (12, 17)], CY, 1, True, CY)


@ico("redo")
def _(d):
    path = QPainterPath(); path.moveTo(23, 13); path.cubicTo(18, 6, 5, 8, 5, 19); d.pen(CY, 2.6); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    d.pl([(28, 12), (20, 7), (20, 17)], CY, 1, True, CY)


@ico("dwg")
def _(d):
    d.pl([(6, 3), (20, 3), (26, 9), (26, 29), (6, 29)], W, 1.6, True); d.txt(16, 20, "DWG", CY, 8)


@ico("dxf")
def _(d):
    d.pl([(6, 3), (20, 3), (26, 9), (26, 29), (6, 29)], W, 1.6, True); d.txt(16, 20, "DXF", GR, 8)


@ico("options")
def _(d):
    d.circ(16, 16, 5, CY, 2.4)
    for k in range(8):
        a = k * math.pi / 4; d.ln(16 + 8 * math.cos(a), 16 + 8 * math.sin(a), 16 + 12 * math.cos(a), 16 + 12 * math.sin(a), W, 3.2)
    d.circ(16, 16, 9, W, 2)


@ico("update")
def _(d):
    d.arc(16, 16, 11, 30, 280, CY, 2.6); d.pl([(26, 4), (27, 12), (19, 11)], CY, 1, True, CY); d.ln(16, 10, 16, 20, GR, 2.4); d.pl([(12, 17), (16, 22), (20, 17)], GR, 2.2)


@ico("about")
def _(d):
    d.circ(16, 16, 12, CY, 2); d.dot(16, 10, W, 2); d.ln(16, 14, 16, 23, W, 2.6)


@ico("help")
def _(d):
    d.circ(16, 16, 12, GR, 2); d.txt(16, 17, "?", W, 16)


@ico("guide")
def _(d):
    d.pl([(4, 6), (15, 8), (15, 28), (4, 26)], W, 1.8, True); d.pl([(28, 6), (17, 8), (17, 28), (28, 26)], CY, 1.8, True); d.ln(7, 13, 12, 14, W, 1.3); d.ln(7, 18, 12, 19, W, 1.3); d.ln(20, 14, 25, 13, CY, 1.3)


# ----------------------------------------------------------------------------- draw 2D
@ico("xline")
def _(d):
    d.ln(2, 28, 30, 4, CY, 1.6); d.sq(16, 16); d.arrow(8, 23, 2, 28, CY) if hasattr(d, "arrow") else None; d.arrow(24, 9, 30, 4, CY) if hasattr(d, "arrow") else None


@ico("ray")
def _(d):
    d.ln(6, 25, 30, 5, CY, 1.6); d.sq(6, 25); d.arrow(24, 10, 30, 5, CY) if hasattr(d, "arrow") else None


@ico("tofront")
def _(d):
    d.rect(4, 4, 16, 16, W, 1.2); d.rect(12, 12, 16, 16, OR, 2, fill=OR) if "fill" in d.rect.__code__.co_varnames else d.rect(12, 12, 16, 16, OR, 2.4)


@ico("toback")
def _(d):
    (d.rect(4, 4, 16, 16, OR, 2, fill=OR) if "fill" in d.rect.__code__.co_varnames else d.rect(4, 4, 16, 16, OR, 2.4)); d.rect(12, 12, 16, 16, W, 1.2)


@ico("draworder")
def _(d):
    d.rect(3, 3, 14, 14, W, 1.2); d.rect(9, 9, 14, 14, OR, 1.8); d.rect(15, 15, 14, 14, CY, 1.2)


@ico("line")
def _(d):
    d.ln(5, 26, 27, 6, W, 2.2); d.sq(5, 26); d.sq(27, 6)


@ico("pline")
def _(d):
    d.pl([(4, 26), (11, 9), (20, 22), (28, 6)], W, 2.2); d.sq(4, 26); d.sq(11, 9); d.sq(20, 22); d.sq(28, 6)


@ico("circle")
def _(d):
    d.circ(16, 16, 11, W, 2.2); d.dot(16, 16, CY, 2.2); d.ln(16, 16, 27, 16, CY, 1.4, True)


@ico("circle2p")
def _(d):
    d.circ(16, 16, 11, W, 2.2); d.sq(5, 16); d.sq(27, 16)


@ico("circle3p")
def _(d):
    d.circ(16, 16, 11, W, 2.2); d.sq(5, 16); d.sq(22, 6.5); d.sq(21, 25.8)


@ico("arc")
def _(d):
    d.arc(16, 20, 12, 0, 180, W, 2.2); d.sq(4, 20); d.sq(16, 8); d.sq(28, 20)


@ico("arcsce")
def _(d):
    d.arc(16, 20, 12, 0, 140, W, 2.2); d.dot(16, 20, CY, 2.2); d.sq(28, 20); d.ln(16, 20, 28, 20, CY, 1.3, True)


@ico("rect")
def _(d):
    d.rect(4, 8, 24, 16, W, 2.2); d.sq(4, 24); d.sq(28, 8)


@ico("polygon")
def _(d):
    pts = [(16 + 12 * math.cos(math.radians(90 + 60 * k)), 16 - 12 * math.sin(math.radians(90 + 60 * k))) for k in range(6)]
    d.pl(pts, W, 2.2, True); d.dot(16, 16, CY, 2)


@ico("ellipse")
def _(d):
    d.ell(16, 16, 13, 8, W, 2.2); d.dot(16, 16, CY, 2); d.ln(16, 16, 29, 16, CY, 1.3, True)


@ico("spline")
def _(d):
    path = QPainterPath(); path.moveTo(3, 24); path.cubicTo(10, 0, 20, 34, 29, 8); d.pen(W, 2.2); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    d.sq(3, 24); d.sq(16, 16); d.sq(29, 8)


@ico("point")
def _(d):
    d.ln(16, 6, 16, 26, W, 1.6); d.ln(6, 16, 26, 16, W, 1.6); d.circ(16, 16, 4, CY, 2.2)


@ico("text")
def _(d):
    d.txt(16, 17, "A", W, 22); d.ln(6, 28, 26, 28, CY, 2)


@ico("mtext")
def _(d):
    d.txt(11, 12, "A", W, 14); d.ln(18, 7, 28, 7, W, 2); d.ln(18, 12, 28, 12, W, 2); d.ln(4, 19, 28, 19, CY, 2); d.ln(4, 25, 22, 25, CY, 2)


@ico("hatch")
def _(d):
    d.rect(4, 6, 24, 20, W, 2)
    d.p.save(); d.p.setClipRect(QRectF(5, 7, 22, 18))
    for k in range(-20, 32, 5):
        d.ln(k, 28, k + 22, 4, CY, 1.3)
    d.p.restore()


@ico("gradient")
def _(d):
    g = QLinearGradient(4, 0, 28, 0); g.setColorAt(0, QColor(CY)); g.setColorAt(1, QColor(PU))
    d.pen(W, 2); d.p.setBrush(QBrush(g)); d.p.drawRect(QRectF(4, 6, 24, 20))


@ico("dimlin")
def _(d):
    d.ln(5, 8, 5, 26, W, 1.4); d.ln(27, 8, 27, 26, W, 1.4); d.arrow(16, 14, 5, 14, CY, 1.6); d.arrow(16, 14, 27, 14, CY, 1.6); d.txt(16, 22, "100", W, 8)


@ico("dimali")
def _(d):
    d.ln(4, 22, 20, 4, GY, 1.2); d.ln(10, 28, 28, 10, W, 1.4); d.arrow(19, 19, 10, 28, CY, 1.6); d.arrow(19, 19, 28, 10, CY, 1.6)


@ico("dimrad")
def _(d):
    d.arc(12, 20, 13, 0, 90, W, 1.8); d.dot(12, 20, W, 1.8); d.arrow(12, 20, 21, 11, CY, 1.6); d.txt(23, 27, "R", CY, 11)


@ico("dimdia")
def _(d):
    d.circ(16, 16, 11, W, 1.8); d.arrow(16, 16, 8, 24, CY, 1.6); d.arrow(16, 16, 24, 8, CY, 1.6); d.txt(24, 25, "Ø", CY, 10)


@ico("dimang")
def _(d):
    d.ln(5, 27, 28, 27, W, 1.8); d.ln(5, 27, 22, 6, W, 1.8); d.arc(5, 27, 15, 0, 51, CY, 1.8); d.txt(24, 20, "°", CY, 12)


@ico("leader")
def _(d):
    d.arrow(17, 14, 5, 26, CY, 1.8); d.ln(17, 14, 23, 8, W, 1.8); d.ln(23, 8, 29, 8, W, 1.8); d.txt(25, 4, "A", W, 8)


@ico("table")
def _(d):
    d.rect(3, 5, 26, 22, W, 1.8)
    for y in (11, 17, 22):
        d.ln(3, y, 29, y, W, 1.2)
    d.ln(10, 5, 10, 27, W, 1.2); d.ln(20, 5, 20, 27, W, 1.2); d.rect(3, 5, 26, 6, CY, 1.2, "#1B5E7E")


@ico("annoscale")
def _(d):
    d.txt(10, 13, "A", W, 16); d.txt(22, 21, "A", CY, 10); d.arrow(6, 28, 26, 28, OR, 1.6); d.txt(23, 9, "1:50", OR, 7, True, 16)


@ico("textfit")
def _(d):
    d.txt(9, 11, "T", W, 13); d.txt(23, 11, "T", W, 7); d.arrow(5, 22, 27, 22, CY, 1.8); d.txt(16, 28, "AUTO", GR, 7)


# ----------------------------------------------------------------------------- modify
@ico("erase")
def _(d):
    d.pl([(5, 21), (17, 9), (27, 19), (19, 27), (11, 27)], W, 1.8, True, "#3A4352"); d.ln(11, 15, 21, 25, RD, 2.4); d.ln(21, 15, 11, 25, RD, 2.4)


@ico("move")
def _(d):
    d.arrow(16, 16, 16, 3, CY); d.arrow(16, 16, 16, 29, CY); d.arrow(16, 16, 3, 16, CY); d.arrow(16, 16, 29, 16, CY)


@ico("copy")
def _(d):
    d.rect(4, 4, 15, 15, GY, 1.6, None, 2); d.rect(13, 13, 15, 15, W, 1.8, "#2D3C50", 2); d.ln(17, 20.5, 24, 20.5, CY, 2); d.ln(20.5, 17, 20.5, 24, CY, 2)


@ico("rotate")
def _(d):
    d.arc(16, 16, 11, 60, 270, CY, 2.4); d.pl([(21, 3), (24, 10), (17, 10)], CY, 1, True, CY); d.rect(12, 12, 8, 8, W, 1.8)


@ico("scale")
def _(d):
    d.rect(4, 14, 14, 14, GY, 1.6); d.rect(4, 4, 24, 24, W, 1.8); d.arrow(10, 22, 25, 7, CY, 2)


@ico("mirror")
def _(d):
    d.ln(16, 3, 16, 29, OR, 1.6, True); d.pl([(4, 24), (13, 24), (13, 8)], W, 1.8, True); d.pl([(28, 24), (19, 24), (19, 8)], CY, 1.8, True)


@ico("offset")
def _(d):
    path = QPainterPath(); path.moveTo(3, 26); path.cubicTo(8, 10, 20, 10, 25, 4)
    path2 = QPainterPath(); path2.moveTo(9, 29); path2.cubicTo(13, 17, 23, 17, 29, 10)
    d.pen(W, 2); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path); d.pen(CY, 2); d.p.drawPath(path2)


@ico("trim")
def _(d):
    d.ln(16, 3, 16, 29, OR, 2); d.ln(3, 16, 16, 16, W, 2.2); d.ln(16, 16, 29, 16, GY, 1.8, True); d.ln(21, 11, 27, 21, RD, 2); d.ln(27, 11, 21, 21, RD, 2)


@ico("extend")
def _(d):
    d.ln(27, 3, 27, 29, OR, 2); d.ln(3, 16, 15, 16, W, 2.2); d.arrow(15, 16, 26, 16, CY, 2)


@ico("fillet")
def _(d):
    d.ln(5, 27, 5, 15, W, 2.2); d.ln(17, 5, 28, 5, W, 2.2); d.arc(17, 15, 12, 90, 90, CY, 2.4)


@ico("chamfer")
def _(d):
    d.ln(5, 27, 5, 14, W, 2.2); d.ln(14, 5, 28, 5, W, 2.2); d.ln(5, 14, 14, 5, CY, 2.4)


@ico("array")
def _(d):
    for i in range(3):
        for j in range(3):
            d.rect(4 + i * 9, 4 + j * 9, 6, 6, W if i + j else CY, 1.6)


@ico("arraypolar")
def _(d):
    d.circ(16, 16, 10, GY, 1.2, None, True)
    for k in range(6):
        a = k * math.pi / 3; d.dot(16 + 10 * math.cos(a), 16 + 10 * math.sin(a), CY if k == 0 else W, 3)


@ico("explode")
def _(d):
    d.rect(11, 11, 10, 10, W, 1.8)
    for a, b in ((8, 8), (24, 8), (8, 24), (24, 24)):
        d.arrow(16 + (a - 16) * 0.55, 16 + (b - 16) * 0.55, a - (a - 16) * 0.35 + (a - 16) * 0.4, b - (b - 16) * 0.35 + (b - 16) * 0.4, OR, 1.6)


@ico("join")
def _(d):
    d.ln(3, 22, 14, 22, W, 2.2); d.ln(18, 22, 29, 10, W, 2.2); d.dot(16, 22, CY, 3.4)


@ico("break")
def _(d):
    d.ln(3, 16, 12, 16, W, 2.2); d.ln(20, 16, 29, 16, W, 2.2); d.sq(12, 16, OR); d.sq(20, 16, OR)


@ico("stretch")
def _(d):
    d.rect(3, 10, 12, 14, W, 1.8); d.pl([(15, 10), (27, 10), (27, 24), (15, 24)], CY, 1.8); d.rect(20, 6, 10, 22, OR, 1.2); d.arrow(12, 28, 26, 28, OR, 1.6)


@ico("matchprop")
def _(d):
    d.rect(5, 4, 22, 9, OR, 1.8, "#5A4520", 3); d.ln(16, 13, 16, 20, W, 2); d.rect(12, 20, 8, 9, W, 1.8, None, 2)


@ico("lengthen")
def _(d):
    d.ln(3, 16, 19, 16, W, 2.2); d.arrow(19, 16, 29, 16, CY, 2)


# ----------------------------------------------------------------------------- 3D solids
@ico("box")
def _(d):
    d.cube(16, 16, 11, W, "#3E7BD6")


@ico("cylinder")
def _(d):
    d.cyl(16, 8, 10, 16, W, "#3E7BD6")


@ico("cone")
def _(d):
    path = QPainterPath(); path.moveTo(16, 3); path.lineTo(5, 25); path.arcTo(QRectF(5, 21, 22, 8), 180, 180); path.closeSubpath()
    g = QLinearGradient(5, 0, 27, 0); g.setColorAt(0, QColor("#24508F")); g.setColorAt(0.45, QColor("#5A9AF0")); g.setColorAt(1, QColor("#1F4277"))
    d.pen(W, 1.6); d.p.setBrush(QBrush(g)); d.p.drawPath(path)


@ico("sphere")
def _(d):
    from PySide6.QtGui import QRadialGradient
    g = QRadialGradient(12, 11, 16); g.setColorAt(0, QColor("#9CC4FF")); g.setColorAt(1, QColor("#1F4277"))
    d.pen(W, 1.6); d.p.setBrush(QBrush(g)); d.p.drawEllipse(QPointF(16, 16), 12, 12)
    d.ell(16, 16, 12, 4.2, "#CFE0F7", 1)


@ico("torus")
def _(d):
    d.ell(16, 16, 13, 8, W, 6); d.ell(16, 16, 13, 8, "#3E7BD6", 4); d.ell(16, 15, 5, 2.4, W, 1.4)


@ico("wedge")
def _(d):
    d.pl([(4, 26), (22, 26), (4, 10)], W, 1.6, True, "#3E7BD6"); d.pl([(22, 26), (28, 20), (10, 4), (4, 10)], W, 1.6, True, "#5A9AF0")
    d.pl([(4, 10), (10, 4), (28, 20), (22, 26)], W, 1.6)


@ico("pyramid")
def _(d):
    d.pl([(16, 3), (4, 24), (16, 29)], W, 1.6, True, "#2E64B0"); d.pl([(16, 3), (16, 29), (28, 24)], W, 1.6, True, "#5A9AF0")


@ico("extrude")
def _(d):
    d.pl([(5, 26), (19, 26), (27, 20), (13, 20)], CY, 2, True, "#1B5E7E"); d.arrow(16, 22, 16, 4, OR, 2.2); d.pl([(5, 13), (19, 13), (27, 7), (13, 7)], W, 1.4, True)


@ico("revolve")
def _(d):
    d.ln(6, 3, 6, 29, OR, 1.6, True); d.pl([(10, 6), (16, 6), (16, 26), (10, 26)], CY, 2); d.arc(16, 16, 10, 300, 120, W, 1.8); d.arc(16, 16, 10, 120, 120, W, 1.8)


@ico("sweep")
def _(d):
    path = QPainterPath(); path.moveTo(4, 26); path.cubicTo(10, 6, 22, 30, 28, 8); d.pen(OR, 1.6); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    d.circ(4, 26, 3.5, CY, 2); d.circ(28, 8, 3.5, W, 2)


@ico("loft")
def _(d):
    d.ell(16, 26, 11, 3.5, CY, 2); d.rect(10, 4, 12, 6, W, 1.8); d.ln(5, 26, 10, 10, GY, 1.4); d.ln(27, 26, 22, 10, GY, 1.4)


@ico("union")
def _(d):
    d.circ(12, 16, 8, W, 1.8, "#3E7BD6"); d.circ(20, 16, 8, W, 1.8, "#3E7BD6"); d.p.setPen(Qt.NoPen); d.p.setBrush(QColor("#3E7BD6")); d.p.drawEllipse(QPointF(12, 16), 7, 7)


@ico("subtract")
def _(d):
    d.circ(12, 16, 8, W, 1.8, "#3E7BD6"); d.circ(20, 16, 8, RD, 1.8, "#1E232B" if not _light else "#FFFFFF")


@ico("intersect")
def _(d):
    d.circ(12, 16, 8, W, 1.4); d.circ(20, 16, 8, W, 1.4)
    path = QPainterPath(); path.addEllipse(QPointF(12, 16), 8, 8); p2 = QPainterPath(); p2.addEllipse(QPointF(20, 16), 8, 8)
    d.p.setPen(Qt.NoPen); d.p.setBrush(QColor("#3E7BD6")); d.p.drawPath(path.intersected(p2))


@ico("slice")
def _(d):
    d.cube(16, 17, 10, W, "#3E7BD6"); d.pl([(2, 20), (14, 4), (30, 12), (18, 28)], OR, 1.6, True); d.ln(2, 20, 30, 12, OR, 1.2, True)


@ico("thicken")
def _(d):
    d.pl([(3, 22), (15, 14), (29, 18)], CY, 2.2); d.pl([(3, 16), (15, 8), (29, 12)], W, 1.6); d.arrow(15, 14, 15, 9, OR, 1.4)


@ico("rotate3d")
def _(d):
    d.cube(16, 17, 8, W); d.ell(16, 17, 14, 5, CY, 2); d.pl([(29, 15), (30, 20), (25, 19)], CY, 1, True, CY)


@ico("mirror3d")
def _(d):
    d.pl([(13, 3), (19, 7), (19, 29), (13, 25)], OR, 1.4, True); d.cube(7, 16, 5, W); d.cube(25, 16, 5, CY)


@ico("presspull")
def _(d):
    d.cube(16, 19, 9, W, "#3E7BD6"); d.arrow(16, 10, 16, 1, OR, 2.2)


# ----------------------------------------------------------------------------- surfaces
@ico("planesurf")
def _(d):
    d.pl([(3, 22), (14, 14), (29, 16), (18, 26)], CY, 2, True, "#1B5E7E")
    for t in (0.33, 0.66):
        d.ln(3 + 11 * t, 22 - 8 * t, 18 + 11 * t, 26 - 10 * t, CY, 1)


@ico("extsurf")
def _(d):
    path = QPainterPath(); path.moveTo(3, 27); path.cubicTo(8, 20, 14, 30, 20, 24); path.lineTo(28, 10); path.cubicTo(22, 16, 16, 6, 11, 13); path.closeSubpath()
    d.pen(CY, 1.8); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)


@ico("revsurf")
def _(d):
    d.ln(16, 2, 16, 30, OR, 1.4, True)
    path = QPainterPath(); path.moveTo(9, 4); path.cubicTo(3, 12, 13, 20, 7, 28); path.lineTo(25, 28); path.cubicTo(19, 20, 29, 12, 23, 4); path.closeSubpath()
    d.pen(CY, 1.8); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)


@ico("loftsurf")
def _(d):
    path = QPainterPath(); path.moveTo(3, 25); path.cubicTo(10, 18, 20, 30, 29, 22); path.lineTo(26, 6); path.cubicTo(18, 12, 12, 2, 6, 8); path.closeSubpath()
    d.pen(CY, 1.8); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path); d.ln(9, 21, 9, 7, CY, 1); d.ln(17, 24, 16, 8, CY, 1)


@ico("edgesurf")
def _(d):
    d.pl([(4, 24), (10, 6), (28, 8), (24, 27)], CY, 1.4, True, "#1B5E7E")
    for k, c in enumerate((OR, GR, PU, RD)):
        pts = [(4, 24), (10, 6), (28, 8), (24, 27), (4, 24)]
        d.ln(*pts[k], *pts[k + 1], c, 2.4)


@ico("rulesurf")
def _(d):
    d.ln(4, 6, 28, 10, OR, 2.2); d.ln(4, 26, 28, 22, GR, 2.2)
    for k in range(5):
        t = k / 4; d.ln(4 + 24 * t, 6 + 4 * t, 4 + 24 * t, 26 - 4 * t, CY, 1)


@ico("sweepsurf")
def _(d):
    path = QPainterPath(); path.moveTo(3, 20); path.cubicTo(10, 8, 22, 30, 29, 14); path.lineTo(29, 6); path.cubicTo(22, 22, 10, 0, 3, 12); path.closeSubpath()
    d.pen(CY, 1.8); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)


@ico("offsetsurf")
def _(d):
    d.pl([(3, 24), (15, 18), (29, 22)], CY, 2.2); d.pl([(3, 14), (15, 8), (29, 12)], W, 2); d.arrow(15, 18, 15, 10, OR, 1.4)


@ico("srfpt")
def _(d):
    d.pl([(5, 23), (12, 7), (27, 10), (23, 26)], CY, 1.4, True, "#1B5E7E")
    for x, y in ((5, 23), (12, 7), (27, 10), (23, 26)):
        d.dot(x, y, OR, 2.6)


@ico("planarsrf")
def _(d):
    path = QPainterPath(); path.moveTo(5, 20); path.cubicTo(4, 6, 16, 4, 20, 9); path.cubicTo(30, 8, 30, 24, 20, 26); path.cubicTo(12, 30, 6, 26, 5, 20)
    d.pen(OR, 2); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)


@ico("extalong")
def _(d):
    d.pl([(4, 26), (8, 18), (14, 22)], OR, 2.2); d.pl([(18, 12), (22, 4), (28, 8)], CY, 1.6)
    path = QPainterPath(); path.moveTo(8, 18); path.cubicTo(12, 8, 16, 14, 22, 4); d.pen(GR, 1.6); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    d.ln(4, 26, 18, 12, CY, 1); d.ln(14, 22, 28, 8, CY, 1)


@ico("exttopt")
def _(d):
    d.pl([(4, 25), (12, 20), (20, 27), (28, 22)], OR, 2.2)
    for x, y in ((4, 25), (12, 20), (20, 27), (28, 22)):
        d.ln(x, y, 16, 5, CY, 1)
    d.dot(16, 5, GR, 2.6)


@ico("sweep2")
def _(d):
    p1 = QPainterPath(); p1.moveTo(3, 24); p1.cubicTo(10, 14, 20, 30, 29, 20)
    p2 = QPainterPath(); p2.moveTo(5, 10); p2.cubicTo(12, 2, 20, 14, 27, 5)
    d.pen(GR, 2); d.p.setBrush(Qt.NoBrush); d.p.drawPath(p1); d.p.drawPath(p2)
    for a, b in (((3, 24), (5, 10)), ((16, 22), (16, 8)), ((29, 20), (27, 5))):
        d.ln(*a, *b, OR if a[0] == 3 else CY, 1.6)


@ico("networksrf")
def _(d):
    for k in range(3):
        y = 7 + 9 * k; path = QPainterPath(); path.moveTo(3, y + 2); path.cubicTo(11, y - 5, 21, y + 6, 29, y - 1)
        d.pen(CY, 1.6); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    for k in range(3):
        x = 6 + 10 * k; path = QPainterPath(); path.moveTo(x, 4); path.cubicTo(x + 4, 12, x - 4, 20, x + 1, 28)
        d.pen(OR, 1.6); d.p.drawPath(path)


@ico("patch")
def _(d):
    path = QPainterPath(); path.moveTo(4, 18); path.cubicTo(4, 4, 28, 4, 28, 16); path.cubicTo(28, 30, 6, 30, 4, 18)
    d.pen(OR, 2); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)
    d.pen(CY, 1); d.p.setBrush(Qt.NoBrush); d.p.drawEllipse(QPointF(16, 17), 7, 5); d.dot(16, 17, GR, 2.2)


@ico("railrev")
def _(d):
    d.ln(16, 3, 16, 29, W, 1, True)
    d.pen(GR, 2); d.p.setBrush(Qt.NoBrush); d.p.drawEllipse(QPointF(16, 22), 12, 5)
    path = QPainterPath(); path.moveTo(28, 22); path.cubicTo(26, 14, 20, 12, 18, 5); d.pen(OR, 2); d.p.drawPath(path)
    path = QPainterPath(); path.moveTo(4, 22); path.cubicTo(6, 14, 12, 12, 14, 5); d.pen(CY, 1.2); d.p.drawPath(path)


@ico("offsetsrf")
def _(d):
    d.pl([(3, 24), (15, 18), (29, 22)], CY, 2.2); d.pl([(3, 14), (15, 8), (29, 12)], W, 2); d.arrow(15, 18, 15, 10, OR, 1.4)


@ico("flip")
def _(d):
    d.pl([(4, 20), (12, 12), (28, 14), (22, 24)], CY, 1.4, True, "#1B5E7E"); d.arrow(16, 17, 16, 4, OR, 1.6); d.arrow(16, 19, 16, 30, GR, 1.6)


@ico("dupborder")
def _(d):
    d.pl([(6, 22), (12, 9), (26, 11), (22, 25)], CY, 1, True, "#1B5E7E"); d.pl([(4, 24), (11, 6), (29, 9), (24, 28)], OR, 2.2, True)


@ico("contour")
def _(d):
    path = QPainterPath(); path.moveTo(3, 12); path.cubicTo(8, 30, 24, 30, 29, 12); d.pen(CY, 1.6); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)
    for x in (9, 16, 23):
        d.ln(x, 5, x, 28, OR, 1.6)


@ico("section")
def _(d):
    path = QPainterPath(); path.moveTo(3, 12); path.cubicTo(8, 30, 24, 30, 29, 12); d.pen(CY, 1.6); d.p.setBrush(QColor("#1B5E7E")); d.p.drawPath(path)
    d.ln(4, 27, 28, 6, OR, 2.2)


# ----------------------------------------------------------------------------- v1.2: annotate / insert / views / blocks
@ico("dimarc")
def _(d):
    path = QPainterPath(); path.moveTo(5, 24); path.cubicTo(8, 10, 24, 10, 27, 24); d.pen(W, 2); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    path = QPainterPath(); path.moveTo(3, 16); path.cubicTo(8, 2, 24, 2, 29, 16); d.pen(OR, 1.6); d.p.drawPath(path)
    d.ln(5, 24, 3, 14, CY, 1); d.ln(27, 24, 29, 14, CY, 1)


@ico("dimcont")
def _(d):
    d.ln(4, 10, 28, 10, OR, 1.6)
    for x in (4, 13, 21, 28):
        d.ln(x, 6, x, 24, CY, 1.2)
    d.ln(4, 26, 28, 26, W, 2)


@ico("dimbase")
def _(d):
    d.ln(4, 6, 28, 6, OR, 1.4); d.ln(4, 11, 20, 11, OR, 1.4); d.ln(4, 16, 12, 16, OR, 1.4)
    for x, y in ((4, 4), (12, 14), (20, 9), (28, 4)):
        d.ln(x, y, x, 24, CY, 1.2)
    d.ln(4, 26, 28, 26, W, 2)


@ico("dimord")
def _(d):
    d.ln(5, 27, 5, 5, W, 1.6); d.ln(5, 27, 28, 27, W, 1.6)
    d.pl([(14, 27), (14, 18), (18, 14), (18, 6)], OR, 1.6); d.pl([(5, 12), (12, 12), (15, 9), (22, 9)], CY, 1.6); d.dot(5, 27, GR, 2.4)


@ico("dimjog")
def _(d):
    d.p.setPen(QPen(QColor(W if not _light else "#2B3644"), 2)); d.p.setBrush(Qt.NoBrush); d.p.drawArc(QRectF(2, 8, 30, 30), 40 * 16, 110 * 16)
    d.pl([(6, 28), (12, 22), (10, 18), (17, 11)], OR, 1.8); d.arrow(12, 16, 18, 10, OR, 1.6)


@ico("centerline")
def _(d):
    d.ln(4, 7, 28, 7, W, 2); d.ln(4, 25, 28, 25, W, 2); d.ln(2, 16, 30, 16, RD, 1.6, True)


@ico("centermark")
def _(d):
    d.ell(16, 16, 10, 10, W, 2); d.ln(3, 16, 29, 16, RD, 1.4, True); d.ln(16, 3, 16, 29, RD, 1.4, True)


@ico("table")
def _(d):
    d.rect(4, 5, 24, 22, W, 1.6, None, 2); d.rect(4, 5, 24, 6, CY, 1, CY, 2)
    for y in (16, 21):
        d.ln(4, y, 28, y, W, 1)
    for x in (12, 20):
        d.ln(x, 11, x, 27, W, 1)


@ico("tableexport")
def _(d):
    d.rect(3, 5, 18, 18, W, 1.4, None, 2); d.ln(3, 11, 21, 11, W, 1); d.ln(3, 17, 21, 17, W, 1); d.ln(12, 5, 12, 23, W, 1)
    d.rect(16, 15, 13, 13, GR, 1, "#1F7A44", 2); d.txt(22.5, 21.5, "X", W, 9)


@ico("areatable")
def _(d):
    d.pl([(3, 12), (9, 4), (17, 7), (15, 15), (6, 17)], OR, 1.6, True, "#5A3A10"); d.rect(12, 16, 17, 12, W, 1.4, None, 2)
    d.ln(12, 20, 29, 20, W, 1); d.ln(12, 24, 29, 24, W, 1); d.ln(20, 16, 20, 28, W, 1)


@ico("find")
def _(d):
    d.ell(13, 13, 8, 8, CY, 2.2); d.ln(19, 19, 28, 28, CY, 3); d.txt(13, 13, "A", W, 9)


@ico("volume")
def _(d):
    d.cube(16, 17, 10, CY, "#1B5E7E", 1.6); d.txt(16, 22, "V", OR, 9)


@ico("detailview")
def _(d):
    d.ell(9, 22, 6, 6, OR, 1.8); d.ell(21, 11, 10, 10, OR, 1.8, "#22303F"); d.ln(13, 18, 15, 17, OR, 1.2)
    d.pl([(15, 14), (21, 8), (27, 12)], CY, 1.8); d.ln(21, 8, 21, 17, CY, 1.4)


@ico("xref")
def _(d):
    d.pl([(5, 4), (18, 4), (23, 9), (23, 28), (5, 28)], W, 1.6, True); d.txt(14, 17, "DWG", CY, 7)
    d.pl([(20, 20), (29, 20)], OR, 2.2); d.arrow(24, 20, 30, 20, OR, 1.8)


@ico("imageclip")
def _(d):
    d.rect(3, 5, 26, 22, W, 1.2, "#2D3C50", 3); d.pl([(5, 25), (12, 14), (18, 21), (22, 16), (28, 25)], GR, 1.4, True, "#1F5A44")
    d.rect(9, 9, 15, 13, OR, 2, None, 0)


@ico("viewmgr")
def _(d):
    d.rect(3, 4, 20, 15, W, 1.6, "#22303F", 2); d.cube(13, 13, 5, CY, "#1B5E7E", 1.2); d.ell(21, 21, 6, 6, OR, 2); d.ln(25, 25, 30, 30, OR, 2.6)


@ico("bedit")
def _(d):
    d.rect(4, 4, 11, 11, CY, 1.6, "#1B5E7E", 2); d.rect(17, 4, 11, 11, W, 1.4, None, 2); d.rect(4, 17, 11, 11, W, 1.4, None, 2)
    d.pl([(18, 27), (20, 21), (27, 14), (30, 17), (23, 24)], OR, 1.4, True, OR)


@ico("attdef")
def _(d):
    d.rect(3, 6, 26, 20, W, 1.6, None, 3); d.txt(11, 16, "A", CY, 13); d.ln(18, 12, 26, 12, OR, 1.8); d.ln(18, 17, 26, 17, OR, 1.8); d.ln(18, 22, 24, 22, OR, 1.8)


@ico("attedit")
def _(d):
    d.rect(3, 6, 22, 20, W, 1.6, None, 3); d.txt(10, 16, "A", CY, 12); d.pl([(16, 26), (18, 20), (26, 12), (29, 15), (21, 23)], OR, 1.4, True, OR)


@ico("apply")
def _(d):
    d.ell(16, 16, 12, 12, GR, 2.4); d.pl([(9, 16), (14, 21), (23, 11)], GR, 3)


# ----------------------------------------------------------------------------- ship structure
@ico("plate3d")
def _(d):
    d.pl([(3, 20), (17, 13), (29, 17), (15, 25)], W, 1.6, True, "#2E6FD0"); d.pl([(3, 20), (15, 25), (15, 28), (3, 23)], W, 1.4, True, "#1D4A8C")
    d.pl([(15, 25), (29, 17), (29, 20), (15, 28)], W, 1.4, True, "#255BA8"); d.txt(17, 9, "t", OR, 11)


@ico("platesurf")
def _(d):
    path = QPainterPath(); path.moveTo(3, 24); path.cubicTo(10, 14, 20, 14, 29, 20); path.lineTo(29, 24); path.cubicTo(20, 18, 10, 18, 3, 28); path.closeSubpath()
    d.pen(W, 1.4); d.p.setBrush(QColor("#2E6FD0")); d.p.drawPath(path); d.arrow(16, 16, 16, 6, OR, 1.6)


@ico("profile3d")
def _(d):
    d.pl([(4, 26), (4, 8), (8, 8), (8, 22), (16, 22), (16, 26)], OR, 1.8, True, "#5A4520")
    d.pl([(8, 8), (26, 2), (26, 16), (16, 22)], W, 1.2); d.pl([(16, 22), (30, 16), (30, 20), (16, 26)], W, 1.2); d.ln(4, 8, 22, 2, W, 1.2); d.ln(22, 2, 26, 2, W, 1.2)


@ico("platehole")
def _(d):
    d.pl([(3, 20), (17, 11), (29, 17), (15, 27)], W, 1.6, True, "#2E6FD0"); d.ell(16, 19, 6, 3.2, OR, 2, "#1E232B" if not _light else "#FFFFFF")


@ico("bracket")
def _(d):
    d.ln(4, 4, 4, 28, W, 3); d.ln(4, 28, 28, 28, W, 3); d.pl([(5, 9), (5, 27), (23, 27)], CY, 1.4, True, "#1B5E7E"); d.ln(5, 9, 23, 27, OR, 2.4)


@ico("matlist")
def _(d):
    d.rect(5, 3, 22, 26, W, 1.8, None, 3)
    for k, c in enumerate((CY, W, W, W)):
        d.dot(10, 9 + 6 * k, c, 1.6); d.ln(13, 9 + 6 * k, 23, 9 + 6 * k, c, 1.8)


@ico("framespacing")
def _(d):
    d.ln(3, 20, 29, 20, W, 1.6)
    for i, x in enumerate((5, 12, 19, 26)):
        d.ln(x, 20, x, 15, W, 1.4); d.ln(x, 12, x, 4, CY, 1)
    d.txt(5, 26, "0", OR, 6); d.txt(12, 26, "1", OR, 6); d.txt(19, 26, "2", OR, 6); d.txt(26, 26, "3", OR, 6)


@ico("dimstyle")
def _(d):
    d.ln(4, 10, 4, 22, W, 1.2); d.ln(28, 10, 28, 22, W, 1.2); d.arrow(16, 14, 5, 14, CY, 1.6); d.arrow(16, 14, 27, 14, CY, 1.6)
    d.rect(18, 18, 12, 11, OR, 1.4, r=2); d.ln(20, 21.5, 28, 21.5, OR, 1.2); d.ln(20, 25, 26, 25, OR, 1.2)


@ico("tcount")
def _(d):
    d.txt(9, 9, "1", OR, 9); d.txt(9, 18, "2", OR, 9); d.txt(9, 27, "3", OR, 9)
    for y in (9, 18, 27):
        d.ln(15, y, 28, y, W, 1.6)


@ico("tnumber")
def _(d):
    d.ell(11, 12, 7, 7, CY, 1.6); d.txt(11, 12, "1", W, 8); d.ell(22, 22, 7, 7, CY, 1.6); d.txt(22, 22, "2", W, 8)
    d.arrow(14, 17, 18, 20, OR, 1.4)


@ico("selsimilar")
def _(d):
    d.rect(3, 4, 10, 10, CY, 1.8); d.rect(19, 4, 10, 10, CY, 1.8, fill="#2EC5FF55"); d.rect(3, 18, 10, 10, CY, 1.8, fill="#2EC5FF55")
    d.ell(24, 23, 5, 5, W, 1.4)


@ico("revcloud")
def _(d):
    import math
    pts = [(8, 6), (16, 4), (24, 6), (28, 13), (27, 21), (21, 27), (12, 27), (5, 22), (4, 13)]
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2; r = math.hypot(b[0] - a[0], b[1] - a[1]) / 2
        d.ell(mx, my, r, r, OR, 1.5)
    d.ell(16, 16, 9, 9, "#00000000", 0.1, fill="#1C222B")


@ico("qdim")
def _(d):
    for x in (5, 13, 21, 28):
        d.ln(x, 6, x, 20, GY, 1.0)
    d.ln(5, 12, 28, 12, CY, 1.6); d.arrow(9, 12, 5, 12, CY, 1.4); d.arrow(24, 12, 28, 12, CY, 1.4)
    d.txt(16, 25, "QD", OR, 9)


@ico("cal")
def _(d):
    d.rect(6, 3, 20, 26, W, 1.6); d.rect(9, 6, 14, 6, CY, 1.4, fill="#2EC5FF55")
    for i in range(3):
        for j in range(3):
            d.dot(11 + i * 5, 16 + j * 4.5, OR if j == 2 and i == 2 else W, 1.5)


@ico("ltscale")
def _(d):
    d.ln(4, 8, 10, 8, W, 1.8); d.ln(14, 8, 20, 8, W, 1.8); d.ln(24, 8, 28, 8, W, 1.8)
    d.ln(4, 16, 14, 16, CY, 1.8); d.ln(19, 16, 28, 16, CY, 1.8)
    d.ln(4, 24, 18, 24, OR, 1.8); d.dot(22, 24, OR, 1.3); d.ln(25, 24, 28, 24, OR, 1.8)


@ico("dsettings")
def _(d):
    for i in range(4):
        d.ln(4 + i * 8, 4, 4 + i * 8, 28, GY, 0.8); d.ln(4, 4 + i * 8, 28, 4 + i * 8, GY, 0.8)
    d.dot(12, 12, OR, 3); d.dot(20, 20, OR, 3); d.ln(6, 26, 26, 6, CY, 1.6)


@ico("vports")
def _(d):
    d.rect(3, 4, 26, 24, W, 1.6, r=2); d.ln(16, 4, 16, 28, CY, 1.6); d.ln(3, 16, 29, 16, CY, 1.6)


@ico("pedit")
def _(d):
    d.ln(4, 26, 12, 10, W, 1.8); d.ln(12, 10, 22, 22, W, 1.8); d.ln(22, 22, 28, 6, W, 1.8)
    d.sq(12, 10); d.sq(22, 22); d.sq(17, 16, OR, 2.6)


@ico("paste")
def _(d):
    d.rect(6, 6, 16, 22, W, 1.6, r=2); d.rect(10, 3, 8, 5, OR, 1.6, r=1); d.rect(14, 13, 14, 15, CY, 1.6, fill="#1E232B", r=1)


@ico("boundary")
def _(d):
    d.rect(4, 4, 24, 24, W, 1.2); d.ell(16, 16, 6, 6, W, 1.2); d.rect(6, 6, 20, 20, OR, 2.0, r=1); d.dot(10, 22, CY, 2.5)


@ico("bom")
def _(d):
    d.rect(3, 4, 26, 24, W, 1.6)
    for y in (10, 16, 22):
        d.ln(3, y, 29, y, W, 1)
    d.ln(9, 4, 9, 28, W, 1); d.rect(3, 4, 26, 6, OR, 1.2, "#5A4520"); d.txt(19, 7, "BOM", W, 6)


@ico("colorthk")
def _(d):
    for k, c in enumerate(("#2E73F2", "#1ACCD9", "#FACC33", "#F24D40")):
        d.rect(4 + k * 6.5, 6, 6, 20, c, 1, c)
    d.rect(4, 6, 26, 20, W, 1.4)


@ico("flatten")
def _(d):
    d.pl([(3, 12), (13, 6), (13, 16), (3, 22)], W, 1.4, True, "#2E6FD0"); d.arrow(15, 14, 21, 14, OR, 1.6); d.rect(22, 8, 8, 14, CY, 1.6)


@ico("detail")
def _(d):
    d.ln(4, 4, 4, 28, W, 3); d.ln(4, 28, 28, 28, W, 3); d.pl([(5, 12), (5, 27), (20, 27)], CY, 1.4, True, "#1B5E7E"); d.circ(22, 9, 6, OR, 1.6); d.txt(22, 10, "D", OR, 8)


@ico("slot")
def _(d):
    d.rect(3, 4, 26, 24, W, 1.4, "#2E3D52"); d.pl([(12, 28), (12, 12), (16, 9), (20, 12), (20, 28)], OR, 1.8, True, "#1E232B" if not _light else "#FFFFFF")
    d.rect(15, 14, 2.6, 14, CY, 1, CY)


@ico("scallop")
def _(d):
    d.ln(3, 26, 29, 26, W, 2.4); d.ln(16, 4, 16, 18, W, 2.4); d.arc(16, 26, 7, 0, 180, OR, 2.2)


@ico("snipe")
def _(d):
    d.pl([(3, 26), (3, 12), (18, 12), (26, 26)], W, 1.8, True, "#2E3D52"); d.txt(22, 9, "30°", OR, 8)


# ----------------------------------------------------------------------------- piping / electrical
@ico("symlib")
def _(d):
    d.rect(3, 3, 12, 12, W, 1.4, None, 2); d.rect(17, 3, 12, 12, W, 1.4, None, 2); d.rect(3, 17, 12, 12, W, 1.4, None, 2); d.rect(17, 17, 12, 12, CY, 1.4, None, 2)
    d.pl([(5, 6), (5, 12), (9, 9)], CY, 1.2, True); d.pl([(13, 6), (13, 12), (9, 9)], CY, 1.2, True); d.circ(23, 9, 3.5, OR, 1.4); d.ln(20, 23, 26, 23, GR, 1.6); d.dot(9, 23, W, 2)


@ico("sym_elec")
def _(d):
    d.circ(16, 16, 11, W, 1.8); d.pl([(18, 4), (10, 17), (16, 17), (13, 28), (22, 13), (16, 13), (19, 4)], OR, 1.2, True, OR)


@ico("sym_pipe")
def _(d):
    d.ln(2, 16, 5, 16, W, 2); d.ln(27, 16, 30, 16, W, 2); _bowtie(d, 16, 16, CY); d.ln(16, 16, 16, 6, W, 1.8); d.ln(11, 6, 21, 6, W, 2)


@ico("pipe3d")
def _(d):
    d.cyl(9, 4, 5, 12, W, "#7A8BA0"); d.p.save(); d.pen(W, 1.4); d.p.setBrush(QColor("#7A8BA0"))
    path = QPainterPath(); path.moveTo(4, 16); path.cubicTo(4, 27, 9, 27, 18, 27); path.lineTo(18, 17); path.cubicTo(14, 17, 14, 17, 14, 16); path.closeSubpath(); d.p.drawPath(path); d.p.restore()
    d.ell(22, 22, 3, 5, W, 1.4, "#9FB0C6"); d.rect(20, 17, 9, 10, W, 1.2, "#7A8BA0")


@ico("fitting")
def _(d):
    d.rect(2, 11, 6, 10, W, 1.4, "#7A8BA0"); d.rect(24, 11, 6, 10, W, 1.4, "#7A8BA0"); _bowtie(d, 16, 16, W, "#3E7BD6"); d.ln(16, 16, 16, 5, W, 2); d.ell(16, 5, 7, 2, OR, 1.8)


@ico("flange")
def _(d):
    d.ell(16, 16, 7, 13, W, 1.8, "#7A8BA0")
    for k in range(6):
        a = k * math.pi / 3 + 0.5; d.dot(16 + 4 * math.cos(a), 16 + 9.5 * math.sin(a), "#1E232B", 1.3)
    d.ell(16, 16, 3, 5.5, W, 1.4, "#1E232B" if not _light else "#FFFFFF")


@ico("tray")
def _(d):
    d.pl([(3, 12), (3, 22), (21, 28), (21, 18)], W, 1.4, True, "#6E7E92"); d.pl([(21, 18), (21, 28), (29, 22), (29, 12)], W, 1.4, True, "#8C9DB2")
    d.pl([(3, 12), (11, 7), (29, 12)], W, 1.2); d.ln(7, 17, 25, 17, OR, 1.4); d.ln(8, 20, 25, 20, CY, 1.4)


@ico("conduit")
def _(d):
    path = QPainterPath(); path.moveTo(3, 24); path.cubicTo(12, 24, 14, 8, 29, 8); d.pen("#9FB0C6", 5); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path); d.pen(OR, 1.4); d.p.drawPath(path)


@ico("equip")
def _(d):
    d.cube(16, 15, 10, W, "#6E7E92"); d.dot(19, 18, GR, 1.6); d.dot(22, 16, RD, 1.6)


@ico("panel")
def _(d):
    d.rect(6, 3, 20, 26, W, 1.8, "#2E3D52", 2); d.ln(16, 3, 16, 29, W, 1.2)
    for y in (8, 13, 18):
        d.dot(11, y, GR, 1.4); d.dot(21, y, OR, 1.4)


# ----------------------------------------------------------------------------- CAM
@ico("camcut")
def _(d):
    d.rect(4, 14, 24, 14, W, 1.6, "#3A4352"); d.pl([(16, 3), (13, 9), (19, 9)], OR, 1, True, OR); d.ln(16, 9, 16, 14, OR, 2)
    d.pl([(8, 20), (14, 20), (14, 24), (22, 24)], CY, 1.6, False, None, True)


@ico("nest")
def _(d):
    d.rect(3, 4, 26, 24, W, 1.6); d.rect(5, 6, 10, 8, CY, 1.4, "#1B5E7E"); d.rect(17, 6, 10, 12, GR, 1.4, "#1F5A44"); d.circ(10, 21, 4.5, OR, 1.4, "#5A4520"); d.rect(17, 20, 10, 6, PU, 1.4, "#3E2D66")


@ico("camsim")
def _(d):
    d.circ(16, 16, 12, W, 1.8); d.pl([(13, 10), (13, 22), (23, 16)], GR, 1, True, GR)


@ico("gcode")
def _(d):
    d.pl([(6, 3), (20, 3), (26, 9), (26, 29), (6, 29)], W, 1.6, True); d.txt(16, 15, "G", OR, 11); d.txt(16, 24, "CODE", CY, 6)


# ----------------------------------------------------------------------------- view
def _view_cube(d, face):
    a = 9 * 0.87; b = 4.5; x, y, s = 16, 16, 9
    top = [(x, y - s), (x + a, y - b), (x, y), (x - a, y - b)]
    left = [(x - a, y - b), (x, y), (x, y + s), (x - a, y + b)]
    right = [(x, y), (x + a, y - b), (x + a, y + b), (x, y + s)]
    for nm, poly in (("top", top), ("front", left), ("right", right)):
        d.pl(poly, W, 1.5, True, CY if nm == face else "#3A4352")


for _f in ("top", "front", "right"):
    DRAW["view_" + _f] = (lambda f: (lambda d: _view_cube(d, f)))(_f)


@ico("view_iso")
def _(d):
    d.cube(16, 16, 10, W, "#2E64B0")


@ico("view_bottom")
def _(d):
    d.cube(16, 16, 10, W); d.pl([(16, 26), (7.3, 21), (16, 16), (24.7, 21)], W, 1, True, CY)


@ico("view_back")
def _(d):
    d.cube(16, 16, 10, W); d.txt(16, 16, "B", CY, 10)


@ico("view_left")
def _(d):
    d.cube(16, 16, 10, W); d.txt(16, 16, "L", CY, 10)


@ico("orbit")
def _(d):
    d.circ(16, 16, 4, CY, 2); d.ell(16, 16, 13, 6, W, 1.8); d.ell(16, 16, 6, 13, W, 1.8); d.dot(29, 16, OR, 2.2)


@ico("pan")
def _(d):
    path = QPainterPath(); path.moveTo(11, 27); path.lineTo(7, 17); path.cubicTo(6, 14, 9, 13, 10, 15); path.lineTo(11, 7); path.cubicTo(11, 4, 15, 4, 15, 7)
    path.lineTo(15, 5); path.cubicTo(15, 2, 19, 2, 19, 5); path.lineTo(19, 7); path.cubicTo(19, 4, 23, 4, 23, 8); path.lineTo(23, 20); path.cubicTo(23, 25, 20, 27, 18, 27); path.closeSubpath()
    d.pen(W, 1.6); d.p.setBrush(QColor("#3A4352")); d.p.drawPath(path)


@ico("zoomext")
def _(d):
    d.circ(13, 13, 8, W, 2.2); d.ln(19, 19, 28, 28, W, 3.2); d.rect(9, 9, 8, 8, CY, 1.6)


@ico("zoomwin")
def _(d):
    d.circ(13, 13, 8, W, 2.2); d.ln(19, 19, 28, 28, W, 3.2); d.ln(9, 13, 17, 13, CY, 2); d.ln(13, 9, 13, 17, CY, 2)


@ico("wire")
def _(d):
    d.cube(16, 16, 11, CY)


@ico("shaded")
def _(d):
    d.cube(16, 16, 11, "#B9C7D8", "#4C8DFF", 1)


@ico("shadededges")
def _(d):
    d.cube(16, 16, 11, W, "#4C8DFF", 2)


@ico("xray")
def _(d):
    d.cube(16, 16, 11, CY, None, 1.4); d.p.setOpacity(0.35); d.cube(16, 16, 11, CY, "#4C8DFF", 1); d.p.setOpacity(1)


@ico("persp")
def _(d):
    d.pl([(4, 8), (28, 3), (28, 29), (4, 24)], W, 1.8, True); d.pl([(10, 12), (22, 10), (22, 22), (10, 20)], CY, 1.6, True)


@ico("ucs")
def _(d):
    d.arrow(6, 26, 27, 26, RD, 2.2); d.arrow(6, 26, 6, 5, GR, 2.2); d.arrow(6, 26, 17, 15, BL, 2.2)


@ico("ucs3p")
def _(d):
    DRAW["ucs"](d); d.sq(27, 26, OR); d.sq(6, 5, OR); d.sq(6, 26, OR)


@ico("ucsview")
def _(d):
    d.rect(3, 4, 26, 24, W, 1.4, None, 3); d.arrow(8, 24, 22, 24, RD, 2); d.arrow(8, 24, 8, 9, GR, 2)


@ico("ucsworld")
def _(d):
    d.circ(16, 16, 12, W, 1.6); d.ell(16, 16, 5, 12, W, 1.2); d.ln(4, 16, 28, 16, W, 1.2); d.arrow(16, 16, 27, 16, RD, 2); d.arrow(16, 16, 16, 5, GR, 2)


@ico("plan")
def _(d):
    d.rect(4, 4, 24, 24, W, 1.6); d.arrow(16, 16, 16, 8, CY, 2); d.dot(16, 16, OR, 3)


@ico("layers")
def _(d):
    for k, c in enumerate((CY, GR, OR)):
        y = 22 - k * 6
        d.pl([(4, y), (16, y - 5), (28, y), (16, y + 5)], W, 1.4, True, QColor(c).darker(150).name())


@ico("props")
def _(d):
    d.rect(4, 4, 24, 24, W, 1.6, None, 3)
    for k in range(4):
        d.ln(8, 9 + k * 5, 14, 9 + k * 5, CY, 1.6); d.ln(17, 9 + k * 5, 24, 9 + k * 5, W, 1.6)


@ico("grid")
def _(d):
    for k in range(5):
        d.ln(4 + k * 6, 4, 4 + k * 6, 28, GY, 1); d.ln(4, 4 + k * 6, 28, 4 + k * 6, GY, 1)
    d.dot(16, 16, CY, 2.4)


@ico("regen")
def _(d):
    d.arc(16, 16, 11, 40, 300, GR, 2.4); d.pl([(27, 6), (28, 14), (20, 12)], GR, 1, True, GR)


# ----------------------------------------------------------------------------- inquiry / blocks
@ico("dist")
def _(d):
    d.rect(3, 12, 26, 9, W, 1.6, "#3A4352", 2)
    for k in range(7):
        d.ln(6 + k * 3.5, 12, 6 + k * 3.5, 16 if k % 2 else 18, W, 1.2)


@ico("area")
def _(d):
    d.pl([(4, 24), (8, 6), (26, 9), (28, 26)], CY, 2, True, "#1B5E7E"); d.txt(16, 17, "m²", W, 9)


@ico("id")
def _(d):
    d.ln(16, 4, 16, 28, GY, 1); d.ln(4, 16, 28, 16, GY, 1); d.sq(16, 16, OR, 4); d.txt(24, 8, "xyz", CY, 7)


@ico("list")
def _(d):
    d.rect(5, 3, 22, 26, W, 1.6, None, 3); d.txt(16, 11, "i", CY, 12); d.ln(10, 18, 22, 18, W, 1.4); d.ln(10, 23, 22, 23, W, 1.4)


@ico("massprop")
def _(d):
    d.cube(12, 15, 8, W, "#3E7BD6"); d.txt(24, 25, "kg", OR, 9)


@ico("block")
def _(d):
    d.rect(4, 4, 24, 24, CY, 1.4, None, 3); d.circ(13, 13, 5, W, 1.6); d.rect(15, 15, 9, 9, W, 1.6)


@ico("insert")
def _(d):
    d.rect(10, 4, 18, 18, CY, 1.4, None, 3); d.circ(17, 11, 3.5, W, 1.4); d.arrow(3, 29, 13, 19, OR, 2)


@ico("select")
def _(d):
    d.pl([(8, 4), (8, 24), (13, 19), (17, 28), (20, 27), (16, 18), (23, 18)], W, 1.6, True, "#3A4352")


@ico("selectall")
def _(d):
    d.rect(3, 3, 26, 26, CY, 1.4, None); d.p.setOpacity(0.5); d.rect(3, 3, 26, 26, CY, 1, "#1B5E7E"); d.p.setOpacity(1); d.txt(16, 16, "ALL", W, 8)


@ico("osnap")
def _(d):
    d.rect(9, 9, 14, 14, GR, 2.2); d.ln(16, 2, 16, 30, W, 1); d.ln(2, 16, 30, 16, W, 1)


_cache = {}


def icon(name, size=32):
    key = (name, size, _light)
    if key in _cache:
        return _cache[key]
    ic = QIcon()
    for s in (16, 24, 32, 48, 64):
        pm = QPixmap(s, s); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing); p.scale(s / 32, s / 32)
        fn = DRAW.get(name)
        if fn is None:
            P(p).txt(16, 16, name[:2].upper(), CY, 11)
        else:
            try:
                fn(P(p))
            except Exception:
                P(p).txt(16, 16, name[:2].upper(), RD, 11)
        p.end()
        ic.addPixmap(pm)
    _cache[key] = ic
    return ic


def pixmap(name, size=32):
    return icon(name).pixmap(size, size)


# ----------------------------------------------------------------------------- redraw (raster / pdf)
@ico("image")
def _(d):
    d.rect(3, 5, 26, 22, W, 1.8, "#2D3C50", 3); d.pl([(5, 25), (12, 14), (18, 21), (22, 16), (28, 25)], GR, 1.8, True, "#1F5A44"); d.dot(22, 11, OR, 3)


@ico("pdfimport")
def _(d):
    d.pl([(6, 3), (20, 3), (26, 9), (26, 29), (6, 29)], W, 1.6, True); d.rect(3, 14, 18, 9, RD, 1, RD, 2); d.txt(12, 18.5, "PDF", W, 7)
    d.arrow(22, 20, 30, 20, CY, 1.6)


@ico("calibrate")
def _(d):
    d.rect(3, 5, 26, 22, GY, 1.4, None, 3); d.sq(7, 22, OR); d.sq(25, 10, OR); d.ln(7, 22, 25, 10, CY, 1.6, True); d.txt(15, 25, "1:1", W, 7)


@ico("deskew")
def _(d):
    d.pl([(5, 9), (25, 4), (28, 22), (8, 27)], GY, 1.4, True); d.ln(4, 26, 28, 26, OR, 2); d.arc(8, 26, 10, 0, 22, CY, 1.6)


@ico("autotrace")
def _(d):
    d.rect(3, 5, 26, 22, GY, 1.2, "#2D3C50", 3)
    path = QPainterPath(); path.moveTo(6, 22); path.cubicTo(10, 8, 18, 26, 26, 9); d.pen("#5B6B80", 4); d.p.setBrush(Qt.NoBrush); d.p.drawPath(path)
    d.pen(CY, 1.6); d.p.drawPath(path); d.sq(6, 22, OR, 2.4); d.sq(26, 9, OR, 2.4); d.txt(24, 26, "AI", GR, 7)


@ico("imagefade")
def _(d):
    d.rect(3, 5, 26, 22, W, 1.6, None, 3); d.p.setOpacity(0.4); d.rect(3, 5, 13, 22, W, 1, "#E8EEF6", 0); d.p.setOpacity(1)


@ico("imgsnap")
def _(d):
    d.rect(3, 5, 26, 22, GY, 1.2, "#2D3C50", 3); d.ln(6, 22, 26, 10, "#5B6B80", 3.5); d.rect(12, 12, 8, 8, GR, 2)


@ico("csvimport")
def _(d):
    d.rect(4, 4, 18, 22, W, 1.6, None, 2)
    for y in (10, 15, 20):
        d.ln(4, y, 22, y, W, 1)
    d.ln(12, 4, 12, 26, W, 1); d.pl([(16, 28), (22, 18), (29, 22)], CY, 2); d.dot(16, 28, OR, 1.8); d.dot(22, 18, OR, 1.8); d.dot(29, 22, OR, 1.8)


@ico("align")
def _(d):
    d.rect(3, 14, 10, 10, GY, 1.4); d.pl([(18, 10), (26, 4), (30, 10), (22, 16)], W, 1.6, True); d.arrow(8, 12, 19, 6, OR, 1.4); d.arrow(12, 20, 24, 14, OR, 1.4)


@ico("imageclip")
def _(d):
    d.rect(3, 5, 26, 22, GY, 1.2, None, 3); d.rect(8, 9, 16, 14, OR, 1.8, None); d.ln(4, 28, 12, 20, W, 2); d.ln(12, 28, 4, 20, W, 2)
