"""Colours and Qt style sheet (modern dark theme, light theme optional)."""

ACCENT = "#2EC5FF"
ACCENT2 = "#7B5CFF"
GOLD = "#F5B841"

DARK = {
    "bg": "#1E232B", "bg2": "#252B35", "bg3": "#2D3440", "panel": "#232933", "line": "#3A4352", "text": "#E6EBF2",
    "muted": "#9AA6B6", "hover": "#34404F", "press": "#1B5E7E", "accent": ACCENT, "view_top": (0.13, 0.15, 0.19),
    "view_bot": (0.20, 0.23, 0.28), "grid": (0.30, 0.34, 0.40), "grid_major": (0.38, 0.43, 0.51), "fg": (1, 1, 1),
}
LIGHT = {
    "bg": "#F3F5F8", "bg2": "#FFFFFF", "bg3": "#E7EBF0", "panel": "#FBFCFD", "line": "#CBD3DD", "text": "#1E2733",
    "muted": "#5B6878", "hover": "#DCE6F2", "press": "#BFE6F7", "accent": "#0A84C6", "view_top": (0.97, 0.98, 1.0),
    "view_bot": (0.88, 0.90, 0.93), "grid": (0.82, 0.85, 0.89), "grid_major": (0.70, 0.74, 0.80), "fg": (0, 0, 0),
}


def stylesheet(t):
    return f"""
QWidget {{ background: {t['bg']}; color: {t['text']}; font-family: 'Segoe UI', 'Noto Sans', 'DejaVu Sans'; font-size: 9pt; }}
QMainWindow::separator {{ background: {t['line']}; width: 3px; height: 3px; }}
QToolTip {{ background: {t['bg3']}; color: {t['text']}; border: 1px solid {t['accent']}; padding: 4px; }}
QMenu {{ background: {t['bg2']}; border: 1px solid {t['line']}; padding: 4px; }}
QMenu::item {{ padding: 5px 26px 5px 26px; border-radius: 4px; }}
QMenu::item:selected {{ background: {t['hover']}; }}
QMenu::separator {{ height: 1px; background: {t['line']}; margin: 4px 8px; }}
QDockWidget {{ titlebar-close-icon: none; font-weight: 600; }}
QDockWidget::title {{ background: {t['bg3']}; padding: 5px 8px; border-bottom: 1px solid {t['line']}; }}
QTabWidget::pane {{ border: 1px solid {t['line']}; border-radius: 4px; top: -1px; }}
QTabBar::tab {{ background: transparent; padding: 6px 12px; border: none; color: {t['muted']}; }}
QTabBar::tab:selected {{ color: {t['text']}; border-bottom: 2px solid {t['accent']}; }}
QTabBar::tab:hover {{ color: {t['text']}; }}
QTabBar#doctabs::tab {{ padding: 5px 10px 5px 12px; margin-right: 1px; border-top-left-radius: 5px; border-top-right-radius: 5px; min-width: 90px; max-width: 260px; }}
QTabBar#doctabs::tab:selected {{ background: {t.get('panel', '#1B222C')}; color: {t['text']}; border-bottom: 2px solid {t['accent']}; font-weight: 600; }}
QPushButton {{ background: {t['bg3']}; border: 1px solid {t['line']}; border-radius: 5px; padding: 5px 14px; }}
QPushButton:hover {{ background: {t['hover']}; border-color: {t['accent']}; }}
QPushButton:pressed {{ background: {t['press']}; }}
QPushButton:default {{ border: 1px solid {t['accent']}; }}
QPushButton#primary {{ background: {t['accent']}; color: #0B1520; font-weight: 600; border: none; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit, QTextEdit {{ background: {t['bg2']}; border: 1px solid {t['line']};
    border-radius: 4px; padding: 3px 6px; selection-background-color: {t['accent']}; selection-color: #0B1520; }}
QAbstractSpinBox QLineEdit, QComboBox QLineEdit {{ border: none; padding: 0px; margin: 0px; background: transparent; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{ border-color: {t['accent']}; }}
QComboBox::drop-down {{ border: none; width: 18px; }}
QComboBox QAbstractItemView {{ background: {t['bg2']}; border: 1px solid {t['line']}; selection-background-color: {t['hover']}; }}
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{ width: 0; border: none; }}
QHeaderView::section {{ background: {t['bg3']}; color: {t['muted']}; border: none; border-right: 1px solid {t['line']}; padding: 4px 6px; font-weight: 600; }}
QTableWidget, QTreeWidget, QListWidget, QTableView {{ background: {t['bg2']}; alternate-background-color: {t['panel']}; border: 1px solid {t['line']};
    gridline-color: {t['line']}; selection-background-color: {t['hover']}; selection-color: {t['text']}; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {t['line']}; border-radius: 4px; min-height: 30px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0; }}
QScrollBar::handle:horizontal {{ background: {t['line']}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QGroupBox {{ border: 1px solid {t['line']}; border-radius: 6px; margin-top: 14px; padding-top: 6px; font-weight: 600; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {t['accent']}; }}
QCheckBox::indicator, QRadioButton::indicator {{ width: 14px; height: 14px; }}
QStatusBar {{ background: {t['bg3']}; border-top: 1px solid {t['line']}; }}
QStatusBar QLabel {{ background: transparent; color: {t['muted']}; padding: 0 6px; }}
QToolButton#status {{ background: transparent; border: 1px solid transparent; border-radius: 4px; padding: 2px 7px; color: {t['muted']}; font-weight: 600; font-size: 8pt; }}
QToolButton#status:checked {{ color: {t['accent']}; background: {t['hover']}; border-color: {t['line']}; }}
QToolButton#status:hover {{ border-color: {t['accent']}; }}
/* ribbon */
QWidget#ribbon {{ background: {t['bg3']}; }}
QWidget#ribbonTop {{ background: {t['bg']}; }}
QWidget#ribbonBody {{ background: {t['bg2']}; border-top: 1px solid {t['line']}; border-bottom: 1px solid {t['line']}; }}
QFrame#rpanel {{ background: transparent; border-right: 1px solid {t['line']}; }}
QLabel#rpanelTitle {{ color: {t['muted']}; font-size: 8pt; background: transparent; }}
QToolButton#rbig, QToolButton#rsmall, QToolButton#qat {{ background: transparent; border: 1px solid transparent; border-radius: 5px; }}
QToolButton#rbig {{ padding: 2px 3px; font-size: 8pt; }}
QToolButton#rsmall {{ padding: 1px 4px; text-align: left; font-size: 8pt; }}
QToolButton#rbig:hover, QToolButton#rsmall:hover, QToolButton#qat:hover {{ background: {t['hover']}; border-color: {t['line']}; }}
QToolButton#rbig:pressed, QToolButton#rsmall:pressed, QToolButton#rbig:checked, QToolButton#rsmall:checked {{ background: {t['press']}; }}
QToolButton#rtab {{ background: transparent; border: none; padding: 6px 9px 5px 9px; color: {t['muted']}; font-weight: 600; }}
QToolButton#rtab:checked {{ color: {t['text']}; border-bottom: 3px solid {t['accent']}; }}
QToolButton#rtab:hover {{ color: {t['text']}; }}
QToolButton#appbtn {{ background: transparent; border: none; }}
QToolButton#cmdopt {{ background: {t['hover']}; border: 1px solid {t['line']}; border-radius: 4px; padding: 1px 7px; color: {t['accent']}; font-weight: 600; }}
QToolButton#cmdopt:hover {{ border-color: {t['accent']}; background: {t['bg3']}; }}
QWidget#palette_title {{ background: {t['bg3']}; border-bottom: 1px solid {t['line']}; }}
QLabel#palette_title_label {{ font-weight: 600; background: transparent; }}
QToolButton#palette_btn {{ background: transparent; border: none; border-radius: 3px; padding: 2px; }}
QToolButton#palette_btn:hover {{ background: {t['hover']}; }}
QToolBar#autohide_left, QToolBar#autohide_right {{ background: {t['bg2']}; border: none; spacing: 2px; padding: 2px 0px; }}
QLineEdit#cmdline {{ background: {t['bg2']}; border: 1px solid {t['line']}; border-radius: 6px; padding: 5px 8px; }}
QPlainTextEdit#cmdhist {{ background: {t['bg']}; border: none; color: {t['muted']}; }}
QLabel#cmdprompt {{ color: {t['accent']}; background: transparent; }}
"""
