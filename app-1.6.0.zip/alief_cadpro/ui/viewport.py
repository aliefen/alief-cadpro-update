"""OpenGL viewport: camera, light renderer (VBO batches), picking, OSNAP, grips, ViewCube, UCS icon, overlays."""
import math
import time
import numpy as np
from PySide6.QtCore import Qt, QPoint, QPointF, QRectF, QTimer, Signal
from PySide6.QtGui import QPainter, QColor, QPen, QFont, QPolygonF, QBrush, QSurfaceFormat, QCursor, QImage
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL import GL as gl
from ..core.geom import unit, norm, Plane, prim_tess, prim_closest, prim_intersect, prim_len, arc_pt, v3, EPS, TAU, bulge_arc
from ..core.aci import aci_rgb
from ..core.document import LINETYPES
from ..core import entities as E

SNAP_KINDS = ["end", "mid", "cen", "quad", "int", "perp", "tan", "near", "node", "ins", "img"]
SNAP_LABEL = {"end": "Endpoint", "mid": "Midpoint", "cen": "Center", "quad": "Quadrant", "int": "Intersection", "perp": "Perpendicular",
              "tan": "Tangent", "near": "Nearest", "node": "Node", "ins": "Insertion", "img": "Image line", "grid": "Grid"}


_hud_cache = {}


def hud_text(p, where, a=None, b=None):
    """drawText for the overlay of the GL viewport: hud_text(p, QPointF, text) or hud_text(p, QRectF, flags, text).
    The string is rendered once into an image by the software rasteriser and drawn as a picture, so it never depends on
    the OpenGL glyph cache (which shows garbled letters on some graphics drivers)."""
    from PySide6.QtGui import QFontMetricsF
    text = b if b is not None else a
    if not text:
        return
    f = p.font(); col = p.pen().color(); dpr = max(1.0, float(p.device().devicePixelRatioF()))
    key = (text, f.key(), col.rgba(), round(dpr, 2))
    it = _hud_cache.get(key)
    if it is None:
        fm = QFontMetricsF(f)
        lines = str(text).split("\n")
        w = max(fm.horizontalAdvance(l) for l in lines) + 4; h = fm.lineSpacing() * len(lines) + 2
        img = QImage(max(1, int(math.ceil(w * dpr))), max(1, int(math.ceil(h * dpr))), QImage.Format_ARGB32_Premultiplied)
        img.setDevicePixelRatio(dpr); img.fill(0)
        q = QPainter(img); q.setRenderHint(QPainter.Antialiasing); q.setRenderHint(QPainter.TextAntialiasing)
        q.setFont(f); q.setPen(col)
        for i, l in enumerate(lines):
            q.drawText(QPointF(2, 1 + fm.ascent() + i * fm.lineSpacing()), l)
        q.end()
        if len(_hud_cache) > 600:
            _hud_cache.clear()
        it = (img, w, h, fm.ascent()); _hud_cache[key] = it
    img, w, h, asc = it
    if isinstance(where, QRectF):
        _v = lambda q: q.value if hasattr(q, "value") else int(q)
        fl = _v(a) if a is not None and b is not None else 0
        x = where.left() - 2
        if fl & _v(Qt.AlignHCenter):
            x = where.center().x() - w / 2
        elif fl & _v(Qt.AlignRight):
            x = where.right() - w + 2
        y = where.top()
        if fl & _v(Qt.AlignVCenter):
            y = where.center().y() - h / 2
        elif fl & _v(Qt.AlignBottom):
            y = where.bottom() - h
        p.drawImage(QPointF(x, y), img)
    else:
        p.drawImage(QPointF(where.x() - 2, where.y() - asc - 1), img)


def default_format():
    f = QSurfaceFormat()
    f.setRenderableType(QSurfaceFormat.OpenGL); f.setProfile(QSurfaceFormat.CompatibilityProfile); f.setVersion(2, 1)
    f.setDepthBufferSize(24); f.setStencilBufferSize(8); f.setSamples(4)
    return f


def quat_from_R(R):
    t = np.trace(R)
    if t > 0:
        s = math.sqrt(t + 1) * 2; return np.array([0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s])
    i = int(np.argmax(np.diag(R)))
    if i == 0:
        s = math.sqrt(1 + R[0, 0] - R[1, 1] - R[2, 2]) * 2; return np.array([(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s])
    if i == 1:
        s = math.sqrt(1 + R[1, 1] - R[0, 0] - R[2, 2]) * 2; return np.array([(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s])
    s = math.sqrt(1 + R[2, 2] - R[0, 0] - R[1, 1]) * 2; return np.array([(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s])


def R_from_quat(q):
    w, x, y, z = q / np.linalg.norm(q)
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def slerp(a, b, t):
    d = np.dot(a, b)
    if d < 0:
        b = -b; d = -d
    if d > 0.9995:
        r = a + t * (b - a); return r / np.linalg.norm(r)
    th = math.acos(d); return (math.sin((1 - t) * th) * a + math.sin(t * th) * b) / math.sin(th)


VIEWS = {   # name: (back(eye) direction, up)
    "top": ((0, 0, 1), (0, 1, 0)), "bottom": ((0, 0, -1), (0, 1, 0)), "front": ((0, -1, 0), (0, 0, 1)), "back": ((0, 1, 0), (0, 0, 1)),
    "left": ((-1, 0, 0), (0, 0, 1)), "right": ((1, 0, 0), (0, 0, 1)), "swiso": ((-1, -1, 1), (0, 0, 1)), "seiso": ((1, -1, 1), (0, 0, 1)),
    "neiso": ((1, 1, 1), (0, 0, 1)), "nwiso": ((-1, 1, 1), (0, 0, 1)),
}


def R_view(back, up):
    b = unit(np.array(back, float)); u = np.array(up, float); u = unit(u - np.dot(u, b) * b)
    r = np.cross(u, b)
    return np.stack([r, u, b], axis=1)


class Camera:
    def __init__(self):
        self.target = np.zeros(3); self.R = np.eye(3); self.h = 300.0; self.persp = False; self.fov = 40.0
        self.W = 800; self.H = 600; self.radius = 1000.0

    def right(self):
        return self.R[:, 0]

    def up(self):
        return self.R[:, 1]

    def back(self):
        return self.R[:, 2]

    def dist(self):
        return self.h / (2 * math.tan(math.radians(self.fov) / 2))

    def eye(self):
        return self.target + self.back() * self.dist()

    def view(self):
        e = self.eye() if self.persp else self.target
        M = np.eye(4); M[:3, :3] = self.R.T; M[:3, 3] = -self.R.T @ e
        return M

    def proj(self):
        a = self.W / max(1, self.H)
        if self.persp:
            d = self.dist(); n = max(d * 0.002, 1e-3); f = d + self.radius * 4 + 10
            t = n * math.tan(math.radians(self.fov) / 2); r = t * a
            return np.array([[n / r, 0, 0, 0], [0, n / t, 0, 0], [0, 0, -(f + n) / (f - n), -2 * f * n / (f - n)], [0, 0, -1, 0]])
        hh = self.h / 2; ww = hh * a; D = max(self.radius * 4, self.h * 4, 10.0)
        n, f = -D, D
        return np.array([[1 / ww, 0, 0, 0], [0, 1 / hh, 0, 0], [0, 0, -2 / (f - n), -(f + n) / (f - n)], [0, 0, 0, 1]])

    def mvp(self):
        return self.proj() @ self.view()

    def key(self):
        return (tuple(np.round(self.target, 9)), tuple(np.round(self.R.ravel(), 9)), round(self.h, 9), self.persp, self.W, self.H)

    def project(self, P):
        P = np.asarray(P, float)
        M = self.mvp()
        c = P @ M[:3, :3].T + M[:3, 3]
        w = P @ M[3, :3] + M[3, 3]
        w = np.where(np.abs(w) < 1e-12, 1e-12, w)
        x = (c[..., 0] / w + 1) * 0.5 * self.W; y = (1 - c[..., 1] / w) * 0.5 * self.H; z = c[..., 2] / w
        return np.stack([x, y], axis=-1), z

    def ray(self, x, y):
        nx = 2 * x / self.W - 1; ny = 1 - 2 * y / self.H
        a = self.W / max(1, self.H)
        if self.persp:
            t = math.tan(math.radians(self.fov) / 2)
            d = unit(-self.back() + self.right() * nx * t * a + self.up() * ny * t)
            return self.eye(), d
        p = self.target + self.right() * nx * self.h / 2 * a + self.up() * ny * self.h / 2
        return p + self.back() * self.radius * 4, -self.back()

    def px(self):
        return self.h / max(1, self.H)

    def screen_to_plane(self, x, y, pl):
        ro, rd = self.ray(x, y)
        q = pl.ray_hit(ro, rd)
        if q is None:   # view edge-on: project on view plane through target
            q = Plane(self.target, self.right(), self.up()).ray_hit(ro, rd)
        return q


def resolve_rgb(c, light_bg):
    if isinstance(c, str) and c.startswith("#"):
        return int(c[1:3], 16) / 255, int(c[3:5], 16) / 255, int(c[5:7], 16) / 255
    c = int(c) if c is not None else 7
    if c in (7, 0, 256):
        return (0.05, 0.05, 0.05) if light_bg else (1, 1, 1)
    return aci_rgb(c)


class Batch:
    """GPU buffers of one group (lines or triangles)."""
    def __init__(self, mode, V, C, N=None, width=1.0, stipple=None):
        self.mode = mode; self.n = len(V); self.width = width; self.stipple = stipple
        self.bufs = []
        self.V = np.ascontiguousarray(V, np.float32); self.C = np.ascontiguousarray(C, np.float32)
        self.N = None if N is None else np.ascontiguousarray(N, np.float32)
        self.vbo = None

    def upload(self):
        if self.vbo is not None or self.n == 0:
            return
        ids = gl.glGenBuffers(3 if self.N is not None else 2)
        ids = list(ids) if hasattr(ids, "__len__") else [ids]
        self.vbo = ids
        for buf, arr in zip(ids, (self.V, self.C, self.N)):
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, buf); gl.glBufferData(gl.GL_ARRAY_BUFFER, arr.nbytes, arr, gl.GL_STATIC_DRAW)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)

    def draw(self, color_override=None, alpha=None):
        if self.n == 0:
            return
        self.upload()
        gl.glEnableClientState(gl.GL_VERTEX_ARRAY)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo[0]); gl.glVertexPointer(3, gl.GL_FLOAT, 0, None)
        if color_override is None:
            gl.glEnableClientState(gl.GL_COLOR_ARRAY)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo[1]); gl.glColorPointer(4, gl.GL_FLOAT, 0, None)
        else:
            gl.glColor4f(*color_override)
        if self.N is not None:
            gl.glEnableClientState(gl.GL_NORMAL_ARRAY)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo[2]); gl.glNormalPointer(gl.GL_FLOAT, 0, None)
        if self.mode == gl.GL_LINES:
            gl.glLineWidth(self.width)
            if self.stipple:
                gl.glEnable(gl.GL_LINE_STIPPLE); gl.glLineStipple(self.stipple[0], self.stipple[1])
        gl.glDrawArrays(self.mode, 0, self.n)
        if self.stipple:
            gl.glDisable(gl.GL_LINE_STIPPLE)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)
        gl.glDisableClientState(gl.GL_VERTEX_ARRAY); gl.glDisableClientState(gl.GL_COLOR_ARRAY); gl.glDisableClientState(gl.GL_NORMAL_ARRAY)

    def free(self):
        if self.vbo:
            try:
                gl.glDeleteBuffers(len(self.vbo), self.vbo)
            except Exception:
                pass
            self.vbo = None


def smooth_normals(V, F, fn, ang=32.0):
    """Crease-aware per-corner normals."""
    nf = len(F)
    if nf == 0:
        return np.zeros((0, 3))
    key = np.round(V / max(1e-9, float(np.ptp(V, axis=0).max()) * 1e-7)).astype(np.int64)
    _, vid = np.unique(key, axis=0, return_inverse=True)
    vid = vid.ravel()
    cv = vid[F].ravel(); cn = np.repeat(fn, 3, axis=0)
    a = V[F[:, 0]]; b = V[F[:, 1]]; c = V[F[:, 2]]
    w = np.repeat(np.linalg.norm(np.cross(b - a, c - a), axis=1), 3) + 1e-30
    order = np.argsort(cv, kind="stable"); cvs = cv[order]
    starts = np.concatenate([[0], np.flatnonzero(np.diff(cvs)) + 1]); counts = np.diff(np.concatenate([starts, [len(cvs)]]))
    if (counts.astype(np.int64) ** 2).sum() > 6e6:
        return cn
    gsz = np.repeat(counts, counts); gst = np.repeat(starts, counts)
    N = len(cvs)
    I = np.repeat(np.arange(N), gsz)
    off = np.arange(len(I)) - np.repeat(np.cumsum(gsz) - gsz, gsz)
    J = np.repeat(gst, gsz) + off
    ni = cn[order][I]; nj = cn[order][J]
    m = np.einsum("ij,ij->i", ni, nj) > math.cos(math.radians(ang))
    acc = np.zeros((N, 3)); np.add.at(acc, I[m], nj[m] * w[order][J[m]][:, None])
    acc /= np.maximum(np.linalg.norm(acc, axis=1, keepdims=True), 1e-30)
    out = np.empty_like(acc); out[order] = acc
    return out


def _rgbf(h):
    """'#rrggbb' -> (r, g, b) floats, or None for an empty value."""
    if not h:
        return None
    c = QColor(h)
    return (c.redF(), c.greenF(), c.blueF()) if c.isValid() else None


class Viewport(QOpenGLWidget):
    mouse_moved = Signal(object)
    view_changed = Signal()

    def __init__(self, ctl):
        super().__init__()
        self.ctl = ctl
        self.cam = Camera()
        self.setMouseTracking(True); self.setFocusPolicy(Qt.StrongFocus); self.setCursor(Qt.BlankCursor)
        self.mode = "shadededges"       # wire | hidden | shaded | shadededges | xray
        self.light = False
        self.show_grid = True; self.osnap_on = True; self.ortho = False; self.snap_on = False; self.dyn = True; self.lwt = False
        self.snap_modes = {"end", "mid", "cen", "quad", "int", "perp", "node", "ins", "img"}
        self.color_by_thk = False
        self.aperture = 12
        from .options import DEFAULTS
        self.opt = dict(DEFAULTS)        # user options (Options dialog); the main window loads the saved profile
        self.click_win = None            # first corner of a click-click selection window
        self.snap_override = None        # one-shot object snap override (Shift + right-click menu)
        self.ucs = Plane()
        self.mouse = QPointF(-100, -100); self.mouse_world = np.zeros(3); self.snap_hit = None
        self.selection = []      # entity ids
        self.hover = None
        self.preview = []        # temp entities
        self.preview_base = None
        self.drag = None         # (kind, start QPointF, extra)
        self.batches = {}; self._built = None; self._pick = None; self._proj = None
        self.textures = {}
        self._recent = []
        self._anim = None
        self.grips = []; self.hot_grip = None
        self.polar_on = False; self.polar_inc = 90.0; self.track = None    # polar tracking (F10)
        self.otrack_on = True; self.acquired = []; self.otracks = []       # object snap tracking (F11): acquired points, active paths
        self._acq_timer = QTimer(self); self._acq_timer.setSingleShot(True); self._acq_timer.timeout.connect(self._acquire)
        self._acq_cand = None
        self.sel_cycling = True                                            # selection cycling for overlapping objects (Ctrl+W)
        self.grid_disp = 10.0                                              # spacing of the grid on screen (snap spacing is separate)
        self._gmenu = None; self._gtimer = QTimer(self); self._gtimer.setSingleShot(True); self._gtimer.timeout.connect(self._grip_hover_menu)
        self._ghover = None
        self.status_text = ""
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick); self._last_move = 0
        self.overlay_msg = None
        self.highlight_extra = []
        self.cam.R = R_view(*VIEWS["top"])

    # ================================================================ doc helpers
    @property
    def doc(self):
        return self.ctl.doc

    @property
    def selection(self):
        """One selection for every viewport of the window (kept by the main window)."""
        s = getattr(self.ctl, "sel_ids", None)
        if s is None:
            s = self.__dict__.setdefault("_sel", [])
        return s

    @selection.setter
    def selection(self, v):
        if getattr(self.ctl, "sel_ids", None) is not None:
            self.ctl.sel_ids = list(v)
        else:
            self._sel = list(v)

    def invalidate(self):
        self._built = None; self._proj = None; self.update()

    # ================================================================ GL lifecycle
    def initializeGL(self):
        gl.glEnable(gl.GL_DEPTH_TEST); gl.glDepthFunc(gl.GL_LEQUAL)
        gl.glEnable(gl.GL_BLEND); gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
        gl.glEnable(gl.GL_LINE_SMOOTH); gl.glHint(gl.GL_LINE_SMOOTH_HINT, gl.GL_NICEST)
        gl.glEnable(gl.GL_MULTISAMPLE)

    def resizeGL(self, w, h):
        self.cam.W = max(1, w); self.cam.H = max(1, h); self._proj = None

    # ================================================================ batch building
    def _colorize(self, e, rgb):
        return rgb

    def build(self):
        doc = self.doc
        lts_g = float(doc.settings.get("ltscale", 1.0) or 1.0)
        key = (id(doc), doc.version, doc.rev, self.mode, self.light, self.color_by_thk, self.lwt, E.Entity.anno_scale, lts_g)
        if self._built == key:
            return
        for b in self.batches.values():
            b.free()
        light = self.light; mode = self.mode; layers = doc.layers
        thk = [e.meta.get("thk", 0) for e in doc.ents.values() if isinstance(e, E.Body) and e.role == "plate"]
        tmin, tmax = (min(thk), max(thk)) if thk else (0, 0)
        from ..core.ship import thickness_colour
        from ..core.document import dash_segments
        edge_dark = (0.12, 0.13, 0.15) if not light else (0.15, 0.15, 0.17)

        class Col:                                     # geometry collected for the GPU and for picking
            __slots__ = ("lines", "fV", "fC", "mV", "mN", "mC", "ps", "pso", "pt", "pto", "imgs")
            def __init__(self):
                self.lines = {}; self.fV = []; self.fC = []; self.mV = []; self.mN = []; self.mC = []
                self.ps = []; self.pso = []; self.pt = []; self.pto = []; self.imgs = []
        def add_lines(col, k, V, rgb):
            L = col.lines.setdefault(k, ([], []))
            L[0].append(V); c = np.empty((len(V), 4), np.float32); c[:] = (rgb[0], rgb[1], rgb[2], 1.0); L[1].append(c)

        def emit(e, owner, parent, col):
            if isinstance(e, E.Insert) and e.heavy():
                # a big block (imported PDF page): one transformed array per colour instead of thousands of objects
                S, Sg, Tr, Tg, pal = e.heavy_geo()
                pcol = doc.color_of(e) if parent is None else e.color
                for k, (cc, lay) in enumerate(pal):
                    if cc == 0:
                        c0 = pcol
                    elif cc in (256, None):
                        c0 = layers[lay].color if (lay != "0" and lay in layers) else pcol
                    else:
                        c0 = cc
                    rgb = resolve_rgb(c0, light)
                    m = Sg == k
                    if m.any():
                        add_lines(col, (1.0, None), S[m].reshape(-1, 3), rgb)
                    m = Tg == k
                    if m.any():
                        tri = Tr[m]; fc = np.empty((len(tri) * 3, 4), np.float32); fc[:] = (rgb[0], rgb[1], rgb[2], 1.0)
                        col.fV.append(tri.reshape(-1, 3)); col.fC.append(fc)
                if len(S):
                    col.ps.append(S); col.pso.append(np.full(len(S), owner))
                return
            if isinstance(e, (E.Insert, E.DetailView)) or e.kind == "array":
                for ch in e.children():
                    emit(ch, owner, e, col)
                return
            try:
                c0 = doc.color_of(e) if parent is None else (e.color if e.color not in (256, None) else (doc.layer_of(e).color if e.layer != "0" else doc.color_of(parent)))
                rgb = resolve_rgb(c0, light)
                lt = doc.ltype_of(e); lw = doc.lw_of(e) if self.lwt else 0
                width = 1.0 if lw <= 25 else min(6.0, lw / 25.0)
                pat = LINETYPES.get(lt)
                key2 = (width, None)
                if isinstance(e, E.ImageE):
                    col.imgs.append(e)          # images are picked by their frame only (like AutoCAD), never by the picture area
                is_body = isinstance(e, E.Body)
                if is_body:
                    brgb = rgb
                    if self.color_by_thk and e.role == "plate":
                        brgb = thickness_colour(e.meta.get("thk", 0), tmin, tmax)
                    V, F = e.V, e.F
                    if len(F):
                        tri = V[F].reshape(-1, 3)
                        col.pt.append(V[F]); col.pto.append(np.full(len(F), owner))
                        if mode != "wire":
                            fn = e.normals()
                            nrm = smooth_normals(V, F, fn) if e.role != "plate" else np.repeat(fn, 3, axis=0)
                            col.mV.append(tri); col.mN.append(nrm)
                            a = 0.32 if mode == "xray" else 1.0
                            cc = brgb if mode != "hidden" else ((0.13, 0.15, 0.19) if not light else (1, 1, 1))
                            col.mC.append(np.tile([*cc, a], (len(tri), 1)))
                    erg = (edge_dark if mode in ("shadededges", "hidden") else rgb)
                    if mode == "shaded":
                        erg = None
                    segs = e.edges()
                    if len(segs) and erg is not None:
                        add_lines(col, (1.0, None), segs.reshape(-1, 3), erg)
                    if len(segs):
                        col.ps.append(segs); col.pso.append(np.full(len(segs), owner))
                    if e.iso is not None and mode in ("wire", "xray", "shadededges", "hidden"):
                        for w in e.iso:
                            sg = np.stack([w[:-1], w[1:]], axis=1)
                            add_lines(col, (1.0, None), sg.reshape(-1, 3), rgb if mode == "wire" else erg)
                            col.ps.append(sg); col.pso.append(np.full(len(sg), owner))
                    return
                scale = lts_g * float(getattr(e, "lts", 1.0) or 1.0) if pat is not None else 1.0
                for w in e.wire():
                    if len(w) < 2:
                        continue
                    sg = np.stack([w[:-1], w[1:]], axis=1)
                    shown = dash_segments(w, pat, scale) if pat is not None else None
                    add_lines(col, key2, (sg if shown is None else shown).reshape(-1, 3), rgb)
                    col.ps.append(sg); col.pso.append(np.full(len(sg), owner))
                groups = e.tris_groups() if hasattr(e, "tris_groups") else None
                if groups is None:
                    t = e.tris()
                    groups = [(t[0], t[1], None)] if t is not None and len(t[1]) else []
                for V, F, gc in groups:
                    if not len(F):
                        continue
                    grgb = rgb if gc is None else resolve_rgb(gc, light)
                    tri = V[F]
                    fc = np.empty((len(F) * 3, 4), np.float32); fc[:] = (grgb[0], grgb[1], grgb[2], 1.0)
                    col.fV.append(tri.reshape(-1, 3)); col.fC.append(fc)
                    col.pt.append(tri); col.pto.append(np.full(len(F), owner))
                    if e.kind in ("text", "dimension", "leader", "table"):
                        # 1 px outline of the glyph triangles keeps thin strokes (1, l, i) visible when zoomed out
                        add_lines(col, (1.0, None), tri[:, [0, 1, 1, 2, 2, 0]].reshape(-1, 3), grgb)
                if isinstance(e, E.PointE):
                    sg = self._point_marker(e.p)
                    add_lines(col, (1.0, None), sg.reshape(-1, 3), rgb)
                    col.ps.append(sg); col.pso.append(np.full(len(sg), owner))
            except Exception:
                import traceback; traceback.print_exc()

        vis = doc.visible_ents()
        if any(e.xd and e.xd.get("order") for e in vis):
            # DRAWORDER: among coplanar fills the one emitted first stays visible, so the highest order goes first
            vis = sorted(vis, key=lambda e: -(e.xd.get("order", 0.0) if e.xd else 0.0))
        main = Col(); front = Col()                     # fills of objects brought to the front are drawn over the line work
        simple = ("line", "circle", "arc", "ellipse", "polyline", "spline", "text", "hatch", "dimension", "leader", "segs", "table", "insert")
        layers = doc.layers
        lay_sig = hash(tuple((l.name, str(l.color), l.ltype, l.lw) for l in layers.values()))
        for e in vis:
            dst = front if (e.xd and e.xd.get("order", 0) > 0) else main
            if e.kind in simple:
                # unchanged objects reuse the arrays of the previous build (touch() drops them)
                ly = layers.get(e.layer)
                ck = (e.color, e.ltype, e.lw, e.lts, ly.color if ly else 7, ly.ltype if ly else "", ly.lw if ly else 0,
                      light, self.lwt, lts_g, E.Entity.anno_scale, mode if e.kind == "insert" else 0,
                      (lay_sig, id(E.Insert.blocks.get(e.name)), self.color_by_thk) if e.kind == "insert" else 0)
                pk = e._cache.get("gl")
                if pk is None or pk[0] != ck:
                    c2 = Col(); emit(e, e.id, None, c2)
                    pk = (ck, c2); e._cache["gl"] = pk
                c2 = pk[1]
            else:
                c2 = Col(); emit(e, e.id, None, c2)
            for k, (Vs, Cs) in c2.lines.items():
                L = main.lines.setdefault(k, ([], [])); L[0].extend(Vs); L[1].extend(Cs)
            dst.fV.extend(c2.fV); dst.fC.extend(c2.fC)
            main.mV.extend(c2.mV); main.mN.extend(c2.mN); main.mC.extend(c2.mC)
            main.ps.extend(c2.ps); main.pso.extend(c2.pso); main.pt.extend(c2.pt); main.pto.extend(c2.pto); main.imgs.extend(c2.imgs)
        for k, (Vs, Cs) in front.lines.items():
            L = main.lines.setdefault(k, ([], [])); L[0].extend(Vs); L[1].extend(Cs)
        self.batches = {}
        for k, (Vs, Cs) in main.lines.items():
            self.batches[("L",) + k] = Batch(gl.GL_LINES, np.vstack(Vs), np.vstack(Cs), None, k[0], None)
        if main.fV:
            self.batches[("F",)] = Batch(gl.GL_TRIANGLES, np.vstack(main.fV), np.vstack(main.fC))
        if front.fV:
            self.batches[("FF",)] = Batch(gl.GL_TRIANGLES, np.vstack(front.fV), np.vstack(front.fC))
        if main.mV:
            self.batches[("M",)] = Batch(gl.GL_TRIANGLES, np.vstack(main.mV), np.vstack(main.mC), np.vstack(main.mN))
        _o = lambda e: (e.xd.get("order", 0.0) if e.xd else 0.0)
        img_list = main.imgs
        img_list.sort(key=_o)                          # images: painted back to front
        self.images = img_list
        top_fill = max([_o(e) for e in vis if e.kind != "image" and _o(e) > 0] or [0.0])
        self.images_front = [e for e in img_list if 0 < _o(e) <= top_fill]        # below the front fills
        self.images_top = [e for e in img_list if _o(e) > top_fill and _o(e) > 0]  # above everything
        S = np.vstack(main.ps) if main.ps else np.zeros((0, 2, 3)); So = np.concatenate(main.pso) if main.pso else np.zeros(0, int)
        T = np.vstack([np.asarray(t).reshape(-1, 3, 3) for t in main.pt]) if main.pt else np.zeros((0, 3, 3))
        To = np.concatenate([np.atleast_1d(np.asarray(o)) for o in main.pto]) if main.pto else np.zeros(0, int)
        self._pick = (S, So, T, To)
        self._proj = None
        bb = doc.extents()
        if bb is not None:
            self.cam.radius = max(1.0, float(norm(bb[1] - bb[0])) * 0.6 + norm((bb[0] + bb[1]) / 2 - self.cam.target))
        self._built = key

    def _point_marker(self, p):
        r = self.cam.px() * 4
        x, y = self.cam.right() * r, self.cam.up() * r
        return np.array([[p - x, p + x], [p - y, p + y]])

    # ================================================================ drawing
    def paintGL(self):
        p = QPainter(self)
        p.beginNativePainting()
        try:
            self.build()
            if not self._scene_from_cache():
                self._gl_scene()
            self._gl_dynamic()
        except Exception:
            import traceback; traceback.print_exc()
        p.endNativePainting()
        try:
            self._overlay(p)
        except Exception:
            import traceback; traceback.print_exc()
        p.end()

    # ---------------------------------------------------------------- cached scene
    # The drawing itself (background, grid, images, all objects) is rendered into an off-screen buffer and only
    # re-rendered when the drawing or the camera changes.  Moving the cursor, rubber bands, highlights and tooltips
    # then cost the same for a drawing of 100 or 100 000 objects.
    def _scene_key(self):
        o = self.opt
        return (self._built, self.cam.key(), self.width(), self.height(), round(self.devicePixelRatioF(), 3), self.show_grid, self.light,
                self.mode, o.get("bg_bot"), o.get("bg_top"), o.get("grid_x"), o.get("grid_y"), o.get("grid_major"), o.get("grid_adaptive"),
                o.get("snap_step"), tuple((e.id, e.fade, e.brightness, e.contrast, e.show_frame) for e in getattr(self, "images", [])),
                E.ImageE.frame_mode)

    def _fbo_free(self):
        f = getattr(self, "_fbo", None)
        if not f:
            return
        try:
            gl.glDeleteFramebuffers(len(f["fbos"]), f["fbos"]); gl.glDeleteRenderbuffers(len(f["rbs"]), f["rbs"]); gl.glDeleteTextures([f["tex"]])
        except Exception:
            pass
        self._fbo = None

    def _fbo_make(self, W, H):
        self._fbo_free()
        def tex_fbo():
            tex = gl.glGenTextures(1); gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
            gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_NEAREST); gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_NEAREST)
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA8, W, H, 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, None)
            gl.glBindTexture(gl.GL_TEXTURE_2D, 0)
            fb = gl.glGenFramebuffers(1); gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, fb)
            gl.glFramebufferTexture2D(gl.GL_FRAMEBUFFER, gl.GL_COLOR_ATTACHMENT0, gl.GL_TEXTURE_2D, tex, 0)
            return fb, tex
        for samples in ((4, 0) if not getattr(Viewport, "_no_msaa", False) else (0,)):
            fbos = []; rbs = []; tex = None
            try:
                if samples:
                    fb = gl.glGenFramebuffers(1); gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, fb); fbos.append(fb)
                    rc = gl.glGenRenderbuffers(1); gl.glBindRenderbuffer(gl.GL_RENDERBUFFER, rc); rbs.append(rc)
                    gl.glRenderbufferStorageMultisample(gl.GL_RENDERBUFFER, samples, gl.GL_RGBA8, W, H)
                    gl.glFramebufferRenderbuffer(gl.GL_FRAMEBUFFER, gl.GL_COLOR_ATTACHMENT0, gl.GL_RENDERBUFFER, rc)
                    rd = gl.glGenRenderbuffers(1); gl.glBindRenderbuffer(gl.GL_RENDERBUFFER, rd); rbs.append(rd)
                    gl.glRenderbufferStorageMultisample(gl.GL_RENDERBUFFER, samples, gl.GL_DEPTH24_STENCIL8, W, H)
                    gl.glFramebufferRenderbuffer(gl.GL_FRAMEBUFFER, gl.GL_DEPTH_STENCIL_ATTACHMENT, gl.GL_RENDERBUFFER, rd)
                    ok = gl.glCheckFramebufferStatus(gl.GL_FRAMEBUFFER) == gl.GL_FRAMEBUFFER_COMPLETE
                    fb2, tex = tex_fbo(); fbos.append(fb2)
                    ok = ok and gl.glCheckFramebufferStatus(gl.GL_FRAMEBUFFER) == gl.GL_FRAMEBUFFER_COMPLETE
                else:
                    fb, tex = tex_fbo(); fbos.append(fb)
                    rd = gl.glGenRenderbuffers(1); gl.glBindRenderbuffer(gl.GL_RENDERBUFFER, rd); rbs.append(rd)
                    gl.glRenderbufferStorage(gl.GL_RENDERBUFFER, gl.GL_DEPTH24_STENCIL8, W, H)
                    gl.glFramebufferRenderbuffer(gl.GL_FRAMEBUFFER, gl.GL_DEPTH_STENCIL_ATTACHMENT, gl.GL_RENDERBUFFER, rd)
                    ok = gl.glCheckFramebufferStatus(gl.GL_FRAMEBUFFER) == gl.GL_FRAMEBUFFER_COMPLETE
                gl.glBindRenderbuffer(gl.GL_RENDERBUFFER, 0)
                if ok:
                    self._fbo = {"fbos": fbos, "rbs": rbs, "tex": tex, "W": W, "H": H, "ms": bool(samples), "key": None}
                    return True
            except Exception:
                ok = False
            try:
                gl.glDeleteFramebuffers(len(fbos), fbos); gl.glDeleteRenderbuffers(len(rbs), rbs)
                if tex is not None:
                    gl.glDeleteTextures([tex])
            except Exception:
                pass
            if samples:
                Viewport._no_msaa = True
        return False

    def _scene_from_cache(self):
        """Draws the scene from the off-screen buffer (rendering it first when needed). False = draw directly."""
        if not self.opt.get("scene_cache", True) or getattr(Viewport, "_no_fbo", False) or self._anim is not None:
            return False
        dpr = self.devicePixelRatioF(); W = max(1, int(self.width() * dpr)); H = max(1, int(self.height() * dpr))
        dfb = self.defaultFramebufferObject()
        try:
            f = getattr(self, "_fbo", None)
            if f is None or f["W"] != W or f["H"] != H:
                if not self._fbo_make(W, H):
                    Viewport._no_fbo = True; gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, dfb); return False
                f = self._fbo
            key = self._scene_key()
            if f["key"] != key:
                gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, f["fbos"][0])
                self._gl_scene()
                if f["ms"]:
                    gl.glBindFramebuffer(gl.GL_READ_FRAMEBUFFER, f["fbos"][0]); gl.glBindFramebuffer(gl.GL_DRAW_FRAMEBUFFER, f["fbos"][1])
                    gl.glBlitFramebuffer(0, 0, W, H, 0, 0, W, H, gl.GL_COLOR_BUFFER_BIT, gl.GL_NEAREST)
                f["key"] = key
            gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, dfb)
            gl.glViewport(0, 0, W, H)
            gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity(); gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()
            gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_BLEND)
            gl.glClearColor(0, 0, 0, 1); gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT | gl.GL_STENCIL_BUFFER_BIT)
            gl.glEnable(gl.GL_TEXTURE_2D); gl.glBindTexture(gl.GL_TEXTURE_2D, f["tex"])
            gl.glTexEnvi(gl.GL_TEXTURE_ENV, gl.GL_TEXTURE_ENV_MODE, gl.GL_REPLACE)
            gl.glColor4f(1, 1, 1, 1)
            gl.glBegin(gl.GL_QUADS)
            for u, v in ((0, 0), (1, 0), (1, 1), (0, 1)):
                gl.glTexCoord2f(u, v); gl.glVertex2f(u * 2 - 1, v * 2 - 1)
            gl.glEnd()
            gl.glBindTexture(gl.GL_TEXTURE_2D, 0); gl.glDisable(gl.GL_TEXTURE_2D); gl.glEnable(gl.GL_DEPTH_TEST)
            gl.glTexEnvi(gl.GL_TEXTURE_ENV, gl.GL_TEXTURE_ENV_MODE, gl.GL_MODULATE)
            return True
        except Exception:
            import traceback; traceback.print_exc()
            Viewport._no_fbo = True
            try:
                gl.glBindFramebuffer(gl.GL_FRAMEBUFFER, dfb)
            except Exception:
                pass
            return False

    @staticmethod
    def _blend_on():
        """QPainter leaves blending in an unknown state: switch it on for transparency (image fade, x-ray, highlights)
        and smooth lines.  The alpha channel of the target stays opaque."""
        gl.glEnable(gl.GL_BLEND)
        try:
            gl.glBlendFuncSeparate(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA, gl.GL_ONE, gl.GL_ONE_MINUS_SRC_ALPHA)
        except Exception:
            gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)

    def _gl_dynamic(self):
        """Highlights and command previews: drawn every frame on top of the (cached) scene."""
        self._blend_on()
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadMatrixd(self.cam.proj().T.ravel())
        gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadMatrixd(self.cam.view().T.ravel())
        gl.glEnable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING)
        self._draw_highlights()
        self._draw_preview()
        # leave a clean state for QPainter
        gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_LINE_STIPPLE); gl.glDisable(gl.GL_TEXTURE_2D)
        gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDepthMask(gl.GL_TRUE); gl.glLineWidth(1.0)
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity(); gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()

    def _gl_scene(self):
        from .theme import DARK, LIGHT
        th = LIGHT if self.light else DARK
        dpr = self.devicePixelRatioF()
        gl.glViewport(0, 0, int(self.width() * dpr), int(self.height() * dpr))
        bot = _rgbf(self.opt.get("bg_bot")) or th["view_bot"]; top = _rgbf(self.opt.get("bg_top")) or th["view_top"]
        self._blend_on()
        gl.glClearColor(*bot, 1); gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT | gl.GL_STENCIL_BUFFER_BIT)
        # gradient background
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity(); gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()
        gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING)
        gl.glBegin(gl.GL_QUADS)
        gl.glColor3f(*bot); gl.glVertex2f(-1, -1); gl.glVertex2f(1, -1)
        gl.glColor3f(*top); gl.glVertex2f(1, 1); gl.glVertex2f(-1, 1)
        gl.glEnd()
        gl.glEnable(gl.GL_DEPTH_TEST)
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadMatrixd(self.cam.proj().T.ravel())
        gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadMatrixd(self.cam.view().T.ravel())
        if self.show_grid:
            self._draw_grid(th)
        self._draw_images()
        # meshes
        mb = self.batches.get(("M",))
        if mb is not None:
            gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(1.0, 1.0)
            if self.mode != "hidden":
                self._lights()
            if self.mode == "xray":
                gl.glDepthMask(gl.GL_FALSE)
            mb.draw()
            gl.glDepthMask(gl.GL_TRUE)
            gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
        fb = self.batches.get(("F",))
        if fb is not None:
            gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-0.5, -0.5)
            fb.draw(); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
        for k, b in self.batches.items():
            if k[0] == "L":
                b.draw()
        self._draw_image_list(getattr(self, "images_front", []), front=True)      # images brought to the front
        fb = self.batches.get(("FF",))
        if fb is not None:
            gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-2.0, -2.0)
            fb.draw(); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
        self._draw_image_list(getattr(self, "images_top", []), front=True)
        gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_LINE_STIPPLE); gl.glDisable(gl.GL_TEXTURE_2D)
        gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDepthMask(gl.GL_TRUE); gl.glLineWidth(1.0)

    def _lights(self):
        gl.glEnable(gl.GL_LIGHTING); gl.glEnable(gl.GL_COLOR_MATERIAL); gl.glColorMaterial(gl.GL_FRONT_AND_BACK, gl.GL_AMBIENT_AND_DIFFUSE)
        gl.glLightModeli(gl.GL_LIGHT_MODEL_TWO_SIDE, 1); gl.glEnable(gl.GL_NORMALIZE)
        gl.glLightModelfv(gl.GL_LIGHT_MODEL_AMBIENT, (0.32, 0.32, 0.34, 1))
        gl.glPushMatrix(); gl.glLoadIdentity()
        gl.glEnable(gl.GL_LIGHT0); gl.glLightfv(gl.GL_LIGHT0, gl.GL_POSITION, (0.35, 0.55, 1.0, 0)); gl.glLightfv(gl.GL_LIGHT0, gl.GL_DIFFUSE, (0.72, 0.72, 0.72, 1))
        gl.glLightfv(gl.GL_LIGHT0, gl.GL_SPECULAR, (0.25, 0.25, 0.25, 1))
        gl.glEnable(gl.GL_LIGHT1); gl.glLightfv(gl.GL_LIGHT1, gl.GL_POSITION, (-0.6, -0.3, 0.4, 0)); gl.glLightfv(gl.GL_LIGHT1, gl.GL_DIFFUSE, (0.22, 0.24, 0.28, 1))
        gl.glPopMatrix()
        gl.glMaterialfv(gl.GL_FRONT_AND_BACK, gl.GL_SPECULAR, (0.3, 0.3, 0.3, 1)); gl.glMaterialf(gl.GL_FRONT_AND_BACK, gl.GL_SHININESS, 40)

    def _draw_images(self):
        self._draw_image_list([e for e in getattr(self, "images", []) if not (e.xd and e.xd.get("order", 0) > 0)])

    def _draw_image_list(self, imgs, front=False):
        if not imgs:
            return
        gl.glEnable(gl.GL_TEXTURE_2D); gl.glDepthMask(gl.GL_FALSE)
        if front:
            gl.glDisable(gl.GL_DEPTH_TEST)
        for e in imgs:
            tex = self._texture(e)
            if tex is None:
                continue
            gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
            gl.glTexEnvi(gl.GL_TEXTURE_ENV, gl.GL_TEXTURE_ENV_MODE, gl.GL_MODULATE)
            gl.glColor4f(1, 1, 1, 1 - e.fade)
            c = e.corners()
            gl.glBegin(gl.GL_QUADS)
            for (u, v), q in zip(((0, 1), (1, 1), (1, 0), (0, 0)), c):
                gl.glTexCoord2f(u, v); gl.glVertex3d(*q)
            gl.glEnd()
        gl.glBindTexture(gl.GL_TEXTURE_2D, 0); gl.glDisable(gl.GL_TEXTURE_2D); gl.glDepthMask(gl.GL_TRUE)
        if front:
            gl.glEnable(gl.GL_DEPTH_TEST)

    def _texture(self, e):
        br = float(getattr(e, "brightness", 0.0)); ct = float(getattr(e, "contrast", 0.0))
        k = (e.id, len(e.data), round(br, 1), round(ct, 1))
        for old in [q for q in self.textures if q[0] == e.id and q != k]:       # adjusted: drop the previous texture
            try:
                gl.glDeleteTextures([self.textures.pop(old)])
            except Exception:
                self.textures.pop(old, None)
        t = self.textures.get(k)
        if t is not None:
            return t
        img = QImage.fromData(e.data)
        if img.isNull():
            return None
        mx = 4096
        if img.width() > mx or img.height() > mx:
            img = img.scaled(mx, mx, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        img = img.convertToFormat(QImage.Format_RGBA8888)
        buf = np.frombuffer(img.constBits(), np.uint8, img.sizeInBytes()).reshape(img.height(), img.bytesPerLine())[:, :img.width() * 4].copy()
        if br or ct:
            buf = adjust_rgba(buf.reshape(img.height(), img.width(), 4), br, ct).reshape(img.height(), img.width() * 4)
        tid = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, tid)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR); gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA, img.width(), img.height(), 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, buf)
        self.textures[k] = tid
        return tid

    def _draw_grid(self, th):
        pl = self.ucs; px = self.cam.px()
        if abs(np.dot(pl.z, self.cam.back())) < 0.05:
            return
        o = self.opt
        gx = float(o.get("grid_x", 0) or 0); gy = float(o.get("grid_y", 0) or 0) or gx
        mj = max(1, int(o.get("grid_major", 5) or 5))
        if gx > 0:                                       # user grid spacing (Drafting Settings), coarsened when too dense
            step, stepy = gx, gy
            if o.get("grid_adaptive", True):
                while min(step, stepy) / px < 7:
                    step *= mj; stepy *= mj
        else:
            step = 10 ** math.floor(math.log10(max(px * 18, 1e-9)))
            for m in (1, 2, 5, 10):
                if step * m / px >= 18:
                    step *= m; break
            stepy = step
        major = step * mj; majory = stepy * mj
        c = pl.to_local(self.cam.target)
        halfw = self.cam.h * self.cam.W / max(1, self.cam.H) / 2 / max(0.2, abs(np.dot(pl.z, self.cam.back())))
        R = max(halfw, self.cam.h / 2) * 1.4
        while R / min(step, stepy) > 400:
            step = major; stepy = majory; major *= mj; majory *= mj
        x0 = math.floor((c[0] - R) / step) * step; x1 = c[0] + R
        y0 = math.floor((c[1] - R) / stepy) * stepy; y1 = c[1] + R
        gl.glLineWidth(1.0); gl.glDepthMask(gl.GL_FALSE)
        gl.glBegin(gl.GL_LINES)
        xs = np.arange(x0, x1, step); ys = np.arange(y0, y1, stepy)
        for x in xs:
            maj = abs(round(x / major) * major - x) < step * 0.01
            col = th["grid_major"] if maj else th["grid"]
            gl.glColor4f(*col, 0.42 if maj else 0.16)
            a = pl.to_world(np.array([x, y0])); b = pl.to_world(np.array([x, y1])); gl.glVertex3d(*a); gl.glVertex3d(*b)
        for y in ys:
            maj = abs(round(y / majory) * majory - y) < stepy * 0.01
            col = th["grid_major"] if maj else th["grid"]
            gl.glColor4f(*col, 0.42 if maj else 0.16)
            a = pl.to_world(np.array([x0, y])); b = pl.to_world(np.array([x1, y])); gl.glVertex3d(*a); gl.glVertex3d(*b)
        # axes
        o = pl.o
        gl.glColor4f(0.85, 0.25, 0.25, 0.8); gl.glVertex3d(*(o)); gl.glVertex3d(*(o + pl.x * R))
        gl.glColor4f(0.25, 0.75, 0.35, 0.8); gl.glVertex3d(*(o)); gl.glVertex3d(*(o + pl.y * R))
        gl.glEnd(); gl.glDepthMask(gl.GL_TRUE)
        self.grid_disp = step               # display only - SNAP uses its own spacing (snap_x / snap_y)

    def _draw_ent_lines(self, ents, rgba, width):
        gl.glLineWidth(width); gl.glColor4f(*rgba)
        gl.glBegin(gl.GL_LINES)
        for e in ents:
            if isinstance(e, E.Body):
                for s in e.edges()[:20000]:
                    gl.glVertex3d(*s[0]); gl.glVertex3d(*s[1])
                if e.iso is not None:
                    for w in e.iso:
                        for i in range(len(w) - 1):
                            gl.glVertex3d(*w[i]); gl.glVertex3d(*w[i + 1])
                continue
            for w in e.wire():
                for i in range(len(w) - 1):
                    gl.glVertex3d(*w[i]); gl.glVertex3d(*w[i + 1])
            if isinstance(e, E.PointE):
                for s in self._point_marker(e.p):
                    gl.glVertex3d(*s[0]); gl.glVertex3d(*s[1])
        gl.glEnd()

    def _draw_ent_fills(self, ents, rgba):
        gl.glColor4f(*rgba)
        gl.glBegin(gl.GL_TRIANGLES)
        for e in ents:
            t = e.tris()
            if t is None:
                continue
            V, F = t
            if len(F) > 60000:
                continue
            for tri in V[F]:
                gl.glVertex3d(*tri[0]); gl.glVertex3d(*tri[1]); gl.glVertex3d(*tri[2])
        gl.glEnd()

    def _draw_highlights(self):
        doc = self.doc
        sel = [doc.ents[i] for i in self.selection if i in doc.ents]
        hl = (0.18, 0.62, 1.0, 1.0)
        gl.glDisable(gl.GL_DEPTH_TEST)
        if sel:
            bodies = [e for e in sel if isinstance(e, E.Body) or e.kind in ("text", "hatch", "table", "dimension", "leader", "insert", "detailview", "array", "attdef")]
            if bodies:
                gl.glEnable(gl.GL_DEPTH_TEST); gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-1, -1)
                self._draw_ent_fills(bodies, (0.18, 0.62, 1.0, 0.35)); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDisable(gl.GL_DEPTH_TEST)
            self._draw_ent_lines(sel, hl, 2.2)
        if self.opt.get("hover", True) and self.hover is not None and self.hover in doc.ents and self.hover not in self.selection:
            e = doc.ents[self.hover]
            self._draw_ent_lines([e], (0.55, 0.85, 1.0, 0.95), 2.0)
            if isinstance(e, E.Body) or e.kind in ("text", "hatch"):
                gl.glEnable(gl.GL_DEPTH_TEST); gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-1, -1)
                self._draw_ent_fills([e], (0.55, 0.85, 1.0, 0.18)); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDisable(gl.GL_DEPTH_TEST)
        if self.highlight_extra:
            self._draw_ent_lines(self.highlight_extra, (1.0, 0.7, 0.15, 1.0), 2.4)
        gl.glEnable(gl.GL_DEPTH_TEST)

    def _draw_preview(self):
        if not self.preview:
            return
        col = (1.0, 0.85, 0.3, 1.0) if not self.light else (0.85, 0.35, 0.0, 1.0)
        gl.glDisable(gl.GL_DEPTH_TEST)
        ents = [e for e in self.preview if e is not None]
        self._draw_ent_lines(ents, col, 1.4)
        fills = [e for e in ents if not isinstance(e, E.Body)]
        self._draw_ent_fills(fills, (col[0], col[1], col[2], 0.85))
        bodies = [e for e in ents if isinstance(e, E.Body)]
        if bodies:
            gl.glEnable(gl.GL_DEPTH_TEST); self._draw_ent_fills(bodies, (col[0], col[1], col[2], 0.25))
        gl.glEnable(gl.GL_DEPTH_TEST)

    # ================================================================ overlay (QPainter)
    def _overlay(self, p):
        p.setRenderHint(QPainter.Antialiasing)
        fg = QColor(30, 30, 30) if self.light else QColor(235, 240, 248)
        acc = QColor("#2EC5FF") if not self.light else QColor("#0A84C6")
        # block editor: dynamic parameters (linear = dimension line + stretch frame, flip = mirror axis)
        be_acts = getattr(self, "be_actions", None) or []
        for prm in (getattr(self, "be_params", None) or []):
            try:
                self._draw_param(p, prm, [a for a in be_acts if a.get("param") == prm.get("name")])
            except Exception:
                pass
        # grips
        o = self.opt
        if self.selection and self.ctl.req is None and o.get("grips", True):
            gs = float(o.get("grip_size", 4))
            self.grips = self._compute_grips()
            for i, (pt, eid, gi) in enumerate(self.grips):
                s, _ = self.cam.project(pt[None])
                x, y = s[0]
                hot = self.hot_grip is not None and self.hot_grip[0] == i
                p.setPen(QPen(QColor("white"), 1)); p.setBrush(QColor(o.get("grip_hot") or "#FF4D4F") if hot else QColor(o.get("grip_color") or "#2F80ED"))
                p.drawRect(QRectF(x - gs, y - gs, 2 * gs, 2 * gs))
        else:
            self.grips = []
        # selection rectangle
        if (self.drag and self.drag[0] == "window") or self.click_win is not None:
            a = self.drag[1] if (self.drag and self.drag[0] == "window") else self.click_win; b = self.mouse
            crossing = b.x() < a.x()
            col = QColor(70, 200, 120) if crossing else QColor(46, 150, 255)
            pen = QPen(col, 1); pen.setStyle(Qt.DashLine if crossing else Qt.SolidLine); p.setPen(pen)
            fill = QColor(col); fill.setAlpha(40); p.setBrush(fill)
            p.drawRect(QRectF(a, b).normalized())
        if o.get("viewcube", True):
            self._draw_viewcube(p)
        if o.get("ucsicon", True):
            self._draw_ucs_icon(p, fg)
        # polar tracking path
        req0 = self.ctl.req
        if self.track is not None and self.snap_hit is None and req0 is not None and req0.kind in ("point", "distance", "angle", "corner"):
            bw, pw, ang, dist = self.track
            s2, _ = self.cam.project(np.array([bw, pw], float)); a, b = s2[0], s2[1]
            d = b - a; L = math.hypot(*d)
            if L > 1e-6:
                far = a + d / L * 6000.0
                pen = QPen(QColor(80, 220, 120, 200), 1, Qt.DashLine); p.setPen(pen)
                p.drawLine(QPointF(*a), QPointF(*far))
                f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f)
                txt = f"Polar: {dist:.4g} < {ang:g}°"
                r = QRectF(b[0] + 14, b[1] + 12, 10 + 6.3 * len(txt), 18)
                p.setPen(Qt.NoPen); p.setBrush(QColor(40, 48, 60, 230)); p.drawRoundedRect(r, 3, 3)
                p.setPen(QColor(150, 240, 170)); hud_text(p, r, Qt.AlignCenter, txt)
        if req0 is not None and self.otrack_on and self.acquired:
            pen = QPen(QColor(90, 230, 130), 1.4); p.setPen(pen)
            for kind, A in self.acquired:                  # acquired points: small +
                s2, _ = self.cam.project(np.array([A], float)); ax, ay = s2[0]
                p.drawLine(QPointF(ax - 5, ay), QPointF(ax + 5, ay)); p.drawLine(QPointF(ax, ay - 5), QPointF(ax, ay + 5))
            lab = []
            for A, P, ang, kind in self.otracks:
                s2, _ = self.cam.project(np.array([A, P], float)); a, b = s2[0], s2[1]
                d = b - a; L = math.hypot(*d)
                if L > 1e-6:
                    p.setPen(QPen(QColor(90, 230, 130, 210), 1, Qt.DotLine))
                    p.drawLine(QPointF(*(a - d / L * 6000.0)), QPointF(*(a + d / L * 6000.0)))
                    up = ang if (d[0] > 1e-6 or (abs(d[0]) <= 1e-6 and d[1] < 0)) else (ang + 180.0) % 360.0
                    lab.append(f"{SNAP_LABEL.get(kind, kind)}: <{up:g}°")
            if lab and self.snap_hit is None:
                f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f)
                txt = ",  ".join(lab); m = self.mouse
                r = QRectF(m.x() + 16, m.y() - 34, 12 + 6.3 * len(txt), 18)
                p.setPen(Qt.NoPen); p.setBrush(QColor(40, 48, 60, 230)); p.drawRoundedRect(r, 3, 3)
                p.setPen(QColor(150, 240, 170)); hud_text(p, r, Qt.AlignCenter, txt)
        if len(getattr(self.ctl, "views", [])) > 1 and getattr(self.ctl, "view", None) is self:
            p.setPen(QPen(QColor("#2EC5FF"), 2)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(1, 1, self.width() - 2, self.height() - 2))
        # osnap marker
        if self.snap_hit is not None and o.get("snap_marker", True):
            kind, wp = self.snap_hit[0], self.snap_hit[1]
            s, _ = self.cam.project(np.asarray(wp)[None]); x, y = s[0]
            self._snap_marker(p, kind, x, y)
            f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f)
            txt = SNAP_LABEL.get(kind, kind)
            if o.get("snap_tooltip", True):
                r = QRectF(x + 12, y + 10, 8 + 6.5 * len(txt), 18)
                p.setPen(Qt.NoPen); p.setBrush(QColor(255, 214, 80, 230)); p.drawRoundedRect(r, 3, 3)
                p.setPen(QColor(20, 20, 20)); hud_text(p, r, Qt.AlignCenter, txt)
        # crosshair cursor
        if self.underMouse() or self.drag:
            mx, my = self.mouse.x(), self.mouse.y()
            req = self.ctl.req
            pick_only = req is not None and req.kind in ("select", "entity")
            idle = req is None
            pen = QPen(QColor(o["crosshair_color"]) if o.get("crosshair_color") else fg, 1); p.setPen(pen); p.setBrush(Qt.NoBrush)
            pb = float(o.get("pickbox", 5))
            full = max(self.width(), self.height()); pct = float(o.get("crosshair_size", 100))
            L = full if pct >= 100 else max(pb + 6, full * pct / 200.0)          # AutoCAD CURSORSIZE: percent of the screen
            if not pick_only:
                p.drawLine(QPointF(mx - L, my), QPointF(mx - pb, my)); p.drawLine(QPointF(mx + pb, my), QPointF(mx + L, my))
                p.drawLine(QPointF(mx, my - L), QPointF(mx, my - pb)); p.drawLine(QPointF(mx, my + pb), QPointF(mx, my + L))
            if pick_only or idle:
                p.drawRect(QRectF(mx - pb, my - pb, 2 * pb, 2 * pb))
        # dynamic input tooltip
        if self.dyn and (self.ctl.req is not None or self.hot_grip is not None) and self.underMouse():
            self._dyn_tip(p)
        if self.overlay_msg:
            f = QFont("Segoe UI"); f.setPixelSize(13); f.setBold(True); p.setFont(f)
            r = QRectF(self.width() / 2 - 240, 14, 480, 30)
            p.setPen(Qt.NoPen); p.setBrush(QColor(20, 30, 45, 210)); p.drawRoundedRect(r, 8, 8)
            p.setPen(QColor("#9FE3FF")); hud_text(p, r, Qt.AlignCenter, self.overlay_msg)

    def _dyn_tip(self, p):
        from PySide6.QtGui import QFontMetricsF
        req = self.ctl.req
        mx, my = self.mouse.x(), self.mouse.y()
        wp = self.mouse_world
        if req is None:                                   # dragging a grip: show the value that a typed number will set
            hot = self.hot_grip; e = self.doc.ents.get(hot[1]) if hot else None
            if e is None:
                return
            lab, val = grip_measure(e, hot[2], wp, self.grips[hot[0]][0] if hot[0] < len(self.grips) else wp)
            lines = [f"** {(hot[3] or 'stretch').upper()} **  type a value + Enter", f"{lab} {val:.3f}"]
        else:
            lines = [req.prompt.split("[")[0].strip()[:60]]
            if req.kind in ("point", "distance", "angle", "corner"):
                base = req.base
                if base is not None:
                    d = wp - base
                    q = self.ucs.to_local(wp) - self.ucs.to_local(base)
                    ang = math.degrees(math.atan2(q[1], q[0])) % 360
                    lines.append(f"L {norm(d):.3f}   ∠ {ang:.2f}°")
                else:
                    q = self.ucs.to_local(wp)
                    lines.append(f"X {q[0]:.3f}   Y {q[1]:.3f}" + (f"   Z {q[2]:.3f}" if abs(q[2]) > 1e-9 else ""))
        typed = self.ctl.typed_text()
        if typed:
            lines.append("▸ " + typed)
        px = int(self.opt.get("dyn_font_px", 13))
        f = QFont("Segoe UI"); f.setPixelSize(px); p.setFont(f); fm = QFontMetricsF(f)
        lh = fm.lineSpacing() + 2
        w = max(fm.horizontalAdvance(l) for l in lines) + 16; h = lh * len(lines) + 8
        r = QRectF(mx + 22, my + 22, w, h)
        if r.right() > self.width():
            r.moveLeft(mx - w - 20)
        if r.bottom() > self.height():
            r.moveTop(my - h - 20)
        p.setPen(QPen(QColor(46, 197, 255, 200), 1)); p.setBrush(QColor(16, 22, 32, 240) if not self.light else QColor(255, 255, 255, 245)); p.drawRoundedRect(r, 5, 5)
        p.setPen(QColor("#FFFFFF") if not self.light else QColor("#101820"))
        for i, l in enumerate(lines):
            hud_text(p, QPointF(r.left() + 8, r.top() + 5 + fm.ascent() + i * lh), l)

    def _snap_marker(self, p, kind, x, y):
        p.setPen(QPen(QColor(self.opt.get("marker_color") or "#FFC400"), 2)); p.setBrush(Qt.NoBrush); s = float(self.opt.get("marker_size", 6))
        if kind == "end":
            p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s))
        elif kind == "mid":
            p.drawPolygon(QPolygonF([QPointF(x, y - s), QPointF(x + s, y + s), QPointF(x - s, y + s)]))
        elif kind == "cen":
            p.drawEllipse(QPointF(x, y), s, s)
        elif kind == "quad":
            p.drawPolygon(QPolygonF([QPointF(x, y - s), QPointF(x + s, y), QPointF(x, y + s), QPointF(x - s, y)]))
        elif kind == "int":
            p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y - s))
        elif kind == "perp":
            p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x - s, y - s))
            p.drawLine(QPointF(x - s, y), QPointF(x, y)); p.drawLine(QPointF(x, y), QPointF(x, y + s))
        elif kind == "tan":
            p.drawEllipse(QPointF(x, y), s, s); p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y - s))
        elif kind == "near":
            p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y - s)); p.drawLine(QPointF(x + s, y - s), QPointF(x - s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y + s))
        elif kind == "node":
            p.drawEllipse(QPointF(x, y), s, s); p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y - s))
        elif kind == "img":
            p.setPen(QPen(QColor(80, 230, 140), 2)); p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s)); p.drawPoint(QPointF(x, y))
        else:
            p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s)); p.drawLine(QPointF(x - s, y), QPointF(x + s, y))

    # ---------------------------------------------------------------- ViewCube
    def _cube_geom(self):
        S = 34; cx, cy = self.width() - 70, 70
        R = self.cam.R
        faces = {"top": ((0, 0, 1), "TOP"), "bottom": ((0, 0, -1), "BOTTOM"), "front": ((0, -1, 0), "FRONT"), "back": ((0, 1, 0), "BACK"),
                 "right": ((1, 0, 0), "RIGHT"), "left": ((-1, 0, 0), "LEFT")}
        out = []
        for key, (n, lab) in faces.items():
            n = np.array(n, float)
            a = np.argmax(np.abs(n)); u = np.zeros(3); u[(a + 1) % 3] = 1; v = np.cross(n, u)
            corners = [n + u + v, n - u + v, n - u - v, n + u - v]
            pts = []
            depth = float(np.dot(n, R[:, 2]))
            for c in corners:
                q = R.T @ (c * S / 1.0 * 0.6)
                pts.append(QPointF(cx + q[0], cy - q[1]))
            out.append((depth, key, lab, QPolygonF(pts), n))
        out.sort(key=lambda t: t[0])
        return out, (cx, cy, S)

    def _draw_viewcube(self, p):
        faces, (cx, cy, S) = self._cube_geom()
        # compass ring
        p.setPen(QPen(QColor(150, 165, 185, 120), 2)); p.setBrush(Qt.NoBrush)
        ring = []
        for k in range(49):
            a = k / 48 * 2 * math.pi; w = np.array([math.cos(a), math.sin(a), -0.95]) * S * 1.15
            q = self.cam.R.T @ w; ring.append(QPointF(cx + q[0], cy - q[1]))
        p.drawPolyline(QPolygonF(ring))
        f = QFont("Segoe UI"); f.setPixelSize(9); f.setBold(True); p.setFont(f)
        hov = getattr(self, "_cube_hover", None)
        for depth, key, lab, poly, n in faces:
            if depth <= 0.02:
                continue
            col = QColor(46, 197, 255, 220) if key == hov else QColor(212, 222, 235, 235) if not self.light else QColor(235, 240, 246, 245)
            shade = int(150 + 80 * depth)
            if key != hov:
                col = QColor(min(255, shade), min(255, shade + 6), min(255, shade + 14), 235)
            p.setPen(QPen(QColor(70, 85, 105), 1)); p.setBrush(col); p.drawPolygon(poly)
            if depth > 0.3:
                c = poly.boundingRect().center()
                p.setPen(QColor(30, 40, 55)); hud_text(p, QRectF(c.x() - 30, c.y() - 8, 60, 16), Qt.AlignCenter, lab)

    def cube_hit(self, pos):
        faces, (cx, cy, S) = self._cube_geom()
        if abs(pos.x() - cx) > S * 1.6 or abs(pos.y() - cy) > S * 1.6:
            return None
        for depth, key, lab, poly, n in reversed(faces):
            if depth > 0.02 and poly.containsPoint(pos, Qt.OddEvenFill):
                # corners of the face -> iso views
                br = poly.boundingRect(); c = br.center()
                dx = (pos.x() - c.x()) / max(1, br.width() / 2); dy = (pos.y() - c.y()) / max(1, br.height() / 2)
                if abs(dx) > 0.55 and abs(dy) > 0.55 and key in ("top", "bottom"):
                    # map to iso direction
                    R = self.cam.R
                    w = R @ np.array([np.sign(dx), -np.sign(dy), 0.0]) + np.array(n) * 1.0
                    return ("dir", w)
                return ("face", key)
        return None

    def _draw_ucs_icon(self, p, fg):
        ox, oy = 46, self.height() - 46; L = 30
        cols = [QColor(240, 80, 80), QColor(80, 210, 110), QColor(90, 150, 255)]
        labels = "XYZ"
        for k, ax in enumerate((self.ucs.x, self.ucs.y, self.ucs.z)):
            q = self.cam.R.T @ ax
            if norm(q[:2]) < 0.08:
                continue
            ex, ey = ox + q[0] * L, oy - q[1] * L
            p.setPen(QPen(cols[k], 2.4)); p.drawLine(QPointF(ox, oy), QPointF(ex, ey))
            f = QFont("Segoe UI"); f.setPixelSize(11); f.setBold(True); p.setFont(f); p.setPen(cols[k])
            hud_text(p, QPointF(ex + q[0] * 8 - 4, ey - q[1] * 8 + 4), labels[k])
        p.setPen(QPen(fg, 1)); p.setBrush(fg); p.drawEllipse(QPointF(ox, oy), 2, 2)

    # ================================================================ picking
    def _projected(self):
        key = (self.cam.key(), self._built)
        if self._proj is not None and self._proj[0] == key:
            return self._proj[1]
        S, So, T, To = self._pick
        s2, sz = self.cam.project(S.reshape(-1, 3)) if len(S) else (np.zeros((0, 2)), np.zeros(0))
        t2, tz = self.cam.project(T.reshape(-1, 3)) if len(T) else (np.zeros((0, 2)), np.zeros(0))
        res = (s2.reshape(-1, 2, 2), sz.reshape(-1, 2), t2.reshape(-1, 3, 2), tz.reshape(-1, 3))
        self._proj = (key, res)
        return res

    def seg_dist(self, x, y):
        s2, sz, t2, tz = self._projected()
        if not len(s2):
            return np.zeros(0), np.zeros(0)
        a = s2[:, 0]; b = s2[:, 1]; d = b - a
        L2 = np.einsum("ij,ij->i", d, d); L2[L2 == 0] = 1e-12
        t = np.clip(((x - a[:, 0]) * d[:, 0] + (y - a[:, 1]) * d[:, 1]) / L2, 0, 1)
        px = a[:, 0] + t * d[:, 0]; py = a[:, 1] + t * d[:, 1]
        dist = np.hypot(px - x, py - y)
        depth = sz[:, 0] + t * (sz[:, 1] - sz[:, 0])
        return dist, depth

    def pick_all(self, x, y, tol=6, filt=None):
        """Every selectable object under the cursor: [(entity, screen distance)], nearest first."""
        self.build()
        S, So, T, To = self._pick
        doc = self.doc
        out = {}
        if len(S):
            dist, depth = self.seg_dist(x, y)
            m = dist <= tol
            if m.any():
                idx = np.flatnonzero(m)
                for i in idx[np.lexsort((depth[idx], dist[idx]))]:
                    eid = int(So[i])
                    if eid in out:
                        continue
                    e = doc.ents.get(eid)
                    if e is not None and doc.selectable(e) and (filt is None or filt(e)):
                        out[eid] = (e, float(dist[i]))
        b = self.pick(x, y, tol, filt, lines=False)
        if b is not None and b.id not in out:
            out[b.id] = (b, float(tol))
        return sorted(out.values(), key=lambda q: q[1])

    def pick(self, x, y, tol=6, filt=None, lines=True):
        self.build()
        S, So, T, To = self._pick
        doc = self.doc
        best = None
        if len(S) and lines:
            dist, depth = self.seg_dist(x, y)
            m = dist <= tol
            if m.any():
                idx = np.flatnonzero(m)
                order = idx[np.lexsort((depth[idx], np.round(dist[idx])))]
                for i in order:
                    eid = int(So[i]); e = doc.ents.get(eid)
                    if e is not None and doc.selectable(e) and (filt is None or filt(e)):
                        best = e; break
        if best is None and len(T):
            s2, sz, t2, tz = self._projected()
            mn = t2.min(axis=1); mx = t2.max(axis=1)
            cand = np.flatnonzero((mn[:, 0] <= x) & (mx[:, 0] >= x) & (mn[:, 1] <= y) & (mx[:, 1] >= y))
            if len(cand):
                a = t2[cand, 0]; b = t2[cand, 1]; c = t2[cand, 2]
                v0 = c - a; v1 = b - a; v2 = np.array([x, y]) - a
                d00 = np.einsum("ij,ij->i", v0, v0); d01 = np.einsum("ij,ij->i", v0, v1); d11 = np.einsum("ij,ij->i", v1, v1)
                d20 = np.einsum("ij,ij->i", v2, v0); d21 = np.einsum("ij,ij->i", v2, v1)
                den = d00 * d11 - d01 * d01; den[den == 0] = 1e-12
                u = (d11 * d20 - d01 * d21) / den; v = (d00 * d21 - d01 * d20) / den
                ins = (u >= -1e-6) & (v >= -1e-6) & (u + v <= 1 + 1e-6)
                if ins.any():
                    ci = cand[ins]; uu = u[ins]; vv = v[ins]
                    z = tz[ci, 0] * (1 - uu - vv) + tz[ci, 2] * uu + tz[ci, 1] * vv
                    owners = To[ci]
                    # images (negative ids) last
                    z = z + (owners < 0) * 10.0
                    for k in np.argsort(z):
                        eid = int(abs(owners[k])); e = doc.ents.get(eid)
                        if e is not None and doc.selectable(e) and (filt is None or filt(e)):
                            best = e; break
        return best

    def window_select(self, a, b, crossing):
        self.build()
        x0, x1 = sorted((a.x(), b.x())); y0, y1 = sorted((a.y(), b.y()))
        S, So, T, To = self._pick
        s2, sz, t2, tz = self._projected()
        ids = set()
        n_own = {}
        def inside(P):
            return (P[..., 0] >= x0) & (P[..., 0] <= x1) & (P[..., 1] >= y0) & (P[..., 1] <= y1)
        all_in = {}; any_in = {}
        if len(s2):
            ins = inside(s2)
            seg_in = ins.all(axis=1)
            seg_any = ins.any(axis=1)
            if crossing:
                # segments crossing the rectangle edges
                cr = self._seg_rect_cross(s2, x0, y0, x1, y1)
                seg_any = seg_any | cr
            for flag, store in ((seg_in, all_in), (seg_any, any_in)):
                pass
            uo, inv = np.unique(So, return_inverse=True)
            cnt = np.bincount(inv); cin = np.bincount(inv, weights=seg_in); cany = np.bincount(inv, weights=seg_any)
            for o, c, ci, ca in zip(uo, cnt, cin, cany):
                all_in[int(o)] = ci == c
                any_in[int(o)] = ca > 0
        if len(t2):
            ins = inside(t2).all(axis=1); insa = inside(t2).any(axis=1)
            uo, inv = np.unique(np.abs(To), return_inverse=True)
            cnt = np.bincount(inv); cin = np.bincount(inv, weights=ins); cany = np.bincount(inv, weights=insa)
            for o, c, ci, ca in zip(uo, cnt, cin, cany):
                o = int(o)
                all_in[o] = all_in.get(o, True) and ci == c
                any_in[o] = any_in.get(o, False) or ca > 0
        doc = self.doc
        for o in set(all_in) | set(any_in):
            ok = any_in.get(o, False) if crossing else all_in.get(o, False)
            e = doc.ents.get(o)
            if ok and e is not None and doc.selectable(e):
                ids.add(o)
        if not self.opt.get("img_window_select", False) and any(doc.ents[i].kind != "image" for i in ids):
            ids = {i for i in ids if doc.ents[i].kind != "image"}      # an underlay is not caught by a window that selects drawing objects
        return [doc.ents[i] for i in sorted(ids)]

    def window_world(self, a, b):
        """The selection rectangle (two screen corners) as 4 points on the work plane (world coordinates)."""
        out = []
        for x, y in ((a.x(), a.y()), (b.x(), a.y()), (b.x(), b.y()), (a.x(), b.y())):
            q = self.cam.screen_to_plane(x, y, self.ucs)
            if q is None:
                return None
            out.append(q)
        return np.array(out)

    def window_hits(self, a, b, filt=None):
        """Objects crossed by the rectangle a-b with the places where they cross: [(entity, world point)], one entry for
        every separate stretch of an object inside the rectangle (TRIM / EXTEND with a crossing window)."""
        self.build()
        x0, x1 = sorted((a.x(), b.x())); y0, y1 = sorted((a.y(), b.y()))
        S, So, T, To = self._pick
        if not len(S):
            return []
        s2, sz, t2, tz = self._projected()
        P0 = s2[:, 0]; D = s2[:, 1] - s2[:, 0]
        t_in = np.zeros(len(s2)); t_out = np.ones(len(s2)); ok = np.ones(len(s2), bool)
        for pk, qk in ((-D[:, 0], P0[:, 0] - x0), (D[:, 0], x1 - P0[:, 0]), (-D[:, 1], P0[:, 1] - y0), (D[:, 1], y1 - P0[:, 1])):   # Liang-Barsky
            par = np.abs(pk) < 1e-12
            ok &= ~(par & (qk < 0))
            with np.errstate(divide="ignore", invalid="ignore"):
                r = np.where(par, 0.0, qk / np.where(par, 1.0, pk))
            t_in = np.where(~par & (pk < 0), np.maximum(t_in, r), t_in)
            t_out = np.where(~par & (pk > 0), np.minimum(t_out, r), t_out)
        ok &= t_in <= t_out
        doc = self.doc; out = []
        idx = np.flatnonzero(ok)
        if not len(idx):
            return []
        runs = {}
        for i in idx:                                       # consecutive segments of the same object = one crossing
            o = int(So[i]); r = runs.setdefault(o, [])
            if r and r[-1][-1] == i - 1:
                r[-1].append(i)
            else:
                r.append([i])
        for o, rr in runs.items():
            e = doc.ents.get(o)
            if e is None or not doc.selectable(e) or (filt is not None and not filt(e)):
                continue
            for run in rr:
                i = run[len(run) // 2]; t = (t_in[i] + t_out[i]) / 2
                out.append((e, S[i, 0] + (S[i, 1] - S[i, 0]) * t))
        return out

    @staticmethod
    def _seg_rect_cross(s2, x0, y0, x1, y1):
        a = s2[:, 0]; b = s2[:, 1]
        res = np.zeros(len(s2), bool)
        edges = [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)), ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
        for (cx, cy), (dx, dy) in edges:
            c = np.array([cx, cy]); d = np.array([dx, dy])
            def orient(p, q, r):
                return (q[..., 0] - p[..., 0]) * (r[..., 1] - p[..., 1]) - (q[..., 1] - p[..., 1]) * (r[..., 0] - p[..., 0])
            o1 = orient(a, b, c); o2 = orient(a, b, d)
            o3 = orient(np.broadcast_to(c, a.shape), np.broadcast_to(d, a.shape), a); o4 = orient(np.broadcast_to(c, a.shape), np.broadcast_to(d, a.shape), b)
            res |= (o1 * o2 < 0) & (o3 * o4 < 0)
        return res

    # ================================================================ OSNAP
    def compute_snap(self, x, y, base=None):
        if not self.osnap_on and not self.snap_override:
            return None
        self.build()
        S, So, T, To = self._pick
        doc = self.doc
        ap = self.aperture
        cand = []
        hov = None; hov_d = 1e9
        if len(S):
            dist, depth = self.seg_dist(x, y)
            m = dist <= ap * 1.4
            if m.any():
                idx = np.flatnonzero(m); idx = idx[np.argsort(dist[idx])]
                seen = []
                for i in idx:
                    o = int(So[i])
                    e0 = doc.ents.get(o)
                    if e0 is None or not doc.selectable(e0):
                        continue                   # locked / frozen layers do not attract the cursor
                    if o not in seen:
                        seen.append(o)
                        if hov is None:
                            hov = o; hov_d = float(dist[i])
                    if len(seen) >= 8:
                        break
                cand = seen
        pb = float(self.opt.get("pickbox", 5)) + 2
        if hov_d > pb:
            hov = None                         # the cursor is not on an object: plain nearest-point rule
        for o in cand:
            if o in self._recent:
                self._recent.remove(o)
            self._recent.insert(0, o)
        del self._recent[6:]
        pool = list(dict.fromkeys(cand + self._recent))
        ents = [doc.ents[o] for o in pool if o in doc.ents]
        best = None
        def consider(kind, P, prio=0, owner=None):
            nonlocal best
            P = np.asarray(P, float).reshape(-1, 3)
            if not len(P):
                return
            s2, z = self.cam.project(P)
            d = np.hypot(s2[:, 0] - x, s2[:, 1] - y)
            k = int(np.argmin(d))
            # points of the object under the cursor win over points of neighbours that are only a few pixels closer
            score = d[k] - (ap * 0.45 if (hov is not None and owner == hov) else 0.0)
            if d[k] <= ap and (best is None or (prio, score) < (best[2], best[4])):
                best = (kind, P[k].copy(), prio, d[k], score)
        modes = {self.snap_override} if self.snap_override else self.snap_modes
        def local_prims(e):
            """Primitives of e; for a big block only its segments near the cursor."""
            if getattr(e, "heavy", None) is not None and e.heavy() and len(S):
                near = np.flatnonzero((So == e.id) & (dist <= ap * 3))
                return [("L", S[i, 0], S[i, 1]) for i in near[:400]]
            return e.prims()
        for e in ents:
            try:
                sn = e.snaps()
            except Exception:
                continue
            for kind in ("end", "mid", "cen", "quad", "node", "ins"):
                if kind in modes and kind in sn and (e.id in cand or kind in ("cen", "node", "ins")):
                    consider(kind, sn[kind], 0, e.id)
        touched = [doc.ents[o] for o in cand[:5] if o in doc.ents]
        if "int" in modes and len(touched) >= 1:
            pts = []
            prs = []
            for e in touched:
                pr = local_prims(e)
                if len(pr) > 400:
                    pr = [q for q in pr if self._prim_near(q, x, y, ap * 3)]
                prs.append(pr)
            for i in range(len(touched)):
                for j in range(i + 1, len(touched)):
                    for a in prs[i]:
                        for b in prs[j]:
                            for sa, sb, q in prim_intersect(a, b):
                                pts.append(q)
            if pts:
                consider("int", pts, 0)
        if best is None and base is not None:
            if "perp" in modes:
                pts = []
                for e in touched:
                    for pr in local_prims(e)[:400]:
                        if pr[0] == "L":
                            a, b = pr[1], pr[2]; d = b - a; L2 = np.dot(d, d)
                            if L2 > 0:
                                t = np.dot(base - a, d) / L2
                                if -1e-9 <= t <= 1 + 1e-9:
                                    pts.append(a + t * d)
                        else:
                            c, r, n, u = pr[1:5]
                            dd = base - c; dd = dd - np.dot(dd, n) * n
                            if norm(dd) > EPS:
                                pts.append(c + unit(dd) * r)
                if pts:
                    consider("perp", pts, 1)
            if "tan" in modes:
                pts = []
                for e in touched:
                    for pr in local_prims(e)[:50]:
                        if pr[0] == "A":
                            c, r, n, u = pr[1:5]
                            dd = base - c; dd = dd - np.dot(dd, n) * n; L = norm(dd)
                            if L > r:
                                a = math.acos(r / L); ux = unit(dd); vy = np.cross(n, ux)
                                for s in (1, -1):
                                    pts.append(c + r * (math.cos(a) * ux + s * math.sin(a) * vy))
                if pts:
                    consider("tan", pts, 1)
        if best is None and "near" in modes and touched and hov is not None:
            e = doc.ents[hov]
            pts = []
            for pr in local_prims(e)[:2000]:
                P = prim_tess(pr) if pr[0] == "A" else np.array([pr[1], pr[2]])
                s2, z = self.cam.project(P)
                for k in range(len(P) - 1):
                    a, b = s2[k], s2[k + 1]; d = b - a; L2 = np.dot(d, d)
                    if L2 <= 0:
                        continue
                    t = min(1, max(0, ((x - a[0]) * d[0] + (y - a[1]) * d[1]) / L2))
                    if np.hypot(*(a + t * d - [x, y])) <= ap:
                        pts.append(P[k] + t * (P[k + 1] - P[k]))
            if pts:
                consider("near", pts, 2)
        if best is None and "img" in modes and getattr(self, "images", None):
            q = self._image_snap(x, y)
            if q is not None:
                best = ("img", q, 3, 0, 0)
        return best

    def _prim_near(self, pr, x, y, tol):
        P = np.array(prim_ends(pr)) if pr[0] == "L" else prim_tess(pr)[::8]
        s2, _ = self.cam.project(P)
        mn = s2.min(axis=0) - tol; mx = s2.max(axis=0) + tol
        return mn[0] <= x <= mx[0] and mn[1] <= y <= mx[1]

    def _image_snap(self, x, y):
        from ..core import raster
        for e in self.images:
            pl = Plane(e.o, e.u, e.v)
            ro, rd = self.cam.ray(x, y)
            q = pl.ray_hit(ro, rd)
            if q is None:
                continue
            px, py = e.world_to_pixel(q)
            if not (0 <= px < e.wpx and 0 <= py < e.hpx):
                continue
            sk = raster.skeleton_cached(e)
            if sk is None:
                continue
            scale = sk.shape[1] / e.wpx
            apx = self.aperture * self.cam.px() / (norm(e.u) / e.wpx) * scale
            r = raster.nearest_on(sk, px * scale, py * scale, max(2, apx))
            if r is not None:
                return e.pixel_to_world(r[0] / scale, r[1] / scale)
        return None

    # ================================================================ grips
    def _compute_grips(self):
        out = []
        doc = self.doc
        for eid in self.selection[:60]:
            e = doc.ents.get(eid)
            if e is None:
                continue
            for gi, pt in enumerate(grip_points(e)):
                out.append((pt, eid, gi))
        return out

    def grip_at(self, x, y):
        for i, (pt, eid, gi) in enumerate(self.grips):
            s, _ = self.cam.project(pt[None])
            g = float(self.opt.get("grip_size", 4)) + 2
            if abs(s[0, 0] - x) <= g and abs(s[0, 1] - y) <= g:
                return i
        return None

    # ================================================================ view control
    def zoom_extents(self, ents=None, animate=True):
        bb = self.doc.extents(ents)
        if bb is None:
            bb = (np.array([-100, -100, 0.0]), np.array([100, 100, 0.0]))
        c = (bb[0] + bb[1]) / 2
        corners = np.array([[bb[i][0], bb[j][1], bb[k][2]] for i in (0, 1) for j in (0, 1) for k in (0, 1)])
        q = (corners - c) @ self.cam.R
        w = np.ptp(q[:, 0]); h = np.ptp(q[:, 1])
        a = self.cam.W / max(1, self.cam.H)
        hh = max(h, w / a, 1e-6) * 1.12
        self._animate_to(c, self.cam.R, hh if norm(bb[1] - bb[0]) > 0 else 100, dur=None if animate else 0.0)

    def zoom_window(self, a, b):
        x0, x1 = sorted((a.x(), b.x())); y0, y1 = sorted((a.y(), b.y()))
        if x1 - x0 < 4 or y1 - y0 < 4:
            return
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        ro, rd = self.cam.ray(cx, cy)
        c = Plane(self.cam.target, self.cam.right(), self.cam.up()).ray_hit(ro, rd)
        hh = max((y1 - y0), (x1 - x0) * self.cam.H / max(1, self.cam.W)) * self.cam.px()
        self._animate_to(c, self.cam.R, hh)

    def set_view(self, name=None, direction=None):
        if name in VIEWS:
            R = R_view(*VIEWS[name])
        else:
            d = unit(np.asarray(direction, float))
            up = (0, 0, 1) if abs(d[2]) < 0.999 else (0, 1, 0)
            R = R_view(d, up)
        self._animate_to(self.cam.target, R, self.cam.h)

    def plan_view(self, pl):
        R = np.stack([pl.x, pl.y, pl.z], axis=1)
        self._animate_to(self.cam.target, R, self.cam.h)

    def _animate_to(self, target, R, h, dur=None):
        dur = float(self.opt.get("anim_ms", 280)) / 1000.0 if dur is None else dur
        if not self.opt.get("anim", True) or dur <= 0.0:
            self.cam.target = np.asarray(target, float); self.cam.R = np.asarray(R, float); self.cam.h = float(h)
            self._anim = None; self._proj = None; self.update(); self.view_changed.emit(); return
        self._anim = (time.time(), dur, self.cam.target.copy(), quat_from_R(self.cam.R), self.cam.h, np.asarray(target, float), quat_from_R(R), float(h))
        if not self.timer.isActive():
            self.timer.start(15)

    def _tick(self):
        if self._anim is None:
            self.timer.stop(); return
        t0, dur, ta, qa, ha, tb, qb, hb = self._anim
        t = min(1.0, (time.time() - t0) / dur)
        s = t * t * (3 - 2 * t)
        self.cam.target = ta + (tb - ta) * s
        self.cam.R = R_from_quat(slerp(qa, qb, s))
        self.cam.h = ha * (hb / ha) ** s if ha > 0 and hb > 0 else hb
        if t >= 1.0:
            self.cam.R = R_from_quat(qb); self._anim = None; self.timer.stop()
        self._proj = None; self.update(); self.view_changed.emit()

    def zoom_at(self, x, y, f):
        ro, rd = self.cam.ray(x, y)
        P = Plane(self.cam.target, self.cam.right(), self.cam.up())
        q = P.ray_hit(ro, rd) if not self.cam.persp else self._depth_point(x, y)
        self.cam.h *= f
        if q is not None:
            self.cam.target = q + (self.cam.target - q) * f
        self._proj = None; self.update(); self.view_changed.emit()

    def _depth_point(self, x, y):
        e = self.pick(x, y, 8)
        ro, rd = self.cam.ray(x, y)
        P = Plane(self.cam.target, self.cam.right(), self.cam.up())
        return P.ray_hit(ro, rd)

    def pan_px(self, dx, dy):
        k = self.cam.px()
        self.cam.target = self.cam.target - self.cam.right() * dx * k + self.cam.up() * dy * k
        self._proj = None; self.update(); self.view_changed.emit()

    def orbit_px(self, dx, dy, pivot=None):
        a = -dx * 0.008; b = -dy * 0.008
        from ..core.geom import m_rotate
        Rz = m_rotate((0, 0, 0), (0, 0, 1), a)[:3, :3]
        R = Rz @ self.cam.R
        Rx = m_rotate((0, 0, 0), R[:, 0], b)[:3, :3]
        R2 = Rx @ R
        if R2[2, 1] < -1e-3 and False:
            R2 = R
        piv = self.cam.target if pivot is None else pivot
        rel = self.cam.target - piv
        self.cam.target = piv + (Rx @ Rz) @ rel
        self.cam.R = R2
        self._proj = None; self.update(); self.view_changed.emit()

    # ================================================================ point resolution
    def world_point(self, x, y, base=None, constrain=True):
        """Mouse -> snapped world point. Returns (point, snap_kind).
        constrain=False: ortho / polar are not applied (opposite corner of a rectangle or window, like AutoCAD)."""
        req = self.ctl.req
        if req is not None and req.kind == "corner" and self.hot_grip is None:
            constrain = False
        hit = self.compute_snap(x, y, base)
        self.otracks = []
        if hit is not None:
            self._acq_watch(hit)
            return hit[1], hit[0]
        self._acq_watch(None)
        self.track = None
        tp = self._otrack_point(x, y, base, constrain)
        if tp is not None:
            return tp, None
        q = self.cam.screen_to_plane(x, y, self.ucs)
        if q is None:
            q = self.cam.target.copy()
        loc = self.ucs.to_local(q)
        o = self.opt
        sx = float(o.get("snap_step", 10.0) or 10.0); sy = float(o.get("snap_y", 0) or 0) or sx
        polar_snap = o.get("snap_type", "Grid") == "Polar"
        if self.polar_on and not self.ortho and base is not None and constrain:
            b = self.ucs.to_local(base); d = loc - b; L = math.hypot(d[0], d[1])
            if L > 1e-9:
                inc = max(0.1, float(self.polar_inc)); angs = set()
                k = 0.0
                while k < 360.0 - 1e-9:
                    angs.add(round(k, 6)); k += inc
                for a in (o.get("polar_extra") or []):
                    try:
                        angs.add(float(a) % 360.0)
                    except (TypeError, ValueError):
                        pass
                a0 = math.degrees(math.atan2(d[1], d[0])) % 360.0
                best = None
                for a in angs:
                    da = abs((a0 - a + 180.0) % 360.0 - 180.0)
                    if best is None or da < best[0]:
                        best = (da, a)
                ra = math.radians(best[1]); u = np.array([math.cos(ra), math.sin(ra)])
                t = float(np.dot(d[:2], u)); off = abs(float(d[0] * u[1] - d[1] * u[0]))
                if t > 0 and off / max(self.cam.px(), 1e-12) <= float(o.get("polar_px", 10)):
                    if self.snap_on and polar_snap:
                        pd = float(o.get("polar_dist", 0) or 0) or sx
                        t = max(pd, round(t / pd) * pd)
                    loc[:2] = b[:2] + u * t; loc[2] = b[2]
                    self.track = (self.ucs.to_world(b), self.ucs.to_world(loc), best[1], t)
                    return self.ucs.to_world(loc), None
        if self.snap_on and not polar_snap:
            loc[0] = round(loc[0] / sx) * sx; loc[1] = round(loc[1] / sy) * sy
        if self.ortho and base is not None and constrain:
            b = self.ucs.to_local(base)
            d = loc - b
            if abs(d[0]) >= abs(d[1]):
                loc[1] = b[1]
            else:
                loc[0] = b[0]
            loc[2] = b[2]
        return self.ucs.to_world(loc), None

    # ---------------------------------------------------------------- object snap tracking (OTRACK, F11)
    ACQ_KINDS = ("end", "mid", "cen", "quad", "int", "node", "ins")

    def _acq_watch(self, hit):
        """Pausing the cursor on an object snap point acquires it (a small + appears); pausing again releases it."""
        req = self.ctl.req
        if not self.otrack_on or req is None or req.kind not in ("point", "distance", "angle", "corner") or hit is None or hit[0] not in self.ACQ_KINDS:
            self._acq_cand = None; self._acq_timer.stop(); return
        c = (hit[0], tuple(np.round(hit[1], 6)))
        if c != self._acq_cand:
            self._acq_cand = c; self._acq_timer.start(int(self.opt.get("otrack_ms", 450)))

    def _acquire(self):
        c = self._acq_cand
        if c is None or self.ctl.req is None:
            return
        for i, a in enumerate(self.acquired):
            if a[1] == c[1]:
                self.acquired.pop(i); self.update(); return
        self.acquired.append(c)
        if len(self.acquired) > 7:
            self.acquired.pop(0)
        self.update()

    def _otrack_point(self, x, y, base, constrain=True):
        """Cursor aligned with an acquired point (0 / 90 deg, or every polar angle): the point on that tracking path,
        or the intersection of two paths / of a path with the ortho or polar direction from the base point."""
        req = self.ctl.req
        if not (self.otrack_on and self.acquired and req is not None and req.kind in ("point", "distance", "angle", "corner")):
            return None
        q = self.cam.screen_to_plane(x, y, self.ucs)
        if q is None:
            return None
        ucs = self.ucs; loc = ucs.to_local(q)[:2]; px = max(self.cam.px(), 1e-12); tol = float(self.opt.get("polar_px", 10)) * px
        if self.opt.get("otrack_polar", False):
            inc = max(1.0, float(self.polar_inc)); angs = [k * inc for k in range(int(round(180.0 / inc)))] or [0.0, 90.0]
        else:
            angs = [0.0, 90.0]
        paths = []                                    # (distance of the cursor, origin, direction, world origin, angle, kind)
        for kind, A in self.acquired:
            A = np.array(A, float); a = ucs.to_local(A)[:2]
            if math.hypot(*(loc - a)) < tol * 0.6:
                continue
            for ang in angs:
                r = math.radians(ang); u = np.array([math.cos(r), math.sin(r)])
                d = abs(float((loc - a)[0] * u[1] - (loc - a)[1] * u[0]))
                if d <= tol:
                    paths.append((d, a, u, A, ang, kind))
        if not paths:
            return None
        paths.sort(key=lambda t: t[0])
        zb = ucs.to_local(base)[2] if base is not None else ucs.to_local(q)[2]
        def cross(a1, u1, a2, u2):
            den = u1[0] * u2[1] - u1[1] * u2[0]
            if abs(den) < 1e-9:
                return None
            w = a2 - a1; t = (w[0] * u2[1] - w[1] * u2[0]) / den
            return a1 + t * u1
        first = paths[0]; pt = None; used = [first]
        for other in paths[1:]:
            X = cross(first[1], first[2], other[1], other[2])
            if X is not None and math.hypot(*(X - loc)) <= tol * 1.5:
                pt = X; used.append(other); break
        if pt is None and base is not None and constrain and (self.ortho or self.polar_on):
            b = ucs.to_local(base)[:2]; d = loc - b
            if self.ortho:
                ub = np.array([1.0, 0.0]) if abs(d[0]) >= abs(d[1]) else np.array([0.0, 1.0])
            else:
                inc = max(0.1, float(self.polar_inc)); a0 = math.degrees(math.atan2(d[1], d[0])); ra = math.radians(round(a0 / inc) * inc)
                ub = np.array([math.cos(ra), math.sin(ra)])
            X = cross(first[1], first[2], b, ub)
            if X is not None and math.hypot(*(X - loc)) <= tol * 1.5:
                pt = X
        if pt is None:
            a, u = first[1], first[2]; pt = a + u * float(np.dot(loc - a, u))
        P = ucs.to_world(np.array([pt[0], pt[1], zb]))
        self.otracks = [(t[3], P, t[4], t[5]) for t in used]
        return P

    # ================================================================ events
    def mouseMoveEvent(self, ev):
        pos = ev.position(); self.mouse = pos
        if self.drag and self.drag[0] in ("pan", "orbit"):
            last = self.drag[2]
            dx, dy = pos.x() - last.x(), pos.y() - last.y()
            if self.drag[0] == "pan":
                self.pan_px(dx, dy)
            else:
                if not self.drag[3] and abs(pos.x() - self.drag[1].x()) + abs(pos.y() - self.drag[1].y()) > 4:
                    self.drag = (self.drag[0], self.drag[1], last, True)
                if self.drag[3]:
                    self.orbit_px(dx, dy, self.drag[4] if len(self.drag) > 4 else None)
            self.drag = (self.drag[0], self.drag[1], pos) + tuple(self.drag[3:])
            return
        req = self.ctl.req
        base = req.base if req is not None else None
        hk = getattr(self, "_cube_hover", None)
        ch = self.cube_hit(pos)
        self._cube_hover = ch[1] if ch and ch[0] == "face" else None
        if req is not None and req.kind in ("point", "distance", "angle", "corner") or self.hot_grip is not None:
            if self.hot_grip is not None:
                base = self.grips[self.hot_grip[0]][0] if self.hot_grip[0] < len(self.grips) else None
            wp, kind = self.world_point(pos.x(), pos.y(), base)
            self.snap_hit = (kind, wp) if kind else None
            self.mouse_world = wp
            if self.hot_grip is not None:
                self.preview = self.ctl.grip_preview(self.hot_grip, wp)
            elif req.preview is not None:
                try:
                    self.preview = [e for e in (req.preview(wp) or []) if e is not None]
                except Exception:
                    self.preview = []
            self.hover = None
        else:
            self.snap_hit = None
            q = self.cam.screen_to_plane(pos.x(), pos.y(), self.ucs)
            if q is not None:
                self.mouse_world = q
            if not self.drag and time.time() - self._last_move > 0.03:
                filt = req.filter if (req is not None and req.kind == "entity") else None
                e = self.pick(pos.x(), pos.y(), self.opt.get('pickbox', 5) + 1, filt)
                self.hover = e.id if e is not None else None
                self._last_move = time.time()
            if req is None and self.grips and not self.drag and self.hot_grip is None:
                g = self.grip_at(pos.x(), pos.y())
                if g is not None:
                    if g != self._ghover:
                        self._ghover = g; self._gtimer.start(int(self.opt.get("grip_menu_ms", 450)))
                else:
                    self._ghover = None; self._gtimer.stop()
                    gm = self._gmenu
                    if gm is not None and gm.isVisible() and not gm.geometry().adjusted(-18, -18, 18, 18).contains(pos.toPoint()):
                        gm.hide()
        self.mouse_moved.emit(self.mouse_world)
        self.update()

    def mousePressEvent(self, ev):
        pos = ev.position(); self.mouse = pos
        if getattr(self.ctl, "view", self) is not self and hasattr(self.ctl, "activate_view"):
            self.ctl.activate_view(self)
        self.setFocus()
        if self._gmenu is not None and self._gmenu.isVisible():
            self._gmenu.hide()
        if ev.button() == Qt.MiddleButton:
            if ev.modifiers() & Qt.ShiftModifier:
                self.drag = ("orbit", pos, pos, True)
            else:
                self.drag = ("pan", pos, pos)
            return
        if ev.button() == Qt.RightButton:
            piv = None
            if self.selection and self.opt.get("orbit_sel", True):
                bb = self.doc.extents([self.doc.ents[i] for i in self.selection if i in self.doc.ents])
                if bb is not None:
                    piv = (bb[0] + bb[1]) / 2
            self.drag = ("orbit", pos, pos, False, piv)
            return
        if ev.button() != Qt.LeftButton:
            return
        ch = self.cube_hit(pos)
        if ch is not None:
            if ch[0] == "face":
                self.set_view(ch[1])
            else:
                self.set_view(direction=ch[1])
            return
        req = self.ctl.req
        if self.click_win is not None:                      # second click of a click-click window
            a = self.click_win; self.click_win = None
            if abs(pos.x() - a.x()) < 3 and abs(pos.y() - a.y()) < 3:
                self.update(); return
            if getattr(self.ctl, "zoom_window_pending", False):
                self.ctl.zoom_window_pending = False; self.zoom_window(a, pos); return
            ents = self.window_select(a, pos, pos.x() < a.x())
            self.ctl.pick_window(ents, bool(ev.modifiers() & Qt.ShiftModifier), (a, pos))
            self.update(); return
        if self.hot_grip is not None:
            base = self.grips[self.hot_grip[0]][0] if self.hot_grip[0] < len(self.grips) else None
            wp, kind = self.world_point(pos.x(), pos.y(), base)
            self.ctl.grip_finish(self.hot_grip, wp); self.hot_grip = None; self.preview = []; self.update()
            return
        if req is not None and req.kind in ("point", "distance", "angle", "corner"):
            wp, kind = self.world_point(pos.x(), pos.y(), req.base)
            self.ctl.feed_point(wp)
            return
        if req is not None and req.kind == "entity":
            e = self._cycle_pick(pos, req.filter)
            if e is not None:
                q = self.cam.screen_to_plane(pos.x(), pos.y(), self.ucs)
                ps = self._pick_point_on(e, pos.x(), pos.y())
                self.ctl.feed_entity(e, ps if ps is not None else q)
            elif getattr(req, "window", False):                # empty spot: a window / fence picks several objects at once
                self.drag = ("window", pos, pos)
            return
        # idle or selection request
        if req is None:
            g = self.grip_at(pos.x(), pos.y())
            if g is not None:
                ge, gi = self._grip_entity(g)
                if ge is not None and ge.kind == "insert" and gi >= 1:
                    kind, prm = ge.dyn_grip_kind(gi - 1)
                    if kind == "flip":                               # flip grip: one click flips
                        self.ctl.grip_finish((g, ge.id, gi, None), None); self.update(); return
                    if kind == "visibility":                         # visibility grip: list of states
                        from PySide6.QtWidgets import QMenu
                        m = QMenu(self); cur = ge.dyn_value(prm)
                        for st in prm.get("states", []):
                            a_ = m.addAction(st); a_.setCheckable(True); a_.setChecked(st == cur)
                        a_ = m.exec(self.mapToGlobal(pos.toPoint() + QPoint(10, 10)))
                        if a_ is not None:
                            self.ctl.grip_finish((g, ge.id, gi, None), a_.text())
                        self.update(); return
                self.hot_grip = (g, self.grips[g][1], self.grips[g][2], None); self.update()
                return
        e = self._cycle_pick(pos, req.filter if req is not None else None)
        if e is not None:
            self.ctl.pick_entity(e, bool(ev.modifiers() & Qt.ShiftModifier))
            self.update()
            return
        self.drag = ("window", pos, pos)

    def refresh_preview(self):
        """Recompute the rubber-band preview at the current cursor position (called after every accepted input)."""
        req = self.ctl.req
        if req is None or req.preview is None or req.kind not in ("point", "distance", "angle", "corner"):
            return
        if self.mouse.x() < 0 or self.mouse.y() < 0:
            return
        try:
            wp, kind = self.world_point(self.mouse.x(), self.mouse.y(), req.base)
            self.mouse_world = wp
            self.preview = [e for e in (req.preview(wp) or []) if e is not None]
        except Exception:
            self.preview = []

    def curve_at_cursor(self, tol=None):
        """(entity, world point on it, unit tangent) for the line / curve under the cursor, else None."""
        x, y = self.mouse.x(), self.mouse.y()
        e = self.pick(x, y, tol or max(8, self.aperture), lambda q: q.kind in ("line", "polyline", "arc", "circle", "spline", "ellipse"))
        if e is None:
            return None
        best = None
        try:
            prs = e.prims()[:3000]
        except Exception:
            return None
        for pr in prs:
            P = prim_tess(pr) if pr[0] == "A" else np.array([pr[1], pr[2]])
            s2, z = self.cam.project(P)
            for k in range(len(P) - 1):
                a, b = s2[k], s2[k + 1]; d = b - a; L2 = np.dot(d, d)
                t = 0 if L2 <= 0 else min(1, max(0, ((x - a[0]) * d[0] + (y - a[1]) * d[1]) / L2))
                dist = np.hypot(*(a + t * d - [x, y]))
                if best is None or dist < best[0]:
                    best = (dist, P[k] + t * (P[k + 1] - P[k]), P[k + 1] - P[k])
        if best is None or np.linalg.norm(best[2]) < 1e-12:
            return None
        return e, best[1], best[2] / np.linalg.norm(best[2])

    def _pick_point_on(self, e, x, y):
        """World point on entity e under cursor (for trim / fillet picks)."""
        best = None
        for pr in e.prims()[:3000]:
            P = prim_tess(pr) if pr[0] == "A" else np.array([pr[1], pr[2]])
            s2, z = self.cam.project(P)
            for k in range(len(P) - 1):
                a, b = s2[k], s2[k + 1]; d = b - a; L2 = np.dot(d, d)
                t = 0 if L2 <= 0 else min(1, max(0, ((x - a[0]) * d[0] + (y - a[1]) * d[1]) / L2))
                dist = np.hypot(*(a + t * d - [x, y]))
                if best is None or dist < best[0]:
                    best = (dist, P[k] + t * (P[k + 1] - P[k]))
        return best[1] if best else None

    def mouseReleaseEvent(self, ev):
        pos = ev.position()
        if self.drag is None:
            return
        kind = self.drag[0]
        if kind == "orbit" and ev.button() == Qt.RightButton:
            moved = self.drag[3]
            self.drag = None
            if not moved:
                g = self.grip_at(pos.x(), pos.y()) if (self.ctl.req is None and self.grips) else None
                if g is not None and self._grip_context(g, ev.globalPosition().toPoint()):
                    return
                if ev.modifiers() & Qt.ShiftModifier:
                    self.ctl.osnap_menu(ev.globalPosition().toPoint(), override=True)      # AutoCAD: Shift + right-click = snap override
                else:
                    self.ctl.right_click(ev.globalPosition().toPoint())
            return
        if kind == "pan" and ev.button() == Qt.MiddleButton:
            self.drag = None; return
        if kind == "orbit":
            self.drag = None; return
        if kind == "window" and ev.button() == Qt.LeftButton:
            a = self.drag[1]; self.drag = None
            if abs(pos.x() - a.x()) < 3 and abs(pos.y() - a.y()) < 3:
                if self.opt.get("pickdrag", "Both") != "Press and drag":
                    self.click_win = a              # click, move, click (AutoCAD implied windowing); Esc cancels
                elif self.ctl.req is None and not (ev.modifiers() & Qt.ShiftModifier):
                    self.ctl.clear_selection()
                self.update(); return
            if getattr(self.ctl, "zoom_window_pending", False):
                self.ctl.zoom_window_pending = False; self.zoom_window(a, pos); return
            ents = self.window_select(a, pos, pos.x() < a.x())
            self.ctl.pick_window(ents, bool(ev.modifiers() & Qt.ShiftModifier), (a, pos))
            self.update()

    def mouseDoubleClickEvent(self, ev):
        if ev.button() == Qt.MiddleButton:
            self.zoom_extents()
        elif ev.button() == Qt.LeftButton and self.ctl.req is None:
            e = self.pick(ev.position().x(), ev.position().y(), self.opt.get('pickbox', 5) + 1) if self.opt.get('dblclick_edit', True) else None
            if e is not None:
                self.ctl.edit_entity(e)

    def wheelEvent(self, ev):
        d = ev.angleDelta().y()
        if d == 0:
            return
        zf = min(100.0, max(3.0, float(self.opt.get("zoom_factor", 60))))        # AutoCAD ZOOMFACTOR 3..100
        f = (1.0 - 0.25 * zf / 100.0) ** (d / 120)
        if self.opt.get("wheel_reverse", False):
            f = 1.0 / f
        self.zoom_at(ev.position().x(), ev.position().y(), f)

    def leaveEvent(self, ev):
        self.hover = None; self.update()

    def keyPressEvent(self, ev):
        if self.hot_grip is not None and ev.key() == Qt.Key_Control:
            self._cycle_grip_mode(); return
        if getattr(self.ctl, "view", self) is not self and hasattr(self.ctl, "activate_view"):
            self.ctl.activate_view(self)
        self.ctl.viewport_key(ev)

    # ================================================================ selection cycling (overlapping objects)
    def _cycle_pick(self, pos, filt=None):
        tol = self.opt.get('pickbox', 5) + 1
        if not self.sel_cycling:
            return self.pick(pos.x(), pos.y(), tol, filt)
        c = self.pick_all(pos.x(), pos.y(), tol, filt)
        if not c:
            return None
        same = [e for e, d in c if d - c[0][1] <= 1.5]
        if len(same) < 2:
            return c[0][0]
        return self._cycle_menu(same[:20], pos)

    def _cycle_menu(self, ents, pos):
        from PySide6.QtWidgets import QMenu
        m = QMenu(self); m.setToolTipsVisible(True)
        t = m.addAction(f"Selection - {len(ents)} overlapping objects"); t.setEnabled(False); m.addSeparator()
        acts = {}
        for e in ents:
            col = e.color if not isinstance(e.color, int) else ("ByLayer" if e.color in (256, 0) else f"ACI {e.color}")
            name = getattr(e, "name", "") if e.kind == "insert" else ""
            a = m.addAction(f"{e.label}{'  ' + name if name else ''}   ·   layer {e.layer}   ·   {col}")
            acts[a] = e
        m.hovered.connect(lambda a: (setattr(self, "hover", acts[a].id) if a in acts else None, self.update()))
        a = exec_menu(m, self.mapToGlobal(pos.toPoint() + QPoint(18, 10)))
        self.hover = None; self.update()
        return acts.get(a)

    # ================================================================ multi-function grips (polyline vertex / midpoint)
    PARAM_COL = {"linear": "#FF9F1A", "polar": "#FF6FB5", "xy": "#00D1B2", "point": "#FFD43B", "rotation": "#4DABF7", "flip": "#B37CFF",
                 "visibility": "#69DB7C"}

    def _label(self, p, at, text, col):
        from PySide6.QtGui import QPainterPath, QFontMetricsF
        f9 = QFont("Segoe UI"); f9.setPixelSize(12); f9.setBold(True)
        tw = QFontMetricsF(f9).horizontalAdvance(text)
        r = QRectF(at.x() - tw / 2 - 6, at.y() - 24, tw + 12, 18)
        p.setPen(Qt.NoPen); p.setBrush(QColor(20, 24, 32, 215)); p.drawRoundedRect(r, 4, 4)
        pp = QPainterPath(); pp.addText(QPointF(at.x() - tw / 2, at.y() - 10.5), f9, text)       # outline text: no GL glyph cache needed
        p.setBrush(QColor(col)); p.drawPath(pp)

    def _draw_param(self, p, prm, acts):
        """Block Editor: draw one dynamic parameter, its grip and the actions attached to it."""
        t = prm["type"]; col = QColor(self.PARAM_COL.get(t, "#FF9F1A"))
        P0 = np.asarray(prm.get("p0", (0, 0, 0)), float); P1 = np.asarray(prm.get("p1", prm.get("p0", (0, 0, 0))), float)
        s2, _ = self.cam.project(np.array([P0, P1], float)); a, b = QPointF(*s2[0]), QPointF(*s2[1])
        def diamond(q):
            p.setPen(QPen(QColor("white"), 1)); p.setBrush(col)
            p.drawPolygon(QPolygonF([q + QPointF(0, -7), q + QPointF(7, 0), q + QPointF(0, 7), q + QPointF(-7, 0)]))
        dim_mid = None
        if t in ("linear", "polar") and math.hypot(b.x() - a.x(), b.y() - a.y()) > 4:
            # shown like a dimension (AutoCAD / GstarCAD): extension lines, dimension line with arrows, the name on it
            dx, dy = b.x() - a.x(), b.y() - a.y(); L = math.hypot(dx, dy); ux, uy = dx / L, dy / L; nx, ny = -uy, ux
            off = min(max(L * 0.22, 26.0), 70.0)
            if prm.get("lp") is not None:
                l2, _ = self.cam.project(np.array([prm["lp"]], float)); off = (l2[0][0] - a.x()) * nx + (l2[0][1] - a.y()) * ny
                if abs(off) < 6:
                    off = 6.0 if off >= 0 else -6.0
            sg = 1.0 if off >= 0 else -1.0
            a2 = QPointF(a.x() + nx * off, a.y() + ny * off); b2 = QPointF(b.x() + nx * off, b.y() + ny * off)
            p.setPen(QPen(col, 1.2)); p.setBrush(Qt.NoBrush)
            p.drawLine(a, QPointF(a2.x() + nx * 5 * sg, a2.y() + ny * 5 * sg)); p.drawLine(b, QPointF(b2.x() + nx * 5 * sg, b2.y() + ny * 5 * sg)); p.drawLine(a2, b2)
            for q, s_ in ((a2, 1.0), (b2, -1.0)):
                p.setBrush(col)
                p.drawPolygon(QPolygonF([q, QPointF(q.x() + ux * 11 * s_ + nx * 3.5, q.y() + uy * 11 * s_ + ny * 3.5),
                                         QPointF(q.x() + ux * 11 * s_ - nx * 3.5, q.y() + uy * 11 * s_ - ny * 3.5)]))
            dim_mid = QPointF((a2.x() + b2.x()) / 2, (a2.y() + b2.y()) / 2 + 12)
        elif t in ("linear", "polar", "xy", "flip"):
            p.setPen(QPen(col, 2, Qt.DashLine)); p.setBrush(Qt.NoBrush)
            if t == "xy":
                c = QPointF(b.x(), a.y()); d = QPointF(a.x(), b.y())
                p.drawLine(a, c); p.drawLine(c, b); p.drawLine(a, d); p.drawLine(d, b)
            else:
                p.drawLine(a, b)
        if t == "rotation":
            rad = math.hypot(b.x() - a.x(), b.y() - a.y())
            p.setPen(QPen(col, 2, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawEllipse(a, rad, rad); p.drawLine(a, b)
        for act in acts:                                         # stretch frames
            f = act.get("frame")
            if f:
                c4, _ = self.cam.project(np.array([[f[0], f[1], 0], [f[2], f[1], 0], [f[2], f[3], 0], [f[0], f[3], 0]], float))
                p.setPen(QPen(col, 1, Qt.DotLine)); p.setBrush(Qt.NoBrush); p.drawPolygon(QPolygonF([QPointF(*q) for q in c4]))
        if prm.get("frame") and not acts:
            f = prm["frame"]
            c4, _ = self.cam.project(np.array([[f[0], f[1], 0], [f[2], f[1], 0], [f[2], f[3], 0], [f[0], f[3], 0]], float))
            p.setPen(QPen(col, 1, Qt.DotLine)); p.setBrush(Qt.NoBrush); p.drawPolygon(QPolygonF([QPointF(*q) for q in c4]))
        if t == "visibility":
            diamond(a); txt = f"{prm['name']}  (visibility)"
            self._label(p, a + QPointF(0, -6), txt, col.name()); return
        if t == "point":
            diamond(a); grip = a
        elif t == "flip":
            m = (a + b) / 2; diamond(m); grip = m
        else:
            diamond(b); grip = b
        from ..core import dynblock as DB
        bv = DB.base_value(prm)
        val = (f"{bv:g}" if isinstance(bv, float) else f"{bv[0]:g}, {bv[1]:g}") if t not in ("flip", "point") else ""
        txt = f"{prm['name']}{' = ' + val if val else ''}  [{t}]"
        if acts:
            txt += "  " + " + ".join(sorted({x['type'].capitalize() for x in acts}))
        mid = dim_mid if dim_mid is not None else ((a + b) / 2 if t not in ("point",) else a)
        self._label(p, mid, txt, col.name())
        if not acts and t != "point":                             # no action yet: yellow warning badge at the grip
            r = QRectF(grip.x() + 9, grip.y() - 22, 15, 15)
            p.setPen(QPen(QColor(60, 50, 0), 1)); p.setBrush(QColor(255, 214, 10)); p.drawRect(r)
            f9 = QFont("Segoe UI"); f9.setPixelSize(12); f9.setBold(True); p.setFont(f9); p.setPen(QColor(20, 20, 20))
            hud_text(p, r, Qt.AlignCenter, "!")

    def _grip_entity(self, g):
        if g is None or g >= len(self.grips):
            return None, None
        pt, eid, gi = self.grips[g][:3]
        return self.doc.ents.get(eid), gi

    def _grip_hover_menu(self):
        g = self._ghover
        if g is None or self.hot_grip is not None or self.ctl.req is not None or not self.opt.get("grip_menu", True):
            return
        e, gi = self._grip_entity(g)
        modes = grip_modes(e, gi) if e is not None else []
        if len(modes) < 2:
            return
        from PySide6.QtWidgets import QFrame, QVBoxLayout, QPushButton
        if self._gmenu is not None:
            self._gmenu.deleteLater()
        fr = QFrame(self); fr.setObjectName("gripmenu")
        fr.setStyleSheet("QFrame#gripmenu{background:#262C36;border:1px solid #3E4A5C;border-radius:4px;}"
                         "QPushButton{color:#E6EAF0;background:transparent;border:none;text-align:left;padding:4px 14px 4px 10px;}"
                         "QPushButton:hover{background:#2F80ED;color:white;}")
        lay = QVBoxLayout(fr); lay.setContentsMargins(2, 2, 2, 2); lay.setSpacing(0)
        for mode, label in modes:
            b = QPushButton(label); b.setCursor(Qt.ArrowCursor)
            b.clicked.connect(lambda _=False, g=g, mode=mode: (fr.hide(), self._grip_mode_chosen(g, mode)))
            lay.addWidget(b)
        fr.adjustSize()
        s2, _ = self.cam.project(np.asarray(self.grips[g][0], float)[None])
        x = int(min(max(4, s2[0][0] + 10), self.width() - fr.width() - 4)); y = int(min(max(4, s2[0][1] + 10), self.height() - fr.height() - 4))
        fr.move(x, y); fr.show(); fr.raise_(); self._gmenu = fr

    def _grip_context(self, g, gpos):
        e, gi = self._grip_entity(g)
        modes = grip_modes(e, gi) if e is not None else []
        if len(modes) < 2:
            return False
        from PySide6.QtWidgets import QMenu
        m = QMenu(self); acts = {}
        for mode, label in modes:
            acts[m.addAction(label)] = mode
        a = m.exec(gpos)
        if a in acts:
            self._grip_mode_chosen(g, acts[a])
        return True

    def _grip_mode_chosen(self, g, mode):
        if g is None or g >= len(self.grips):
            return
        pt, eid, gi = self.grips[g][:3]
        if mode in ("remove", "line"):
            self.ctl.grip_finish((g, eid, gi, mode), None); self.update(); return
        self.hot_grip = (g, eid, gi, mode); self.setFocus()
        label = dict(grip_modes(self.doc.ents.get(eid), gi)).get(mode, mode)
        self.ctl.message(f"{label}: click the new position (Ctrl = next grip mode, Esc = cancel)")
        self.update()

    def _cycle_grip_mode(self):
        g, eid, gi = self.hot_grip[:3]; cur = self.hot_grip[3] if len(self.hot_grip) > 3 else None
        modes = [m for m, _ in grip_modes(self.doc.ents.get(eid), gi) if m not in ("remove", "line")]
        if len(modes) < 2:
            return
        i = (modes.index(cur or "stretch") + 1) % len(modes) if (cur or "stretch") in modes else 0
        self.hot_grip = (g, eid, gi, modes[i])
        self.ctl.message("Grip mode: " + dict(grip_modes(self.doc.ents.get(eid), gi)).get(modes[i], modes[i]))
        self.preview = self.ctl.grip_preview(self.hot_grip, self.mouse_world); self.update()

    def window_contains_screen(self, rect, P):
        s2, _ = self.cam.project(np.asarray(P, float))
        x0, x1 = sorted((rect[0].x(), rect[1].x())); y0, y1 = sorted((rect[0].y(), rect[1].y()))
        return (s2[:, 0] >= x0) & (s2[:, 0] <= x1) & (s2[:, 1] >= y0) & (s2[:, 1] <= y1)

    def grab_image(self):
        return self.grabFramebuffer()


def exec_menu(m, gpos):
    """Shows a popup menu and returns the chosen action (separate function so tests can stand in for the user)."""
    return m.exec(gpos)


def adjust_rgba(a, brightness, contrast):
    """Brightness / contrast (-100 .. +100 each) on an RGBA uint8 array; alpha is untouched."""
    x = a[..., :3].astype(np.float32)
    c = float(contrast)
    if c:
        f = (259.0 * (c * 2.55 + 255.0)) / (255.0 * (259.0 - c * 2.55))
        x = (x - 128.0) * f + 128.0
    if brightness:
        x = x + float(brightness) * 2.55
    out = a.copy(); out[..., :3] = np.clip(x, 0, 255).astype(np.uint8)
    return out


def grip_points(e):
    k = e.kind
    if k == "line":
        return [e.p0, e.p1, (e.p0 + e.p1) / 2]
    if k == "circle":
        u = e.u(); v = np.cross(e.n, u)
        return [e.c, e.c + e.r * u, e.c + e.r * v, e.c - e.r * u, e.c - e.r * v]
    if k == "arc":
        p0, p1 = e.ends(); return [e.c, p0, p1]
    if k == "polyline":
        if len(e.pts) > 300:
            return list(e.pts[:200])
        return list(e.pts) + poly_mids(e)
    if k == "point":
        return [e.p]
    if k in ("text", "table"):
        return [e.p]
    if k == "insert":
        return [e.snaps()["ins"][0]] + e.dyn_grips()
    if k == "detailview":
        return [e.snaps()["ins"][0]]
    if k == "array":
        return e.grips()
    if k == "ellipse":
        return [e.c, e.c + e.major]
    if k == "spline":
        return list((e.fit if e.fit is not None else e.ctrl)[:100])
    if k == "image":
        return list(e.corners())
    if k == "dimension":
        return list(e.dpts)
    if k == "leader":
        return list(e.pts)
    if k == "body":
        bb = e.bbox()
        return [(bb[0] + bb[1]) / 2] if bb is not None else []
    return []


def poly_mids(e):
    """Midpoint grip of every polyline segment (on the arc for bulged segments)."""
    out = []; n = len(e.pts)
    for i in range(e.seg_count()):
        a, b = e.pts[i], e.pts[(i + 1) % n]; bl = e.bulges[i] if i < len(e.bulges) else 0.0
        arc = bulge_arc(a, b, bl, e.n) if abs(bl) > 1e-12 else None
        if arc is None:
            out.append((a + b) / 2)
        else:
            c, r, nn, u, a0, a1 = arc
            v = np.cross(nn, u); t = (a0 + a1) / 2
            out.append(c + r * (math.cos(t) * u + math.sin(t) * v))
    return out


def _poly_grip_kind(e, gi):
    n = len(e.pts)
    if gi < n or n > 300:
        return "vertex", gi
    return "mid", gi - n


def grip_modes(e, gi):
    """[(mode, label)] offered on a grip (multi-function grips like AutoCAD); [] when only a plain stretch exists."""
    if e is None or e.kind != "polyline":
        return []
    k, i = _poly_grip_kind(e, gi)
    if k == "vertex":
        m = [("stretch", "Stretch Vertex"), ("add", "Add Vertex")]
        if len(e.pts) > 2:
            m.append(("remove", "Remove Vertex"))
        return m
    arc = i < len(e.bulges) and abs(e.bulges[i]) > 1e-12
    return [("stretch", "Stretch"), ("add", "Add Vertex"), ("line", "Convert to Line") if arc else ("arc", "Convert to Arc")]


def bulge_3p(a, m, b, n):
    """Bulge of the polyline arc segment a -> b passing through m (plane normal n)."""
    from ..core.geom import arc_from_3p, ang_in_plane
    r = arc_from_3p(np.asarray(a, float), np.asarray(m, float), np.asarray(b, float))
    if r is None:
        return 0.0
    c = r[0]; n = unit(np.asarray(n, float)); u = unit(a - c)
    am = ang_in_plane(c, n, u, m) % TAU; ab = ang_in_plane(c, n, u, b) % TAU
    if am < ab:
        return math.tan(ab / 4)
    return -math.tan((TAU - ab) / 4)


def poly_grip(e, gi, p, mode=None):
    mode = mode or "stretch"
    k, i = _poly_grip_kind(e, gi)
    P = e.pts; B = np.asarray(e.bulges, float).copy(); n = len(P)
    if len(B) < n:
        B = np.concatenate([B, np.zeros(n - len(B))])
    if k == "vertex":
        if mode == "stretch":
            P[i] = p
        elif mode == "add":
            B[i] = 0.0
            e.pts = np.insert(P, i + 1, p, axis=0); B = np.insert(B, i + 1, 0.0)
        elif mode == "remove" and n > 2:
            e.pts = np.delete(P, i, axis=0); B = np.delete(B, i)
            if i > 0:
                B[i - 1] = 0.0
    else:
        j = (i + 1) % n; a, b = P[i].copy(), P[j].copy()
        if mode == "stretch":
            if abs(B[i]) > 1e-12:
                B[i] = bulge_3p(a, p, b, e.n)
            else:
                d = p - (a + b) / 2; P[i] = a + d; P[j] = b + d
        elif mode == "add":
            B[i] = 0.0
            e.pts = np.insert(P, i + 1, p, axis=0); B = np.insert(B, i + 1, 0.0)
        elif mode == "arc":
            B[i] = bulge_3p(a, p, b, e.n)
        elif mode == "line":
            B[i] = 0.0
    e.bulges = B
    e.touch()


def grip_measure(e, gi, p, base):
    """(label, value) shown while a grip is dragged = what a typed number sets."""
    k = e.kind
    if k == "circle" and gi >= 1:
        return "Radius", float(norm(p - e.c))
    if k == "line" and gi in (0, 1):
        return "Length", float(norm(p - (e.p1 if gi == 0 else e.p0)))
    return "Distance", float(norm(p - base))


def grip_typed_point(e, gi, text, cur, base, ucs):
    """Point for a value typed while a grip is dragged: number = radius (circle) / length (line end) / distance along the
    cursor direction; x,y = absolute; @dx,dy and @d<angle = relative to the grip. None if the text is not understood."""
    t = text.strip().replace(" ", "")
    try:
        if t.startswith("@") and "<" in t:
            d, a = t[1:].split("<"); a = math.radians(float(a)); d = float(d)
            return ucs.to_world(ucs.to_local(base) + np.array([d * math.cos(a), d * math.sin(a), 0.0]))
        if t.startswith("@"):
            v = [float(x) for x in t[1:].split(",")]; v += [0.0] * (3 - len(v))
            return ucs.to_world(ucs.to_local(base) + np.array(v[:3]))
        if "," in t:
            v = [float(x) for x in t.split(",")]; v += [0.0] * (3 - len(v))
            return ucs.to_world(np.array(v[:3]))
        d = float(eval(t, {"__builtins__": {}}, {"pi": math.pi}))
    except Exception:
        return None
    if d <= 0:
        return None
    k = e.kind
    if k == "circle" and gi >= 1:
        o = e.c
    elif k == "line" and gi in (0, 1):
        o = e.p1 if gi == 0 else e.p0
    else:
        o = base
    v = cur - o
    if norm(v) < 1e-9:
        v = base - o
    if norm(v) < 1e-9:
        v = ucs.x
    return o + unit(v) * d


def grip_apply(e, gi, p, mode=None):
    """Move grip gi of entity e to p (in place)."""
    k = e.kind
    from ..core.geom import m_translate
    if k == "line":
        if gi == 0:
            e.p0 = p.copy()
        elif gi == 1:
            e.p1 = p.copy()
        else:
            e.transform(m_translate(p - (e.p0 + e.p1) / 2))
    elif k == "circle":
        if gi == 0:
            e.c = p.copy()
        else:
            r = norm(p - e.c)
            if r > 0:
                e.r = r
    elif k == "arc":
        if gi == 0:
            e.c = p.copy()
        else:
            p0, p1 = e.ends(); pm = arc_pt(e.c, e.r, e.n, e.u(), (e.a0 + e.a1) / 2)
            a = E.Arc.through(p if gi == 1 else p0, pm, p if gi == 2 else p1)
            if a is not None:
                e.c, e.r, e.n, e.a0, e.a1 = a.c, a.r, a.n, a.a0, a.a1
    elif k == "polyline":
        poly_grip(e, gi, p, mode)
    elif k == "spline":
        if e.fit is not None:
            f = e.fit.copy(); f[gi] = p
            s = E.Spline.through(f); e.ctrl, e.knots, e.deg, e.fit = s.ctrl, s.knots, s.deg, s.fit
        else:
            e.ctrl[gi] = p
    elif k == "array":
        e.grip_set(gi, p)
    elif k == "insert" and gi >= 1:
        e.dyn_grip_set(gi - 1, p)
    elif k == "dimension":
        e.dpts[gi] = p.copy()
    elif k == "leader":
        e.pts[gi] = p
    elif k == "ellipse" and gi == 1:
        e.major = p - e.c
    else:
        pts = grip_points(e)
        if gi < len(pts):
            e.transform(m_translate(p - pts[gi]))
    e.touch()


def prim_ends(pr):
    from ..core.geom import prim_ends as pe
    return pe(pr)
