"""MTEXT formatting codes (the same inline codes AutoCAD writes into DXF / DWG).

   \\P new paragraph         \\L..\\l underline     \\O..\\o overline      \\K..\\k strike-through
   \\fArial|b1|i0;  font      \\H2.5; height        \\H1.5x; relative height  \\C1; ACI colour   \\c16711680; true colour
   \\W0.8; width factor      \\Q15; oblique angle   \\T1.2; tracking        \\S1^2; \\S1/2; \\S1#2; stacked text
   \\pxqc; paragraph alignment (ql qc qr qj)        { } group              \\\\ \\{ \\} literals      %%d %%p %%c  ° ± Ø
"""
import re

ALIGN = {"l": 0, "c": 1, "r": 2, "j": 3, "d": 3}
ALIGN_CODE = {0: "l", 1: "c", 2: "r", 3: "j"}


class Fmt:
    __slots__ = ("font", "bold", "italic", "under", "over", "strike", "hf", "habs", "color", "wf", "obl", "track")

    def __init__(self, font=None):
        self.font = font; self.bold = False; self.italic = False; self.under = False; self.over = False; self.strike = False
        self.hf = 1.0; self.habs = None; self.color = None; self.wf = 1.0; self.obl = 0.0; self.track = 1.0

    def copy(self):
        f = Fmt()
        for k in Fmt.__slots__:
            setattr(f, k, getattr(self, k))
        return f

    def key(self):
        return tuple(getattr(self, k) for k in Fmt.__slots__)


class Run:
    """A piece of text with one format. stack = (top, bottom, kind) for stacked text ('^' tolerance, '/' fraction, '#' diagonal)."""
    __slots__ = ("text", "fmt", "stack")

    def __init__(self, text, fmt, stack=None):
        self.text = text; self.fmt = fmt; self.stack = stack


class Para:
    __slots__ = ("align", "runs")

    def __init__(self, align=None):
        self.align = align; self.runs = []


def has_codes(s):
    return bool(re.search(r"\\[PpLlOoKkfFHCcWQTSA~]|[{}]", s or ""))


def parse(s, base_font=None):
    """MTEXT string -> list of paragraphs (each with an alignment and runs)."""
    s = (s or "").replace("\r\n", "\n").replace("\n", "\\P")
    s = s.replace("%%d", "\u00b0").replace("%%D", "\u00b0").replace("%%p", "\u00b1").replace("%%P", "\u00b1").replace("%%c", "\u00d8").replace("%%C", "\u00d8")
    paras = [Para()]; stack = []; cur = Fmt(base_font); buf = []
    def flush():
        if buf:
            paras[-1].runs.append(Run("".join(buf), cur.copy())); buf.clear()
    i = 0; n = len(s)
    def arg(j):
        k = s.find(";", j)
        if k < 0:
            return s[j:], n
        return s[j:k], k + 1
    while i < n:
        ch = s[i]
        if ch == "\\" and i + 1 < n:
            c = s[i + 1]
            if c in "\\{}":
                buf.append(c); i += 2; continue
            if c == "~":
                buf.append("\u00a0"); i += 2; continue
            if c == "P":
                flush(); paras.append(Para(paras[-1].align)); i += 2; continue
            if c == "N":
                buf.append(" "); i += 2; continue
            if c in "LlOoKk":
                flush()
                cur = cur.copy()
                if c in "Ll":
                    cur.under = c == "L"
                elif c in "Oo":
                    cur.over = c == "O"
                else:
                    cur.strike = c == "K"
                i += 2; continue
            if c in "fFHCcWQTApS":
                a, j = arg(i + 2)
                if c == "S":
                    flush()
                    m = re.match(r"^(.*?)(?<!\\)([\^/#])(.*)$", a)
                    if m:
                        top, kind, bot = m.group(1).replace("\\", ""), m.group(2), m.group(3).replace("\\", "")
                    else:
                        top, kind, bot = a, "^", ""
                    paras[-1].runs.append(Run(top + ("/" if kind in "/#" else "") + bot, cur.copy(), (top.strip(), bot.strip(), kind)))
                    i = j; continue
                flush(); cur = cur.copy()
                try:
                    if c in "fF":
                        parts = a.split("|"); cur.font = parts[0] or cur.font
                        for q in parts[1:]:
                            if q[:1] == "b":
                                cur.bold = q[1:] == "1"
                            elif q[:1] == "i":
                                cur.italic = q[1:] == "1"
                    elif c == "H":
                        if a.lower().endswith("x"):
                            cur.hf = cur.hf * float(a[:-1])
                        else:
                            cur.habs = float(a); cur.hf = 1.0
                    elif c == "C":
                        v = int(float(a)); cur.color = None if v in (0, 256) else v
                    elif c == "c":
                        v = int(float(a)); cur.color = "#%02x%02x%02x" % ((v >> 16) & 255, (v >> 8) & 255, v & 255)
                    elif c == "W":
                        cur.wf = float(a.rstrip("xX"))
                    elif c == "Q":
                        cur.obl = float(a)
                    elif c == "T":
                        cur.track = float(a.rstrip("xX"))
                    elif c == "p":
                        m = re.search(r"q([lcrjd])", a)
                        if m:
                            paras[-1].align = ALIGN[m.group(1)]
                except (ValueError, IndexError):
                    pass
                i = j; continue
            buf.append(c); i += 2; continue
        if ch == "{":
            flush(); stack.append(cur.copy()); i += 1; continue
        if ch == "}":
            flush()
            if stack:
                cur = stack.pop()
            i += 1; continue
        buf.append(ch); i += 1
    flush()
    return paras


def plain(s):
    """Text without the formatting codes (paragraphs separated by new lines)."""
    return "\n".join("".join(r.text for r in p.runs) for p in parse(s))


def _esc(t):
    return t.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


def encode(paras):
    """List of paragraphs -> MTEXT string."""
    out = []
    for pi, p in enumerate(paras):
        s = ""
        if p.align is not None and p.align != 0:
            s += "\\pxq%s;" % ALIGN_CODE.get(p.align, "l")
        elif pi > 0 and paras[pi - 1].align not in (None, 0):
            s += "\\pxql;"
        for r in p.runs:
            f = r.fmt; pre = ""
            if f.font or f.bold or f.italic:
                pre += "\\f%s|b%d|i%d;" % (f.font or "Arial", 1 if f.bold else 0, 1 if f.italic else 0)
            if f.habs:
                pre += "\\H%g;" % f.habs
            elif abs(f.hf - 1.0) > 1e-6:
                pre += "\\H%gx;" % f.hf
            if f.color is not None:
                if isinstance(f.color, str):
                    c = f.color.lstrip("#"); pre += "\\c%d;" % ((int(c[0:2], 16) << 16) | (int(c[2:4], 16) << 8) | int(c[4:6], 16))
                else:
                    pre += "\\C%d;" % int(f.color)
            if abs(f.wf - 1.0) > 1e-6:
                pre += "\\W%g;" % f.wf
            if abs(f.obl) > 1e-6:
                pre += "\\Q%g;" % f.obl
            if abs(f.track - 1.0) > 1e-6:
                pre += "\\T%g;" % f.track
            if f.under:
                pre += "\\L"
            if f.over:
                pre += "\\O"
            if f.strike:
                pre += "\\K"
            if r.stack is not None:
                body = "\\S%s%s%s;" % (_esc(r.stack[0]), r.stack[2], _esc(r.stack[1]))
            else:
                body = _esc(r.text)
            s += ("{" + pre + body + "}") if pre else body
        out.append(s)
    return "\\P".join(out)
