"""Curve editing: trim, extend, offset, fillet, chamfer, join, break, sub-curves."""
import math
import numpy as np
from .geom import (EPS, TAU, unit, norm, v3, prim_len, prim_point, prim_ends, prim_intersect, prims_length, prims_sub,
                   prims_closest, prim_tangent, arc_pt, line_line_3d, ang_in_plane, Plane, arbitrary_x, prim_sub)
from . import entities as E


def is_editable_curve(e):
    return e.kind in ("line", "arc", "circle", "polyline", "ellipse", "spline")


def curve_prims(e):
    return e.prims()


def _style(src, dst):
    dst.layer, dst.color, dst.ltype, dst.lw = src.layer, src.color, src.ltype, src.lw
    return dst


def sub_curve(e, s0, s1):
    """Entity for the part between arc lengths s0 < s1 (for closed curves s1 may wrap past L)."""
    pr = curve_prims(e); L = prims_length(pr)
    if e.closed and s1 > L + 1e-9:
        parts = prims_sub(pr, s0, L) + prims_sub(pr, 0, s1 - L)
    else:
        parts = prims_sub(pr, s0, min(s1, L))
    if not parts:
        return None
    if e.kind == "line":
        return _style(e, E.Line(parts[0][1], parts[0][2]))
    if e.kind in ("arc", "circle"):
        a = parts[0]
        if len(parts) > 1:
            a0 = a[5]; a1 = parts[-1][6] + TAU if parts[-1][6] <= a0 else parts[-1][6]
            a = ("A", a[1], a[2], a[3], a[4], a0, a0 + sum(p[6] - p[5] for p in parts))
        arc = E.Arc(a[1], a[2], 0, 1, a[3])
        u = arc.u()
        p0 = arc_pt(a[1], a[2], a[3], a[4], a[5])
        arc.a0 = ang_in_plane(a[1], a[3], u, p0) % TAU
        arc.a1 = arc.a0 + (a[6] - a[5])
        return _style(e, arc)
    if e.kind == "ellipse":
        P = e.pts()
        d = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
        t = np.linspace(e.t0, e.t1, len(P))
        def t_at(s):
            return float(np.interp(s % (d[-1] + 1e-12) if e.closed else s, d, t))
        t0 = t_at(s0); t1 = t_at(s1 if s1 <= d[-1] else s1 - d[-1])
        if t1 <= t0:
            t1 += TAU
        return _style(e, E.Ellipse(e.c, e.major, e.ratio, e.n, t0, t1))
    pl = E.polyline_from_prims(parts, e.n if e.kind == "polyline" else None, closed=False)
    if e.kind == "spline":
        from .geom import prims_tess
        P = prims_tess(parts)
        idx = np.linspace(0, len(P) - 1, min(len(P), max(4, len(P) // 6))).astype(int)
        return _style(e, E.Spline.through(P[idx]))
    if e.kind == "polyline" and e.is3d:
        pl.is3d = True
    return _style(e, pl)


def intersections_with(e, others):
    """Arc-length params on e where it meets any of the other entities."""
    pr = curve_prims(e); ss = []
    acc = 0.0
    oprims = [p for o in others if o is not e for p in o.prims()]
    for p in pr:
        L = prim_len(p)
        for q in oprims:
            for sa, sb, pt in prim_intersect(p, q):
                if -1e-9 <= sa <= L + 1e-9:
                    ss.append(acc + min(max(sa, 0), L))
        acc += L
    return sorted(set(round(s, 9) for s in ss)), acc


def trim(e, pick, cutters):
    """Return list of remaining pieces (or None when nothing to trim)."""
    if not is_editable_curve(e):
        return None
    ss, L = intersections_with(e, cutters)
    sp, _ = prims_closest(curve_prims(e), pick)
    if e.closed:
        ss = [s for s in ss if s < L - 1e-9]
        if len(ss) < 2:
            return None
        k = np.searchsorted(ss, sp)
        a = ss[k - 1] if k > 0 else ss[-1] - L
        b = ss[k] if k < len(ss) else ss[0] + L
        a, b = a % L, b % L
        if b <= a:
            b += L
        if a < 0:
            a += L; b += L
        piece = sub_curve(e, b % L, (b % L) + (L - (b - a)))
        return [piece] if piece else []
    inner = [s for s in ss if 1e-9 < s < L - 1e-9]
    pts = [0.0] + inner + [L]
    k = np.searchsorted(pts, sp)
    k = min(max(k, 1), len(pts) - 1)
    a, b = pts[k - 1], pts[k]
    if not inner:
        return None
    out = []
    if a > 1e-9:
        out.append(sub_curve(e, 0, a))
    if b < L - 1e-9:
        out.append(sub_curve(e, b, L))
    return [o for o in out if o is not None]


def break_curve(e, p1, p2):
    pr = curve_prims(e); L = prims_length(pr)
    s1, _ = prims_closest(pr, p1); s2, _ = prims_closest(pr, p2)
    if e.closed:
        if abs(s1 - s2) < 1e-9:
            return None
        a, b = s1, s2
        if b < a:
            b += L
        piece = sub_curve(e, b % L, b % L + (L - (b - a)))
        return [piece] if piece else []
    a, b = sorted((s1, s2))
    out = []
    if a > 1e-9:
        out.append(sub_curve(e, 0, a))
    if b < L - 1e-9:
        out.append(sub_curve(e, b if b > a else a, L))
    return [o for o in out if o is not None]


def extend(e, pick, bounds):
    """Extend the end of an open line / arc / polyline nearest to pick up to the nearest boundary."""
    if e.kind not in ("line", "arc", "polyline") or e.closed:
        return None
    pr = curve_prims(e); L = prims_length(pr)
    sp, _ = prims_closest(pr, pick)
    at_start = sp < L / 2
    seg = pr[0] if at_start else pr[-1]
    bprims = [p for o in bounds if o is not e for p in o.prims()]
    best = None
    if seg[0] == "L":
        a, b = seg[1], seg[2]
        if at_start:
            a, b = b, a        # extend beyond 'b'
        d = b - a; Lseg = norm(d)
        for q in bprims:
            for sa, sb, pt in prim_intersect(("L", a, b), q, extend_a=True):
                t = sa / Lseg if Lseg > 0 else 0
                if t > 1 + 1e-9 and (best is None or t < best[0]):
                    best = (t, pt)
        if best is None:
            return None
        newp = best[1]
    else:
        c, r, n, u, a0, a1 = seg[1:]
        full = ("A", c, r, n, u, 0.0, TAU)
        cand = []
        for q in bprims:
            for sa, sb, pt in prim_intersect(full, q):
                ang = ang_in_plane(c, n, u, pt)
                if at_start:
                    da = (a0 - ang) % TAU
                else:
                    da = (ang - a1) % TAU
                if 1e-9 < da < TAU - (a1 - a0) - 1e-9:
                    cand.append((da, pt))
        if not cand:
            return None
        newp = min(cand, key=lambda x: x[0])[1]
    out = e.copy(); out.id = e.id
    if e.kind == "line":
        if at_start:
            out.p0 = newp
        else:
            out.p1 = newp
    elif e.kind == "arc":
        u = out.u(); ang = ang_in_plane(out.c, out.n, u, newp) % TAU
        if at_start:
            out.a0 = ang
            if out.a1 <= out.a0:
                out.a1 += TAU
            while out.a1 - out.a0 > TAU:
                out.a1 -= TAU
        else:
            out.a1 = ang if ang > out.a0 else ang + TAU
    else:
        if seg[0] == "L":
            if at_start:
                out.pts[0] = newp
            else:
                out.pts[-1] = newp
        else:
            # arc segment of polyline: recompute bulge
            c, r, n, u, a0, a1 = seg[1:]
            if at_start:
                p_end = prim_ends(seg)[1]
                sweep = (a1 - a0) + (a0 - ang_in_plane(c, n, u, newp)) % TAU
                out.pts[0] = newp
                out.bulges[0] = math.copysign(math.tan(sweep / 4), out.bulges[0])
            else:
                sweep = (a1 - a0) + (ang_in_plane(c, n, u, newp) - a1) % TAU
                out.pts[-1] = newp
                out.bulges[-2] = math.copysign(math.tan(sweep / 4), out.bulges[-2])
    out.touch()
    return out


def _left(n, t):
    return unit(np.cross(n, t))


def offset(e, d, side_pt, plane_n=None):
    """Offset copy of a curve towards side_pt."""
    n = plane_n if plane_n is not None else np.array([0, 0, 1.0])
    if e.kind == "line":
        t = unit(e.p1 - e.p0)
        pl = e.p0
        nn = n if abs(np.dot(n, t)) < 0.999 else arbitrary_x(t)
        left = _left(nn, t)
        s = 1.0 if np.dot(side_pt - e.p0, left) >= 0 else -1.0
        out = _style(e, E.Line(e.p0 + left * d * s, e.p1 + left * d * s))
        return out
    if e.kind in ("circle", "arc"):
        inside = norm(side_pt - e.c) < e.r
        r = e.r - d if inside else e.r + d
        if r <= 1e-9:
            return None
        out = e.copy(); out.r = r; out.touch()
        return out
    if e.kind == "ellipse" or e.kind == "spline":
        P = e.pts() if e.kind == "spline" else e.pts()
        pl = e.plane()
        nn = pl.z if pl is not None else n
        T = np.gradient(P, axis=0)
        L = np.cross(nn, T); L = L / np.maximum(np.linalg.norm(L, axis=1, keepdims=True), 1e-18)
        k = int(np.argmin(np.linalg.norm(P - side_pt, axis=1)))
        s = 1.0 if np.dot(side_pt - P[k], L[k]) >= 0 else -1.0
        Q = P + L * d * s
        if e.kind == "ellipse" and e.closed:
            return _style(e, E.Polyline(Q[:-1], True, None, nn))
        idx = np.linspace(0, len(Q) - 1, min(len(Q), 24)).astype(int)
        return _style(e, E.Spline.through(Q[idx]))
    if e.kind == "polyline":
        nn = e.n
        pr = curve_prims(e)
        if not pr:
            return None
        sp, q = prims_closest(pr, side_pt)
        # which prim
        acc = 0; k = 0
        for i, p in enumerate(pr):
            if sp <= acc + prim_len(p) + 1e-12:
                k = i; break
            acc += prim_len(p)
        t = prim_tangent(pr[k], sp - acc)
        s = 1.0 if np.dot(side_pt - q, _left(nn, t)) >= 0 else -1.0
        off = []
        for p in pr:
            if p[0] == "L":
                t = unit(p[2] - p[1]); l = _left(nn, t) * d * s
                off.append(("L", p[1] + l, p[2] + l))
            else:
                c, r, an, u, a0, a1 = p[1:]
                ccw = np.dot(an, nn) > 0
                rr = r - d * s if ccw else r + d * s
                if rr <= 1e-9:
                    return None
                off.append(("A", c, rr, an, u, a0, a1))
        # connect consecutive offset primitives
        res = [list(x) for x in off]
        npr = len(res)
        pairs = range(npr if e.closed else npr - 1)
        for i in pairs:
            a = res[i]; b = res[(i + 1) % npr]
            ea = prim_ends(tuple(a))[1]; sb = prim_ends(tuple(b))[0]
            if norm(ea - sb) < 1e-9:
                continue
            X = None
            if a[0] == "L" and b[0] == "L":
                r_ = line_line_3d(a[1], a[2] - a[1], b[1], b[2] - b[1])
                if r_ is not None:
                    X = a[1] + r_[0] * (a[2] - a[1])
            else:
                cands = prim_intersect(tuple(a) if a[0] == "L" else ("A",) + tuple(a[1:5]) + (0.0, TAU),
                                       tuple(b) if b[0] == "L" else ("A",) + tuple(b[1:5]) + (0.0, TAU), True, True)
                if cands:
                    X = min((c[2] for c in cands), key=lambda pt: norm(pt - (ea + sb) / 2))
            if X is None:
                continue
            _set_end(a, X); _set_start(b, X)
        out = []
        for p in res:
            out.append(tuple(p))
        pl = E.polyline_from_prims(out, nn, closed=e.closed)
        if pl is None:
            return None
        if e.closed:
            pl.closed = True
            if len(pl.pts) > len(e.pts):
                pl.pts = pl.pts[:len(e.pts)]; pl.bulges = pl.bulges[:len(e.pts)]
        return _style(e, pl)
    return None


def _set_end(p, X):
    if p[0] == "L":
        p[2] = X
    else:
        c, r, n, u = p[1], p[2], p[3], p[4]
        a = p[5] + (ang_in_plane(c, n, u, X) - p[5]) % TAU
        p[6] = a


def _set_start(p, X):
    if p[0] == "L":
        p[1] = X
    else:
        c, r, n, u = p[1], p[2], p[3], p[4]
        a = ang_in_plane(c, n, u, X)
        a1 = p[6]
        p[5] = a1 - (a1 - a) % TAU


def _corner(l1, pk1, l2, pk2):
    """Lines l1, l2 with pick points -> (X, u1, u2, keep1, keep2) where keep = far end on the picked side."""
    d1 = l1.p1 - l1.p0; d2 = l2.p1 - l2.p0
    r = line_line_3d(l1.p0, d1, l2.p0, d2)
    if r is None:
        return None
    X = l1.p0 + r[0] * d1
    q1 = l1.p0 + np.dot(pk1 - l1.p0, d1) / np.dot(d1, d1) * d1
    q2 = l2.p0 + np.dot(pk2 - l2.p0, d2) / np.dot(d2, d2) * d2
    u1 = unit(q1 - X); u2 = unit(q2 - X)
    if norm(u1) < EPS:
        u1 = unit(d1)
    if norm(u2) < EPS:
        u2 = unit(d2)
    k1 = l1.p0 if np.dot(l1.p0 - X, u1) > np.dot(l1.p1 - X, u1) else l1.p1
    k2 = l2.p0 if np.dot(l2.p0 - X, u2) > np.dot(l2.p1 - X, u2) else l2.p1
    return X, u1, u2, k1, k2


def fillet_lines(l1, pk1, l2, pk2, r):
    c = _corner(l1, pk1, l2, pk2)
    if c is None:
        return None
    X, u1, u2, k1, k2 = c
    if r <= 1e-12:
        return _style(l1, E.Line(k1, X)), _style(l2, E.Line(k2, X)), None
    th = math.acos(max(-1, min(1, np.dot(u1, u2)))) / 2
    if th < 1e-6 or th > math.pi / 2 - 1e-9:
        return None
    t = r / math.tan(th)
    T1 = X + u1 * t; T2 = X + u2 * t
    cen = X + unit(u1 + u2) * r / math.sin(th)
    mid = cen + unit(X - cen) * r
    arc = E.Arc.through(T1, mid, T2)
    if arc is not None:
        _style(l1, arc)
    return _style(l1, E.Line(k1, T1)), _style(l2, E.Line(k2, T2)), arc


def chamfer_lines(l1, pk1, l2, pk2, d1, d2):
    c = _corner(l1, pk1, l2, pk2)
    if c is None:
        return None
    X, u1, u2, k1, k2 = c
    T1 = X + u1 * d1; T2 = X + u2 * d2
    ch = _style(l1, E.Line(T1, T2)) if norm(T1 - T2) > 1e-9 else None
    return _style(l1, E.Line(k1, T1)), _style(l2, E.Line(k2, T2)), ch


def fillet_polyline(pl, r):
    """Fillet every line-line vertex of a polyline with radius r (returns new polyline)."""
    P = pl.pts; n = len(P); B = pl.bulges
    newp = []; newb = []
    idx = range(n)
    for i in idx:
        if (not pl.closed and (i == 0 or i == n - 1)) or abs(B[i - 1]) > 1e-12 or abs(B[i]) > 1e-12:
            newp.append(P[i]); newb.append(B[i]); continue
        a = P[i - 1]; b = P[i]; c = P[(i + 1) % n]
        u1 = unit(a - b); u2 = unit(c - b)
        th = math.acos(max(-1, min(1, np.dot(u1, u2)))) / 2
        if th < 1e-6 or th > math.pi / 2 - 1e-6:
            newp.append(P[i]); newb.append(B[i]); continue
        t = r / math.tan(th)
        if t > min(norm(a - b), norm(c - b)) * 0.999:
            newp.append(P[i]); newb.append(B[i]); continue
        T1 = b + u1 * t; T2 = b + u2 * t
        sweep = math.pi - 2 * th
        sgn = 1 if np.dot(np.cross(-u1, u2), pl.n) > 0 else -1
        newp += [T1, T2]; newb += [sgn * math.tan(sweep / 4), 0.0]
    out = E.Polyline(np.array(newp), pl.closed, newb, pl.n)
    return _style(pl, out)


def join(ents, tol=1e-6):
    """Join lines / arcs / open polylines with coincident ends into polylines. Returns (new, used)."""
    pool = [(e, list(e.prims())) for e in ents if e.kind in ("line", "arc", "polyline") and not e.closed]
    used = []
    results = []
    while pool:
        e, chain = pool.pop(0)
        members = [e]
        grown = True
        while grown:
            grown = False
            s = prim_ends(chain[0])[0]; t = prim_ends(chain[-1])[1]
            for k, (f, fp) in enumerate(pool):
                fs = prim_ends(fp[0])[0]; fe = prim_ends(fp[-1])[1]
                if norm(fs - t) < tol:
                    chain = chain + fp
                elif norm(fe - t) < tol:
                    chain = chain + _reverse(fp)
                elif norm(fe - s) < tol:
                    chain = fp + chain
                elif norm(fs - s) < tol:
                    chain = _reverse(fp) + chain
                else:
                    continue
                members.append(f); pool.pop(k); grown = True
                break
        if len(members) > 1:
            n = None
            for m in members:
                if m.kind in ("arc", "polyline"):
                    n = m.n; break
            if n is None:
                from .geom import plane_of_points
                pts = np.array([prim_ends(p)[0] for p in chain] + [prim_ends(chain[-1])[1]])
                r = plane_of_points(pts)
                n = r[1] if r is not None else np.array([0, 0, 1.0])
                if n[2] < 0:
                    n = -n
            pl = E.polyline_from_prims(chain, n)
            if pl is not None:
                _style(members[0], pl)
                results.append(pl); used += members
    return results, used


def _reverse(prims):
    out = []
    for p in reversed(prims):
        if p[0] == "L":
            out.append(("L", p[2], p[1]))
        else:
            c, r, n, u, a0, a1 = p[1:]
            # reversed arc: CCW about -n
            n2 = -n
            u2 = unit(arc_pt(c, 1, n, u, a1) - c)
            out.append(("A", c, r, n2, u2, 0.0, a1 - a0))
    return out
