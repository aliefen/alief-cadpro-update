"""FILLET / CHAMFER between any two of: line, arc, circle, polyline segment (line or arc), including two adjacent segments of
the same polyline. Works in the plane of the objects (world XY or any plane parallel to it)."""
import math
import numpy as np
from . import entities as E
from .geom import unit, norm, bulge_arc, TAU, v3

Z = np.array([0.0, 0.0, 1.0])


def _2(p):
    return np.asarray(p, float)[:2]


class Elem:
    """The picked piece of an object: kind 'L' (a, b) or 'C' (centre c, radius r)."""
    def __init__(self, ent, pick, seg=None):
        self.ent = ent; self.pick = np.asarray(pick, float); self.seg = seg; self.z = 0.0
        k = ent.kind
        if k == "line":
            self.k = "L"; self.a, self.b = ent.p0.copy(), ent.p1.copy(); self.z = float(ent.p0[2])
        elif k in ("arc", "circle"):
            self.k = "C"; self.c = ent.c.copy(); self.r = float(ent.r); self.z = float(ent.c[2])
        elif k == "polyline":
            n = len(ent.pts); i = seg
            a, b = ent.pts[i], ent.pts[(i + 1) % n]; bl = ent.bulges[i] if i < len(ent.bulges) else 0.0
            self.z = float(a[2])
            arc = bulge_arc(a, b, bl, ent.n) if abs(bl) > 1e-12 else None
            if arc is None:
                self.k = "L"; self.a, self.b = a.copy(), b.copy()
            else:
                self.k = "C"; self.c = arc[0].copy(); self.r = float(arc[1])
                self.pa, self.pb = a.copy(), b.copy(); self.bulge = float(bl)
        else:
            raise ValueError("unsupported")

    def foot(self, q):
        """Closest point of the (infinite) element to q, and q's side."""
        q = np.asarray(q, float)
        if self.k == "L":
            d = self.b - self.a; L2 = float(np.dot(d[:2], d[:2]))
            t = float(np.dot((q - self.a)[:2], d[:2]) / L2) if L2 > 0 else 0.0
            p = self.a + t * d; p[2] = self.z
            return p
        v = (q - self.c)[:2]; L = math.hypot(*v)
        if L < 1e-12:
            v = np.array([1.0, 0.0]); L = 1.0
        p = self.c.copy(); p[:2] = self.c[:2] + v / L * self.r
        return p


def nearest_segment(pl, pick):
    """Index of the polyline segment closest to pick."""
    best = None; n = len(pl.pts)
    for i in range(pl.seg_count()):
        a, b = pl.pts[i], pl.pts[(i + 1) % n]
        bl = pl.bulges[i] if i < len(pl.bulges) else 0.0
        if abs(bl) > 1e-12:
            arc = bulge_arc(a, b, bl, pl.n)
            c, r = arc[0], arc[1]
            from .geom import arc_pts
            P = arc_pts(*arc, seg=24)
            d = min(norm(_2(P[k]) - _2(pick)) for k in range(len(P)))
        else:
            d2 = b - a; L2 = float(np.dot(d2[:2], d2[:2]))
            t = 0.0 if L2 <= 0 else min(1.0, max(0.0, float(np.dot((pick - a)[:2], d2[:2]) / L2)))
            d = norm(_2(a + t * d2) - _2(pick))
        if best is None or d < best[0]:
            best = (d, i)
    return best[1] if best else 0


def make_elem(ent, pick):
    if ent.kind == "polyline":
        return Elem(ent, pick, nearest_segment(ent, pick))
    return Elem(ent, pick)


# ------------------------------------------------------------------------------------------- intersections (2D)
def _ll(a1, b1, a2, b2):
    d1 = (b1 - a1)[:2]; d2 = (b2 - a2)[:2]
    den = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(den) < 1e-14 * max(1.0, float(np.dot(d1, d1) * np.dot(d2, d2))):
        return []
    w = (a2 - a1)[:2]
    t = (w[0] * d2[1] - w[1] * d2[0]) / den
    return [a1[:2] + t * d1]


def _lc(a, b, c, r):
    d = (b - a)[:2]; f = (a - c)[:2]
    A = float(np.dot(d, d)); B = 2 * float(np.dot(f, d)); C = float(np.dot(f, f)) - r * r
    disc = B * B - 4 * A * C
    if A < 1e-24 or disc < -1e-9 * max(1.0, B * B):
        return []
    disc = max(0.0, disc); s = math.sqrt(disc)
    return [a[:2] + (-B - s) / (2 * A) * d, a[:2] + (-B + s) / (2 * A) * d]


def _cc(c1, r1, c2, r2):
    d = (c2 - c1)[:2]; L = math.hypot(*d)
    if L < 1e-12 or L > r1 + r2 + 1e-9 or L < abs(r1 - r2) - 1e-9:
        return []
    a = (r1 * r1 - r2 * r2 + L * L) / (2 * L); h = math.sqrt(max(0.0, r1 * r1 - a * a))
    m = c1[:2] + a * d / L; perp = np.array([-d[1], d[0]]) / L
    return [m + h * perp, m - h * perp]


def intersect(e1, e2):
    if e1.k == "L" and e2.k == "L":
        return _ll(e1.a, e1.b, e2.a, e2.b)
    if e1.k == "L":
        return _lc(e1.a, e1.b, e2.c, e2.r)
    if e2.k == "L":
        return _lc(e2.a, e2.b, e1.c, e1.r)
    return _cc(e1.c, e1.r, e2.c, e2.r)


def _offsets(e, R):
    """Curves at distance R from the element: lines ('L', a, b) or circles ('C', c, r)."""
    if e.k == "L":
        d = unit(e.b - e.a); nrm = np.array([-d[1], d[0], 0.0])
        return [("L", e.a + nrm * R, e.b + nrm * R), ("L", e.a - nrm * R, e.b - nrm * R)]
    out = [("C", e.c, e.r + R)]
    if abs(e.r - R) > 1e-12:
        out.append(("C", e.c, abs(e.r - R)))
    return out


def _cut(o1, o2):
    class T:
        pass
    a = T(); b = T()
    for o, t in ((o1, a), (o2, b)):
        t.k = o[0]
        if o[0] == "L":
            t.a, t.b = o[1], o[2]
        else:
            t.c, t.r = o[1], o[2]
    return intersect(a, b)


# ------------------------------------------------------------------------------------------- fillet solving
def solve_fillet(e1, e2, R, same_poly=None):
    """-> (centre, T1, T2) of the fillet arc or None.  same_poly = shared vertex for adjacent polyline segments."""
    cands = []
    for o1 in _offsets(e1, R):
        for o2 in _offsets(e2, R):
            for c in _cut(o1, o2):
                C = np.array([c[0], c[1], e1.z])
                T1 = e1.foot(C); T2 = e2.foot(C)
                if norm(T1 - T2) < 1e-9:
                    continue
                cands.append((C, T1, T2))
    if not cands:
        return None
    def on_seg(e, T):
        if e.k == "L":
            d = e.b - e.a; L2 = float(np.dot(d[:2], d[:2]))
            t = float(np.dot((T - e.a)[:2], d[:2]) / L2) if L2 > 0 else 0.0
            return max(0.0, -t, t - 1.0) * math.sqrt(L2)
        return 0.0
    best = None
    for C, T1, T2 in cands:
        if same_poly is not None:
            score = on_seg(e1, T1) * 1e3 + on_seg(e2, T2) * 1e3 + norm(T1 - same_poly) + norm(T2 - same_poly)
        else:
            score = norm(_2(T1) - _2(e1.pick)) + norm(_2(T2) - _2(e2.pick))
            if e1.k == "L" and e2.k == "L":           # keep the picked halves of both lines (AutoCAD rule)
                X = intersect(e1, e2)
                if X:
                    X = np.array([X[0][0], X[0][1], e1.z])
                    for e, T in ((e1, T1), (e2, T2)):
                        if np.dot((T - X)[:2], (e.pick - X)[:2]) < 0:
                            score += 1e9
        # the fillet arc must be the short way round between the tangent points
        if best is None or score < best[0]:
            best = (score, C, T1, T2)
    return best[1], best[2], best[3]


def fillet_arc(C, T1, T2, R, like):
    v1 = unit(T1 - C); v2 = unit(T2 - C)
    m = v1 + v2
    if norm(m) < 1e-9:
        m = np.array([-v1[1], v1[0], 0.0])
    mid = C + unit(m) * R
    a = E.Arc.through(T1, mid, T2)
    if a is not None:
        a.layer, a.color, a.ltype, a.lw = like.layer, like.color, like.ltype, like.lw
    return a


def _sweep_ccw(c, p, q):
    a = math.atan2(*(p - c)[1::-1]); b = math.atan2(*(q - c)[1::-1])
    return (b - a) % TAU


def bulge_of(c, p, q, ccw):
    """Bulge for an arc around c from p to q, counter-clockwise (ccw) or clockwise."""
    s = _sweep_ccw(c, p, q)
    if ccw:
        return math.tan(s / 4)
    return -math.tan((TAU - s) % TAU / 4)


# ------------------------------------------------------------------------------------------- trimming
def _keep_line(e, T, X=None):
    """New end points of a line element trimmed / extended to T, keeping the picked side.
    The side is judged against the corner X (intersection with the other object) like AutoCAD, so a pick
    between the tangent point and the corner still keeps the main part of the line."""
    d = e.b - e.a; L2 = float(np.dot(d[:2], d[:2]))
    if L2 <= 0:
        return ("end", T)
    tT = float(np.dot((T - e.a)[:2], d[:2]) / L2)
    tP = float(np.dot((e.pick - e.a)[:2], d[:2]) / L2)
    ref = tT
    if X is not None:
        ref = float(np.dot((X - e.a)[:2], d[:2]) / L2)
        if abs(tP - ref) * math.sqrt(L2) < 1e-6:          # picked exactly at the corner: keep the longer part
            return ("end", T) if ref >= 0.5 else ("start", T)
    return ("end", T) if tP <= ref else ("start", T)       # which end point is replaced by T


def _trim_arc_ent(arc, T, pick, X=None):
    """Arc entity trimmed / extended so that one end is at T and the picked part stays."""
    u = arc.u(); v = np.cross(arc.n, u)
    def ang(p):
        d = p - arc.c
        return math.atan2(float(np.dot(d, v)), float(np.dot(d, u)))
    a0, a1 = arc.a0, arc.a1; span = a1 - a0
    aT = (ang(T) - a0) % TAU; aP = (ang(pick) - a0) % TAU
    aR = (ang(X) - a0) % TAU if X is not None and norm(X - arc.c) > 1e-12 else aT
    if aT <= span + 1e-9:                                  # T on the arc
        return (a0 + aT, a1) if aP > aR else (a0, a0 + aT)
    # T beyond an end: extend the nearer end
    if aT - span < TAU - aT:
        return (a0, a0 + aT)
    return (a0 + aT - TAU, a1)


def apply_trim(doc, e, T, keep_ent_cache, X=None):
    """Trim / extend the element to the tangent point T (modifies the entity in the document).
    X = corner (intersection with the other object) used to decide which side was picked."""
    ent = e.ent
    if ent.kind == "line":
        doc.modify(ent); which, P = _keep_line(e, T, X)
        if which == "end":
            ent.p1 = P.copy()
        else:
            ent.p0 = P.copy()
        ent.touch(); return True
    if ent.kind == "arc":
        doc.modify(ent); a0, a1 = _trim_arc_ent(ent, T, e.pick, X)
        ent.a0 = a0 % TAU; ent.a1 = ent.a0 + (a1 - a0) % TAU if (a1 - a0) % TAU > 1e-12 else ent.a0 + TAU
        ent.touch(); return True
    if ent.kind == "circle":
        return True                                        # circles are never trimmed (AutoCAD rule)
    if ent.kind == "polyline":
        n = len(ent.pts); i = e.seg; j = (i + 1) % n
        if e.k == "L":
            which, P = _keep_line(e, T, X)
            vi = j if which == "end" else i
        else:
            # arc segment: replace the end that is on the far side of T from the pick
            dT = _sweep_ccw(e.c, e.pa, X if X is not None else T); dP = _sweep_ccw(e.c, e.pa, e.pick)
            ccw = e.bulge > 0
            if not ccw:
                dT = (TAU - dT) % TAU; dP = (TAU - dP) % TAU
            vi = j if dP <= dT else i
        if ent.closed or vi not in (0, n - 1):
            return False                                    # inside an open / closed polyline: cannot trim there
        doc.modify(ent); P0 = ent.pts[vi].copy(); ent.pts[vi] = np.array([T[0], T[1], P0[2]])
        if e.k == "C":
            a, b = ent.pts[i], ent.pts[j]
            ent.bulges[i] = bulge_of(e.c, a, b, e.bulge > 0)
        ent.touch(); return True
    return False


def fillet(doc, ent1, pick1, ent2, pick2, R, trim=True, chamfer=None):
    """Fillet (R) or chamfer (chamfer=(d1, d2)) two objects in the document. -> (ok, message, new entities)."""
    if ent1 is ent2 and ent1.kind == "polyline":
        return _same_poly(doc, ent1, pick1, pick2, R, chamfer)
    try:
        e1 = make_elem(ent1, pick1); e2 = make_elem(ent2, pick2)
    except ValueError:
        return False, "Select lines, arcs, circles or polylines", []
    if chamfer is not None:
        if e1.k != "L" or e2.k != "L":
            return False, "CHAMFER works on lines and straight polyline segments", []
        X = intersect(e1, e2)
        if not X:
            return False, "The lines are parallel", []
        X = np.array([X[0][0], X[0][1], e1.z])
        u1 = unit(np.append((e1.pick - X)[:2], 0.0)); u2 = unit(np.append((e2.pick - X)[:2], 0.0))
        T1 = X + u1 * chamfer[0]; T2 = X + u2 * chamfer[1]
        new = []
        if norm(T1 - T2) > 1e-9:
            ln = E.Line(T1, T2); ln.layer, ln.color, ln.ltype, ln.lw = ent1.layer, ent1.color, ent1.ltype, ent1.lw; new.append(ln)
        if trim:
            ok1 = apply_trim(doc, e1, T1, None, X); ok2 = apply_trim(doc, e2, T2, None, X)
            if not (ok1 and ok2):
                return False, "A polyline can only be trimmed at its end segments", []
        return True, "", new
    if R <= 1e-12:
        P = intersect(e1, e2)
        if not P:
            return False, "The objects do not meet (parallel lines or curves too far apart)", []
        P = min(P, key=lambda q: norm(q - _2(pick1)) + norm(q - _2(pick2)))
        X = np.array([P[0], P[1], e1.z])
        if trim:
            ok = apply_trim(doc, e1, X, None, X) and apply_trim(doc, e2, X, None, X)
            if not ok:
                return False, "A polyline can only be trimmed at its end segments", []
        return True, "", []
    sol = solve_fillet(e1, e2, R)
    if sol is None:
        return False, "No fillet of that radius fits between these objects", []
    C, T1, T2 = sol
    arc = fillet_arc(C, T1, T2, R, ent1)
    if trim:
        X = _corner(e1, e2, (T1 + T2) / 2)
        ok = apply_trim(doc, e1, T1, None, X) and apply_trim(doc, e2, T2, None, X)
        if not ok:
            return False, "A polyline can only be filleted at its end segments (or two of its own segments)", []
    return True, "", [arc] if arc is not None else []


def _corner(e1, e2, near):
    """Intersection of the two elements nearest to 'near' (the corner the fillet replaces) or None."""
    P = intersect(e1, e2)
    if not P:
        return None
    q = min(P, key=lambda q: norm(q - _2(near)))
    return np.array([q[0], q[1], e1.z])


def _same_poly(doc, pl, pick1, pick2, R, chamfer):
    n = len(pl.pts)
    i = nearest_segment(pl, pick1); j = nearest_segment(pl, pick2)
    if i == j:
        return False, "Pick two different segments", []
    a, b = sorted((i, j))
    if b == a + 1:
        s1, s2, vi = a, b, b
    elif pl.closed and a == 0 and b == pl.seg_count() - 1:
        s1, s2, vi = b, a, 0
    else:
        return False, "Only two segments that meet at a vertex can be filleted", []
    e1 = Elem(pl, pick1, s1); e2 = Elem(pl, pick2, s2)
    V = pl.pts[vi].copy()
    if chamfer is not None:
        if e1.k != "L" or e2.k != "L":
            return False, "CHAMFER works on straight segments", []
        u1 = unit(e1.a - V); u2 = unit(e2.b - V)
        T1 = V + u1 * chamfer[0]; T2 = V + u2 * chamfer[1]; bl = 0.0
    elif R <= 1e-12:
        return True, "", []
    else:
        sol = solve_fillet(e1, e2, R, same_poly=V)
        if sol is None:
            return False, "No fillet of that radius fits", []
        C, T1, T2 = sol
        ccw = float(np.cross(np.append((T1 - C)[:2], 0), np.append((T2 - C)[:2], 0))[2]) > 0
        bl = bulge_of(C, T1, T2, ccw)
        if abs(bl) > 1.0:                                   # took the long way round: use the short arc
            bl = bulge_of(C, T1, T2, not ccw)
    doc.modify(pl)
    P = [p.copy() for p in pl.pts]; B = list(np.asarray(pl.bulges, float)) + [0.0] * (n - len(pl.bulges))
    T1 = np.array([T1[0], T1[1], V[2]]); T2 = np.array([T2[0], T2[1], V[2]])
    if e1.k == "C":
        B[s1] = bulge_of(e1.c, P[s1], T1, e1.bulge > 0)
    if e2.k == "C":
        B[s2] = bulge_of(e2.c, T2, P[(s2 + 1) % n], e2.bulge > 0)
    P[vi:vi + 1] = [T1, T2]; B[vi:vi + 1] = [bl, B[vi]]
    if vi == 0:                                             # closed polyline, corner at vertex 0: the arc is the last segment
        P = P[1:] + P[:1]; B = B[1:] + B[:1]
    pl.pts = np.array(P); pl.bulges = np.array(B, float); pl.touch()
    return True, "", []


def fillet_all(pl, R):
    """PEDIT / FILLET Polyline: every straight-straight corner of the polyline rounded with radius R."""
    n = len(pl.pts)
    P = [p.copy() for p in pl.pts]; B = list(np.asarray(pl.bulges, float)) + [0.0] * (n - len(pl.bulges))
    outP, outB = [], []
    cnt = 0
    for k in range(n):
        if (not pl.closed and (k == 0 or k == n - 1)) or abs(B[k - 1]) > 1e-12 or abs(B[k]) > 1e-12:
            outP.append(P[k]); outB.append(B[k]); continue
        a, v, c = P[k - 1], P[k], P[(k + 1) % n]
        u1 = unit(a - v); u2 = unit(c - v)
        cosang = max(-1.0, min(1.0, float(np.dot(u1, u2)))); th = math.acos(cosang) / 2
        if th < 1e-6 or th > math.pi / 2 - 1e-6:
            outP.append(v); outB.append(B[k]); continue
        t = R / math.tan(th)
        if t > norm(a - v) * 0.999 or t > norm(c - v) * 0.999:
            outP.append(v); outB.append(B[k]); continue
        T1 = v + u1 * t; T2 = v + u2 * t
        C = v + unit(u1 + u2) * R / math.sin(th)
        ccw = float(np.cross(T1 - C, T2 - C)[2]) > 0
        bl = bulge_of(C, T1, T2, ccw)
        if abs(bl) > 1.0:
            bl = bulge_of(C, T1, T2, not ccw)
        outP += [T1, T2]; outB += [bl, B[k]]; cnt += 1
    pl.pts = np.array(outP); pl.bulges = np.array(outB, float); pl.touch()
    return cnt
