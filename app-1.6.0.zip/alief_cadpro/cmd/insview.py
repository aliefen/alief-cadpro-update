"""Insert / Views / Redraw additions: live detail views, external references (DXF / DWG), image clip and frame,
block base point, named views."""
import math
import os
import numpy as np
from ..core import entities as E
from ..core.geom import unit, norm, Plane
from .misc import T, STD_SCALES


# ------------------------------------------------------------------------------------------------ detail view (Redraw)
def _next_name(doc):
    used = {e.name for e in doc.ents.values() if e.kind == "detailview"}
    for k in range(26):
        if chr(65 + k) not in used:
            return chr(65 + k)
    return "A%d" % (len(used) + 1)


def cmd_detailview(c):
    """Enlarged detail that stays linked to the main drawing: it redraws itself when the drawing changes and its size
    follows drawing scale / detail scale."""
    from .misc import ensure_scale; ensure_scale(c)
    pl = c.ucs
    st = {"shape": "circle"}
    while True:
        p = yield c.pt(f"DETAILVIEW  Specify centre of the area to enlarge (boundary = {st['shape']}) [Circular/Rectangular]",
                       options=["Circular", "Rectangular"])
        if p is None:
            return
        if p == "Circular":
            st["shape"] = "circle"; continue
        if p == "Rectangular":
            st["shape"] = "rect"; continue
        break
    if st["shape"] == "circle":
        r = yield c.dist("Specify radius of the detail area", base=p, preview=lambda q: [E.Circle(p, norm(q - p), pl.z)])
        if not isinstance(r, float) or r <= 0:
            return
        size = (r, r)
    else:
        def box(q):
            a = pl.to_local(q) - pl.to_local(p)
            hw, hh = abs(a[0]), abs(a[1])
            return E.Polyline(np.array([p + pl.x * sx * hw + pl.y * sy * hh for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]), True, None, pl.z)
        q = yield c.pt("Specify a corner of the detail area", base=p, preview=lambda q: [box(q)])
        if q is None:
            return
        a = pl.to_local(q) - pl.to_local(p); size = (abs(a[0]), abs(a[1]))
        if min(size) <= 0:
            return
    k = E.Entity.anno_scale
    smaller = [s for s in STD_SCALES if s < k]
    dflt = smaller[max(0, len(smaller) - 3)] if smaller else k / 2            # about 2 standard steps larger than the drawing
    ds = yield c.num(f"Detail scale 1:N  (drawing scale is 1:{k:g}) <{dflt:g}>", float(dflt))
    ds = float(ds or dflt)
    if ds <= 0:
        return
    name = _next_name(c.doc)
    mk = lambda q: E.DetailView(p, size, q, ds, name, st["shape"], pl.z, pl.x, 3.5)
    q = yield c.pt(f"Specify location of DETAIL {name} (magnification {k / ds:g} x)", base=p, preview=lambda q: [mk(q)])
    if q is None:
        return
    d = mk(q); d.layer = "DETAIL"; c.doc.ensure_layer("DETAIL", 7); c.doc.add_keep(d)
    c.msg(f"DETAIL {name} at scale 1:{ds:g} created. It follows the main drawing; change its scale or size in Properties.")


# ------------------------------------------------------------------------------------------------ external references
def _load_ref(c, path):
    """Read a DXF / DWG / ACP file into a block definition named XREF_<file>. -> block name or None."""
    from ..core.document import Document
    from ..core import dxfio
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".acp":
            d = Document.load(path)
        else:
            fn = path
            if ext == ".dwg":
                import tempfile
                fn = dxfio.dwg_convert(path, tempfile.mkdtemp(prefix="cadpro_xref_"))
            d = Document(); dxfio.import_dxf(d, fn)
    except Exception as ex:
        c.msg(f"Reference could not be read: {ex}"); return None
    finally:
        c.doc.activate()
    name = "XREF_" + os.path.splitext(os.path.basename(path))[0].upper().replace(" ", "_")
    for n, L in d.layers.items():
        if n not in c.doc.layers:
            c.doc.layers[n] = L
    for bn, b in d.blocks.items():
        if bn not in c.doc.blocks:
            c.doc.blocks[bn] = b
    ents = []
    for e in d.ents.values():
        e.id = 0; ents.append(e)
    c.doc.add_block(E.Block(name, (0, 0, 0), ents))
    c.doc.settings.setdefault("xrefs", {})[name] = path
    return name


def cmd_xattach(c, path=None):
    path = path or c.app.ask_open("Attach DWG / DXF reference", "CAD drawings (*.dwg *.dxf *.acp);;All files (*)")
    if not path:
        return
    name = _load_ref(c, path)
    if name is None:
        return
    mk = lambda p: E.Insert.make(name, p, 1, 1, 1, 0.0, c.ucs.z)
    p = yield c.pt(f"XATTACH {os.path.basename(path)}  Specify insertion point <0,0,0>", default=c.ucs.o.copy(), preview=lambda q: [mk(q)])
    if p is None:
        p = c.ucs.o.copy()
    ins = mk(p); ins.layer = "XREF"; c.doc.ensure_layer("XREF", 8); c.doc.add_keep(ins)
    c.view.zoom_extents([ins])
    c.msg(f"Reference {name} attached ({len(c.doc.blocks[name].ents)} objects). XRELOAD reads the file again after it has changed.")


def cmd_xreload(c):
    xr = c.doc.settings.get("xrefs", {})
    if not xr:
        c.msg("The drawing has no external references"); return
    n = 0
    for name, path in list(xr.items()):
        if not os.path.exists(path):
            c.msg(f"{name}: file not found - {path}"); continue
        if _load_ref(c, path):
            n += 1
    for e in c.doc.ents.values():
        if e.kind == "insert":
            e.touch()
    c.doc.rev += 1; c.view.invalidate()
    c.msg(f"{n} reference(s) reloaded")
    return
    yield


def cmd_xlist(c):
    xr = c.doc.settings.get("xrefs", {})
    lines = [f"{n:<28} {'OK ' if os.path.exists(p) else 'MISSING'}  {p}" for n, p in xr.items()]
    c.app.show_text("External references", "\n".join(lines) or "No external references. Use XATTACH (Insert > DWG Reference).")
    return
    yield


# ------------------------------------------------------------------------------------------------ images
def cmd_imageclip(c):
    r = yield c.ent("IMAGECLIP  Select image", filt=lambda e: e.kind == "image")
    if r is None:
        return
    e = r[0]
    a = yield c.pt("Specify first corner of the part to keep")
    if a is None:
        return
    b = yield c.corner("Specify opposite corner", a)
    if b is None:
        return
    uu = float(np.dot(e.u, e.u)); vv = float(np.dot(e.v, e.v))
    fa = sorted((float(np.dot(a - e.o, e.u)) / uu, float(np.dot(b - e.o, e.u)) / uu))
    fb = sorted((float(np.dot(a - e.o, e.v)) / vv, float(np.dot(b - e.o, e.v)) / vv))
    x0, x1 = max(0.0, fa[0]), min(1.0, fa[1]); y0, y1 = max(0.0, fb[0]), min(1.0, fb[1])
    if x1 - x0 < 1e-4 or y1 - y0 < 1e-4:
        c.msg("The clip window does not overlap the image"); return
    from PySide6.QtGui import QImage
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice
    img = QImage.fromData(e.data)
    px0, px1 = int(round(x0 * img.width())), int(round(x1 * img.width()))
    py0, py1 = int(round((1 - y1) * img.height())), int(round((1 - y0) * img.height()))
    cut = img.copy(px0, py0, max(1, px1 - px0), max(1, py1 - py0))
    ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly); cut.save(buf, "PNG")
    c.doc.modify(e)
    o = e.o + e.u * x0 + e.v * y0
    e.o, e.u, e.v = o, e.u * (x1 - x0), e.v * (y1 - y0)
    e.data = bytes(ba); e.wpx, e.hpx = cut.width(), cut.height(); e.touch()
    c.view.textures = {}; c.view.invalidate()
    c.msg(f"Image clipped to {cut.width()} x {cut.height()} pixels")


def cmd_imageframe(c):
    imgs = [e for e in c.doc.ents.values() if e.kind == "image"]
    if not imgs:
        c.msg("No images in the drawing"); return
    on = not imgs[0].show_frame
    for e in imgs:
        c.doc.modify(e); e.show_frame = on; e.touch()
    c.view.invalidate(); c.msg("Image frames " + ("ON" if on else "OFF"))
    return
    yield


# ------------------------------------------------------------------------------------------------ blocks
def cmd_blockbase(c):
    r = yield c.ent("BLOCKBASE  Select a block reference to change its base point", filt=lambda e: e.kind == "insert")
    if r is None:
        return
    ins = r[0]; blk = c.doc.blocks.get(ins.name)
    if blk is None:
        return
    p = yield c.pt("Specify new base point")
    if p is None:
        return
    Mi = np.linalg.inv(ins.Meff()); q = (Mi @ np.append(p, 1.0))[:3]            # the point in block coordinates
    blk.base = q
    c.doc.rev += 1; c.view.invalidate()
    c.msg(f"Base point of block {ins.name} changed (insertion snap and INSERT now use the new point)")


# ------------------------------------------------------------------------------------------------ named views
def _view_state(v):
    return {"target": [float(x) for x in v.cam.target], "R": [[float(x) for x in r] for r in v.cam.R], "h": float(v.cam.h), "persp": bool(v.cam.persp)}


def restore_view(c, name):
    d = c.doc.settings.get("views", {}).get(name)
    if d is None:
        c.msg(f'View "{name}" not found'); return False
    v = c.view; v.cam.persp = bool(d.get("persp", False))
    v._animate_to(np.array(d["target"], float), np.array(d["R"], float), float(d["h"]))
    return True


def cmd_view(c):
    views = c.doc.settings.setdefault("views", {})
    o = yield c.opt("VIEW  [Save/Restore/Delete/List] <Save>" + (f"   saved: {', '.join(views)}" if views else ""), ["Save", "Restore", "Delete", "List"], "Save")
    if o == "Save":
        n = yield c.text("Enter name for the current view")
        if n and n.strip():
            views[n.strip()] = _view_state(c.view); c.doc.modified = True; c.app.refresh_views(); c.msg(f'View "{n.strip()}" saved')
    elif o in ("Restore", "Delete"):
        if not views:
            c.msg("No saved views"); return
        n = c.app.choose("View", f"{o} view", list(views))
        if n and o == "Restore":
            restore_view(c, n)
        elif n:
            views.pop(n, None); c.app.refresh_views(); c.msg(f'View "{n}" deleted')
    elif o == "List":
        c.app.show_text("Named views", "\n".join(views) or "No saved views. VIEW > Save stores the current view (also saved in the drawing).")


@T
def cmd_pan(c):
    c.msg("PAN: hold the mouse wheel (middle button) and drag.  Zoom: turn the wheel.  Double-click the wheel = zoom extents.")


@T
def cmd_orbit(c):
    c.msg("3DORBIT: hold the right button and drag (or Shift + wheel button).  Click the ViewCube for standard views.")


def cmd_imageadjust(c):
    """Brightness / contrast / fade with live sliders (pre-selected image, or pick one)."""
    img = [e for e in c.app.selected_ents() if e.kind == "image"]
    if len(img) != 1:
        s = yield c.ent("IMAGEADJUST  Select image", filt=lambda e: e.kind == "image")
        if s is None:
            return
        img = [s[0]]
    e = img[0]
    before = (e.brightness, e.contrast, e.fade)
    c.doc.modify(e)
    r = c.app.dialog_image_adjust(e)
    if r is None:
        e.brightness, e.contrast, e.fade = before; e.touch()
    else:
        e.brightness, e.contrast, e.fade = r; e.touch()
        c.msg(f"Image: brightness {e.brightness:g}, contrast {e.contrast:g}, fade {e.fade * 100:g} %")
    c.doc.rev += 1


def _order_of(e):
    return float(e.xd.get("order", 0.0)) if e.xd else 0.0


def set_draw_order(doc, ents, mode, ref=None):
    """mode Front / Back / Above / Under (the last two relative to ref). Order is stored per object (saved, undoable)."""
    ids = {e.id for e in ents}
    others = sorted({_order_of(o) for o in doc.ents.values() if o.id not in ids} | {0.0})
    if mode == "Front":
        v = max(others) + 1.0
    elif mode == "Back":
        v = min(others) - 1.0
    else:
        r = _order_of(ref)
        if mode == "Above":
            hi = [o for o in others if o > r]; v = (r + min(hi)) / 2 if hi else r + 1.0
        else:
            lo = [o for o in others if o < r]; v = (r + max(lo)) / 2 if lo else r - 1.0
        if v == 0.0:                       # 0 is the neutral level of every untouched object: move the reference instead
            v = 0.5 if mode == "Above" else -0.5
    for e in ents:
        doc.modify(e); e.xd = dict(e.xd or {}); e.xd["order"] = v; e.touch()
    return v


def _order_cmd(c, mode=None):
    ents = yield c.sel("DRAWORDER  Select objects")
    if not ents:
        return
    if mode is None:
        mode = yield c.opt("Enter object ordering option [Above objects/Under objects/Front/Back] <Back>", ["Above", "Under", "Front", "Back"], "Back")
        if mode is None:
            return
    ref = None
    if mode in ("Above", "Under"):
        s = yield c.ent("Select reference object")
        if s is None:
            return
        ref = s[0]
    set_draw_order(c.doc, ents, mode, ref)
    c.msg(f"{len(ents)} object(s): {'brought to front' if mode == 'Front' else 'sent to back' if mode == 'Back' else mode.lower() + ' the reference object'}. "
          "Images and filled objects (hatch, solid, text) follow the order; plain lines stay above normal fills.")


def cmd_draworder(c):
    yield from _order_cmd(c, None)


def cmd_front(c):
    yield from _order_cmd(c, "Front")


def cmd_back(c):
    yield from _order_cmd(c, "Back")


def register(eng):
    R = eng.register
    R("DETAILVIEW", cmd_detailview, ["DV", "VIEWDETAIL", "DETAILAUTO"], "Live enlarged detail linked to the main drawing (auto scale)")
    R("XATTACH", cmd_xattach, ["XA", "XREF", "ATTACH"], "Attach a DWG / DXF / ACP drawing as external reference")
    R("XRELOAD", cmd_xreload, [], "Reload external references from their files"); R("XLIST", cmd_xlist, [], "List external references")
    R("IMAGECLIP", cmd_imageclip, ["ICL"], "Clip (crop) a raster image"); R("IMAGEFRAME", cmd_imageframe, [], "Show / hide image frames")
    R("IMAGEADJUST", cmd_imageadjust, ["IAD", "IMAGEFADE"], "Brightness, contrast and fade of a raster image")
    R("DRAWORDER", cmd_draworder, ["DR"], "Draw order: bring to front, send to back, above / under an object")
    R("BRINGTOFRONT", cmd_front, ["BTF"], "Bring objects to the front")
    R("SENDTOBACK", cmd_back, ["STB"], "Send objects to the back")
    R("BLOCKBASE", cmd_blockbase, ["BASE"], "Change the base point of a block")
    R("VIEW", cmd_view, ["V", "VIEWMANAGER"], "Named views: save / restore / delete")
    R("PAN", cmd_pan, ["P"], "Pan (how to)"); R("3DORBIT", cmd_orbit, ["ORBIT", "3DO"], "Orbit (how to)")
