"""Version 1.6 commands: STRETCH (free, any selection), TRIM / EXTEND with a crossing window or fence, QDIM, REVCLOUD,
CAL (geometry calculator), LTSCALE / CELTSCALE / LINETYPE, associative HATCH."""
import math
import numpy as np
from ..core import entities as E
from ..core import editops as X
from ..core.geom import unit, norm, Plane, m_translate, prim_intersect, prims_closest, bulge_arc, TAU
from .misc import T


# ===================================================================================================== helpers
def _poly_inside(poly, Q):
    """Q (N x 2) inside the 2D polygon (ray casting)."""
    Q = np.asarray(Q, float).reshape(-1, 2); x, y = Q[:, 0], Q[:, 1]
    ins = np.zeros(len(Q), bool); n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]; x2, y2 = poly[(i + 1) % n]
        cond = (y1 > y) != (y2 > y)
        with np.errstate(divide="ignore", invalid="ignore"):
            xi = (x2 - x1) * (y - y1) / np.where(y2 - y1 == 0, 1e-300, (y2 - y1)) + x1
        ins ^= cond & (x < xi)
    return ins


def make_inside(ucs, wins):
    """wins = [(4 world points, crossing)] -> f(points N x 3) -> mask of the points inside any of the windows."""
    polys = [ucs.to_local(np.asarray(w, float))[:, :2] for w, _ in wins if w is not None]
    def inside(P):
        P = np.asarray(P, float).reshape(-1, 3)
        m = np.zeros(len(P), bool)
        if not polys:
            return m
        Q = ucs.to_local(P)[:, :2]
        for pg in polys:
            m |= _poly_inside(pg, Q)
        return m
    return inside


# ===================================================================================================== STRETCH
def stretch_entity(e, d, inside, M=None):
    """Moves the defining points of e that are inside the stretch windows by d (in place). True if anything moved."""
    M = m_translate(d) if M is None else M
    k = e.kind
    if k == "line":
        m = inside(np.array([e.p0, e.p1]))
        if m[0]:
            e.p0 = e.p0 + d
        if m[1]:
            e.p1 = e.p1 + d
        return bool(m.any())
    if k == "polyline":
        m = inside(e.pts)
        if m.any():
            e.pts = e.pts + np.where(m[:, None], d, 0.0)
        return bool(m.any())
    if k == "arc":
        p0, p1 = e.ends(); m = inside(np.array([p0, p1, e.c]))
        if m[0] and m[1]:
            e.transform(M); return True
        if m[0] or m[1]:
            # one end follows: the arc keeps its bulge (shape) between the new end points
            sw = (e.a1 - e.a0) % TAU or TAU; b = math.tan(sw / 4)
            q0 = p0 + d if m[0] else p0; q1 = p1 + d if m[1] else p1
            a = bulge_arc(q0, q1, b, e.n)
            if a is not None:
                n2 = E.Arc.through(q0, a[0] + a[1] * (math.cos(a[5] / 2) * a[3] + math.sin(a[5] / 2) * np.cross(a[2], a[3])), q1)
                if n2 is not None:
                    e.c, e.r, e.n, e.a0, e.a1 = n2.c, n2.r, n2.n, n2.a0, n2.a1
                    return True
        return False
    if k == "spline":
        if getattr(e, "fit", None) is not None:
            m = inside(e.fit)
            if m.any():
                s = E.Spline.through(e.fit + np.where(m[:, None], d, 0.0)); e.ctrl, e.knots, e.deg, e.fit = s.ctrl, s.knots, s.deg, s.fit
            return bool(m.any())
        m = inside(e.ctrl)
        if m.any():
            e.ctrl = e.ctrl + np.where(m[:, None], d, 0.0)
        return bool(m.any())
    if k == "dimension":
        m = inside(np.array(e.dpts)); e.dpts = [p + d if f else p for p, f in zip(e.dpts, m)]
        return bool(m.any())
    if k == "leader":
        m = inside(e.pts)
        if m.any():
            e.pts = e.pts + np.where(m[:, None], d, 0.0)
        return bool(m.any())
    if k == "hatch":
        any_ = False; new = []
        for L in e.loops:
            m = inside(L); any_ = any_ or bool(m.any()); new.append(L + np.where(m[:, None], d, 0.0))
        e.loops = new
        return any_
    # everything else moves as a whole when its reference point is inside
    ref = None
    for a in ("c", "p", "o"):
        v = getattr(e, a, None)
        if isinstance(v, np.ndarray) and v.shape == (3,):
            ref = v; break
    if ref is None and k == "insert":
        try:
            ref = np.asarray(e.M, float)[:3, 3]
        except Exception:
            ref = None
    if ref is None:
        bb = e.bbox()
        if bb is None:
            return False
        ok = bool(inside(np.array(bb)).all())
    else:
        ok = bool(inside(np.array([ref]))[0])
    if ok:
        e.transform(M)
    return ok


def cmd_stretch(c):
    """STRETCH: objects crossed by the selection windows are stretched (their points inside the windows move);
    objects completely inside, or picked one by one, are moved.  Drag freely or type a distance / displacement."""
    had_pre = bool(c.view.selection); idle = list(getattr(c.app, "idle_windows", []))
    req = c.sel("STRETCH  Select objects to stretch with a crossing window (drag right to left), Enter when done")
    ents = yield req
    if not ents:
        return
    wins = list(getattr(req, "windows", [])) or (idle if had_pre else [])
    inside0 = make_inside(c.ucs, wins)
    by_window = set()
    if wins:
        for e in ents:                                    # an object without any point in a window was picked: it moves as a whole
            try:
                pts = np.vstack([np.asarray(w, float) for w in e.wire()] or [np.array(e.bbox())])
            except Exception:
                pts = None
            if pts is not None and len(pts) and inside0(pts).any():
                by_window.add(e.id)
    everything = lambda P: np.ones(len(np.asarray(P, float).reshape(-1, 3)), bool)
    def apply(d, dry=True):
        out = []; M = m_translate(d)
        for e in ents:
            n = e.copy() if dry else e
            if not dry:
                c.doc.modify(e)
            try:
                stretch_entity(n, d, inside0 if e.id in by_window else everything, M)
            except Exception:
                pass
            n.touch(); out.append(n)
        return out
    b = yield c.pt("Specify base point or [Displacement] <Displacement>", options=["Displacement"])
    if b is None or isinstance(b, str):
        v = yield c.pt("Specify displacement <0,0,0>  (x,y or pick a point = vector from the origin)")
        if v is None:
            return
        d = np.asarray(v, float) - c.ucs.o
    else:
        q = yield c.pt("Specify second point or <use first point as displacement>  (drag, or type a distance / @dx,dy)", base=b,
                       preview=lambda q: apply(q - b))
        d = (np.asarray(b, float) - c.ucs.o) if q is None else (q - b)
    if norm(d) < 1e-12:
        return
    apply(d, dry=False)
    c.msg(f"Stretched {len(by_window)} object(s), moved {len(ents) - len(by_window)}" if wins else f"Moved {len(ents)} object(s) (no crossing window was used)")


# ===================================================================================================== TRIM / EXTEND
def _fence_hits(c, pts, filt):
    out = []
    segs = [("L", np.asarray(pts[i], float), np.asarray(pts[i + 1], float)) for i in range(len(pts) - 1)]
    for e in c.doc.visible_ents():
        if not c.doc.selectable(e) or not filt(e):
            continue
        try:
            prims = X.curve_prims(e)
        except Exception:
            continue
        for pr in prims:
            for sg in segs:
                L = norm(sg[2] - sg[1])
                try:
                    hits = prim_intersect(pr, sg)
                except Exception:
                    hits = []
                for sa, sb, pt in hits:
                    if -1e-9 <= sb <= L + 1e-9:
                        out.append((e, np.asarray(pt, float)))
    return out


def _trim_extend(c, extend=False):
    name = "EXTEND" if extend else "TRIM"
    edges = yield c.sel(f"{name}  Select {'boundary' if extend else 'cutting'} edges or <Enter = all objects>")
    if not edges:
        edges = list(c.doc.visible_ents())
    pieces = {}                                           # id of a replaced object -> the objects that replaced it
    def live(e, pk):
        """The object (or the piece of it) that is now nearest to the pick point."""
        if e.id in c.doc.ents and c.doc.ents[e.id] is e:
            return e
        cand = []; stack = list(pieces.get(e.id, []))
        while stack:
            x = stack.pop()
            if x.id in c.doc.ents and c.doc.ents[x.id] is x:
                cand.append(x)
            else:
                stack += pieces.get(x.id, [])
        best = None
        for x in cand:
            try:
                dd = prims_closest(X.curve_prims(x), pk)[0]
            except Exception:
                continue
            if best is None or dd < best[0]:
                best = (dd, x)
        return best[1] if best else None
    def one(e, pk):
        nonlocal edges
        e = live(e, pk)
        if e is None:
            return False
        if extend:
            n = X.extend(e, pk, edges)
            if n is None:
                return False
            c.doc.modify(e); c.doc.remove(e); n.id = 0; c.doc.add_keep(n)
            pieces[e.id] = [n]; edges = [n if x is e else x for x in edges]
            return True
        res = X.trim(e, pk, edges)
        if res is None:
            return False
        c.doc.remove(e)
        new = [c.doc.add_keep(r) for r in res]
        pieces[e.id] = new; edges = [x for x in edges if x is not e] + new
        return True
    verb = name.lower()
    while True:
        r = c.ent(f"Select object to {verb}, or drag a window across several objects [Fence] <exit>", filt=X.is_editable_curve, options=["Fence"])
        r.window = True
        s = yield r
        if s is None:
            return
        if s == "Fence":
            pts = []
            while True:
                q = yield c.pt("Specify next fence point <done>" if pts else "Specify first fence point", base=pts[-1] if pts else None,
                               preview=(lambda q, pts=pts: [E.Polyline(pts + [q], False)]) if pts else None)
                if q is None:
                    break
                pts.append(np.asarray(q, float))
            hits = _fence_hits(c, pts, X.is_editable_curve) if len(pts) > 1 else []
        elif isinstance(s, tuple) and len(s) == 2 and isinstance(s[0], str) and s[0] == "window":
            hits = list(s[1])
        else:
            hits = [s]
        n = sum(1 for e, pk in hits if one(e, pk))
        if n == 0:
            c.msg("No boundary found in that direction" if extend else "Object does not intersect a cutting edge")
        elif len(hits) > 1:
            c.msg(f"{n} object(s) {'extended' if extend else 'trimmed'}")


def cmd_trim(c):
    yield from _trim_extend(c, False)


def cmd_extend(c):
    yield from _trim_extend(c, True)


# ===================================================================================================== QDIM
def _dim_step(st):
    k = E.Entity.anno_scale if st.get("anno") else 1.0
    return max(float(st.get("dli", 3.75)), float(st.get("th", 2.5)) * 1.5 + float(st.get("gap", 0.8)) * 2) * k


def _qdim_points(ents):
    pts = []; circ = []
    for e in ents:
        k = e.kind
        if k == "line":
            pts += [e.p0, e.p1]
        elif k == "polyline":
            pts += list(e.pts)
        elif k in ("circle", "arc"):
            pts.append(e.c); circ.append(e)
        elif k == "ellipse":
            pts.append(e.c)
        elif k == "point":
            pts.append(e.p)
        elif k == "insert":
            try:
                pts.append(np.asarray(e.M, float)[:3, 3])
            except Exception:
                pass
        elif k == "spline":
            w = e.wire()
            if w:
                pts += [w[0][0], w[0][-1]]
    return pts, circ


def cmd_qdim(c):
    from .draw2d import _dimstyle, _dim_add
    from .misc import ensure_scale; ensure_scale(c)
    ents = yield c.sel("QDIM  Select geometry to dimension")
    if not ents:
        return
    pts, circ = _qdim_points(ents)
    if len(pts) < 2 and not circ:
        c.msg("Select lines, polylines, circles or arcs"); return
    pl = c.ucs; mode = c.doc.settings.get("qdim_mode", "Continuous")
    L = np.array([pl.to_local(p) for p in pts]) if pts else np.zeros((0, 3))
    def build(q):
        st0 = _dimstyle(c); out = []
        lq = pl.to_local(q)
        if mode in ("Radius", "Diameter"):
            for e in circ:
                u = unit(q - e.c) if norm(q - e.c) > 1e-9 else pl.x
                u = u - np.dot(u, e.n) * e.n; u = unit(u) if norm(u) > 1e-9 else e.u()
                p = e.c + u * e.r
                out.append(E.Dimension("radius" if mode == "Radius" else "diameter", [e.c, p, p + u * st0.get("th", 2.5) * 3 * (E.Entity.anno_scale if st0.get("anno") else 1.0)],
                                       pl.z, pl.x, dict(st0)))
            return out
        if len(L) < 2:
            return out
        mn = L[:, :2].min(axis=0); mx = L[:, :2].max(axis=0)
        ox = max(mn[0] - lq[0], lq[0] - mx[0], 0.0); oy = max(mn[1] - lq[1], lq[1] - mx[1], 0.0)
        horiz = oy >= ox                                   # dimension line above / below the objects measures along X
        ax = 0 if horiz else 1; oth = 1 - ax
        side = 1.0 if lq[oth] >= (mn[oth] + mx[oth]) / 2 else -1.0
        tol = max(float(mx[ax] - mn[ax]), 1e-9) * 1e-7
        order = np.argsort(L[:, ax]); groups = []
        for i in order:                                    # one extension origin per position: the point nearest to the dimension line
            if groups and abs(L[i, ax] - L[groups[-1], ax]) <= tol:
                if (L[i, oth] - L[groups[-1], oth]) * side > 0:
                    groups[-1] = i
            else:
                groups.append(i)
        P = [pts[i] for i in groups]
        if len(P) < 2:
            return out
        st = dict(st0); st["rot"] = 0 if horiz else 90
        step = _dim_step(st); off = pl.y if horiz else pl.x
        def lin(a, b, level=0):
            return E.Dimension("linear", [a, b, q + off * side * step * level], pl.z, pl.x, dict(st))
        if mode == "Baseline":
            for i in range(1, len(P)):
                out.append(lin(P[0], P[i], i - 1))
        elif mode == "Staggered":
            n = len(P); pairs = [(i, n - 1 - i) for i in range(n // 2)]
            for lev, (i, j) in enumerate(reversed(pairs)):
                out.append(lin(P[i], P[j], lev))
        elif mode == "Ordinate":
            for p in P:
                so = dict(st0); so["axis"] = "x" if horiz else "y"
                lp = pl.to_local(p); e_ = lp.copy(); e_[oth] = lq[oth]
                out.append(E.Dimension("ordinate", [P[0], p, pl.to_world(e_)], pl.z, pl.x, so))
        else:
            for i in range(len(P) - 1):
                out.append(lin(P[i], P[i + 1]))
        return out
    opts = ["Continuous", "Staggered", "Baseline", "Ordinate", "Radius", "Diameter"]
    while True:
        q = yield c.pt(f"Specify dimension line position, or [Continuous/Staggered/Baseline/Ordinate/Radius/Diameter] <{mode}>", options=opts,
                       preview=lambda q: build(q))
        if q is None:
            return
        if isinstance(q, str):
            mode = q; c.doc.settings["qdim_mode"] = mode; continue
        ds = build(q)
        for d in ds:
            _dim_add(c, d)
        c.msg(f"QDIM {mode}: {len(ds)} dimension(s)")
        return


def _chain(c, baseline):
    from .draw2d import _dim_add
    from .annot import _last_linear, _scale
    _scale(c)
    name = "DIMBASELINE" if baseline else "DIMCONTINUE"
    base = _last_linear(c)
    r = yield c.ent(f"{name}  Select base dimension" + (" <last dimension>" if base is not None else ""),
                    filt=lambda e: e.kind == "dimension" and e.dtype in ("linear", "aligned"))
    first_from_pick = None
    if r is not None:
        base = r[0]
        # the extension line nearest to the pick is the base line (AutoCAD)
        if r[1] is not None and norm(np.asarray(r[1]) - base.dpts[1]) < norm(np.asarray(r[1]) - base.dpts[0]) and baseline:
            first_from_pick = 1
    if base is None:
        c.msg("Create a linear or aligned dimension first"); return
    step = _dim_step(base.style)
    cur = base; n = 0
    org0 = base.dpts[first_from_pick] if first_from_pick is not None else base.dpts[0]
    while True:
        P = cur.dpts
        org = org0 if baseline else P[1]
        def mk(q, cur=cur, org=org):
            d = E.Dimension(cur.dtype, [org, q, cur.dpts[2]], cur.n, cur.xdir, dict(cur.style))
            if baseline:
                g = E._dim_geometry(cur)[0]
                dl = None
                for seg in g:                               # the dimension line = the segment through the dimension point
                    if len(seg) == 2:
                        dl = seg
                if dl is not None and norm(dl[1] - dl[0]) > 1e-9:
                    u = unit(dl[1] - dl[0]); w = dl[0] - cur.dpts[0]; away = w - np.dot(w, u) * u
                    if norm(away) > 1e-9:
                        d.dpts[2] = cur.dpts[2] + unit(away) * step
            return d
        q = yield c.pt("Specify second extension line origin <done>", base=org, preview=lambda q: [mk(q)])
        if q is None:
            break
        d = mk(q); _dim_add(c, d); n += 1; cur = d
    if n:
        c.msg(f"{n} dimension(s) added")


def cmd_dimcontinue(c):
    yield from _chain(c, False)


def cmd_dimbaseline(c):
    yield from _chain(c, True)


# ===================================================================================================== REVCLOUD
def cloud_polyline(loop, arc, n=(0, 0, 1), keep_corners=True, calligraphy=False):
    """Closed revision cloud along the closed loop (N x 3 world points): arcs of chord length ~arc bulging outwards."""
    P = np.asarray(loop, float).reshape(-1, 3)
    if len(P) > 1 and norm(P[0] - P[-1]) < 1e-9:
        P = P[:-1]
    if len(P) < 3 or arc <= 0:
        return None
    pl = Plane.from_normal(P[0], n); Q = pl.to_local(P)[:, :2]
    area = 0.5 * float(np.sum(Q[:, 0] * np.roll(Q[:, 1], -1) - np.roll(Q[:, 0], -1) * Q[:, 1]))
    if area < 0:
        P = P[::-1]
    out = []
    if keep_corners:
        for i in range(len(P)):
            a, b = P[i], P[(i + 1) % len(P)]; L = norm(b - a)
            k = max(1, int(round(L / arc)))
            for j in range(k):
                out.append(a + (b - a) * (j / k))
    else:
        C = np.vstack([P, P[:1]]); d = np.linalg.norm(np.diff(C, axis=0), axis=1); cum = np.concatenate([[0.0], np.cumsum(d)])
        k = max(4, int(round(cum[-1] / arc)))
        for t in np.arange(k) * (cum[-1] / k):
            out.append(np.array([np.interp(t, cum, C[:, i]) for i in range(3)]))
    if len(out) < 3:
        return None
    e = E.Polyline(out, True, [0.5] * len(out)); e.n = unit(np.asarray(n, float))
    if calligraphy:
        e.width = arc * 0.08
    return e


def cmd_revcloud(c):
    st = c.doc.settings
    arc = float(st.get("revcloud_arc", 0) or 0)
    if arc <= 0:
        arc = max(c.view.cam.h / 28.0, 1e-6)
    style = st.get("revcloud_style", "Normal"); mode = st.get("revcloud_mode", "Rectangular")
    n = c.ucs.z
    def finish(e):
        if e is None:
            c.msg("Revision cloud: the outline is too small for this arc length"); return
        e.layer = c.doc.cur_layer; c.doc.add(e); c.msg(f"Revision cloud: {len(e.pts)} arcs, arc length {arc:g}, {style}")
    mk = lambda loop, corners=True: cloud_polyline(loop, arc, n, corners, style == "Calligraphy")
    opts = ["Arc length", "Object", "Rectangular", "Polygonal", "Freehand", "Style"]
    while True:
        head = {"Rectangular": "Specify first corner point", "Polygonal": "Specify start point", "Freehand": "Specify first point (then move the cursor, click to finish)"}[mode]
        s = yield c.pt(f"REVCLOUD  ({mode}, arc {arc:g}, {style})  {head} or [Arc length/Object/Rectangular/Polygonal/Freehand/Style]", options=opts)
        if s is None:
            return
        if isinstance(s, str):
            if s == "Arc length":
                v = yield c.dist(f"Specify arc length <{arc:g}>", default=arc)
                if v:
                    arc = float(v); st["revcloud_arc"] = arc
            elif s == "Style":
                o = yield c.opt(f"Select arc style [Normal/Calligraphy] <{style}>", ["Normal", "Calligraphy"], style)
                if o:
                    style = o; st["revcloud_style"] = style
            elif s == "Object":
                r = yield c.ent("Select a closed object (polyline, circle, ellipse, spline)", filt=lambda e: getattr(e, "closed", False) and e.kind != "hatch")
                if r is None:
                    continue
                e0 = r[0]; w = e0.wire()
                if not w:
                    continue
                straight = e0.kind == "polyline" and not np.any(np.abs(np.asarray(e0.bulges, float)) > 1e-12)
                cl = mk(e0.pts if straight else w[0], straight)
                if cl is not None:
                    c.doc.remove(e0)
                finish(cl); return
            else:
                mode = s; st["revcloud_mode"] = mode
            continue
        a = np.asarray(s, float)
        if mode == "Rectangular":
            def rect(q):
                la, lq = c.ucs.to_local(a), c.ucs.to_local(q)
                return [c.ucs.to_world(np.array(v)) for v in ((la[0], la[1], la[2]), (lq[0], la[1], la[2]), (lq[0], lq[1], la[2]), (la[0], lq[1], la[2]))]
            b = yield c.corner("Specify opposite corner", a, preview=lambda q: [mk(rect(q))])
            if b is None:
                return
            finish(mk(rect(b))); return
        if mode == "Polygonal":
            pts = [a]
            while True:
                q = yield c.pt("Specify next point <close>", base=pts[-1],
                               preview=lambda q, pts=pts: [mk(pts + [q]) if len(pts) >= 2 else E.Polyline(pts + [q], False)])
                if q is None:
                    break
                pts.append(np.asarray(q, float))
            if len(pts) >= 3:
                finish(mk(pts))
            return
        # freehand: the path follows the cursor until the next click
        path = [a]
        def trail(q):
            if norm(q - path[-1]) >= arc * 0.9:
                path.append(np.asarray(q, float).copy())
            return [mk(path + [q], False) if len(path) >= 3 else E.Polyline(path + [q], False)]
        q = yield c.pt("Guide the cursor along the cloud path, click to close it", preview=trail)
        if q is None or len(path) < 3:
            return
        finish(mk(path, False)); return


# ===================================================================================================== CAL
class V(np.ndarray):
    """3D vector for CAL: v*w = dot product, v&w = cross product, scalar*v, v/scalar, abs(v) = length."""
    def __new__(cls, x=0.0, y=0.0, z=0.0):
        return np.asarray([float(x), float(y), float(z)], float).view(cls)

    def __mul__(self, o):
        return float(np.dot(self, o)) if isinstance(o, np.ndarray) else np.multiply(self, o).view(V)

    def __rmul__(self, o):
        return np.multiply(self, o).view(V)

    def __and__(self, o):
        return np.cross(self, o).view(V)

    def __abs__(self):
        return float(np.linalg.norm(self))


CAL_PICKS = {"end": "end", "mid": "mid", "cen": "cen", "int": "int", "qua": "quad", "nea": "near", "nod": "node", "ins": "ins",
             "per": "perp", "tan": "tan", "cur": None}


def cal_namespace(app=None):
    d2r = math.radians; r2d = math.degrees
    def vec(a, b): return (np.asarray(b) - np.asarray(a)).view(V)
    def vec1(a, b): return unit(np.asarray(b, float) - np.asarray(a, float)).view(V)
    def dist(a, b): return float(norm(np.asarray(b, float) - np.asarray(a, float)))
    def ang(*a):
        if len(a) == 1:
            return r2d(math.atan2(a[0][1], a[0][0])) % 360.0
        if len(a) == 2:
            v = np.asarray(a[1], float) - np.asarray(a[0], float); return r2d(math.atan2(v[1], v[0])) % 360.0
        u = np.asarray(a[1], float) - np.asarray(a[0], float); w = np.asarray(a[2], float) - np.asarray(a[0], float)
        return (r2d(math.atan2(w[1], w[0]) - math.atan2(u[1], u[0]))) % 360.0
    def pld(a, b, d): return (np.asarray(a, float) + unit(np.asarray(b, float) - np.asarray(a, float)) * d).view(V)
    def plt(a, b, t): return (np.asarray(a, float) + (np.asarray(b, float) - np.asarray(a, float)) * t).view(V)
    def rot(p, o, a, *rest):
        p = np.asarray(p, float) - np.asarray(o, float); r = d2r(a if not rest else rest[0])
        return (np.asarray(o, float) + np.array([p[0] * math.cos(r) - p[1] * math.sin(r), p[0] * math.sin(r) + p[1] * math.cos(r), p[2]])).view(V)
    def ill(a, b, c_, d):
        a, b, c_, d = (np.asarray(x, float) for x in (a, b, c_, d)); u = b - a; w = d - c_
        den = u[0] * w[1] - u[1] * w[0]
        if abs(den) < 1e-14:
            raise ValueError("the lines are parallel")
        t = ((c_ - a)[0] * w[1] - (c_ - a)[1] * w[0]) / den
        return (a + u * t).view(V)
    def dpl(p, a, b):
        p, a, b = (np.asarray(x, float) for x in (p, a, b)); u = unit(b - a); w = p - a
        return float(norm(w - np.dot(w, u) * u))
    ns = {"V": V, "pi": math.pi, "PI": math.pi, "e": math.e,
          "sin": lambda a: math.sin(d2r(a)), "cos": lambda a: math.cos(d2r(a)), "tang": lambda a: math.tan(d2r(a)), "tan_": lambda a: math.tan(d2r(a)),
          "asin": lambda v: r2d(math.asin(v)), "acos": lambda v: r2d(math.acos(v)), "atan": lambda v: r2d(math.atan(v)),
          "ln": math.log, "log": math.log10, "exp": math.exp, "exp10": lambda v: 10.0 ** v, "sqr": lambda v: v * v, "sqrt": math.sqrt,
          "abs": abs, "round": lambda v: float(round(v)), "trunc": lambda v: float(math.trunc(v)), "r2d": r2d, "d2r": d2r,
          "min": min, "max": max,
          "vec": vec, "vec1": vec1, "dist": dist, "ang": ang, "pld": pld, "plt": plt, "rot": rot, "ill": ill, "dpl": dpl,
          "xof": lambda p: V(p[0], 0, 0), "yof": lambda p: V(0, p[1], 0), "zof": lambda p: V(0, 0, p[2]),
          "xyof": lambda p: V(p[0], p[1], 0), "rxof": lambda p: float(p[0]), "ryof": lambda p: float(p[1]), "rzof": lambda p: float(p[2]),
          "mid2": lambda a, b: ((np.asarray(a, float) + np.asarray(b, float)) / 2).view(V)}
    if app is not None:
        try:
            lp = app.engine.last_point
            ns["last"] = V(*lp) if lp is not None else V()
        except Exception:
            ns["last"] = V()
    return ns


def cal_translate(expr):
    """CAL syntax -> Python: [x,y,z] vectors, ^ power, @ = last point."""
    import re
    s = expr.strip()
    if "__" in s or any(k in s for k in ("import", "lambda", "exec", "eval", "open(", "getattr", "class")):
        raise ValueError("not allowed in an expression")
    s = s.replace("^", "**")
    s = re.sub(r"\[([^\[\]]*)\]", lambda m: "V(" + ",".join(p if p.strip() else "0" for p in (m.group(1).split(",") + ["0", "0", "0"])[:3]) + ")", s)
    s = re.sub(r"@", "last", s)
    return s


def cal_eval(expr, ns):
    return eval(cal_translate(expr), {"__builtins__": {}}, ns)


def cal_format(v):
    if isinstance(v, np.ndarray):
        return ",".join(f"{float(x):.10g}" for x in np.asarray(v).ravel()[:3])
    if isinstance(v, (int, float, np.floating)):
        return f"{float(v):.10g}"
    return str(v)


def cmd_cal(c):
    """CAL: evaluates an expression.  Numbers, [x,y,z] points, + - * / ^, sin cos tang asin acos atan (degrees), sqrt sqr ln log exp
    abs round trunc pi, dist(p1,p2) ang(p1,p2) pld(p1,p2,d) plt(p1,p2,t) ill(p1,p2,p3,p4) dpl(p,p1,p2) vec vec1 rot xof yof zof,
    object snaps end mid cen int qua nea ins nod per (each one asks for a pick), cur (pick any point), rad (pick a circle / arc),
    @ = last point, mee = midpoint between two endpoints."""
    import re
    while True:
        s = yield c.text(">> Expression  (e.g. (end+end)/2, dist(end,end), 2*pi*rad, 125.5/3)  <exit>")
        if not s or not str(s).strip():
            return
        expr = str(s).strip()
        expr = re.sub(r"\bmee\b", "((end+end)/2)", expr)
        ns = cal_namespace(c.app); k = [0]
        failed = False
        # every snap word asks for one pick, in the order they are written
        tokens = list(re.finditer(r"\b(end|mid|cen|int|qua|nea|nod|ins|per|cur|rad)\b(?!\s*\()", expr))
        out = expr
        for i in range(len(tokens) - 1, -1, -1):
            m = tokens[i]; out = out[:m.start()] + f"_p{i}" + out[m.end():]
        for i, m in enumerate(tokens):
            w = m.group(1)
            if w == "rad":
                r = yield c.ent(f">> Select circle, arc or polyline arc segment for RAD ({i + 1}/{len(tokens)})", filt=lambda e: e.kind in ("circle", "arc", "polyline"))
                if r is None:
                    failed = True; break
                val = None
                if r[0].kind in ("circle", "arc"):
                    val = float(r[0].r)
                else:
                    from .annot import _arc_of
                    a = _arc_of(r[0], r[1], c.ucs.z)
                    val = float(norm(a[1] - a[0])) if a else None
                if val is None:
                    c.msg("No arc there"); failed = True; break
                ns[f"_p{i}"] = val
            else:
                snap = CAL_PICKS[w]
                if snap:
                    c.view.snap_override = snap
                q = yield c.pt(f">> Select entity for {w.upper()} snap ({i + 1}/{len(tokens)})" if snap else f">> Enter a point ({i + 1}/{len(tokens)})")
                if q is None or isinstance(q, str):
                    failed = True; break
                ns[f"_p{i}"] = V(*q)
        if failed:
            continue
        try:
            v = eval(cal_translate(out), {"__builtins__": {}}, ns)
        except Exception as ex:
            c.msg(f">> Error: {ex}"); continue
        txt = cal_format(v)
        c.msg(f"{expr} = {txt}")
        c.doc.settings["cal_last"] = txt
        try:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(txt)
        except Exception:
            pass
        if isinstance(v, np.ndarray):
            c.app.engine.last_point = np.asarray(v, float).view(np.ndarray).copy()


def cal_inline(app, text):
    """'=expr' or \"'cal expr\" typed at a command prompt -> text of the value (number or x,y,z) or None."""
    t = text.strip()
    low = t.lower()
    if low.startswith("'cal"):
        t = t[4:].strip()
    elif t.startswith("="):
        t = t[1:].strip()
    else:
        return None
    if not t:
        return None
    ns = cal_namespace(app)
    try:
        ns["cur"] = V(*app.view.mouse_world)
    except Exception:
        pass
    return cal_format(cal_eval(t, ns))


# ===================================================================================================== linetype scale
def cmd_ltscale(c):
    cur = float(c.doc.settings.get("ltscale", 1.0) or 1.0)
    v = yield c.num(f"LTSCALE  Enter new linetype scale factor <{cur:g}>", default=cur)
    if v is None or float(v) <= 0:
        return
    c.doc.settings["ltscale"] = float(v); c.doc.rev += 1; c.doc.modified = True
    c.msg(f"Global linetype scale = {float(v):g}")


def cmd_celtscale(c):
    cur = float(getattr(c.doc, "cur_lts", 1.0) or 1.0)
    v = yield c.num(f"CELTSCALE  Enter linetype scale of new objects <{cur:g}>", default=cur)
    if v is None or float(v) <= 0:
        return
    c.doc.cur_lts = float(v); c.msg(f"Linetype scale of new objects = {float(v):g}")


@T
def cmd_linetype(c):
    c.app.linetype_manager()


@T
def cmd_imageframe(c):
    """IMAGEFRAME: 0 = frames hidden and images cannot be selected (locked underlay for redrawing), 1 = frames shown."""
    imgs = [e for e in c.doc.ents.values() if e.kind == "image"]
    if not imgs:
        c.msg("No images in the drawing"); return
    on = not imgs[0].show_frame
    c.doc.begin("imageframe")
    for e in imgs:
        c.doc.modify(e); e.show_frame = on; e.touch()
    c.doc.end()
    c.app.clear_selection(silent=True)
    c.msg("IMAGEFRAME 1: image frames shown, images can be selected by their frame" if on else
          "IMAGEFRAME 0: image frames hidden - images are locked (cannot be selected) while you redraw over them")


def cmd_plotwindow(c):
    """Two corners of the plot window (from the Plot dialog, button Window<); the dialog opens again afterwards."""
    st = dict(getattr(c.app, "_plot_state", None) or {})
    a = yield c.pt("PLOT  Specify first corner of the plot window")
    b = None
    if a is not None:
        la = c.ucs.to_local(a)
        def box(q):
            lq = c.ucs.to_local(q)
            return [E.Polyline([c.ucs.to_world(np.array(v)) for v in ((la[0], la[1], la[2]), (lq[0], la[1], la[2]), (lq[0], lq[1], la[2]), (la[0], lq[1], la[2]))], True)]
        b = yield c.corner("Specify opposite corner", a, preview=box)
    if a is not None and b is not None:
        st["window"] = [list(map(float, a)), list(map(float, b))]; st["area"] = "Window"
    c.app.after_command(lambda: c.app.file_plot(st))


def register(eng):
    R = eng.register
    R("PLOTWINDOW", cmd_plotwindow, [], "Pick the plot window (used by the Plot dialog)")
    R("STRETCH", cmd_stretch, ["S"], "Stretch with crossing windows (free drag, distance or displacement); picked objects move")
    R("TRIM", cmd_trim, ["TR"], "Trim: click, or drag a window / fence across several objects")
    R("EXTEND", cmd_extend, ["EX"], "Extend: click, or drag a window / fence across several objects")
    R("QDIM", cmd_qdim, ["QD"], "Quick dimension: Continuous / Staggered / Baseline / Ordinate / Radius / Diameter of the selected geometry")
    R("DIMCONTINUE", cmd_dimcontinue, ["DCO", "DIMCONT"], "Continue a linear dimension (chain)")
    R("DIMBASELINE", cmd_dimbaseline, ["DBA", "DIMBASE"], "Baseline dimensions from the same origin")
    R("REVCLOUD", cmd_revcloud, ["REVC"], "Revision cloud: Rectangular / Polygonal / Freehand / Object, Arc length, Style")
    R("CAL", cmd_cal, ["CALC"], "Geometry calculator (also: type =expression at any prompt)")
    R("LTSCALE", cmd_ltscale, ["LTS"], "Global linetype scale factor")
    R("CELTSCALE", cmd_celtscale, [], "Linetype scale of new objects")
    R("LINETYPE", cmd_linetype, ["LT", "LTYPE"], "Linetype manager: linetypes, global and object scale")
    R("IMAGEFRAME", cmd_imageframe, [], "Show / hide image frames (hidden = images locked)")
