"""Piping and electrical: 2D symbol library, 3D fittings, 3D pipe routing, cable trays, conduit and equipment."""
import math
import numpy as np
from ..core import entities as E, symbols as SY, fittings3d as F, solids as S
from ..core.geom import unit, norm, Plane, v3, m_rotate


INLINE = {"Gate valve", "Globe valve", "Ball valve", "Butterfly valve", "Check valve", "SDNR valve", "Needle valve", "Plug cock",
          "Reducing valve", "Solenoid valve", "Pneumatic valve", "Motor valve", "Quick-closing valve", "Storm valve", "Y-strainer",
          "Mud box", "Filter", "Duplex filter", "Centrifugal pump", "Gear pump", "Concentric reducer", "Eccentric reducer", "Flange pair",
          "Spectacle blind", "Expansion joint", "Flexible hose", "Flow meter", "Sight glass", "Steam trap", "Heat exchanger",
          "Circuit breaker", "Air circuit breaker", "Fuse", "Contactor", "Isolator"}


def _block_xrange(blk):
    """(xmin, xmax) of the block geometry on its own axis (texts ignored)."""
    xs = []
    for e in blk.ents:
        if e.kind in ("text", "hatch"):
            continue
        try:
            for pr in e.prims():
                xs += [pr[1][0], pr[2][0]] if pr[0] == "L" else [pr[1][0] - pr[2], pr[1][0] + pr[2]]
        except Exception:
            pass
    return (min(xs), max(xs)) if xs else (0.0, 0.0)


def insert_symbol(c, name):
    """Insert a 2D symbol repeatedly. Clicking on a line / polyline / arc puts the symbol ON it, turned to the line direction
    (option Perpendicular = at 90 deg to the line) and - for in-line symbols - opens the line under the symbol."""
    from .misc import ensure_scale; ensure_scale(c)
    from ..core import editops as X
    blk, layer = SY.make_block(name)
    if blk.name not in c.doc.blocks:
        c.doc.add_block(blk)
    sc = float(c.doc.settings.get("sym_scale", 1.0))
    st = {"ang": 0.0, "perp": False, "brk": name in INLINE}
    x0, x1 = _block_xrange(blk)

    def mk(p, ang=0.0):
        ins = E.Insert.make(blk.name, p, sc, sc, sc, ang, c.ucs.z)
        x = c.ucs.x; y = c.ucs.y
        ins.M[:3, 0] = (math.cos(ang) * x + math.sin(ang) * y) * sc
        ins.M[:3, 1] = (-math.sin(ang) * x + math.cos(ang) * y) * sc
        ins.M[:3, 2] = c.ucs.z * sc
        ins.M[:3, 3] = p
        ins.anno = True; ins.layer = layer
        return ins

    def locate(q):
        """-> (point, angle, host curve or None)"""
        hit = c.view.curve_at_cursor()
        if hit is None:
            return q, st["ang"], None
        e, ph, t = hit
        sh = c.view.snap_hit
        p = q if (sh and sh[0] in ("end", "mid", "int", "node", "cen", "quad")) else ph      # keep an exact object snap
        tl = np.array([np.dot(t, c.ucs.x), np.dot(t, c.ucs.y)])
        if np.hypot(*tl) < 1e-9:
            return p, st["ang"], e
        ang = math.atan2(tl[1], tl[0])
        if ang > math.pi / 2 + 1e-9 or ang <= -math.pi / 2 + 1e-9:       # keep symbols upright / readable
            ang += math.pi
        if st["perp"]:
            ang += math.pi / 2
        return p, ang, e

    def pv(q):
        p, ang, e = locate(q)
        return [mk(p, ang)]

    n = 0
    while True:
        opts = ["Angle", "Perpendicular", "Break"]
        info = f"angle={math.degrees(st['ang']):g}  on-line={'90 deg' if st['perp'] else 'aligned'}  break={'on' if st['brk'] else 'off'}"
        p = yield c.pt(f"SYMBOL {name}  Click a line or a point [Angle/Perpendicular/Break] ({info}) <exit>", preview=pv, options=opts)
        if p is None:
            if n:
                c.msg(f"{n} x {name} inserted")
            return
        if p == "Angle":
            a = yield c.num(f"Rotation angle for free placement <{math.degrees(st['ang']):g}>", math.degrees(st["ang"]))
            st["ang"] = math.radians(float(a or 0.0)); continue
        if p == "Perpendicular":
            st["perp"] = not st["perp"]; c.msg("Symbol on a line: " + ("90 deg to the line" if st["perp"] else "aligned with the line")); continue
        if p == "Break":
            st["brk"] = not st["brk"]; c.msg("Break the line under the symbol: " + ("on" if st["brk"] else "off")); continue
        pos, ang, host = locate(p)
        ins = c.doc.add_keep(mk(pos, ang)); n += 1
        if host is not None and st["brk"] and not st["perp"] and host.kind in ("line", "polyline", "arc") and not host.closed and x1 - x0 > 1e-6:
            try:
                M = ins.Meff(); d = M[:3, 0]                       # world vector of one block unit along the symbol axis
                a, b = pos + d * x0, pos + d * x1
                res = X.break_curve(host, a, b)
                if res:
                    c.doc.remove(host)
                    for r in res:
                        c.doc.add_keep(r)
            except Exception:
                pass


def _ang(c, p, q):
    d = c.ucs.to_local(q) - c.ucs.to_local(p)
    return math.atan2(d[1], d[0])


def cmd_symbol(c, name=None):
    if name is None:
        c.app.show_symbol_library(); return
    yield from insert_symbol(c, name)


def cmd_fitting(c, opt=None):
    opt = opt or c.app.dialog_fitting()
    if not opt:
        return
    ftype = opt["ftype"]; dn = opt["dn"]
    kw = dict(std=opt["std"], pipe_std=opt["pipe_std"])
    if ftype.startswith("Reducer"):
        kw["dn2"] = opt.get("dn2")
    if ftype == "Pipe (straight)":
        kw["length"] = opt.get("length", 1000.0)
    try:
        man, meta = F.build_fitting(ftype, dn, **kw)
    except Exception as ex:
        c.msg(f"Fitting failed: {ex}"); return
    def frame(p, q, r=None):
        d = unit(q - p) if q is not None and norm(q - p) > 1e-9 else c.ucs.x
        if r is not None and norm(r - p) > 1e-9:
            y = r - p; y = y - np.dot(y, d) * d
            if norm(y) < 1e-9:
                y = c.ucs.z if abs(np.dot(c.ucs.z, d)) < 0.9 else c.ucs.y
        else:
            y = c.ucs.y if abs(np.dot(c.ucs.y, d)) < 0.9 else c.ucs.z
            y = y - np.dot(y, d) * d
        return Plane(p, d, unit(y))
    from ..core.solids import from_manifold, place
    role = "pipe" if ftype == "Pipe (straight)" else "fitting"
    mk = lambda fr: from_manifold(place(man, fr), role, dict(meta))
    while True:
        p = yield c.pt(f"{ftype} {F.size_text(dn)}  Specify connection point (port 1) <exit>", preview=lambda q: [mk(frame(q, None))])
        if p is None:
            return
        q = yield c.pt("Specify run direction point", base=p, preview=lambda q: [mk(frame(p, q))])
        if q is None:
            return
        r = None
        if ftype.startswith("Elbow") or ftype == "Tee equal" or "valve" in ftype or ftype == "Y-strainer" or ftype.startswith("Reducer ecc"):
            r = yield c.pt("Specify branch / stem direction point <default>", base=p, preview=lambda rr: [mk(frame(p, q, rr))])
        b = mk(frame(p, q, r)); b.layer = "PIPING"
        c.doc.add_keep(b)


def cmd_pipe3d(c):
    opt = c.app.dialog_pipe()
    if not opt:
        return
    o = yield c.pt("PIPE3D  Specify start point or [Object]", options=["Object"])
    pts = []
    if o == "Object":
        s = yield c.ent("Select path (line / polyline / 3D polyline)", filt=lambda e: e.kind in ("line", "polyline"))
        if s is None:
            return
        e = s[0]
        pts = [e.p0, e.p1] if e.kind == "line" else list(e.pts) + ([e.pts[0]] if e.closed else [])
    else:
        if o is None:
            return
        pts = [o]
        while True:
            q = yield c.pt("Specify next point of the pipe route <done>", base=pts[-1],
                           preview=lambda q: [E.Polyline(np.array(pts + [q]), False, None, c.ucs.z, True)])
            if q is None:
                break
            pts.append(q)
    if len(pts) < 2:
        return
    try:
        parts = F.route_pipe(pts, opt["dn"], opt["pipe_std"], opt.get("R"), opt.get("flanges"), opt["std"])
    except Exception as ex:
        c.msg(f"Pipe route failed: {ex}"); return
    for b in parts:
        b.layer = "PIPING"; c.doc.add_keep(b)
    L = sum(b.meta.get("length", 0) for b in parts if b.role == "pipe")
    c.msg(f"Pipe {F.size_text(opt['dn'])}: {len(parts)} parts, straight length {L / 1000:.2f} m")


def cmd_tray(c):
    opt = c.app.dialog_tray()
    if not opt:
        return
    o = yield c.pt("CABLETRAY  Specify start point or [Object]", options=["Object"])
    pts = []
    if o == "Object":
        s = yield c.ent("Select path", filt=lambda e: e.kind in ("line", "polyline"))
        if s is None:
            return
        e = s[0]; pts = [e.p0, e.p1] if e.kind == "line" else list(e.pts)
    elif o is not None:
        pts = [o]
        while True:
            q = yield c.pt("Specify next point <done>", base=pts[-1], preview=lambda q: [E.Polyline(np.array(pts + [q]), False, None, c.ucs.z, True)])
            if q is None:
                break
            pts.append(q)
    if len(pts) < 2:
        return
    try:
        b = F.cable_tray(pts, opt["W"], opt["H"], c.ucs.z)
    except Exception as ex:
        c.msg(f"Cable tray failed: {ex}"); return
    b.layer = "ELECTRICAL"; c.doc.add_keep(b)


def cmd_conduit(c):
    dn = 25
    o = yield c.pt("CONDUIT  Specify start point")
    if o is None:
        return
    pts = [o]
    while True:
        q = yield c.pt("Specify next point <done>", base=pts[-1], preview=lambda q: [E.Polyline(np.array(pts + [q]), False, None, c.ucs.z, True)])
        if q is None:
            break
        pts.append(q)
    if len(pts) < 2:
        return
    try:
        parts = F.route_pipe(pts, dn, "JIS G3452 SGP", F.B169[dn][0] * 2)
    except Exception as ex:
        c.msg(str(ex)); return
    for b in parts:
        b.role = "equipment"; b.meta["ftype"] = "Conduit " + b.meta.get("ftype", ""); b.layer = "ELECTRICAL"; c.doc.add_keep(b)


def cmd_equip(c):
    opt = c.app.dialog_equipment()
    if not opt:
        return
    def mk(p, a=0.0):
        x = math.cos(a) * c.ucs.x + math.sin(a) * c.ucs.y
        fr = Plane(p, x, np.cross(c.ucs.z, x))
        return F.equipment_body(opt["kind"], opt["dims"], fr)
    while True:
        p = yield c.pt(f"{opt['kind']}  Specify base point <exit>", preview=lambda q: [mk(q)])
        if p is None:
            return
        a = yield c.angle("Specify rotation <0>", base=p, default=0.0, preview=lambda q: [mk(p, _ang(c, p, q))])
        b = mk(p, math.radians(a or 0)); b.layer = "ELECTRICAL"; c.doc.add_keep(b)


def register(eng):
    R = eng.register
    R("SYMBOL", cmd_symbol, ["SYM", "INSSYM"], "Electrical / piping symbol library")
    R("FITTING", cmd_fitting, ["FIT", "VALVE"], "3D pipe fitting / flange / valve by size and standard")
    R("PIPE3D", cmd_pipe3d, ["PIPE", "ROUTE"], "3D pipe route with automatic bends")
    R("CABLETRAY", cmd_tray, ["TRAY"], "3D cable tray along a route")
    R("CONDUIT", cmd_conduit, [], "3D electrical conduit")
    R("EQUIPMENT", cmd_equip, ["EQUIP"], "3D electrical equipment (JB, light, panel, motor, socket)")
