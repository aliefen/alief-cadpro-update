"""Drawing entities (all coordinates in world space, float64)."""
import math
import numpy as np
from .geom import (EPS, TAU, Plane, unit, norm, v3, arbitrary_x, arc_pt, arc_pts, bulge_arc, arc_from_3p,
                   ang_in_plane, prim_tess, prim_ends, prims_tess, prims_length, xform_pt, xform_vec, m_det,
                   m_scale_factor, bspline_eval, poly_area2, poly_centroid2, point_in_poly, fmt, cross, is_translation)

REGISTRY = {}


def register(cls):
    REGISTRY[cls.kind] = cls
    return cls


def arr(a):
    return np.asarray(a, float).tolist()


class Entity:
    kind = "base"
    label = "Entity"
    text_tess = None        # set by the UI: f(text_entity) -> (V, F) triangles in world space
    text_measure = None     # set by the UI: f(string, font) -> width in units of the text height
    text_rich = None        # set by the UI: f(text_entity) -> [(V, F, colour)] for MTEXT with formatting codes

    @staticmethod
    def measure(s, font="Arial"):
        if Entity.text_measure is not None:
            try:
                return Entity.text_measure(s, font)
            except Exception:
                pass
        return 0.92 * max((len(l) for l in str(s).split("\n")), default=0)
    anno_scale = 1.0        # drawing scale (1:N) used by annotative text / dimensions / symbols / tables

    xd = None               # optional extended data dict, e.g. {"vis": [state names]} inside dynamic blocks

    def __init__(self):
        self.id = 0
        self.layer = "0"
        self.color = 256          # 256 = ByLayer, 0 = ByBlock, 1..255 ACI, or "#rrggbb"
        self.ltype = "ByLayer"
        self.lw = -1              # 1/100 mm; -1 ByLayer
        self.lts = 1.0            # object linetype scale (multiplied by LTSCALE)
        self._cache = {}

    # ---------------------------------------------------------------- common
    def touch(self):
        self._cache = {}

    def cached(self, key, fn):
        v = self._cache.get(key)
        if v is None:
            v = fn()
            self._cache[key] = v
        return v

    def copy(self):
        e = from_dict(self.to_dict())
        e.id = 0
        return e

    def style_from(self, src):
        """Layer, colour, linetype, linetype scale and lineweight of src (pieces of TRIM / BREAK / OFFSET / FILLET ...)."""
        self.layer, self.color, self.ltype, self.lw = src.layer, src.color, src.ltype, src.lw
        self.lts = float(getattr(src, "lts", 1.0) or 1.0)
        return self

    def base_dict(self):
        d = {"kind": self.kind, "id": self.id, "layer": self.layer, "color": self.color, "ltype": self.ltype, "lw": self.lw}
        if getattr(self, "xd", None):
            d["xd"] = self.xd
        if getattr(self, "lts", 1.0) != 1.0:
            d["lts"] = self.lts
        return d

    def load_base(self, d):
        self.id = d.get("id", 0); self.layer = d.get("layer", "0"); self.color = d.get("color", 256)
        self.ltype = d.get("ltype", "ByLayer"); self.lw = d.get("lw", -1); self.lts = float(d.get("lts", 1.0) or 1.0)
        if d.get("xd"):
            self.xd = dict(d["xd"])

    # ---------------------------------------------------------------- geometry interface
    def prims(self):
        return []

    def wire(self):
        """List of polylines (Nx3) for display."""
        def mk():
            out = []; cur = None
            for pr in self.prims():
                pts = prim_tess(pr)
                if cur is not None and norm(cur[-1] - pts[0]) < 1e-9:
                    cur = np.vstack([cur, pts[1:]])
                    out[-1] = cur
                else:
                    cur = pts; out.append(cur)
            return out
        return self.cached("wire", mk)

    def tris(self):
        return None

    def snaps(self):
        return {}

    def bbox(self):
        def mk():
            pts = [w for w in self.wire() if len(w)]
            t = self.tris()
            if t is not None and len(t[0]):
                pts.append(t[0])
            if not pts:
                return None
            P = np.vstack(pts)
            return P.min(axis=0), P.max(axis=0)
        return self.cached("bbox", mk)

    def transform(self, M):
        raise NotImplementedError

    def explode(self):
        return None

    def info(self):
        """[(name, value_text)] for LIST and the properties panel."""
        return []

    def props(self):
        """Editable geometry properties [(name, value, setter)]."""
        return []

    is_curve = False
    closed = False

    def length(self):
        return prims_length(self.prims())

    def plane(self):
        return None


# ===================================================================================================== POINT
@register
class PointE(Entity):
    kind = "point"; label = "Point"

    def __init__(self, p=(0, 0, 0)):
        super().__init__(); self.p = v3(p)

    def to_dict(self):
        d = self.base_dict(); d["p"] = arr(self.p); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"]); e.load_base(d); return e

    def wire(self):
        return self.cached("wire", lambda: [])

    def bbox(self):
        return self.p.copy(), self.p.copy()

    def snaps(self):
        return {"node": [self.p]}

    def transform(self, M):
        self.p = xform_pt(M, self.p); self.touch()

    def info(self):
        return [("Position", self.p)]

    def props(self):
        return [("Position X", self.p[0], lambda v: self._set(0, v)), ("Position Y", self.p[1], lambda v: self._set(1, v)),
                ("Position Z", self.p[2], lambda v: self._set(2, v))]

    def _set(self, i, v):
        self.p[i] = v; self.touch()


# ===================================================================================================== LINE
@register
class Line(Entity):
    kind = "line"; label = "Line"; is_curve = True

    def __init__(self, p0=(0, 0, 0), p1=(1, 0, 0)):
        super().__init__(); self.p0 = v3(p0); self.p1 = v3(p1)

    def to_dict(self):
        d = self.base_dict(); d.update(p0=arr(self.p0), p1=arr(self.p1)); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p0"], d["p1"]); e.load_base(d); return e

    def prims(self):
        return [("L", self.p0, self.p1)]

    def snaps(self):
        return {"end": [self.p0, self.p1], "mid": [(self.p0 + self.p1) / 2]}

    def transform(self, M):
        self.p0 = xform_pt(M, self.p0); self.p1 = xform_pt(M, self.p1); self.touch()

    def info(self):
        d = self.p1 - self.p0
        return [("Start", self.p0), ("End", self.p1), ("Length", norm(d)),
                ("Angle in XY", math.degrees(math.atan2(d[1], d[0])) % 360), ("Delta", d)]

    def props(self):
        r = []
        for nm, attr in (("Start", "p0"), ("End", "p1")):
            for i, ax in enumerate("XYZ"):
                r.append((f"{nm} {ax}", getattr(self, attr)[i], (lambda a, k: lambda v: self._set(a, k, v))(attr, i)))
        r.append(("Length", norm(self.p1 - self.p0), self._set_len))
        return r

    def _set(self, a, i, v):
        getattr(self, a)[i] = v; self.touch()

    def _set_len(self, L):
        d = unit(self.p1 - self.p0)
        if norm(d) > 0:
            self.p1 = self.p0 + d * L; self.touch()


# ===================================================================================================== CIRCLE / ARC
@register
class Circle(Entity):
    kind = "circle"; label = "Circle"; is_curve = True; closed = True

    def __init__(self, c=(0, 0, 0), r=1.0, n=(0, 0, 1)):
        super().__init__(); self.c = v3(c); self.r = float(r); self.n = unit(v3(n))

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), r=self.r, n=arr(self.n)); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["r"], d.get("n", (0, 0, 1))); e.load_base(d); return e

    def u(self):
        return arbitrary_x(self.n)

    def prims(self):
        return [("A", self.c, self.r, self.n, self.u(), 0.0, TAU)]

    def plane(self):
        return Plane.from_normal(self.c, self.n)

    def snaps(self):
        u = self.u(); v = cross(self.n, u)
        return {"cen": [self.c], "quad": [self.c + self.r * u, self.c + self.r * v, self.c - self.r * u, self.c - self.r * v]}

    def transform(self, M):
        if is_translation(M):
            self.c = self.c + M[:3, 3]; self.touch(); return
        self.c = xform_pt(M, self.c); self.n = unit(xform_vec(M, self.n)); self.r *= m_scale_factor(M); self.touch()

    def area(self):
        return math.pi * self.r ** 2

    def info(self):
        return [("Center", self.c), ("Radius", self.r), ("Diameter", 2 * self.r), ("Circumference", TAU * self.r),
                ("Area", self.area()), ("Normal", self.n)]

    def props(self):
        r = [(f"Center {ax}", self.c[i], (lambda k: lambda v: self._setc(k, v))(i)) for i, ax in enumerate("XYZ")]
        r += [("Radius", self.r, self._setr), ("Diameter", 2 * self.r, lambda v: self._setr(v / 2)),
              ("Area", self.area(), lambda v: self._setr(math.sqrt(max(v, 0) / math.pi)))]
        return r

    def _setc(self, i, v):
        self.c[i] = v; self.touch()

    def _setr(self, v):
        if v > 0:
            self.r = float(v); self.touch()


@register
class Arc(Entity):
    kind = "arc"; label = "Arc"; is_curve = True

    def __init__(self, c=(0, 0, 0), r=1.0, a0=0.0, a1=math.pi / 2, n=(0, 0, 1)):
        super().__init__(); self.c = v3(c); self.r = float(r); self.n = unit(v3(n))
        self.a0 = float(a0) % TAU; self.a1 = float(a1) % TAU
        if self.a1 <= self.a0 + 1e-12:
            self.a1 += TAU

    @classmethod
    def through(cls, p1, p2, p3):
        """Arc from p1 through p2 to p3."""
        r = arc_from_3p(p1, p2, p3)
        if r is None:
            return None
        c, rad, n = r
        u = arbitrary_x(n)
        a1 = ang_in_plane(c, n, u, p1); a2 = ang_in_plane(c, n, u, p2); a3 = ang_in_plane(c, n, u, p3)
        if (a2 - a1) % TAU < (a3 - a1) % TAU:
            return cls(c, rad, a1, a3, n)
        n = -n; u = arbitrary_x(n)
        return cls(c, rad, ang_in_plane(c, n, u, p1), ang_in_plane(c, n, u, p3), n)

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), r=self.r, a0=self.a0, a1=self.a1, n=arr(self.n)); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["r"], d["a0"], d["a1"], d.get("n", (0, 0, 1))); e.load_base(d); return e

    def u(self):
        return arbitrary_x(self.n)

    def prims(self):
        return [("A", self.c, self.r, self.n, self.u(), self.a0, self.a1)]

    def plane(self):
        return Plane.from_normal(self.c, self.n)

    def ends(self):
        u = self.u()
        return arc_pt(self.c, self.r, self.n, u, self.a0), arc_pt(self.c, self.r, self.n, u, self.a1)

    def snaps(self):
        u = self.u(); p0, p1 = self.ends()
        q = [arc_pt(self.c, self.r, self.n, u, k * math.pi / 2) for k in range(4)
             if (k * math.pi / 2 - self.a0) % TAU <= self.a1 - self.a0 + 1e-12]
        return {"end": [p0, p1], "mid": [arc_pt(self.c, self.r, self.n, u, (self.a0 + self.a1) / 2)], "cen": [self.c], "quad": q}

    def transform(self, M):
        if is_translation(M):
            self.c = self.c + M[:3, 3]; self.touch(); return
        u = self.u()
        p1 = xform_pt(M, arc_pt(self.c, self.r, self.n, u, self.a0))
        p2 = xform_pt(M, arc_pt(self.c, self.r, self.n, u, (self.a0 + self.a1) / 2))
        p3 = xform_pt(M, arc_pt(self.c, self.r, self.n, u, self.a1))
        if self.a1 - self.a0 > math.pi * 1.999:
            self.c = xform_pt(M, self.c); self.r *= m_scale_factor(M); self.n = unit(xform_vec(M, self.n)) * (1 if m_det(M) > 0 else -1)
            self.touch(); return
        a = Arc.through(p1, p2, p3)
        if a is not None:
            self.c, self.r, self.n, self.a0, self.a1 = a.c, a.r, a.n, a.a0, a.a1
        self.touch()

    def sweep(self):
        return self.a1 - self.a0

    def info(self):
        p0, p1 = self.ends()
        return [("Center", self.c), ("Radius", self.r), ("Start angle", math.degrees(self.a0)),
                ("End angle", math.degrees(self.a1) % 360), ("Included angle", math.degrees(self.sweep())),
                ("Arc length", self.r * self.sweep()), ("Start", p0), ("End", p1)]

    def props(self):
        r = [(f"Center {ax}", self.c[i], (lambda k: lambda v: self._setc(k, v))(i)) for i, ax in enumerate("XYZ")]
        r += [("Radius", self.r, self._setr), ("Start angle", math.degrees(self.a0), lambda v: self._seta(v, None)),
              ("End angle", math.degrees(self.a1) % 360, lambda v: self._seta(None, v))]
        return r

    def _setc(self, i, v):
        self.c[i] = v; self.touch()

    def _setr(self, v):
        if v > 0:
            self.r = float(v); self.touch()

    def _seta(self, a0, a1):
        a0 = math.radians(a0) % TAU if a0 is not None else self.a0
        a1 = math.radians(a1) % TAU if a1 is not None else self.a1 % TAU
        if a1 <= a0:
            a1 += TAU
        self.a0, self.a1 = a0, a1; self.touch()


# ===================================================================================================== ELLIPSE
@register
class Ellipse(Entity):
    kind = "ellipse"; label = "Ellipse"; is_curve = True

    def __init__(self, c=(0, 0, 0), major=(1, 0, 0), ratio=0.5, n=(0, 0, 1), t0=0.0, t1=TAU):
        super().__init__(); self.c = v3(c); self.major = v3(major); self.ratio = float(ratio); self.n = unit(v3(n))
        self.t0 = float(t0); self.t1 = float(t1)
        if self.t1 <= self.t0:
            self.t1 += TAU

    @property
    def closed(self):
        return self.t1 - self.t0 >= TAU - 1e-9

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), major=arr(self.major), ratio=self.ratio, n=arr(self.n), t0=self.t0, t1=self.t1)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["major"], d["ratio"], d["n"], d["t0"], d["t1"]); e.load_base(d); return e

    def pts(self, seg=96):
        t = np.linspace(self.t0, self.t1, max(8, int(seg * (self.t1 - self.t0) / TAU)) + 1)
        a = self.major; b = cross(self.n, a) * self.ratio
        return self.c + np.cos(t)[:, None] * a + np.sin(t)[:, None] * b

    def prims(self):
        def mk():
            P = self.pts()
            return [("L", P[i], P[i + 1]) for i in range(len(P) - 1)]
        return self.cached("prims", mk)

    def wire(self):
        return self.cached("wire", lambda: [self.pts()])

    def plane(self):
        return Plane(self.c, self.major, cross(self.n, self.major))

    def snaps(self):
        a = self.major; b = cross(self.n, a) * self.ratio
        s = {"cen": [self.c], "quad": [self.c + a, self.c + b, self.c - a, self.c - b]}
        if not self.closed:
            P = self.pts(); s["end"] = [P[0], P[-1]]
        return s

    def transform(self, M):
        self.c = xform_pt(M, self.c)
        b = cross(self.n, self.major) * self.ratio
        self.major = xform_vec(M, self.major); b2 = xform_vec(M, b)
        n2 = unit(cross(self.major, b2))
        self.n = n2; self.ratio = norm(b2) / max(norm(self.major), EPS); self.touch()

    def area(self):
        return math.pi * norm(self.major) ** 2 * self.ratio if self.closed else 0.0

    def info(self):
        return [("Center", self.c), ("Major radius", norm(self.major)), ("Minor radius", norm(self.major) * self.ratio),
                ("Ratio", self.ratio), ("Area", self.area())]


# ===================================================================================================== POLYLINE
@register
class Polyline(Entity):
    kind = "polyline"; label = "Polyline"; is_curve = True

    def __init__(self, pts=(), closed=False, bulges=None, n=(0, 0, 1), is3d=False):
        super().__init__()
        self.pts = np.asarray(pts, float).reshape(-1, 3).copy() if len(pts) else np.zeros((0, 3))
        self.bulges = np.zeros(len(self.pts)) if bulges is None else np.asarray(bulges, float).copy()
        self.closed = bool(closed); self.n = unit(v3(n)); self.is3d = bool(is3d)
        self.width = 0.0

    def to_dict(self):
        d = self.base_dict(); d.update(pts=arr(self.pts), bulges=arr(self.bulges), closed=self.closed, n=arr(self.n), is3d=self.is3d)
        if self.width:
            d["width"] = self.width
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["pts"], d["closed"], d.get("bulges"), d.get("n", (0, 0, 1)), d.get("is3d", False)); e.load_base(d)
        e.width = float(d.get("width", 0.0) or 0.0)
        return e

    def tris(self):
        """A polyline with a global width (PEDIT Width) is drawn as a filled band."""
        if not self.width or self.width <= 0:
            return None
        def mk():
            V, F = [], []; h = self.width / 2
            for w in self.wire():
                W = np.asarray(w, float)
                for i in range(len(W) - 1):
                    a, b = W[i], W[i + 1]; d = b - a; L = norm(d)
                    if L < 1e-12:
                        continue
                    s = cross(self.n, d / L) * h; k = len(V)
                    V += [a + s, a - s, b - s, b + s]; F += [[k, k + 1, k + 2], [k, k + 2, k + 3]]
            return (np.array(V), np.array(F, np.int32)) if V else None
        return self.cached("tris", mk)

    def seg_count(self):
        n = len(self.pts)
        return n if self.closed else n - 1

    def prims(self):
        def mk():
            out = []; n = len(self.pts)
            for i in range(self.seg_count()):
                p0, p1 = self.pts[i], self.pts[(i + 1) % n]
                if norm(p1 - p0) < 1e-12:
                    continue
                b = self.bulges[i] if i < len(self.bulges) else 0.0
                a = bulge_arc(p0, p1, b, self.n) if abs(b) > 1e-12 and not self.is3d else None
                out.append(("A",) + a if a else ("L", p0.copy(), p1.copy()))
            return out
        return self.cached("prims", mk)

    def plane(self):
        if self.is3d or len(self.pts) == 0:
            return None
        return Plane.from_normal(self.pts[0], self.n)

    def snaps(self):
        s = {"end": list(self.pts), "mid": [], "cen": []}
        from .geom import prim_point, prim_len
        for pr in self.prims():
            s["mid"].append(prim_point(pr, prim_len(pr) / 2))
            if pr[0] == "A":
                s["cen"].append(pr[1])
        if self.closed and len(self.pts) >= 3:
            g = self.cached("gcen", lambda: _area_centroid(self))
            if g is not None:
                s["gcen"] = [g]
        return s

    def transform(self, M):
        if is_translation(M):
            self.pts = self.pts + M[:3, 3]; self.touch(); return
        self.pts = xform_pt(M, self.pts)
        self.n = unit(xform_vec(M, self.n))
        if m_det(M) < 0:
            self.bulges = -self.bulges
        self.touch()

    def explode(self):
        out = []
        for pr in self.prims():
            if pr[0] == "L":
                out.append(Line(pr[1], pr[2]))
            else:
                c, r, n, u, a0, a1 = pr[1:]
                p0, p1 = prim_ends(pr); pm = arc_pt(c, r, n, u, (a0 + a1) / 2)
                a = Arc.through(p0, pm, p1)
                if a:
                    out.append(a)
        return out

    def area(self):
        if not self.closed or self.is3d:
            return 0.0
        P = prims_tess(self.prims())
        pl = Plane.from_normal(self.pts[0], self.n)
        return abs(poly_area2(pl.to_local(P)[:, :2]))

    def info(self):
        r = [("Vertices", len(self.pts)), ("Closed", "Yes" if self.closed else "No"), ("Length", self.length())]
        if self.closed:
            r.append(("Area", self.area()))
        return r

    def props(self):
        r = [("Closed (1/0)", 1 if self.closed else 0, self._setclosed)]
        for i, p in enumerate(self.pts[:40]):
            for k, ax in enumerate("XYZ"):
                r.append((f"Vertex {i + 1} {ax}", p[k], (lambda j, kk: lambda v: self._setv(j, kk, v))(i, k)))
        return r

    def _setclosed(self, v):
        self.closed = bool(round(v)); self.touch()

    def _setv(self, i, k, v):
        self.pts[i, k] = v; self.touch()


def polyline_from_prims(prims, n=None, closed=None):
    """Build a planar polyline (with bulges) from connected primitives."""
    if not prims:
        return None
    pts = []; bul = []
    for pr in prims:
        a, b = prim_ends(pr)
        pts.append(a)
        if pr[0] == "A":
            sw = pr[6] - pr[5]
            sgn = 1.0
            if n is not None and np.dot(pr[3], n) < 0:
                sgn = -1.0
            bul.append(sgn * math.tan(sw / 4))
            if n is None:
                n = pr[3]
        else:
            bul.append(0.0)
    end = prim_ends(prims[-1])[1]
    if closed is None:
        closed = norm(end - pts[0]) < 1e-7
    if not closed:
        pts.append(end); bul.append(0.0)
    if n is None:
        from .geom import plane_of_points
        r = plane_of_points(np.vstack([pts, [end]]))
        n = r[1] if r else np.array([0, 0, 1.0])
        if np.dot(n, [0, 0, 1]) < 0 and abs(n[2]) > 0.5:
            n = -n
    return Polyline(np.array(pts), closed, bul, n)


# ===================================================================================================== SPLINE
@register
class Spline(Entity):
    kind = "spline"; label = "Spline"; is_curve = True

    def __init__(self, ctrl=(), knots=None, deg=3, weights=None, fit=None, closed=False):
        super().__init__()
        self.ctrl = np.asarray(ctrl, float).reshape(-1, 3)
        self.deg = int(deg)
        if knots is None:
            n = len(self.ctrl); p = min(self.deg, n - 1)
            self.deg = p
            knots = [0] * (p + 1) + list(np.linspace(0, 1, n - p + 1)[1:-1]) + [1] * (p + 1)
        self.knots = [float(k) for k in knots]
        self.weights = None if weights is None else [float(w) for w in weights]
        self.fit = None if fit is None else np.asarray(fit, float).reshape(-1, 3)
        self.closed = bool(closed)

    @classmethod
    def through(cls, pts):
        from .geom import bspline_interp
        P = np.asarray(pts, float)
        ctrl, U = bspline_interp(P, 3)
        s = cls(ctrl, U, min(3, len(P) - 1)); s.fit = P.copy()
        s.closed = norm(P[0] - P[-1]) < 1e-9
        return s

    def to_dict(self):
        d = self.base_dict()
        d.update(ctrl=arr(self.ctrl), knots=self.knots, deg=self.deg, weights=self.weights,
                 fit=None if self.fit is None else arr(self.fit), closed=self.closed)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["ctrl"], d["knots"], d["deg"], d.get("weights"), d.get("fit"), d.get("closed", False)); e.load_base(d)
        return e

    def pts(self, n=None):
        n = n or max(32, 12 * len(self.ctrl))
        U = self.knots
        t = np.linspace(U[self.deg], U[-self.deg - 1], n + 1)
        return bspline_eval(self.ctrl, U, self.deg, t, self.weights)

    def prims(self):
        def mk():
            P = self.pts()
            return [("L", P[i], P[i + 1]) for i in range(len(P) - 1) if norm(P[i + 1] - P[i]) > 1e-12]
        return self.cached("prims", mk)

    def wire(self):
        return self.cached("wire", lambda: [self.pts()])

    def plane(self):
        from .geom import plane_of_points
        r = plane_of_points(self.ctrl)
        if r is None or r[2] > 1e-6:
            return None
        return Plane.from_normal(r[0], r[1])

    def snaps(self):
        P = self.pts(8)
        s = {"end": [P[0], P[-1]]}
        if self.fit is not None:
            s["node"] = list(self.fit)
        if self.closed or norm(P[0] - P[-1]) < 1e-9:
            g = self.cached("gcen", lambda: _area_centroid(self))
            if g is not None:
                s["gcen"] = [g]
        return s

    def transform(self, M):
        self.ctrl = xform_pt(M, self.ctrl)
        if self.fit is not None:
            self.fit = xform_pt(M, self.fit)
        self.touch()

    def info(self):
        return [("Degree", self.deg), ("Control points", len(self.ctrl)),
                ("Fit points", 0 if self.fit is None else len(self.fit)), ("Length", self.length())]


# ===================================================================================================== TEXT
def _area_centroid(e):
    """Geometric centre (centroid of the enclosed area) of a closed curve; None for a degenerate one."""
    if e.kind == "polyline" and abs(float(e.n[2])) > 0.999999 and not np.any(np.asarray(e.bulges)):
        q = np.asarray(e.pts, float)                       # straight-sided polyline in the XY plane: direct shoelace
        x, y = q[:, 0], q[:, 1]; x1 = np.concatenate([x[1:], x[:1]]); y1 = np.concatenate([y[1:], y[:1]])
        cr = x * y1 - x1 * y; A = cr.sum() / 2.0
        if abs(A) < 1e-12 * max(1.0, float(max(np.ptp(x), np.ptp(y)) ** 2)):
            return None
        return np.array([((x + x1) * cr).sum() / (6 * A), ((y + y1) * cr).sum() / (6 * A), float(q[0, 2])])
    try:
        from .geom import prims_tess
        P = prims_tess(e.prims())
    except Exception:
        P = None
    if P is None or len(P) < 3:
        return None
    P = np.asarray(P, float)
    pl = e.plane() if hasattr(e, "plane") else None
    if pl is None:
        return None
    q = pl.to_local(P)[:, :2]
    x, y = q[:, 0], q[:, 1]; x1, y1 = np.roll(x, -1), np.roll(y, -1)
    cr = x * y1 - x1 * y; A = cr.sum() / 2.0
    if abs(A) < 1e-12 * max(1.0, float(np.ptp(q) ** 2)):
        return None
    cx = ((x + x1) * cr).sum() / (6 * A); cy = ((y + y1) * cr).sum() / (6 * A)
    return pl.to_world(np.array([cx, cy]))


def freeze_anno(e, k, blocks=None, _seen=None):
    """Annotative object -> fixed size as it looks at the drawing scale 1:k (objects pasted into a drawing that has
    another scale keep their size).  Blocks used by the object are converted too (blocks: the block table)."""
    try:
        kind = e.kind
        if kind in ("text", "attdef") and getattr(e, "anno", 0):
            e.hm = float(e.anno) * k; e.anno = 0.0
        elif kind == "leader" and getattr(e, "anno", False):
            e.hm *= k; e.asz0 *= k; e.land0 *= k; e.anno = False
        elif kind == "dimension" and e.style.get("anno"):
            st = dict(e.style)
            for x in ("th", "asz", "exo", "exe", "gap"):
                if x in st:
                    st[x] = st[x] * k
            st["anno"] = False; e.style = st
        elif kind == "table" and getattr(e, "anno", False):
            e.th *= k; e.rh *= k; e.widths = [w * k for w in e.widths]; e.anno = False
        elif kind == "insert":
            if getattr(e, "anno", False):
                b = (blocks or {}).get(e.name); base = b.base if b is not None else np.zeros(3)
                S = np.eye(4) * k; S[3, 3] = 1; S[:3, 3] = base - k * base
                e.M = e.M @ S; e.anno = False
            b = (blocks or {}).get(e.name)
            _seen = _seen if _seen is not None else set()
            if b is not None and e.name not in _seen:
                _seen.add(e.name)
                for ch in b.ents:
                    freeze_anno(ch, k, blocks, _seen)
                b._geo = None; b._plain = None
        e.touch()
    except Exception:
        pass


class Ghost:
    """Preview of many objects under one transformation (MOVE / COPY / ROTATE / paste of a big selection): the view
    draws their cached line work through the matrix M instead of copying and transforming every object per cursor move."""
    kind = "ghost"; id = 0; is_curve = False; xd = None
    _c = None                                              # (key, segments, triangles) of the last source list

    def __init__(self, ents, M):
        self.ents = ents; self.M = np.asarray(M, float)

    def wire(self):
        return []

    def tris(self):
        return None

    def geo(self):
        key = (id(self.ents), len(self.ents))
        c = Ghost._c
        if c is None or c[0] != key:
            S = []; T = []
            for e in self.ents:
                try:
                    if isinstance(e, Insert) and e.heavy():
                        S.append(np.asarray(e.heavy_geo()[0], float).reshape(-1, 2, 3)); continue
                    if e.kind == "hatch" and e.pattern != "SOLID":
                        S.append(e.segs())
                        for l in e.loops:
                            S.append(np.stack([l, np.roll(l, -1, axis=0)], axis=1))
                        continue
                    if isinstance(e, Body):
                        S.append(np.asarray(e.edges(), float).reshape(-1, 2, 3)[:20000]); continue
                    for w in (e.wire() if not isinstance(e, Insert) else [x for ch in e.children() for x in ch.wire()]):
                        if len(w) > 1:
                            S.append(np.stack([w[:-1], w[1:]], axis=1))
                    t = e.tris()
                    if t is not None and len(t[1]) and len(t[1]) < 60000:
                        T.append(np.asarray(t[0], float)[t[1]])
                except Exception:
                    continue
            c = Ghost._c = (key, np.concatenate(S) if S else np.zeros((0, 2, 3)), np.concatenate(T) if T else np.zeros((0, 3, 3)), self.ents)
        return c[1], c[2]


def ghost(ents, M, copies, limit=150):
    """Preview list for `ents` transformed by M: real copies for a few objects, one Ghost for many."""
    if len(ents) <= limit:
        return copies(ents, M)
    return [Ghost(ents, M)]


@register
class Text(Entity):
    kind = "text"; label = "Text"
    HALIGN = ["Left", "Center", "Right"]
    VALIGN = ["Baseline", "Bottom", "Middle", "Top"]

    def __init__(self, p=(0, 0, 0), s="Text", h=2.5, xdir=(1, 0, 0), n=(0, 0, 1), halign=0, valign=0, font="Arial", wf=1.0):
        super().__init__(); self.p = v3(p); self.s = str(s); self.anno = 0.0; self.hm = float(h); self.n = unit(v3(n))
        x = v3(xdir); x = x - np.dot(x, self.n) * self.n
        self.xdir = unit(x) if norm(x) > EPS else arbitrary_x(self.n)
        self.halign = int(halign); self.valign = int(valign); self.font = font; self.wf = float(wf)
        self.width = 0.0      # mtext box width (0 = no wrap)
        self.rich = ""        # MTEXT string with formatting codes (see core/mtext.py); self.s is then its plain text
        self.lsf = 1.0        # mtext line spacing factor

    @property
    def h(self):
        return self.anno * Entity.anno_scale if self.anno else self.hm

    @h.setter
    def h(self, v):
        if self.anno:
            self.anno = float(v) / Entity.anno_scale
        else:
            self.hm = float(v)

    def ydir(self):
        return cross(self.n, self.xdir)

    def rotation(self):
        ax = arbitrary_x(self.n); ay = cross(self.n, ax)
        return math.atan2(np.dot(self.xdir, ay), np.dot(self.xdir, ax))

    def to_dict(self):
        d = self.base_dict()
        d.update(p=arr(self.p), s=self.s, h=self.hm, anno=self.anno, xdir=arr(self.xdir), n=arr(self.n), halign=self.halign,
                 valign=self.valign, font=self.font, wf=self.wf, width=self.width)
        if self.rich:
            d["rich"] = self.rich
        if self.lsf != 1.0:
            d["lsf"] = self.lsf
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"], d["s"], d["h"], d["xdir"], d["n"], d.get("halign", 0), d.get("valign", 0), d.get("font", "Arial"),
                d.get("wf", 1.0))
        e.width = d.get("width", 0.0); e.anno = d.get("anno", 0.0); e.rich = d.get("rich", "") or ""; e.lsf = float(d.get("lsf", 1.0) or 1.0)
        e.load_base(d); return e

    def set_rich(self, rich):
        """Formatted (MTEXT) content; an empty string or text without codes makes it a plain text again."""
        from . import mtext
        rich = rich or ""
        if rich and mtext.has_codes(rich):
            self.rich = rich; self.s = mtext.plain(rich)
        else:
            self.rich = ""; self.s = rich.replace("\\P", "\n") if rich else self.s
        self.touch()

    def rich_src(self):
        """MTEXT string used for the layout: the formatted text, or the plain text of an mtext with a box width
        (so it wraps like AutoCAD even without formatting codes); '' for a plain single-line text."""
        if self.rich:
            return self.rich
        if self.width and self.width > 0:
            return self.s.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}").replace("\n", "\\P")
        return ""

    def tris_groups(self):
        """[(V, F, colour or None)] for formatted / wrapped text (several colours); None for plain text."""
        if not self.rich_src() or Entity.text_rich is None:
            return None
        def mk():
            try:
                return Entity.text_rich(self)
            except Exception:
                import traceback; traceback.print_exc()
                return []
        return self.cached("trig", mk)

    def tris(self):
        if self.rich_src() and Entity.text_rich is not None:
            def mk2():
                g = [x for x in (self.tris_groups() or []) if len(x[1])]
                if not g:
                    return None
                V = []; F = []; off = 0
                for v, f, _c in g:
                    V.append(v); F.append(f + off); off += len(v)
                return np.vstack(V), np.vstack(F)
            return self.cached("tris", mk2)
        def mk():
            if Entity.text_tess is not None:
                try:
                    return Entity.text_tess(self)
                except Exception:
                    pass
            return None
        return self.cached("tris", mk)

    def box_local(self):
        lines = self.s.split("\n")
        w = max(len(l) for l in lines) * self.h * 0.62 * self.wf
        H = self.h * (1 + 1.6 * (len(lines) - 1))
        return w, H

    def wire(self):
        def mk():
            if self.tris() is not None:
                return []
            w, H = self.box_local()
            x, y = self.xdir, self.ydir()
            dx = [0, -w / 2, -w][self.halign]
            o = self.p + dx * x
            return [np.array([o, o + w * x, o + w * x + self.h * y, o + self.h * y, o])]
        return self.cached("wire", mk)

    def snaps(self):
        return {"ins": [self.p]}

    def plane(self):
        return Plane(self.p, self.xdir, self.ydir())

    def transform(self, M):
        sf = m_scale_factor(M)
        y = self.ydir(); x0 = self.xdir.copy()
        self.p = xform_pt(M, self.p); x2 = unit(xform_vec(M, self.xdir)); y2 = unit(xform_vec(M, y))
        if m_det(M) < 0:      # mirrored text stays readable (MIRRTEXT = 0)
            if np.dot(-x2, x0) >= np.dot(x2, x0):
                x2 = -x2
                if self.halign in (0, 2) and "\n" not in self.s:
                    w = self.box_local()[0]
                    self.p = self.p - x2 * w * (1 if self.halign == 0 else -1)
            else:
                y2 = -y2
        self.n = unit(cross(x2, y2)); self.xdir = x2
        self.width *= sf
        if not self.anno:
            self.hm *= sf
        self.touch()

    def info(self):
        return [("Text", self.s), ("Height", self.h), ("Annotative (paper mm)", self.anno or "No"),
                ("Rotation", math.degrees(self.rotation())), ("Insertion", self.p), ("Font", self.font)]

    def props(self):
        return [("Text", self.s, self._sets), ("Height", self.h, self._seth), ("Paper height (0=off)", self.anno, self._setanno),
                ("Rotation", math.degrees(self.rotation()), self._setrot), ("Width factor", self.wf, self._setwf),
                ("Box width (0 = no wrap)", self.width, self._setbw), ("Line spacing factor", self.lsf, self._setlsf),
                ("Insert X", self.p[0], lambda v: self._setp(0, v)), ("Insert Y", self.p[1], lambda v: self._setp(1, v)),
                ("Insert Z", self.p[2], lambda v: self._setp(2, v))]

    def _sets(self, v):
        self.s = str(v); self.rich = ""; self.touch()      # typing plain text in Properties drops the MTEXT formatting

    def _setbw(self, v):
        self.width = max(0.0, float(v)); self.touch()

    def _setlsf(self, v):
        if 0.25 <= float(v) <= 4.0:
            self.lsf = float(v); self.touch()

    def _seth(self, v):
        if v > 0:
            self.h = float(v); self.touch()

    def _setwf(self, v):
        if v > 0:
            self.wf = float(v); self.touch()

    def _setanno(self, v):
        v = float(v)
        if v > 0:
            self.anno = v
        else:
            self.hm = self.h; self.anno = 0.0
        self.touch()

    def _setrot(self, deg):
        ax = arbitrary_x(self.n); ay = cross(self.n, ax); a = math.radians(deg)
        self.xdir = math.cos(a) * ax + math.sin(a) * ay; self.touch()

    def _setp(self, i, v):
        self.p[i] = v; self.touch()


# ===================================================================================================== HATCH
from . import hatchpat as HP
HATCH_PATTERNS = HP.LIBRARY          # name -> (category, description, PAT line families); see core/hatchpat.py


@register
class Hatch(Entity):
    kind = "hatch"; label = "Hatch"

    def __init__(self, loops=(), n=(0, 0, 1), pattern="SOLID", scale=1.0, angle=0.0):
        super().__init__(); self.loops = [np.asarray(l, float).reshape(-1, 3) for l in loops]
        self.n = unit(v3(n)); self.pattern = pattern; self.scale = float(scale); self.angle = float(angle)
        self.pdef = None     # PAT line families of a custom pattern (stored in the drawing so it opens the same everywhere)

    def to_dict(self):
        d = self.base_dict(); d.update(loops=[arr(l) for l in self.loops], n=arr(self.n), pattern=self.pattern, scale=self.scale,
                                       angle=self.angle)
        if self.pdef:
            d["pdef"] = [list(f[:5]) + [list(f[5])] for f in self.pdef]
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["loops"], d["n"], d["pattern"], d["scale"], d.get("angle", 0)); e.load_base(d)
        if d.get("pdef"):
            e.pdef = [tuple(f[:5]) + (tuple(f[5]) if len(f) > 5 else (),) for f in d["pdef"]]
        return e

    def segs(self):
        """Pattern line work as one (N, 2, 3) array (drawn without per-segment work)."""
        def mk():
            if self.pattern == "SOLID":
                return np.zeros((0, 2, 3))
            pl, L = self.local_loops()
            segs = HP.segments(L, HP.families(self.pattern, self.pdef), self.scale, self.angle)
            if not segs:
                return np.zeros((0, 2, 3))
            return pl.to_world(np.asarray(segs, float).reshape(-1, 2)).reshape(-1, 2, 3)
        return self.cached("hsegs", mk)

    def set_pattern(self, name, pdef=None):
        name = str(name).strip().upper()
        if pdef is None and name not in HP.LIBRARY and name in HP.USER:
            pdef = HP.USER[name][1]
        if pdef is None and name not in HP.LIBRARY:
            raise ValueError(f"unknown hatch pattern {name}")
        self.pattern = name; self.pdef = [tuple(f) for f in pdef] if pdef else None; self.touch()

    def plane(self):
        o = self.loops[0][0] if self.loops else np.zeros(3)
        return Plane.from_normal(o, self.n)

    def local_loops(self):
        pl = self.plane()
        return pl, [pl.to_local(l)[:, :2] for l in self.loops if len(l) >= 3]

    def tris(self):
        def mk():
            if self.pattern != "SOLID":
                return None
            pl, L = self.local_loops()
            return triangulate_loops(pl, L)
        return self.cached("tris", mk)

    def wire(self):
        def mk():
            if self.pattern == "SOLID":
                return []
            S_ = self.segs()
            return list(S_) if len(S_) else []
        return self.cached("wire", mk)

    def transform(self, M):
        self.loops = [xform_pt(M, l) for l in self.loops]; self.n = unit(xform_vec(M, self.n)) if m_det(M) > 0 else unit(-xform_vec(M, -self.n))
        self.scale *= m_scale_factor(M); self.touch()

    def area(self):
        pl, L = self.local_loops()
        return area_evenodd(L)

    def info(self):
        return [("Pattern", self.pattern), ("Scale", self.scale), ("Angle", self.angle), ("Loops", len(self.loops)),
                ("Area", self.area())]

    def props(self):
        return [("Pattern", self.pattern, self.set_pattern), ("Pattern scale", self.scale, self._setsc), ("Pattern angle", self.angle, self._setang)]

    def _setsc(self, v):
        if v > 0:
            self.scale = v; self.touch()

    def _setang(self, v):
        self.angle = v; self.touch()


def area_evenodd(loops2):
    A = 0.0
    for i, l in enumerate(loops2):
        a = abs(poly_area2(l)); depth = sum(1 for j, m in enumerate(loops2) if j != i and point_in_poly(l[0], m))
        A += a if depth % 2 == 0 else -a
    return A


def triangulate_loops(pl, loops2, fill="EvenOdd"):
    """Triangulate 2D loops (even-odd) with manifold3d; returns (V world, F)."""
    import manifold3d as m3
    loops2 = [np.asarray(l, float) for l in loops2 if len(l) >= 3]
    if not loops2:
        return None
    cs = m3.CrossSection([l for l in loops2], getattr(m3.FillRule, fill))
    polys = [np.asarray(p, float) for p in cs.to_polygons()]
    if not polys:
        return None
    F = np.asarray(m3.triangulate(polys), np.int32)
    V2 = np.vstack(polys)
    return pl.to_world(V2), F


def hatch_lines(loops2, ang, spacing):
    """Parallel hatch line segments clipped (even-odd) to 2D loops."""
    if spacing <= 0:
        return []
    ca, sa = math.cos(ang), math.sin(ang)
    R = np.array([[ca, sa], [-sa, ca]])          # rotate world->hatch frame (lines along x')
    segs = []
    for l in loops2:
        q = l @ R.T
        segs.append(np.stack([q, np.roll(q, -1, axis=0)], axis=1))
    if not segs:
        return []
    S = np.vstack(segs)
    y0, y1 = S[:, :, 1].min(), S[:, :, 1].max()
    if (y1 - y0) / spacing > 4000:
        spacing = (y1 - y0) / 4000
    ys = np.arange(math.floor(y0 / spacing) * spacing, y1, spacing)
    out = []
    Ri = R
    a = S[:, 0]; b = S[:, 1]
    for y in ys:
        m = (a[:, 1] > y) != (b[:, 1] > y)
        if not m.any():
            continue
        aa, bb = a[m], b[m]
        xs = np.sort(aa[:, 0] + (y - aa[:, 1]) * (bb[:, 0] - aa[:, 0]) / (bb[:, 1] - aa[:, 1]))
        for i in range(0, len(xs) - 1, 2):
            out.append([np.array([xs[i], y]) @ Ri, np.array([xs[i + 1], y]) @ Ri])
    return out


# ===================================================================================================== DIMENSION
@register
class Dimension(Entity):
    kind = "dimension"; label = "Dimension"

    def __init__(self, dtype="aligned", pts=(), n=(0, 0, 1), xdir=(1, 0, 0), style=None):
        super().__init__(); self.dtype = dtype; self.dpts = [v3(p) for p in pts]; self.n = unit(v3(n))
        self.xdir = unit(v3(xdir)); self.style = dict(DIMSTYLE_DEFAULT, **(style or {}))
        self.override = ""

    def to_dict(self):
        d = self.base_dict(); d.update(dtype=self.dtype, pts=[arr(p) for p in self.dpts], n=arr(self.n), xdir=arr(self.xdir),
                                       style=self.style, override=self.override)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["dtype"], d["pts"], d["n"], d.get("xdir", (1, 0, 0)), d.get("style")); e.override = d.get("override", "")
        e.load_base(d); return e

    def plane(self):
        x = self.xdir - np.dot(self.xdir, self.n) * self.n
        if norm(x) < EPS:
            x = arbitrary_x(self.n)
        return Plane(self.dpts[0], x, cross(self.n, unit(x)))

    def measure(self):
        P = self.dpts; pl = self.plane()
        if self.dtype == "linear":
            q = pl.to_local(np.array(P))
            return abs(q[1, 0] - q[0, 0]) if self.style.get("rot", 0) == 0 else abs(q[1, 1] - q[0, 1])
        if self.dtype == "aligned":
            return norm(P[1] - P[0])
        if self.dtype == "radius":
            return norm(P[1] - P[0])
        if self.dtype == "diameter":
            return 2 * norm(P[1] - P[0])
        if self.dtype == "angular":
            a = unit(P[1] - P[0]); b = unit(P[2] - P[0])
            return math.degrees(math.acos(max(-1, min(1, np.dot(a, b)))))
        if self.dtype == "arc":             # arc length: P = [centre, start, end, location], style["sweep"] = CCW angle about n
            return norm(P[1] - P[0]) * abs(self.style.get("sweep", 0.0))
        if self.dtype == "jogged":
            return norm(P[1] - P[0])
        if self.dtype == "ordinate":        # P = [origin, feature, leader end]; style["axis"] = "x" | "y"
            q = pl.to_local(np.array(P))
            return abs(q[1, 0] - q[0, 0]) if self.style.get("axis", "x") == "x" else abs(q[1, 1] - q[0, 1])
        return 0.0

    def text(self):
        if self.override:
            return self.override.replace("<>", self._num())
        pre = {"radius": "R", "diameter": "Ø", "jogged": "R", "arc": "\u2322 "}.get(self.dtype, "")
        st = self.style
        if self.dtype == "angular":
            return self._num()
        v = self.measure() * float(st.get("lfac", 1.0) or 1.0)
        s = f"{st.get('prefix', '')}{pre}{fmt_dim_linear(v, st)}{st.get('suffix', '')}"
        tol = st.get("tol", "None")
        if tol and tol != "None":
            tp = int(st.get("tol_dec", st.get("dec", 0)))
            fz = lambda x: _dsep(f"{abs(float(x)):.{tp}f}", st)
            up, lo = st.get("tol_up", 0.0), st.get("tol_lo", 0.0)
            if tol == "Symmetrical":
                s += f" \u00b1{fz(up)}"
            elif tol == "Deviation":
                s += f" +{fz(up)}/-{fz(lo)}"
            elif tol == "Limits":
                s = f"{st.get('prefix', '')}{pre}{fmt_dim_linear(v + float(up), st)} / {fmt_dim_linear(v - float(lo), st)}{st.get('suffix', '')}"
            elif tol == "Basic":
                s = f"[{s}]"
        if st.get("alt"):
            a = dict(st, unit=st.get("alt_unit", "Decimal"), dec=int(st.get("alt_dec", 2)), rnd=0.0)
            s += f" [{st.get('alt_prefix', '')}{fmt_dim_linear(v * float(st.get('alt_f', 0.03937007874)), a)}{st.get('alt_suffix', '')}]"
        return s

    def _num(self):
        st = self.style
        if self.dtype == "angular":
            return fmt_dim_angle(self.measure(), st)
        return fmt_dim_linear(self.measure() * float(st.get("lfac", 1.0) or 1.0), st)

    def _arrow_lines(self):
        """Open / tick / oblique arrowheads are line work."""
        typ = self.style.get("arrow", "closed")
        if typ not in ("open", "tick", "oblique"):
            return []
        out = []; asz = eff_style(self.style)["asz"]
        for tip, d in self.geometry()[1]:
            d = unit(d); s = cross(self.n, d)
            if typ == "open":
                out += [np.array([tip, tip - d * asz + s * asz / 3.5]), np.array([tip, tip - d * asz - s * asz / 3.5])]
            else:
                q = unit(d + s) * asz * 0.5
                out.append(np.array([tip - q, tip + q]))
        return out

    def geometry(self):
        """(lines [Nx3 polylines], arrows [(tip, dir)], text (pos, xdir, height, string))."""
        def mk():
            return _dim_geometry(self)
        return self.cached("geom", mk)

    def wire(self):
        return self.cached("wire", lambda: list(self.geometry()[0]) + self._arrow_lines())

    def tris(self):
        def mk():
            lines, arrows, txt = self.geometry()
            Vs, Fs, off = [], [], 0
            asz = eff_style(self.style)["asz"]; typ = self.style.get("arrow", "closed")
            for tip, d in arrows:
                d = unit(d); s = cross(self.n, d)
                if typ == "closed":
                    V = np.array([tip, tip - d * asz + s * asz / 6, tip - d * asz - s * asz / 6])
                    Vs.append(V); Fs.append(np.array([[off, off + 1, off + 2]])); off += 3
                elif typ == "dot":
                    r = asz / 4; ang = np.linspace(0, 2 * math.pi, 13)[:-1]
                    V = np.vstack([tip] + [tip + r * (math.cos(a) * d + math.sin(a) * s) for a in ang])
                    Vs.append(V); Fs.append(np.array([[off, off + 1 + i, off + 1 + (i + 1) % 12] for i in range(12)])); off += 13
            if txt:
                t = Text(txt[0], txt[3], txt[2], txt[1], self.n, 1, 1)
                tt = t.tris()
                if tt is not None:
                    Vs.append(tt[0]); Fs.append(tt[1] + off); off += len(tt[0])
            if not Vs:
                return None
            return np.vstack(Vs), np.vstack(Fs).astype(np.int32)
        return self.cached("tris", mk)

    def snaps(self):
        return {"node": list(self.dpts)}

    def transform(self, M):
        self.dpts = [xform_pt(M, p) for p in self.dpts]; self.n = unit(xform_vec(M, self.n)); self.xdir = unit(xform_vec(M, self.xdir))
        self.touch()

    def explode(self):
        out = [Line(l[i], l[i + 1]) for l in self.geometry()[0] for i in range(len(l) - 1)]
        txt = self.geometry()[2]
        if txt:
            out.append(Text(txt[0], txt[3], txt[2], txt[1], self.n, 1, 1))
        return out

    def info(self):
        return [("Type", self.dtype), ("Measurement", self.measure()), ("Text", self.text())]

    def props(self):
        return [("Text height", self.style["th"], lambda v: self._st("th", v)), ("Arrow size", self.style["asz"], lambda v: self._st("asz", v)),
                ("Decimals", self.style["dec"], lambda v: self._st("dec", int(v))), ("Text override", self.override, self._ov)]

    def _st(self, k, v):
        self.style[k] = v; self.touch()

    def _ov(self, v):
        self.override = str(v) if v not in (None, 0, 0.0) else ""; self.touch()


DIMSTYLE_DEFAULT = {"th": 2.5, "asz": 2.5, "exo": 1.25, "exe": 1.25, "gap": 0.8, "dec": 0, "lfac": 1.0, "rot": 0, "anno": False}
DIM_UNITS = ["Scientific", "Decimal", "Engineering", "Architectural", "Fractional", "Windows Desktop"]
DIM_ANGLES = ["Decimal Degrees", "Degrees Minutes Seconds", "Gradians", "Radians"]


def _dsep(s, st):
    return s.replace(".", ",") if st.get("dsep", ".") == "," else s


def _frac(v, den):
    """v as 'whole num/den' with the denominator reduced (den = 1, 2, 4 ... 256)."""
    n = int(round(abs(v) * den)); w, r = divmod(n, den)
    if r:
        g = math.gcd(r, den); r //= g; d2 = den // g
        return (f"{w} " if w else "") + f"{r}/{d2}"
    return str(w)


def fmt_dim_linear(v, st):
    """Dimension number in the unit format of the style: Scientific, Decimal, Engineering (feet + decimal inches),
    Architectural (feet + fractional inches), Fractional, Windows Desktop; with round-off and zero suppression."""
    unit_ = st.get("unit", "Decimal"); dec = int(st.get("dec", 0))
    rnd = float(st.get("rnd", 0.0) or 0.0)
    if rnd > 0:
        v = round(v / rnd) * rnd
    lead = bool(st.get("zlead")); trail = bool(st.get("dimz"))
    def dz(s):
        if trail and "." in s:
            s = s.rstrip("0").rstrip(".")
        if lead and (s.startswith("0.") or s.startswith("-0.")):
            s = s.replace("0.", ".", 1)
        return s
    sign = "-" if v < 0 else ""; a = abs(v)
    if unit_ == "Scientific":
        m = f"{a:.{dec}E}"; mant, ex = m.split("E")
        return _dsep(sign + dz(mant), st) + "E" + ("+" if int(ex) >= 0 else "-") + f"{abs(int(ex)):02d}"
    if unit_ == "Engineering":
        ft = int(a // 12 + 1e-9); inch = a - ft * 12
        if round(inch, dec) >= 12:
            ft += 1; inch = 0.0
        si = dz(f"{inch:.{dec}f}")
        if st.get("zft") and ft == 0:
            return sign + _dsep(si, st) + '"'
        if st.get("zin") and float(si or 0) == 0:
            return sign + f"{ft}'"
        return sign + f"{ft}'-" + _dsep(si, st) + '"'
    if unit_ in ("Architectural", "Fractional"):
        den = 2 ** min(8, max(0, dec))
        if unit_ == "Fractional":
            return sign + _frac(a, den)
        n = int(round(a * den)); ft, rem = divmod(n, 12 * den)
        si = _frac(rem / den, den)
        if st.get("zft") and ft == 0:
            return sign + si + '"'
        if st.get("zin") and rem == 0:
            return sign + f"{ft}'"
        return sign + f"{ft}'-{si}" + '"'
    s = dz(f"{a:.{dec}f}")
    if unit_ == "Windows Desktop":
        try:
            import locale
            s = s.replace(".", locale.localeconv().get("decimal_point", ".") or ".")
        except Exception:
            pass
        return sign + s
    return sign + _dsep(s, st)


def fmt_dim_angle(deg, st):
    """Angle (degrees) in the angular format of the style."""
    fmt = st.get("aunit", "Decimal Degrees"); dec = int(st.get("adec", st.get("dec", 1)))
    lead = bool(st.get("azlead")); trail = bool(st.get("aztrail"))
    def dz(s):
        if trail and "." in s:
            s = s.rstrip("0").rstrip(".")
        if lead and s.startswith("0."):
            s = s[1:]
        return s
    if fmt == "Degrees Minutes Seconds":
        tot = abs(deg) * 3600.0
        if dec <= 0:
            return f"{int(round(abs(deg)))}°"
        if dec in (1, 2):
            m = int(round(tot / 60.0)); d, m = divmod(m, 60)
            return f"{d}°{m}'"
        sd = max(0, dec - 4); sec = round(tot, sd); d = int(sec // 3600); m = int((sec - d * 3600) // 60); sx = sec - d * 3600 - m * 60
        return f"{d}°{m}'" + _dsep(f"{sx:.{sd}f}", st) + '"'
    if fmt == "Gradians":
        return _dsep(dz(f"{deg * 10.0 / 9.0:.{dec}f}"), st) + "g"
    if fmt == "Radians":
        return _dsep(dz(f"{math.radians(deg):.{dec}f}"), st) + "r"
    return _dsep(dz(f"{deg:.{dec}f}"), st) + "°"


def eff_style(style):
    if not style.get("anno"):
        return style
    k = Entity.anno_scale
    return dict(style, **{x: style[x] * k for x in ("th", "asz", "exo", "exe", "gap")})


def _dim_geometry(d):
    st = eff_style(d.style); pl = d.plane(); n = d.n
    P = d.dpts
    lines, arrows = [], []
    th = st["th"]; gap = st["gap"]
    txt = None
    if d.dtype in ("linear", "aligned") and len(P) >= 3:
        if d.dtype == "linear":
            ang = math.radians(st.get("rot", 0) or 0)
            dx = math.cos(ang) * pl.x + math.sin(ang) * pl.y
        else:
            dx = unit(P[1] - P[0]) if norm(P[1] - P[0]) > EPS else pl.x
        dy = cross(n, dx)
        off = np.dot(P[2] - P[0], dy)
        a = P[0] + dy * (off - np.dot(P[0] - P[0], dy)); b = P[1] + dy * (off - np.dot(P[1] - P[0], dy))
        # extension lines
        for i_, (p, q) in enumerate(((P[0], a), (P[1], b))):
            v = q - p; L = norm(v)
            if L > EPS and not st.get("se1" if i_ == 0 else "se2"):
                u = v / L
                lines.append(np.array([p + u * min(st["exo"], L), q + u * st["exe"]]))
        if norm(b - a) > EPS:
            arrows += [(a, a - b), (b, b - a)]
        mid = (a + b) / 2
        tx = dx if np.dot(dx, pl.x) >= -1e-9 else -dx
        ty = cross(n, tx)
        s_ = d.text(); wtxt = Entity.measure(s_) * th
        horiz = st.get("talign") == "Horizontal" and abs(np.dot(tx, pl.x)) < 0.999
        if st.get("tad") == "Centered" or horiz:
            # text on the dimension line: the line is broken around it
            half = (th if horiz else wtxt) / 2 + gap
            if norm(b - a) > 2 * half + EPS:
                u_ = unit(b - a); lines.append(np.array([a, mid - u_ * half])); lines.append(np.array([mid + u_ * half, b]))
            else:
                lines.append(np.array([a, b]))
            txt = (mid - (pl.y if horiz else ty) * th / 2, pl.x if horiz else tx, th, s_)
        else:
            lines.append(np.array([a, b]))
            txt = (mid + ty * (th / 2 + gap), tx, th, s_)
    elif d.dtype in ("radius", "diameter") and len(P) >= 2:
        c, p = P[0], P[1]
        u = unit(p - c); r = norm(p - c)
        q = P[2] if len(P) > 2 else p + u * th * 3
        if d.dtype == "diameter":
            lines.append(np.array([c - u * r, p])); arrows += [(p, u), (c - u * r, -u)]
        else:
            lines.append(np.array([c, p])); arrows.append((p, u))
        if norm(q - p) > EPS and np.dot(q - p, u) > 0:
            lines.append(np.array([p, q]))
        tx = pl.x if np.dot(u, pl.x) >= 0 else -pl.x
        ty = cross(n, tx)
        txt = (q + tx * (th * 0.62 * len(d.text()) / 2 + gap) * (1 if np.dot(u, pl.x) >= 0 else 1) + ty * 0, tx, th, d.text())
        txt = (txt[0] + ty * (th / 2 + gap), tx, th, txt[3])
    elif d.dtype == "angular" and len(P) >= 4:
        c, p1, p2, loc = P[:4]
        r = norm(loc - c)
        u = unit(p1 - c); w = unit(p2 - c)
        nn = unit(cross(u, w))
        if norm(nn) < EPS:
            nn = n
        a1 = math.acos(max(-1, min(1, np.dot(u, w))))
        pts = arc_pts(c, r, nn, u, 0, a1, 32)
        lines.append(pts)
        for e, p in ((pts[0], p1), (pts[-1], p2)):
            if norm(e - c) > norm(p - c):
                lines.append(np.array([p, e + unit(e - c) * st["exe"]]))
        t0 = cross(nn, u); t1 = -cross(nn, w)
        arrows += [(pts[0], -t0), (pts[-1], -t1)]
        m = arc_pt(c, r + th * 0.8, nn, u, a1 / 2)
        tx = unit(cross(nn, m - c)) * -1
        if np.dot(tx, pl.x) < 0:
            tx = -tx
        txt = (m, tx, th, d.text())
    elif d.dtype == "arc" and len(P) >= 4:
        c, p1, p2, loc = P[:4]
        r0 = norm(p1 - c); r = norm(loc - c); u = unit(p1 - c)
        sw = float(st.get("sweep", 0.0)); nn = n if sw >= 0 else -n; a1 = abs(sw)
        pts = arc_pts(c, r, nn, u, 0, a1, max(8, int(48 * a1 / math.pi)))
        lines.append(pts)
        w = unit(p2 - c)
        for e, q, dv in ((pts[0], p1, u), (pts[-1], p2, w)):        # extension lines, radial
            if abs(r - r0) > EPS:
                sgn = 1 if r > r0 else -1
                lines.append(np.array([q + dv * sgn * st["exo"], e + dv * sgn * st["exe"]]))
        t0 = cross(nn, u); t1 = cross(nn, w)
        arrows += [(pts[0], -t0), (pts[-1], t1)]
        m = arc_pt(c, r + th * 0.8, nn, u, a1 / 2)
        tx = unit(cross(nn, m - c)) * -1
        if np.dot(tx, pl.x) < 0:
            tx = -tx
        txt = (m, tx, th, d.text())
    elif d.dtype == "jogged" and len(P) >= 3:
        c, p, loc = P[:3]
        u = unit(p - c); s = cross(n, u)
        d1 = norm(loc - p); j = min(d1 * 0.5, st["asz"] * 2.5)
        m1 = p + (loc - p) * 0.45; m2 = p + (loc - p) * 0.55
        lines.append(np.array([loc, m2 + s * j / 2, m1 - s * j / 2, p]))
        arrows.append((p, p - (m1 - s * j / 2)))
        tx = pl.x if np.dot(loc - p, pl.x) >= 0 else -pl.x
        txt = (loc + pl.x * (th * 0.62 * len(d.text()) / 2 + gap) * (1 if np.dot(loc - p, pl.x) >= 0 else -1) + cross(n, pl.x) * 0, pl.x, th, d.text())
    elif d.dtype == "ordinate" and len(P) >= 3:
        o, f, e = P[:3]
        ax = pl.x if st.get("axis", "x") == "x" else pl.y            # measured axis; the leader runs along the other one
        run = pl.y if st.get("axis", "x") == "x" else pl.x
        L = np.dot(e - f, run); side = np.dot(e - f, ax)
        k1 = f + run * L * 0.35; k2 = k1 + ax * side + run * L * 0.3
        lines.append(np.array([f + run * math.copysign(min(abs(L) * 0.2, st["exo"]), L), k1, k2, f + ax * side + run * L]))
        end = f + ax * side + run * L
        sgn = 1 if L >= 0 else -1
        if st.get("axis", "x") == "x":
            txt = (end + run * sgn * (th * 0.62 * len(d.text()) / 2 + gap), pl.y, th, d.text())
        else:
            txt = (end + run * sgn * (th * 0.62 * len(d.text()) / 2 + gap), pl.x, th, d.text())
    return lines, arrows, txt


# ===================================================================================================== LEADER
LEADER_ARROWS = ("closed", "open", "dot", "tick", "none")


@register
class Leader(Entity):
    """Leader / multileader: one or more leader lines (arrow tip ... landing point), an optional horizontal landing and
    the text.  pts = first leader line, its last point is the landing point; extra = the other leader lines (their
    points up to, not including, the landing point)."""
    kind = "leader"; label = "Leader"

    def __init__(self, pts=(), s="", h=2.5, n=(0, 0, 1), asz=2.5):
        super().__init__(); self.pts = np.asarray(pts, float).reshape(-1, 3); self.s = s; self.hm = float(h)
        self.n = unit(v3(n)); self.asz0 = float(asz); self.anno = False
        self.extra = []; self.land0 = 0.0; self.arrow = "closed"; self.side = 0     # side: 0 = automatic, 1 = text right, -1 = text left

    @property
    def h(self):
        return self.hm * (Entity.anno_scale if self.anno else 1.0)

    @property
    def asz(self):
        return self.asz0 * (Entity.anno_scale if self.anno else 1.0)

    @property
    def land(self):
        return self.land0 * (Entity.anno_scale if self.anno else 1.0)

    def to_dict(self):
        d = self.base_dict(); d.update(pts=arr(self.pts), s=self.s, h=self.hm, n=arr(self.n), asz=self.asz0, anno=self.anno)
        if self.extra:
            d["extra"] = [arr(x) for x in self.extra]
        if self.land0:
            d["land"] = self.land0
        if self.arrow != "closed":
            d["arrow"] = self.arrow
        if self.side:
            d["side"] = self.side
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["pts"], d["s"], d["h"], d["n"], d.get("asz", 2.5)); e.anno = d.get("anno", False)
        e.extra = [np.asarray(x, float).reshape(-1, 3) for x in d.get("extra", [])]
        e.land0 = float(d.get("land", 0.0) or 0.0); e.arrow = d.get("arrow", "closed"); e.side = int(d.get("side", 0) or 0)
        e.load_base(d); return e

    # ---- geometry
    def lines(self):
        """All leader lines as point arrays that end at the landing point."""
        if len(self.pts) < 2:
            return []
        return [self.pts] + [np.vstack([x, self.pts[-1:]]) for x in self.extra if len(x)]

    def _dir(self):
        """(plane, +1 / -1): the text and the landing go to the right or to the left of the landing point."""
        pl = Plane.from_normal(self.pts[-1], self.n)
        if self.side:
            return pl, (1.0 if self.side > 0 else -1.0)
        return pl, (1.0 if np.dot(self.pts[-1] - self.pts[-2], pl.x) >= 0 else -1.0)

    def land_end(self):
        pl, sg = self._dir()
        return self.pts[-1] + pl.x * sg * self.land

    def _txt(self):
        if not self.s or len(self.pts) < 2:
            return None
        pl, sg = self._dir(); right = sg > 0
        p = self.land_end() + pl.x * (self.h * 0.5 * sg)
        if "\n" in self.s:
            return Text(p, self.s, self.h, pl.x, self.n, 0 if right else 2, 2)
        return Text(p - pl.y * self.h / 2, self.s, self.h, pl.x, self.n, 0 if right else 2, 0)

    def wire(self):
        def mk():
            W = [w.copy() for w in self.lines()]
            if W and self.land > 0:
                W.append(np.array([self.pts[-1], self.land_end()]))
            a = self.asz
            for w in self.lines():
                tip = w[0]; d = unit(w[0] - w[1]); sd = cross(self.n, d)
                if norm(d) < EPS:
                    continue
                if self.arrow == "open":
                    W.append(np.array([tip - d * a + sd * a / 4, tip, tip - d * a - sd * a / 4]))
                elif self.arrow == "tick":
                    t = unit(d + sd) * a / 2; W.append(np.array([tip - t, tip + t]))
            return W
        return self.cached("wire", mk)

    def tris(self):
        def mk():
            if len(self.pts) < 2:
                return None
            V = []; F = []; off = 0; a = self.asz
            for w in self.lines():
                tip = w[0]; d = unit(w[0] - w[1]); sd = cross(self.n, d)
                if norm(d) < EPS:
                    continue
                if self.arrow == "closed":
                    V.append(np.array([tip, tip - d * a + sd * a / 6, tip - d * a - sd * a / 6])); F.append(np.array([[0, 1, 2]]) + off); off += 3
                elif self.arrow == "dot":
                    k = 16; r = a / 4; ang = np.arange(k) * (TAU / k)
                    ring = tip + np.outer(np.cos(ang), d) * r + np.outer(np.sin(ang), sd) * r
                    V.append(np.vstack([tip[None], ring])); F.append(np.array([[0, 1 + i, 1 + (i + 1) % k] for i in range(k)]) + off); off += k + 1
            t = self._txt()
            tt = t.tris() if t else None
            if tt is not None:
                V.append(tt[0]); F.append(tt[1] + off)
            if not V:
                return None
            return np.vstack(V), np.vstack(F).astype(np.int32)
        return self.cached("tris", mk)

    def snaps(self):
        if not len(self.pts):
            return {}
        return {"end": [w[0] for w in self.lines()] + [self.pts[-1]]}

    # ---- grips: every point of every leader line, the landing point once, the end of the landing
    def grip_map(self):
        g = [("m", 0, i) for i in range(len(self.pts))]
        for j, x in enumerate(self.extra):
            g += [("x", j, i) for i in range(len(x))]
        if self.land > 0:
            g.append(("land", 0, 0))
        return g

    def grip_pts(self):
        out = []
        for t, j, i in self.grip_map():
            out.append(self.pts[i] if t == "m" else (self.extra[j][i] if t == "x" else self.land_end()))
        return out

    def transform(self, M):
        self.pts = xform_pt(M, self.pts); self.n = unit(xform_vec(M, self.n))
        self.extra = [xform_pt(M, x) for x in self.extra]
        if np.linalg.det(np.asarray(M, float)[:3, :3]) < 0 and self.side:
            self.side = -self.side
        if not self.anno:
            sf = m_scale_factor(M); self.hm *= sf; self.asz0 *= sf; self.land0 *= sf
        self.touch()

    def explode(self):
        out = []
        for w in self.wire():
            out += [Line(w[i], w[i + 1]) for i in range(len(w) - 1)]
        t = self._txt()
        return out + ([t] if t else [])

    def info(self):
        return [("Text", self.s), ("Leader lines", 1 + len(self.extra)), ("Vertices", len(self.pts))]

    def props(self):
        return [("Text", self.s, self._sets), ("Text height", self.h, self._seth),
                ("Arrowhead (closed/open/dot/tick/none)", self.arrow, self._setarrow), ("Arrowhead size", self.asz, self._setasz),
                ("Landing distance (0 = no landing)", self.land, self._setland)]

    def _sets(self, v):
        self.s = str(v).replace("\\P", "\n"); self.touch()

    def _seth(self, v):
        if v > 0:
            self.hm = v / (Entity.anno_scale if self.anno else 1.0); self.touch()

    def _setasz(self, v):
        if float(v) >= 0:
            self.asz0 = float(v) / (Entity.anno_scale if self.anno else 1.0); self.touch()

    def _setland(self, v):
        if float(v) >= 0:
            self.land0 = float(v) / (Entity.anno_scale if self.anno else 1.0); self.touch()

    def _setarrow(self, v):
        v = str(v).strip().lower()
        v = {"closed filled": "closed", "filled": "closed", "arrow": "closed", "oblique": "tick"}.get(v, v)
        if v in LEADER_ARROWS:
            self.arrow = v; self.touch()


# ===================================================================================================== BLOCK INSERT
class Block:
    def __init__(self, name, base=(0, 0, 0), ents=(), params=None, actions=None):
        self.name = name; self.base = v3(base); self.ents = list(ents)
        self.params = list(params or [])        # dynamic block parameters (see core/dynblock.py)
        self.actions = list(actions or [])      # dynamic block actions

    HEAVY = 300             # blocks with at least this many objects are drawn from one cached array (imported PDF pages ...)

    def plain(self):
        """True if every reference shows the same geometry (no dynamic parameters, no attributes)."""
        k = (len(self.ents), len(self.params))
        c = getattr(self, "_plain", None)
        if c is None or c[0] != k:
            c = (k, not self.params and not any(e.kind == "attdef" for e in self.ents)); self._plain = c
        return c[1]

    def geo(self):
        """Line work and filled triangles of the whole block in block coordinates, grouped by (colour, layer):
        {"S": (N,2,3), "Sg": (N,), "T": (M,3,3), "Tg": (M,), "pal": [(colour, layer)], "box": (min, max)} - cached."""
        g = getattr(self, "_geo", None)
        doc = DetailView.doc; sig = None; LT = {}; dash = None; lts_g = 1.0
        try:                                               # linetypes of the objects inside (dashes are part of the display)
            from .document import LINETYPES as LT, dash_segments as dash
            lts_g = float(doc.settings.get("ltscale", 1.0) or 1.0)
            sig = (lts_g, hash(tuple((l.name, l.ltype) for l in doc.layers.values())))
        except Exception:
            doc = None
        if g is not None and g["n"] == len(self.ents) and g.get("sig") == sig:
            return g
        pal = {}; S = []; Sg = []; Tr = []; Tg = []; D = []; Dg = []; any_dash = False
        for e in self.ents:
            try:
                k = pal.setdefault((e.color if not isinstance(e.color, list) else tuple(e.color), e.layer), len(pal))
                pat = None
                if doc is not None and e.is_curve:
                    lt = e.ltype
                    if lt in ("ByLayer", None, ""):
                        ly = doc.layers.get(e.layer); lt = ly.ltype if ly is not None else "Continuous"
                    pat = LT.get(lt)
                for w in e.wire():
                    w = np.asarray(w, float)
                    if len(w) >= 2:
                        sg = np.stack([w[:-1], w[1:]], axis=1)
                        S.append(sg); Sg.append(np.full(len(w) - 1, k))
                        sh = dash(w, pat, lts_g * float(getattr(e, "lts", 1.0) or 1.0)) if pat is not None else None
                        if sh is not None:
                            any_dash = True; sg = np.asarray(sh, float).reshape(-1, 2, 3)
                        D.append(sg); Dg.append(np.full(len(sg), k))
                t = e.tris()
                if t is not None and len(t[1]):
                    tri = np.asarray(t[0], float)[np.asarray(t[1])]
                    Tr.append(tri); Tg.append(np.full(len(tri), k))
            except Exception:
                continue
        S = np.vstack(S) if S else np.zeros((0, 2, 3)); Tr = np.vstack(Tr) if Tr else np.zeros((0, 3, 3))
        P = np.vstack([S.reshape(-1, 3), Tr.reshape(-1, 3)]) if len(S) or len(Tr) else np.zeros((1, 3))
        g = {"n": len(self.ents), "sig": sig, "D": (np.vstack(D) if any_dash else None), "Dg": (np.concatenate(Dg) if any_dash else None),
             "S": S, "Sg": np.concatenate(Sg) if Sg else np.zeros(0, int), "T": Tr,
             "Tg": np.concatenate(Tg) if Tg else np.zeros(0, int), "pal": [k for k, _ in sorted(pal.items(), key=lambda kv: kv[1])],
             "box": (P.min(axis=0), P.max(axis=0))}
        self._geo = g
        return g

    def to_dict(self):
        d = {"name": self.name, "base": arr(self.base), "ents": [e.to_dict() for e in self.ents], "params": self.params}
        if self.actions:
            d["actions"] = self.actions
        return d

    @classmethod
    def from_dict(cls, d):
        return cls(d["name"], d["base"], [from_dict(x) for x in d["ents"]], d.get("params"), d.get("actions"))

    def attdefs(self):
        return [e for e in self.ents if e.kind == "attdef"]

    def param(self, ptype):
        return [p for p in self.params if p.get("type") == ptype]


@register
class Insert(Entity):
    kind = "insert"; label = "Block reference"
    blocks = {}       # shared with the document (set by Document)

    def __init__(self, name="", M=None):
        super().__init__(); self.name = name; self.M = np.eye(4) if M is None else np.asarray(M, float); self.anno = False
        self.attribs = {}       # attribute tag -> value
        self.dyn = {}           # dynamic parameter name -> value

    def Meff(self):
        if not self.anno:
            return self.M
        b = Insert.blocks.get(self.name); base = b.base if b is not None else np.zeros(3)
        k = Entity.anno_scale; S = np.eye(4) * k; S[3, 3] = 1; S[:3, 3] = base - k * base
        return self.M @ S

    @classmethod
    def make(cls, name, p, sx=1, sy=1, sz=1, rot=0.0, n=(0, 0, 1)):
        pl = Plane.from_normal(p, n)
        R = np.eye(4); c, s = math.cos(rot), math.sin(rot)
        R[:2, :2] = [[c, -s], [s, c]]
        S = np.diag([sx, sy, sz, 1.0])
        b = cls.blocks.get(name)
        T = np.eye(4)
        if b is not None:
            T[:3, 3] = -b.base
        return cls(name, pl.matrix() @ R @ S @ T)

    def to_dict(self):
        d = self.base_dict(); d.update(name=self.name, M=self.M.tolist(), anno=self.anno)
        if self.attribs:
            d["attribs"] = self.attribs
        if self.dyn:
            d["dyn"] = self.dyn
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["name"], d["M"]); e.anno = d.get("anno", False); e.attribs = dict(d.get("attribs") or {}); e.dyn = dict(d.get("dyn") or {})
        e.load_base(d); return e

    def dyn_value(self, prm):
        """Current value of a dynamic parameter (falls back to the block default, value sets applied)."""
        from . import dynblock as DB
        return DB.value(prm, self.dyn.get(prm["name"]))

    def _dyn_grips(self):
        b = Insert.blocks.get(self.name)
        if b is None or not b.params:
            return []
        from . import dynblock as DB
        return DB.grips(b, self)

    def dyn_grips(self):
        """World positions of the dynamic grips (one per parameter, AutoCAD style)."""
        M = self.Meff()
        return [(M @ np.append(q, 1.0))[:3] for q, p, k in self._dyn_grips()]

    def dyn_grip_kind(self, i):
        g = self._dyn_grips()
        return (g[i][2], g[i][1]) if 0 <= i < len(g) else (None, None)

    def dyn_grip_set(self, i, w):
        from . import dynblock as DB
        g = self._dyn_grips()
        if not (0 <= i < len(g)):
            return
        q0, p, kind = g[i]
        self.dyn = dict(self.dyn)
        if kind == "flip":
            self.dyn[p["name"]] = not self.dyn_value(p)
        elif kind == "visibility":
            st = p.get("states") or []
            if w is not None and isinstance(w, str):
                self.dyn[p["name"]] = w
            elif st:
                cur = self.dyn_value(p); self.dyn[p["name"]] = st[(st.index(cur) + 1) % len(st)] if cur in st else st[0]
        else:
            q = (np.linalg.inv(self.Meff()) @ np.append(v3(w), 1.0))[:3]
            v = DB.grip_value(p, q)
            if v is not None:
                self.dyn[p["name"]] = v
        self.touch()

    def _local_ents(self, b):
        """Block entities for THIS reference: visibility state and every dynamic action applied, attributes filled in."""
        from . import dynblock as DB
        out = []
        for e, c in DB.evaluate(b, self, stretch_entity):
            if c.kind == "attdef":
                t = Text(c.p, self.attribs.get(c.tag, c.default), c.hm, c.xdir, c.n, c.halign, c.valign)
                t.anno = c.anno; t.layer = c.layer; t.color = c.color
                if c.invisible:
                    continue
                c = t
            out.append((e, c))
        return out

    def children(self):
        def mk():
            b = Insert.blocks.get(self.name)
            if b is None:
                return []
            out = []
            M = self.Meff(); sf = m_scale_factor(M)
            for e, c in self._local_ents(b):
                c.transform(M)
                if isinstance(c, Dimension) and abs(sf - 1) > 1e-12:
                    c.style["lfac"] = c.style.get("lfac", 1.0) / sf
                    if not c.style.get("anno"):
                        for k in ("th", "asz", "exo", "exe", "gap"):
                            c.style[k] = c.style.get(k, DIMSTYLE_DEFAULT[k]) * sf
                    c.touch()
                c.layer = e.layer if e.layer != "0" else self.layer
                if e.color == 0:
                    c.color = self.color
                out.append(c)
            return out
        return self.cached("children", mk)

    def heavy(self):
        """Reference of a big plain block: displayed, picked and snapped from the block's cached arrays."""
        b = Insert.blocks.get(self.name)
        return b is not None and len(b.ents) >= Block.HEAVY and not self.dyn and not self.anno and b.plain()

    def heavy_geo(self):
        """(segments (N,2,3), groups, triangles (M,3,3), groups, palette) of a heavy reference in world coordinates."""
        def mk():
            g = Insert.blocks[self.name].geo(); M = self.Meff(); R = M[:3, :3].T; t = M[:3, 3]
            return (g["S"] @ R + t, g["Sg"], g["T"] @ R + t, g["Tg"], g["pal"])
        return self.cached("hgeo", mk)

    def heavy_disp(self):
        """(segments, groups) to draw: like heavy_geo but with the linetypes (dashes) of the objects applied."""
        b = Insert.blocks[self.name]; g = b.geo()
        if g.get("D") is None:
            S, Sg = self.heavy_geo()[:2]
            return S, Sg
        c = self._cache.get("hdisp")
        if c is None or c[0] is not g:
            M = self.Meff()
            c = (g, g["D"] @ M[:3, :3].T + M[:3, 3], g["Dg"]); self._cache["hdisp"] = c
        return c[1], c[2]

    def bbox(self):
        if not self.heavy():
            return Entity.bbox(self)
        def mk():
            g = Insert.blocks[self.name].geo(); lo, hi = g["box"]; M = self.Meff()
            C = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]) @ M[:3, :3].T + M[:3, 3]
            return C.min(axis=0), C.max(axis=0)
        return self.cached("bbox", mk)

    def wire(self):
        if self.heavy():
            def mk():                                       # outline + a sample of the line work (highlight / drag preview)
                S = self.heavy_geo()[0]; lo, hi = self.bbox()
                box = np.array([[lo[0], lo[1], lo[2]], [hi[0], lo[1], lo[2]], [hi[0], hi[1], lo[2]], [lo[0], hi[1], lo[2]], [lo[0], lo[1], lo[2]]])
                step = max(1, len(S) // 1500)
                return [box] + [sg for sg in S[::step]]
            return self.cached("wire", mk)
        return self.cached("wire", lambda: [w for c in self.children() for w in c.wire()])

    def full_segments(self):
        """All line segments (N,2,3) of the reference (hatch boundaries, plotting)."""
        if self.heavy():
            return self.heavy_geo()[0]
        W = [np.stack([w[:-1], w[1:]], axis=1) for w in self.wire() if len(w) >= 2]
        return np.vstack(W) if W else np.zeros((0, 2, 3))

    def tris(self):
        if self.heavy():
            return None
        def mk():
            V, F, off = [], [], 0
            for c in self.children():
                t = c.tris()
                if t is not None and len(t[0]):
                    V.append(t[0]); F.append(t[1] + off); off += len(t[0])
            return (np.vstack(V), np.vstack(F)) if V else None
        return self.cached("tris", mk)

    def prims(self):
        if self.heavy():
            return self.cached("prims", lambda: [("L", sg[0], sg[1]) for sg in self.heavy_geo()[0]])
        return self.cached("prims", lambda: [p for c in self.children() for p in c.prims()])

    def snaps(self):
        s = {"ins": [xform_pt(self.M, Insert.blocks[self.name].base) if self.name in Insert.blocks else self.M[:3, 3].copy()]}
        if self.heavy():
            S = self.heavy_geo()[0]
            s["end"] = S.reshape(-1, 3); s["mid"] = S.mean(axis=1)
            return s
        for c in self.children():
            for k, v in c.snaps().items():
                s.setdefault(k, []).extend(v)
        return s

    def transform(self, M):
        self.M = M @ self.M; self.touch()

    def explode(self):
        return [c.copy() for c in self.children()]

    def info(self):
        return [("Block", self.name), ("Insertion", xform_pt(self.M, Insert.blocks[self.name].base) if self.name in Insert.blocks else self.M[:3, 3]),
                ("Scale", m_scale_factor(self.M)), ("Annotative", "Yes" if self.anno else "No")]

    def props(self):
        b = Insert.blocks.get(self.name); out = []
        if b is None:
            return out
        from . import dynblock as DB
        for a in b.attdefs():
            out.append((f"Attribute {a.tag}", self.attribs.get(a.tag, a.default), lambda v, t=a.tag: self._attr(t, v)))
        for p in b.params:
            v = self.dyn_value(p); t = p["type"]
            if t == "visibility":
                out.append((p["name"] + "  (" + " / ".join(p.get("states", [])) + ")", v, lambda v, p=p: self._dyn(p, str(v))))
            elif t in ("linear", "rotation"):
                out.append((p["name"] + ("  (deg)" if t == "rotation" else ""), float(v), lambda v, p=p: self._dyn(p, v)))
            elif t == "flip":
                out.append((p["name"] + "  (0 / 1)", 1 if v else 0, lambda v, p=p: self._dyn(p, bool(float(v)))))
            else:
                lab = {"polar": "  (distance < angle)", "xy": "  (x, y)", "point": "  (dx, dy)"}[t]
                out.append((p["name"] + lab, DB.fmt(p, v), lambda v, p=p: self._dyn(p, v)))
        return out

    def _attr(self, tag, v):
        self.attribs[tag] = "" if v is None else str(v) if not isinstance(v, float) or v != int(v) else str(int(v)); self.touch()

    def _dyn(self, p, v):
        from . import dynblock as DB
        if isinstance(v, str) or (p["type"] in ("polar", "xy", "point") and not isinstance(v, (list, tuple))):
            try:
                v = DB.parse(p, v)
            except (TypeError, ValueError, IndexError):
                return
            if v is None:
                return
        self.dyn = dict(self.dyn); self.dyn[p["name"]] = DB.value(p, v); self.touch()


class Segs(Entity):
    """Loose line segments of one colour (internal: generated children of a detail view; never saved)."""
    kind = "segs"; label = "Segments"

    def __init__(self, S=()):
        super().__init__(); self.S = np.asarray(S, float).reshape(-1, 2, 3)

    def wire(self):
        return [s for s in self.S]

    def bbox(self):
        return (self.S.reshape(-1, 3).min(axis=0), self.S.reshape(-1, 3).max(axis=0)) if len(self.S) else None

    def snaps(self):
        return {"end": list(self.S.reshape(-1, 3)[:400])} if len(self.S) else {}

    def to_dict(self):
        d = self.base_dict(); d.update(kind="polyline"); return d


def _clip_circle(S, r):
    """Clip 2D segments S (k, 2, 2) (local coordinates, circle centred on 0) -> (kept segments, index of source)."""
    a = S[:, 0]; d = S[:, 1] - S[:, 0]
    A = np.einsum("ij,ij->i", d, d); B = 2 * np.einsum("ij,ij->i", a, d); C = np.einsum("ij,ij->i", a, a) - r * r
    A = np.where(A < 1e-18, 1e-18, A)
    disc = B * B - 4 * A * C
    ok = disc > 0
    sq = np.sqrt(np.where(ok, disc, 0))
    t0 = np.clip((-B - sq) / (2 * A), 0, 1); t1 = np.clip((-B + sq) / (2 * A), 0, 1)
    ok &= t1 - t0 > 1e-9
    idx = np.flatnonzero(ok)
    return np.stack([a[idx] + d[idx] * t0[idx, None], a[idx] + d[idx] * t1[idx, None]], axis=1), idx, t0[idx], t1[idx]


def _clip_rect(S, hw, hh):
    a = S[:, 0]; d = S[:, 1] - S[:, 0]
    t0 = np.zeros(len(S)); t1 = np.ones(len(S)); ok = np.ones(len(S), bool)
    for p, q in ((-d[:, 0], a[:, 0] + hw), (d[:, 0], hw - a[:, 0]), (-d[:, 1], a[:, 1] + hh), (d[:, 1], hh - a[:, 1])):
        par = np.abs(p) < 1e-15
        ok &= ~(par & (q < 0))
        with np.errstate(divide="ignore", invalid="ignore"):
            r = np.where(par, 0.0, q / np.where(par, 1.0, p))
        t0 = np.where(~par & (p < 0), np.maximum(t0, r), t0)
        t1 = np.where(~par & (p > 0), np.minimum(t1, r), t1)
    ok &= t1 - t0 > 1e-9
    idx = np.flatnonzero(ok)
    return np.stack([a[idx] + d[idx] * t0[idx, None], a[idx] + d[idx] * t1[idx, None]], axis=1), idx, t0[idx], t1[idx]


def _lay_vis(doc, e):
    l = doc.layers.get(e.layer)
    return l is None or bool(l.visible)


@register
class DetailView(Entity):
    """Live enlarged detail of a region of the drawing. The geometry is regenerated from the main drawing whenever the
    drawing changes, and its magnification = drawing scale / detail scale (a 1:5 detail on a 1:50 drawing is 10 x)."""
    kind = "detailview"; label = "Detail view"
    doc = None                     # the active document (set by Document.activate)

    def __init__(self, c=(0, 0, 0), size=(100.0, 100.0), pos=(0, 0, 0), dscale=5.0, name="A", shape="circle", n=(0, 0, 1), xdir=(1, 0, 0), th=3.5):
        super().__init__(); self.c = v3(c); self.size = (float(size[0]), float(size[1])); self.pos = v3(pos); self.dscale = float(dscale)
        self.name = str(name); self.shape = shape; self.n = unit(v3(n)); self.xdir = unit(v3(xdir)); self.th = float(th)
        self._key = None; self._kids = []

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), size=list(self.size), pos=arr(self.pos), dscale=self.dscale, name=self.name, shape=self.shape,
                                       n=arr(self.n), xdir=arr(self.xdir), th=self.th)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["size"], d["pos"], d["dscale"], d.get("name", "A"), d.get("shape", "circle"), d.get("n", (0, 0, 1)), d.get("xdir", (1, 0, 0)),
                d.get("th", 3.5)); e.load_base(d); return e

    def plane(self):
        return Plane(self.c, self.xdir, cross(self.n, self.xdir))

    def mag(self):
        return Entity.anno_scale / max(self.dscale, 1e-9)

    def children(self):
        doc = DetailView.doc
        key = (id(doc), getattr(doc, "rev", 0), getattr(doc, "version", 0), Entity.anno_scale, self.dscale, tuple(self.pos), tuple(self.c), self.size,
               self.name, self.shape)
        if key != self._key:
            self._key = key; self._cache = {}
            try:
                self._kids = self._build(doc)
            except Exception:
                import traceback; traceback.print_exc(); self._kids = []
        return self._kids

    def _build(self, doc):
        pl = self.plane(); m = self.mag(); k = Entity.anno_scale
        hw, hh = self.size
        rad = hw
        out = []
        M = np.eye(4); M[:3, :3] *= m; M[:3, 3] = self.pos - m * self.c          # scale about the region centre, move to the detail position
        def inside(p):
            q = pl.to_local(p)
            return (q[0] * q[0] + q[1] * q[1] <= rad * rad) if self.shape == "circle" else (abs(q[0]) <= hw and abs(q[1]) <= hh)
        reach = (rad if self.shape == "circle" else math.hypot(hw, hh)) * 1.02
        if doc is not None:
            for e in list(doc.ents.values()):
                if e is self or e.kind in ("detailview", "image") or not _lay_vis(doc, e):
                    continue
                try:
                    bb = e.bbox()
                    if bb is not None:
                        cen = (np.asarray(bb[0]) + np.asarray(bb[1])) / 2; ext = norm(np.asarray(bb[1]) - np.asarray(bb[0])) / 2
                        if norm(pl.to_local(cen)[:2]) > reach + ext:
                            continue
                    col = doc.color_of(e)
                    if e.kind == "text":
                        if inside(e.p):
                            t = e.copy(); t.transform(M); t.color = col; t.layer = e.layer
                            if e.anno:
                                t.anno = e.anno                      # annotative text keeps its paper height
                            out.append(t)
                        continue
                    if e.kind == "dimension":
                        if all(inside(p) for p in e.dpts[:2]):
                            d = e.copy(); d.transform(M); d.color = col; d.layer = e.layer
                            d.style["lfac"] = d.style.get("lfac", 1.0) / m          # the detail still shows the true size
                            d.touch(); out.append(d)
                        continue
                    W = e.edges() if e.kind == "body" else None
                    if W is None:
                        segs = [np.stack([w[:-1], w[1:]], axis=1) for w in e.wire() if len(w) >= 2]
                        if not segs:
                            continue
                        W = np.vstack(segs)
                    if not len(W):
                        continue
                    W = np.asarray(W, float).reshape(-1, 2, 3)
                    L = pl.to_local(W.reshape(-1, 3)).reshape(-1, 2, 3)
                    S2, idx, t0, t1 = (_clip_circle(L[:, :, :2], rad) if self.shape == "circle" else _clip_rect(L[:, :, :2], hw, hh))
                    if not len(idx):
                        continue
                    A = W[idx, 0]; D = W[idx, 1] - W[idx, 0]
                    S3 = np.stack([A + D * t0[:, None], A + D * t1[:, None]], axis=1)
                    S3 = (S3.reshape(-1, 3) @ M[:3, :3].T + M[:3, 3]).reshape(-1, 2, 3)
                    g = Segs(S3); g.color = col; g.layer = e.layer; out.append(g)
                except Exception:
                    continue
        # frames, label and the marker on the main drawing
        x, y = pl.x, pl.y
        def frame(cen, f):
            if self.shape == "circle":
                c = Circle(cen, rad * f, self.n)
            else:
                P = [cen + x * a * hw * f + y * b * hh * f for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
                c = Polyline(np.array(P), True, None, self.n)
            c.color = self.color; c.layer = self.layer
            return c
        out.append(frame(self.c, 1.0)); out.append(frame(self.pos, m))
        th = self.th * k
        top = (rad if self.shape == "circle" else hh)
        t = Text(self.c + y * (top + th * 0.4) + x * (0 if self.shape == "circle" else hw), self.name, th * 1.2, x, self.n, 1 if self.shape == "circle" else 0, 1)
        t.color = self.color; t.layer = self.layer; out.append(t)
        lab = Text(self.pos - y * (top * m + th * 1.2), f"DETAIL {self.name}\nSCALE 1:{self.dscale:g}", th, x, self.n, 1, 3)
        lab.color = self.color; lab.layer = self.layer; out.append(lab)
        return out

    def wire(self):
        return [w for c in self.children() for w in c.wire()]

    def tris(self):
        V, F, off = [], [], 0
        for c in self.children():
            t = c.tris()
            if t is not None and len(t[0]):
                V.append(t[0]); F.append(t[1] + off); off += len(t[0])
        return (np.vstack(V), np.vstack(F)) if V else None

    def bbox(self):
        P = [w for w in self.wire() if len(w)]
        if not P:
            return (self.pos - 1, self.pos + 1)
        A = np.vstack(P)
        return A.min(axis=0), A.max(axis=0)

    def snaps(self):
        s = {"ins": [self.pos.copy()], "cen": [self.c.copy()]}
        for c in self.children():
            for k, v in c.snaps().items():
                s.setdefault(k, []).extend(v[:300])
        return s

    def transform(self, M):
        """Moving a detail view moves the enlarged view; the source region stays on the main drawing."""
        self.pos = xform_pt(M, self.pos); self.touch()

    def explode(self):
        out = []
        for c in self.children():
            if isinstance(c, Segs):
                for s in c.S:
                    l = Line(s[0], s[1]); l.color = c.color; l.layer = c.layer; out.append(l)
            else:
                out.append(c.copy())
        return out

    def info(self):
        return [("Detail", self.name), ("Detail scale", f"1:{self.dscale:g}"), ("Magnification", self.mag()), ("Source centre", self.c),
                ("Region", f"{self.shape}  {self.size[0]:g}" + ("" if self.shape == "circle" else f" x {self.size[1]:g} (half sizes)"))]

    def props(self):
        return [("Name", self.name, lambda v: self._set("name", str(v))), ("Detail scale 1:", self.dscale, lambda v: self._set("dscale", max(1e-6, float(v)))),
                ("Region size", self.size[0], lambda v: self._set("size", (max(1e-6, float(v)), self.size[1] if self.shape != "circle" else max(1e-6, float(v))))),
                ("Label height (paper)", self.th, lambda v: self._set("th", float(v)))]

    def _set(self, k, v):
        setattr(self, k, v); self.touch()


# ===================================================================================================== MESH BODIES
@register
class Body(Entity):
    """Triangle-mesh body: role = solid | surface | mesh | plate | profile."""
    kind = "body"; label = "3D Solid"
    LABELS = {"solid": "3D Solid", "surface": "Surface", "mesh": "Mesh", "plate": "3D Plate", "profile": "3D Profile",
              "pipe": "3D Pipe", "fitting": "Pipe fitting", "equipment": "Equipment"}

    def __init__(self, V=(), F=(), role="solid", meta=None, iso=None):
        super().__init__()
        self.V = np.asarray(V, float).reshape(-1, 3); self.F = np.asarray(F, np.int64).reshape(-1, 3)
        self.role = role; self.meta = dict(meta or {}); self.iso = iso   # iso: list of Nx3 isolines for surfaces

    @property
    def label(self):
        return Body.LABELS.get(self.role, "Body")

    def to_dict(self):
        import base64
        d = self.base_dict()
        d.update(role=self.role, meta=_jsonable(self.meta),
                 V=base64.b64encode(self.V.astype("<f8").tobytes()).decode(),
                 F=base64.b64encode(self.F.astype("<i4").tobytes()).decode(),
                 iso=None if self.iso is None else [arr(i) for i in self.iso])
        return d

    @classmethod
    def from_dict(cls, d):
        import base64
        V = np.frombuffer(base64.b64decode(d["V"]), "<f8").reshape(-1, 3) if isinstance(d["V"], str) else d["V"]
        F = np.frombuffer(base64.b64decode(d["F"]), "<i4").reshape(-1, 3) if isinstance(d["F"], str) else d["F"]
        e = cls(V.copy(), F.astype(np.int64), d.get("role", "solid"), d.get("meta"), d.get("iso")); e.load_base(d)
        if e.iso is not None:
            e.iso = [np.asarray(i, float) for i in e.iso]
        return e

    def tris(self):
        return self.V, self.F

    def normals(self):
        def mk():
            a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
            fn = cross(b - a, c - a)
            ln = np.linalg.norm(fn, axis=1, keepdims=True); ln[ln == 0] = 1
            return fn / ln
        return self.cached("fn", mk)

    def edges(self, ang=25.0):
        """Feature edges (crease > ang deg) + boundary edges as (K,2,3) array."""
        def mk():
            F = self.F
            if len(F) == 0:
                return np.zeros((0, 2, 3))
            fn = self.normals()
            e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
            fi = np.tile(np.arange(len(F)), 3)
            # merge coincident vertices for topology
            key = np.round(self.V / max(1e-9, self.scale() * 1e-9)).astype(np.int64)
            _, inv = np.unique(key, axis=0, return_inverse=True)
            inv = inv.ravel()
            ee = np.sort(inv[e], axis=1)
            order = np.lexsort((ee[:, 1], ee[:, 0]))
            ee, fi, e = ee[order], fi[order], e[order]
            same = np.all(ee[1:] == ee[:-1], axis=1)
            keep = []
            i = 0; n = len(ee)
            while i < n:
                j = i + 1
                while j < n and same[j - 1]:
                    j += 1
                if j - i == 1:
                    keep.append(i)
                else:
                    c = abs(float(np.dot(fn[fi[i]], fn[fi[i + 1]])))
                    if np.dot(fn[fi[i]], fn[fi[i + 1]]) < math.cos(math.radians(ang)) or j - i > 2:
                        keep.append(i)
                i = j
            k = np.array(keep, int)
            if not len(k):
                return np.zeros((0, 2, 3))
            return np.stack([self.V[e[k, 0]], self.V[e[k, 1]]], axis=1)
        return self.cached("edges", mk)

    def scale(self):
        if len(self.V) == 0:
            return 1.0
        return max(1e-6, float(np.max(self.V.max(axis=0) - self.V.min(axis=0))))

    def wire(self):
        def mk():
            E = self.edges()
            out = [E[i] for i in range(len(E))]
            if self.iso is not None:
                out += list(self.iso)
            return out
        return self.cached("wire", mk)

    def prims(self):
        return self.cached("prims", lambda: [("L", e[0], e[1]) for e in self.edges()])

    def snaps(self):
        def mk():
            E = self.edges()
            if not len(E):
                return {}
            P = E.reshape(-1, 3)
            P = np.unique(np.round(P, 9), axis=0)
            s = {"end": list(P[:4000]), "mid": list(((E[:, 0] + E[:, 1]) / 2)[:4000])}
            if self.role == "profile" and "path" in self.meta:
                s["node"] = [np.asarray(p) for p in self.meta["path"]]
            return s
        return self.cached("snaps", mk)

    def transform(self, M):
        self.V = xform_pt(M, self.V)
        if m_det(M) < 0:
            self.F = self.F[:, ::-1].copy()
        if self.iso is not None:
            self.iso = [xform_pt(M, i) for i in self.iso]
        if "plane" in self.meta:
            pl = Plane.from_dict(self.meta["plane"]).transformed(M)
            self.meta["plane"] = pl.to_dict()
        if "path" in self.meta:
            self.meta["path"] = arr(xform_pt(M, np.asarray(self.meta["path"], float)))
        self.touch()

    def volume(self):
        a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
        return float(np.einsum("ij,ij->i", a, cross(b, c)).sum() / 6.0)

    def centroid(self):
        a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
        v = np.einsum("ij,ij->i", a, cross(b, c)) / 6.0
        V = v.sum()
        if abs(V) < 1e-18:
            return self.V.mean(axis=0) if len(self.V) else np.zeros(3)
        return ((a + b + c) / 4 * v[:, None]).sum(axis=0) / V

    def area(self):
        a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
        return float(np.linalg.norm(cross(b - a, c - a), axis=1).sum() / 2)

    def info(self):
        r = [("Type", self.label), ("Triangles", len(self.F))]
        if self.role in ("solid", "plate", "profile", "mesh"):
            r += [("Volume", abs(self.volume())), ("Centroid", self.centroid())]
        r.append(("Surface area", self.area()))
        m = self.meta
        if self.role == "plate":
            r += [("Mark", m.get("mark", "")), ("Thickness", m.get("thk")), ("Grade", m.get("grade")),
                  ("Plate area (one side)", m.get("area", 0))]
        if self.role == "profile":
            r += [("Mark", m.get("mark", "")), ("Profile", m.get("size")), ("Grade", m.get("grade")), ("Length", m.get("length"))]
        if self.role in ("pipe", "fitting", "equipment"):
            r += [("Item", m.get("ftype", "")), ("Size", m.get("size", ""))] + ([("Length", m["length"])] if "length" in m else [])
        return r

    def props(self):
        r = []
        if self.role in ("plate", "profile"):
            r.append(("Mark", self.meta.get("mark", ""), lambda v: self._meta("mark", str(v))))
            r.append(("Grade", self.meta.get("grade", ""), lambda v: self._meta("grade", str(v))))
        return r

    def _meta(self, k, v):
        self.meta[k] = v; self.touch()


# ===================================================================================================== IMAGE UNDERLAY
@register
class ImageE(Entity):
    """Raster underlay: origin o (lower-left), u = full width vector, v = full height vector."""
    kind = "image"; label = "Raster image"
    frame_mode = 1          # IMAGEFRAME: 0 = no frame (images cannot be picked), 1 = frame shown and plotted, 2 = shown, not plotted

    def __init__(self, data=b"", o=(0, 0, 0), u=(100, 0, 0), v=(0, 100, 0), wpx=1, hpx=1, name="image"):
        super().__init__(); self.data = data; self.o = v3(o); self.u = v3(u); self.v = v3(v)
        self.wpx = int(wpx); self.hpx = int(hpx); self.name = name; self.fade = 0.25; self.show_frame = True
        self.brightness = 0.0; self.contrast = 0.0          # -100 .. +100

    def to_dict(self):
        import base64
        d = self.base_dict(); d.update(data=base64.b64encode(self.data).decode(), o=arr(self.o), u=arr(self.u), v=arr(self.v),
                                       wpx=self.wpx, hpx=self.hpx, name=self.name, fade=self.fade, frame=self.show_frame,
                                       bright=self.brightness, contrast=self.contrast)
        return d

    @classmethod
    def from_dict(cls, d):
        import base64
        e = cls(base64.b64decode(d["data"]), d["o"], d["u"], d["v"], d["wpx"], d["hpx"], d.get("name", "image"))
        e.fade = d.get("fade", 0.25); e.show_frame = d.get("frame", True)
        e.brightness = float(d.get("bright", 0.0)); e.contrast = float(d.get("contrast", 0.0)); e.load_base(d); return e

    def corners(self):
        o, u, v = self.o, self.u, self.v
        return np.array([o, o + u, o + u + v, o + v])

    def wire(self):
        return self.cached("wire", lambda: [np.vstack([self.corners(), self.corners()[:1]])] if self.show_frame else [])

    def bbox(self):
        c = self.corners(); return c.min(axis=0), c.max(axis=0)

    def prims(self):
        c = self.corners()
        return [("L", c[i], c[(i + 1) % 4]) for i in range(4)]

    def snaps(self):
        return {"end": list(self.corners())}

    def pixel_to_world(self, px, py):
        """Pixel (x right, y down) -> world point."""
        return self.o + self.u * (px / self.wpx) + self.v * (1 - py / self.hpx)

    def world_to_pixel(self, p):
        pl = Plane(self.o, self.u, self.v)
        q = pl.to_local(p)
        return q[..., 0] / norm(self.u) * self.wpx, (1 - q[..., 1] / norm(self.v)) * self.hpx

    def transform(self, M):
        p0 = xform_pt(M, self.o); pu = xform_pt(M, self.o + self.u); pv = xform_pt(M, self.o + self.v)
        self.o, self.u, self.v = p0, pu - p0, pv - p0; self.touch()

    def info(self):
        return [("Image", self.name), ("Pixels", f"{self.wpx} x {self.hpx}"), ("Width", norm(self.u)), ("Height", norm(self.v)),
                ("Pixel size", norm(self.u) / max(1, self.wpx)), ("Fade", self.fade)]

    def props(self):
        return [("Brightness (-100..100)", self.brightness, self._setbright), ("Contrast (-100..100)", self.contrast, self._setcontrast),
                ("Fade (0-0.97)", self.fade, self._setfade), ("Frame (1/0)", 1 if self.show_frame else 0, self._setframe)]

    def _setbright(self, v):
        self.brightness = min(100.0, max(-100.0, float(v))); self.touch()

    def _setcontrast(self, v):
        self.contrast = min(100.0, max(-100.0, float(v))); self.touch()

    def _setfade(self, v):
        self.fade = min(0.97, max(0.0, float(v))); self.touch()

    def _setframe(self, v):
        self.show_frame = bool(round(v)); self.touch()


# ===================================================================================================== TABLE (BOM)
@register
class Table(Entity):
    """Table with annotative sizes (paper mm x drawing scale). Origin = top-left corner."""
    kind = "table"; label = "Table"

    @staticmethod
    def fit_widths(rows, mins, th=2.5, maxw=None):
        """Column widths (paper mm) wide enough for the longest cell of each column."""
        out = []
        for c, m in enumerate(mins):
            need = max((Entity.measure(r[c]) for r in rows if c < len(r)), default=0) * th + 1.6 * th
            w = max(float(m), round(need + 0.49))
            if maxw and c < len(maxw) and maxw[c]:
                w = min(w, maxw[c])
            out.append(w)
        return out

    def __init__(self, p=(0, 0, 0), rows=(), widths=(), title="", th=2.5, rh=7.0, xdir=(1, 0, 0), n=(0, 0, 1)):
        super().__init__(); self.p = v3(p); self.rows = [list(map(str, r)) for r in rows]; self.widths = [float(w) for w in widths]
        self.title = title; self.th = float(th); self.rh = float(rh); self.xdir = unit(v3(xdir)); self.n = unit(v3(n)); self.anno = True
        self.aligns = []

    def k(self):
        return Entity.anno_scale if self.anno else 1.0

    def to_dict(self):
        d = self.base_dict(); d.update(p=arr(self.p), rows=self.rows, widths=self.widths, title=self.title, th=self.th, rh=self.rh,
                                       xdir=arr(self.xdir), n=arr(self.n), anno=self.anno, aligns=self.aligns)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"], d["rows"], d["widths"], d.get("title", ""), d["th"], d["rh"], d["xdir"], d["n"])
        e.anno = d.get("anno", True); e.aligns = d.get("aligns", []); e.load_base(d); return e

    def parts(self):
        def mk():
            k = self.k(); x = self.xdir; y = cross(self.n, x); rh = self.rh * k; th = self.th * k
            W = sum(self.widths) * k
            lines = []; texts = []
            yy = 0.0
            if self.title:
                texts.append(Text(self.p + x * W / 2 - y * rh * 0.6, self.title, th * 1.4, x, self.n, 1, 2))
                lines.append(np.array([self.p, self.p + x * W]))
                yy = rh * 1.2
            nrow = len(self.rows)
            for r in range(nrow + 1):
                o = self.p - y * (yy + r * rh)
                lines.append(np.array([o, o + x * W]))
            xs = np.concatenate([[0], np.cumsum(self.widths)]) * k
            bot = self.p - y * (yy + nrow * rh)
            for i, cx in enumerate(xs):          # inner column lines stop below the title row
                top = self.p if (i == 0 or i == len(xs) - 1) else self.p - y * yy
                lines.append(np.array([top + x * cx, bot + x * cx]))
            for r, row in enumerate(self.rows):
                for c, cell in enumerate(row[:len(self.widths)]):
                    al = self.aligns[c] if c < len(self.aligns) else (1 if r == 0 else 0)
                    if r == 0:
                        al = 1
                    cx0, cx1 = xs[c], xs[c + 1]
                    px = cx0 + 0.25 * th * 2 if al == 0 else ((cx0 + cx1) / 2 if al == 1 else cx1 - 0.5 * th)
                    pos = self.p + x * px - y * (yy + (r + 0.5) * rh)
                    room = (cx1 - cx0) - 1.0 * th; need = Entity.measure(cell) * th
                    wf = 1.0 if need <= room or need <= 0 else max(0.45, room / need)     # squeeze over-long cells
                    t = Text(pos, cell, th, x, self.n, al, 2, wf=wf)
                    texts.append(t)
            return lines, texts
        return self.cached("parts", mk)

    def wire(self):
        return self.cached("wire", lambda: list(self.parts()[0]))

    def tris(self):
        def mk():
            V, F, off = [], [], 0
            for t in self.parts()[1]:
                tt = t.tris()
                if tt is not None and len(tt[0]):
                    V.append(tt[0]); F.append(tt[1] + off); off += len(tt[0])
            return (np.vstack(V), np.vstack(F)) if V else None
        return self.cached("tris", mk)

    def snaps(self):
        L = self.parts()[0]
        return {"end": [L[0][0], L[0][1]]} if L else {}

    def transform(self, M):
        self.p = xform_pt(M, self.p); self.xdir = unit(xform_vec(M, self.xdir)); self.n = unit(xform_vec(M, self.n))
        if not self.anno:
            sf = m_scale_factor(M); self.th *= sf; self.rh *= sf; self.widths = [w * sf for w in self.widths]
        self.touch()

    def explode(self):
        L, T = self.parts()
        return [Line(l[0], l[1]) for l in L] + [Text(t.p, t.s, t.h, t.xdir, t.n, t.halign, t.valign, wf=t.wf) for t in T]

    def info(self):
        return [("Rows", len(self.rows)), ("Columns", len(self.widths)), ("Title", self.title)]


def _jsonable(o):
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    return o


def from_dict(d):
    return REGISTRY[d["kind"]].from_dict(d)


XLINE_HALF = 1.0e7        # construction lines are drawn this far to each side (10 km in mm)


def make_xline(p, d, ray=False):
    """Construction line through p along d (ray: starts at p). A very long Line flagged xd["inf"], so that every edit
    command (TRIM, OFFSET, snaps ...) works on it; zoom extents and automatic scale ignore it."""
    p = v3(p); d = unit(v3(d))
    e = Line(p if ray else p - d * XLINE_HALF, p + d * XLINE_HALF)
    e.xd = dict(e.xd or {}); e.xd["inf"] = "ray" if ray else "xline"
    return e
