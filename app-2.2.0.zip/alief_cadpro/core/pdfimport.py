"""PDF import with PDFium (pypdfium2, Apache-2.0 / BSD): vector paths -> lines / polylines, text -> text,
fills -> solid hatch, embedded images or the whole rendered page -> raster underlay. Loaded only when used."""
import ctypes
import math
import numpy as np
from . import entities as E
from .geom import norm

PT_MM = 25.4 / 72.0


def _qimage_png(arr):
    from PySide6.QtGui import QImage
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice
    a = np.ascontiguousarray(arr)
    h, w = a.shape[:2]
    fmt = QImage.Format_RGB888 if a.shape[2] == 3 else QImage.Format_RGBA8888
    img = QImage(a.data, w, h, a.strides[0], fmt).copy()
    ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly); img.save(buf, "PNG")
    return bytes(ba), w, h


def page_count(path):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    n = len(pdf); pdf.close()
    return n


def page_thumb(path, i, width=220):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path); pg = pdf[i]
    W, H = pg.get_size()
    bm = pg.render(scale=width / W, rev_byteorder=True)
    png = _qimage_png(bm.to_numpy())[0]
    pdf.close()
    return png, (W * PT_MM, H * PT_MM)


def _mat(obj):
    import pypdfium2.raw as R
    m = R.FS_MATRIX()
    R.FPDFPageObj_GetMatrix(obj, ctypes.byref(m))
    return np.array([[m.a, m.c, m.e], [m.b, m.d, m.f], [0, 0, 1.0]])


def _color(fn, obj):
    r, g, b, a = (ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint())
    if not fn(obj, ctypes.byref(r), ctypes.byref(g), ctypes.byref(b), ctypes.byref(a)):
        return None
    if a.value == 0:
        return None
    if r.value < 40 and g.value < 40 and b.value < 40:
        return 7
    if r.value > 235 and g.value > 235 and b.value > 235:
        return "#ffffff"
    return "#%02x%02x%02x" % (r.value, g.value, b.value)


def _in_poly(Q, poly):
    """Even-odd point-in-polygon test for many points: Q (n,2), poly (m,2) -> bool (n,)."""
    Q = np.asarray(Q, float).reshape(-1, 2); x = Q[:, 0][:, None]; y = Q[:, 1][:, None]
    xi = poly[:, 0][None]; yi = poly[:, 1][None]; xj = np.roll(poly[:, 0], 1)[None]; yj = np.roll(poly[:, 1], 1)[None]
    with np.errstate(divide="ignore", invalid="ignore"):
        c = ((yi > y) != (yj > y)) & (x < (xj - xi) * (y - yi) / (yj - yi + 1e-300) + xi)
    return (np.count_nonzero(c, axis=1) % 2) == 1


def clip_polyline(P, closed, poly, keep_inside):
    """Parts of the polyline P (n,3) inside / outside the polygon poly (m,2).  Returns None when P is kept unchanged,
    else a list of (points, closed) pieces (empty = nothing left)."""
    P = np.asarray(P, float)
    if closed:
        P = np.vstack([P, P[:1]])
    A = P[:-1]; B = P[1:]; n = len(A)
    if n == 0:
        return None
    E0 = poly; E1 = np.roll(poly, -1, axis=0); d = (B - A)[:, :2]; e = E1 - E0
    den = d[:, None, 0] * e[None, :, 1] - d[:, None, 1] * e[None, :, 0]
    w = E0[None] - A[:, None, :2]
    with np.errstate(divide="ignore", invalid="ignore"):
        t = (w[..., 0] * e[None, :, 1] - w[..., 1] * e[None, :, 0]) / den
        u = (w[..., 0] * d[:, None, 1] - w[..., 1] * d[:, None, 0]) / den
    hit = (np.abs(den) > 1e-300) & (t > 1e-9) & (t < 1 - 1e-9) & (u >= 0) & (u <= 1)
    has = hit.any(axis=1)
    mid_in = _in_poly((A[:, :2] + B[:, :2]) / 2, poly)
    if not has.any():
        if bool(np.all(mid_in == keep_inside)):
            return None
        if bool(np.all(mid_in != keep_inside)):
            return []
    out = []; cur = []
    def flush():
        if len(cur) >= 2:
            out.append(np.array(cur))
        cur.clear()
    for i in range(n):
        if not has[i]:
            if mid_in[i] == keep_inside:
                if not cur:
                    cur.append(A[i])
                cur.append(B[i])
            else:
                flush()
            continue
        ts = [0.0] + sorted(float(x) for x in t[i][hit[i]]) + [1.0]
        for a, b in zip(ts[:-1], ts[1:]):
            if b - a < 1e-12:
                continue
            m = A[i] + (B[i] - A[i]) * ((a + b) / 2)
            if bool(_in_poly(m[:2], poly)[0]) == keep_inside:
                pa = A[i] + (B[i] - A[i]) * a; pb = A[i] + (B[i] - A[i]) * b
                if cur and float(np.abs(cur[-1] - pa).max()) > 1e-9 * max(1.0, float(np.abs(pa).max())):
                    flush()
                if not cur:
                    cur.append(pa)
                cur.append(pb)
            else:
                flush()
    flush()
    if closed and len(out) >= 2 and float(np.abs(out[0][0] - out[-1][-1]).max()) < 1e-9 * max(1.0, float(np.abs(out[0][0]).max())):
        out[0] = np.vstack([out[-1], out[0][1:]]); out.pop()
    return [(q, False) for q in out]


def clean_text(s):
    """Text of a PDF without the characters no font can show (control codes, private-use glyph numbers of fonts without
    a Unicode table, replacement marks): those came out as small boxes and stray dashes."""
    import unicodedata
    out = []
    for ch in s:
        cat = unicodedata.category(ch)
        if ch in "\t\u00a0" or cat == "Zs":
            out.append(" ")
        elif cat in ("Cc", "Cf", "Co", "Cn", "Cs") or ch == "\ufffd":
            continue
        else:
            out.append(ch)
    return " ".join("".join(out).split())


def merge_fills(items, tol):
    """Filled shapes of one colour -> the areas they cover together.  A solid hatch is written to a PDF as hundreds of
    thin strips or triangles: joined here into the original area.  items: [(list of (n,2) loops, even_odd)].
    Returns [[outer loop, hole loops ...], ...]."""
    import manifold3d as m3
    simple = []; parts = []
    for loops, eo in items:
        loops = [np.asarray(l, float) for l in loops if len(l) >= 3]
        if not loops:
            continue
        if len(loops) == 1:
            l = loops[0]; x = l[:, 0]; y = l[:, 1]
            a2 = float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
            simple.append(l if a2 >= 0 else l[::-1])
        else:
            parts.append(m3.CrossSection(loops, m3.FillRule.EvenOdd if eo else m3.FillRule.NonZero))
    if simple:
        parts.insert(0, m3.CrossSection(simple, m3.FillRule.NonZero))
    if not parts:
        return []
    cs = parts[0] if len(parts) == 1 else m3.CrossSection.batch_boolean(parts, m3.OpType.Add)
    if tol > 0:                                            # close the hairline gaps between the strips
        cs = cs.offset(tol, m3.JoinType.Miter, 2.0).offset(-tol, m3.JoinType.Miter, 2.0).simplify(tol * 0.25)
    res = []
    for comp in cs.decompose():
        polys = [np.asarray(q, float) for q in comp.to_polygons()]
        polys = [q for q in polys if len(q) >= 3]
        if not polys:
            continue
        ar = [abs(float(np.dot(q[:, 0], np.roll(q[:, 1], -1)) - np.dot(q[:, 1], np.roll(q[:, 0], -1)))) for q in polys]
        k = int(np.argmax(ar))
        res.append([polys[k]] + [q for i, q in enumerate(polys) if i != k])
    return res


def import_pdf(path, page=0, scale=1.0, origin=(0, 0, 0), vectors=True, texts=True, fills=False, images=True,
               raster_page=False, dpi=200, layer_prefix="PDF", join=True, progress=None, cancel=None):
    """Return list of entities. scale = model units per paper mm (e.g. 100 for a 1:100 drawing in mm).
    progress(fraction, text) is called now and then; cancel() -> True stops the import (raises KeyboardInterrupt)."""
    import pypdfium2 as pdfium
    import pypdfium2.raw as R
    out = []
    o = np.asarray(origin, float)
    pdf = pdfium.PdfDocument(path)
    pg = pdf[page]
    Wp, Hp = pg.get_size()
    k = PT_MM * scale
    if raster_page:
        bm = pg.render(scale=dpi / 72.0, rev_byteorder=True)
        png, w, h = _qimage_png(bm.to_numpy())
        img = E.ImageE(png, o, (Wp * k, 0, 0), (0, Hp * k, 0), w, h, f"page {page + 1}")
        img.layer = layer_prefix + "_IMAGE"; out.append(img)
    tp = pg.get_textpage() if texts else None
    lw_thick = 0.45
    runs = []
    fx, fy = ctypes.c_float(), ctypes.c_float()
    fm, st = ctypes.c_int(), ctypes.c_int()
    wd = ctypes.c_float()
    l_, b_, r_, t_ = ctypes.c_float(), ctypes.c_float(), ctypes.c_float(), ctypes.c_float()
    SEG_MOVE, SEG_LINE, SEG_BEZ = R.FPDF_SEGMENT_MOVETO, R.FPDF_SEGMENT_LINETO, R.FPDF_SEGMENT_BEZIERTO
    counter = [0]
    nobj = R.FPDFPage_CountObjects(pg.raw)
    GetSeg, GetPt, GetTyp, GetCl = R.FPDFPath_GetPathSegment, R.FPDFPathSegment_GetPoint, R.FPDFPathSegment_GetType, R.FPDFPathSegment_GetClose
    ObjType, Count = R.FPDFPageObj_GetType, R.FPDFPath_CountSegments
    T_FORM, T_PATH, T_TEXT, T_IMAGE = R.FPDF_PAGEOBJ_FORM, R.FPDF_PAGEOBJ_PATH, R.FPDF_PAGEOBJ_TEXT, R.FPDF_PAGEOBJ_IMAGE
    bx, by = ctypes.byref(fx), ctypes.byref(fy)
    ox, oy, oz = float(o[0]), float(o[1]), float(o[2])

    def tick():
        counter[0] += 1
        if counter[0] % 2000 == 0:
            if cancel is not None and cancel():
                raise KeyboardInterrupt("cancelled")
            if progress is not None:
                progress(min(0.9, counter[0] / max(1, nobj) * 0.85), f"{counter[0]:,} PDF objects read")

    masks = []; fill_items = {}
    page_box = (ox, oy, ox + Wp * k, oy + Hp * k)

    def clip_of(obj, M):
        """Clip polygon (n,2) of a page object in drawing units, or None (no clip / the whole page / not a simple area)."""
        try:
            cp = R.FPDFPageObj_GetClipPath(obj)
            if not cp or R.FPDFClipPath_CountPaths(cp) != 1:
                return None
            ns = R.FPDFClipPath_CountPathSegments(cp, 0)
            if ns < 3 or ns > 64:
                return None
            key = []
            for j in range(ns):
                sg = R.FPDFClipPath_GetPathSegment(cp, 0, j)
                if R.FPDFPathSegment_GetType(sg) == SEG_BEZ:
                    return None
                GetPt(sg, bx, by); key.append((fx.value, fy.value))
            key = tuple(key); hit = clip_cache.get((key, M.tobytes()))
            if hit is not None:
                return hit if len(hit) else None
            q = np.array([(ox + (M[0, 0] * x + M[0, 1] * y + M[0, 2]) * k, oy + (M[1, 0] * x + M[1, 1] * y + M[1, 2]) * k) for x, y in key])
            if float(np.abs(q[0] - q[-1]).max()) < 1e-9 * max(1.0, k):
                q = q[:-1]
            eps = 0.5 * k
            whole = (q[:, 0].min() <= page_box[0] + eps and q[:, 1].min() <= page_box[1] + eps and q[:, 0].max() >= page_box[2] - eps
                     and q[:, 1].max() >= page_box[3] - eps)
            res = np.zeros((0, 2)) if (whole or len(q) < 3) else q
            clip_cache[(key, M.tobytes())] = res
            return res if len(res) else None
        except Exception:
            return None
    clip_cache = {}

    def emit_path(obj, Mo, clip=None):
        R.FPDFPath_GetDrawMode(obj, ctypes.byref(fm), ctypes.byref(st))
        col = _color(R.FPDFPageObj_GetStrokeColor, obj) or 7
        fcol = _color(R.FPDFPageObj_GetFillColor, obj)
        R.FPDFPageObj_GetStrokeWidth(obj, ctypes.byref(wd))
        n = Count(obj)
        if not n:
            return
        # raw segment list first (one pass of ctypes calls), then the transform
        typ = [0] * n; cl = [False] * n; P = [None] * n
        a, b_, c, d, e_, f = Mo[0, 0], Mo[0, 1], Mo[0, 2], Mo[1, 0], Mo[1, 1], Mo[1, 2]
        for i in range(n):
            sg = GetSeg(obj, i)
            GetPt(sg, bx, by)
            x = fx.value; y = fy.value
            P[i] = np.array((ox + (a * x + b_ * y + c) * k, oy + (d * x + e_ * y + f) * k, oz))
            typ[i] = GetTyp(sg); cl[i] = GetCl(sg)
        polys = []; cur = []; i = 0
        while i < n:
            t = typ[i]
            if t == SEG_MOVE:
                if len(cur) >= 2:
                    polys.append((cur, False))
                cur = [P[i]]
            elif t == SEG_LINE:
                cur.append(P[i])
            elif t == SEG_BEZ and i + 2 < n:
                p0 = cur[-1] if cur else P[i]; c1, c2, p3 = P[i], P[i + 1], P[i + 2]
                size = norm(c1 - p0) + norm(c2 - c1) + norm(p3 - c2)
                m = int(min(16, max(2, size / max(k, 1e-12) / 1.5)))         # about one segment per 1.5 mm of curve on paper
                u = np.linspace(0, 1, m + 1)[1:, None]
                cur.extend(list((1 - u) ** 3 * p0 + 3 * (1 - u) ** 2 * u * c1 + 3 * (1 - u) * u * u * c2 + u ** 3 * p3))
                i += 2
                if cl[i] and len(cur) >= 2:
                    polys.append((cur, True)); cur = [cur[0]]
                i += 1
                continue
            if cl[i] and len(cur) >= 2:
                polys.append((cur, True)); cur = [cur[0]]
            i += 1
        if len(cur) >= 2:
            polys.append((cur, False))
        thick = wd.value * math.sqrt(abs(Mo[0, 0] * Mo[1, 1] - Mo[0, 1] * Mo[1, 0])) * PT_MM >= lw_thick
        norm_polys = []
        for pp, closed in polys:
            pp = np.asarray(pp)
            if len(pp) >= 2 and norm(pp[0] - pp[-1]) < 1e-9 * max(1, k):
                closed = True; pp = pp[:-1]
            norm_polys.append((pp, closed))
        if clip is not None:                               # the PDF shows only what is inside the clip area (viewport)
            cl2 = []
            for pp, closed in norm_polys:
                r = clip_polyline(pp, closed, clip, True)
                cl2 += [(pp, closed)] if r is None else r
            if fm.value and len(cl2) != len(norm_polys):
                fm.value = 0 if not st.value else fm.value
            norm_polys = cl2
        if fm.value:
            area_loops = [pp[:, :2] for pp, closed in norm_polys if len(pp) >= 3]      # a filled path is closed by definition
            if area_loops and fcol == "#ffffff":
                # a white area (wipeout, background mask, table background) hides what was drawn before it
                for l in area_loops:
                    masks.append((len(out), len(runs), l))
            elif area_loops and fcol is not None:
                fill_items.setdefault(fcol, []).append((area_loops, fm.value == 1))
        if not vectors or not st.value:
            return
        for pp, closed in norm_polys:
            if len(pp) < 2:
                continue
            e = E.Line(pp[0], pp[1]) if len(pp) == 2 and not closed else E.Polyline(pp, closed)
            e.color = col; e.layer = layer_prefix + "_GEOMETRY"
            if thick:
                e.lw = 50
            out.append(e)

    def walk(obj, M):
        tick()
        t = ObjType(obj)
        Mo = M @ _mat(obj)
        if t == T_FORM:
            for i in range(R.FPDFFormObj_CountObjects(obj)):
                walk(R.FPDFFormObj_GetObject(obj, i), Mo)
            return
        if t == T_PATH and (vectors or fills):
            emit_path(obj, Mo, clip_of(obj, M))
        elif t == T_TEXT and tp is not None:
            nch = R.FPDFTextObj_GetText(obj, tp.raw, None, 0)
            if nch <= 2:
                return
            buf = ctypes.create_string_buffer(nch * 2)
            R.FPDFTextObj_GetText(obj, tp.raw, ctypes.cast(buf, ctypes.POINTER(ctypes.c_ushort)), nch * 2)
            s_ = clean_text(buf.raw[:nch * 2 - 2].decode("utf-16-le", errors="ignore"))
            if not s_:
                return
            if not R.FPDFPageObj_GetBounds(obj, ctypes.byref(l_), ctypes.byref(b_), ctypes.byref(r_), ctypes.byref(t_)):
                return
            q = M @ np.array([[l_.value, r_.value], [b_.value, t_.value], [1.0, 1.0]])
            l, r = sorted(q[0]); b, tt = sorted(q[1])
            ang = math.atan2(Mo[1, 0], Mo[0, 0])
            cp_ = clip_of(obj, M)
            if cp_ is not None and not bool(_in_poly(np.array([ox + (l + r) / 2 * k, oy + (b + tt) / 2 * k]), cp_)[0]):
                return                                     # text outside the clip area is not shown by the PDF
            runs.append([l, b, r, tt, s_, ang])
        elif t == T_IMAGE and images and not raster_page:
            try:
                im = pdfium.PdfImage(obj, pg, pdf) if hasattr(pdfium, "PdfImage") else None
                bm = im.get_bitmap(render=True)
                arr_ = bm.to_numpy()
                png, w, h = _qimage_png(arr_[..., ::-1] if arr_.shape[2] == 3 else arr_)
                cpt = Mo @ np.array([[0, 1, 1, 0], [0, 0, 1, 1], [1, 1, 1, 1.0]])
                x0, y0 = cpt[0].min(), cpt[1].min(); x1, y1 = cpt[0].max(), cpt[1].max()
                img = E.ImageE(png, o + np.array([x0 * k, y0 * k, 0]), ((x1 - x0) * k, 0, 0), (0, (y1 - y0) * k, 0), w, h, "pdf image")
                img.layer = layer_prefix + "_IMAGE"; out.append(img)
            except Exception:
                pass

    try:
        for i in range(nobj):
            walk(R.FPDFPage_GetObject(pg.raw, i), np.eye(3))
        # ---- hidden parts: what a white area covers (and was drawn before it) is cut away
        if masks:
            if progress is not None:
                progress(0.86, f"{len(masks):,} masked areas")
            idx = [i for i, e in enumerate(out) if e.kind in ("line", "polyline")]
            if idx:
                bb = np.array([np.concatenate([(e.pts if e.kind == "polyline" else np.array([e.p0, e.p1]))[:, :2].min(axis=0),
                                               (e.pts if e.kind == "polyline" else np.array([e.p0, e.p1]))[:, :2].max(axis=0)]) for e in (out[i] for i in idx)])
                ia = np.array(idx)
                pieces = {}                                # index in out -> current list of entities
                for seq, rseq, poly in masks:
                    lo = poly.min(axis=0); hi = poly.max(axis=0)
                    if float((hi - lo).max()) < 0.2 * k:
                        continue
                    cand = ia[(ia < seq) & (bb[:, 2] >= lo[0]) & (bb[:, 0] <= hi[0]) & (bb[:, 3] >= lo[1]) & (bb[:, 1] <= hi[1])]
                    for i in cand:
                        cur = pieces.get(int(i), [out[i]]); new = []
                        for e in cur:
                            P_ = e.pts if e.kind == "polyline" else np.array([e.p0, e.p1]); cl_ = bool(getattr(e, "closed", False))
                            r = clip_polyline(P_, cl_, poly, False)
                            if r is None:
                                new.append(e); continue
                            for q, c2 in r:
                                ne = E.Line(q[0], q[1]) if len(q) == 2 else E.Polyline(q, c2)
                                ne.color, ne.layer, ne.lw = e.color, e.layer, e.lw; new.append(ne)
                        pieces[int(i)] = new
                    tick()
                if pieces:
                    out2 = []
                    for i, e in enumerate(out):
                        out2 += pieces.get(i, [e])
                    out[:] = out2
            keep_runs = []
            for ri, q in enumerate(runs):
                cx_, cy_ = ox + (q[0] + q[2]) / 2 * k, oy + (q[1] + q[3]) / 2 * k
                if any(rseq > ri and bool(_in_poly(np.array([cx_, cy_]), poly)[0]) for seq, rseq, poly in masks):
                    continue
                keep_runs.append(q)
            runs[:] = keep_runs
        # ---- filled areas: the strips / triangles of one colour joined into whole areas
        for fcol, items in fill_items.items():
            try:
                areas = merge_fills(items, 0.02 * k)
            except Exception:
                import traceback; traceback.print_exc(); areas = [[l] for loops, eo in items for l in loops]
            z3 = lambda l: np.column_stack([l, np.full(len(l), oz)])
            for loops in areas:
                if fills:
                    hh = E.Hatch([z3(l) for l in loops], (0, 0, 1), "SOLID"); hh.color = fcol; hh.layer = layer_prefix + "_FILL"; out.append(hh)
                elif vectors:
                    for l in loops:
                        e = E.Polyline(z3(l), True); e.color = fcol; e.layer = layer_prefix + "_OUTLINE"; out.append(e)
        if tp is not None:
            if not runs:                                   # PDFs without text objects in the page tree: read the text page instead
                for i in range(tp.count_rects()):
                    try:
                        l, b, r, t2 = tp.get_rect(i)
                        s_ = clean_text(tp.get_text_bounded(l, b, r, t2))
                    except Exception:
                        continue
                    if s_:
                        runs.append([l, b, r, t2, s_, 0.0])
            out += _text_runs(runs, o, k, scale, layer_prefix)
            tp.close()
    finally:
        pdf.close()
    if progress is not None:
        progress(0.92, f"{len(out):,} objects - joining line segments")
    if join:
        out = merge_segments(out)
    return out


def _text_runs(runs, o, k, scale, layer_prefix):
    """Merge text pieces that sit on one line into one text each."""
    out = []
    hor = [q for q in runs if abs(q[5]) < 0.3 or abs(abs(q[5]) - math.pi) < 0.3]
    other = [q for q in runs if q not in hor] if len(hor) != len(runs) else []
    hor.sort(key=lambda q: (round(q[1], 0), q[0]))
    merged = []
    for q in hor:
        if merged:
            m = merged[-1]; h = max(m[3] - m[1], q[3] - q[1])
            if abs(m[1] - q[1]) < 0.25 * h and -0.2 * h < q[0] - m[2] < 0.9 * h:
                gap = q[0] - m[2]
                m[4] += (" " if gap > 0.22 * h else "") + q[4]; m[2] = max(m[2], q[2]); m[3] = max(m[3], q[3]); continue
        merged.append(list(q))
    W = lambda x, y: o + np.array([x * k, y * k, 0.0])
    for l, b, r, t_, st, ang in merged:
        hh = t_ - b
        tx = E.Text(W(l, b + hh * 0.2), st, hh * 0.72 * PT_MM * scale, (1, 0, 0), (0, 0, 1), 0, 0)
        tx.color = 7; tx.layer = layer_prefix + "_TEXT"; out.append(tx)
    for l, b, r, t_, st, ang in other:
        hh = t_ - b; ww = r - l
        vertical = abs(abs(ang) - math.pi / 2) < 0.3
        if vertical:
            tx = E.Text(W(r - ww * 0.2, b), st, ww * 0.72 * PT_MM * scale, (0, 1, 0), (0, 0, 1), 0, 0)
        else:
            h0 = min(hh, ww) * 0.72
            tx = E.Text(W(l, b), st, h0 * PT_MM * scale, (math.cos(ang), math.sin(ang), 0), (0, 0, 1), 0, 0)
        tx.color = 7; tx.layer = layer_prefix + "_TEXT"; out.append(tx)
    return out


def merge_segments(ents, tol_rel=1e-6):
    """Chain PDF line segments that meet end to end (same colour / layer / weight, only two at a point) into polylines - O(n)."""
    lines = [e for e in ents if e.kind == "line"]
    others = [e for e in ents if e.kind != "line"]
    if len(lines) < 2:
        return ents
    span = 1.0
    try:
        P = np.array([[l.p0[0], l.p0[1]] for l in lines[:2000]])
        span = max(float(np.ptp(P, axis=0).max()), 1.0)
    except Exception:
        pass
    q = span * tol_rel
    key = lambda p: (round(float(p[0]) / q), round(float(p[1]) / q))
    groups = {}
    for l in lines:
        groups.setdefault((l.layer, str(l.color), l.lw), []).append(l)
    res = []
    for g, ls in groups.items():
        at = {}
        for i, l in enumerate(ls):
            at.setdefault(key(l.p0), []).append((i, 0)); at.setdefault(key(l.p1), []).append((i, 1))
        used = [False] * len(ls)
        def nxt(pk, i):
            c = at.get(pk, [])
            if len(c) != 2:
                return None
            for j, end in c:
                if j != i and not used[j]:
                    return j, end
            return None
        for i, l in enumerate(ls):
            if used[i]:
                continue
            used[i] = True
            chain = [l.p0.copy(), l.p1.copy()]
            # grow forward from p1
            cur, pk = i, key(l.p1)
            while True:
                r = nxt(pk, cur)
                if r is None:
                    break
                j, end = r; used[j] = True; m = ls[j]
                pnew = m.p1 if end == 0 else m.p0
                chain.append(pnew.copy()); cur, pk = j, key(pnew)
            # grow backward from p0
            cur, pk = i, key(l.p0)
            while True:
                r = nxt(pk, cur)
                if r is None:
                    break
                j, end = r; used[j] = True; m = ls[j]
                pnew = m.p1 if end == 0 else m.p0
                chain.insert(0, pnew.copy()); cur, pk = j, key(pnew)
            if len(chain) == 2:
                res.append(l); continue
            closed = key(chain[0]) == key(chain[-1])
            pl = E.Polyline(np.array(chain[:-1] if closed else chain), closed)
            pl.layer, pl.color, pl.lw = l.layer, l.color, l.lw
            res.append(pl)
    return others + res


def infer_dashes(ents, min_run=4):
    """Rows of short collinear segments with regular gaps (a dashed line drawn dash by dash in the PDF) become one line
    with the Dashed linetype and a matching linetype scale."""
    lines = [e for e in ents if e.kind == "line"]
    if len(lines) < min_run:
        return ents
    P0 = np.array([l.p0[:2] for l in lines]); P1 = np.array([l.p1[:2] for l in lines])
    D = P1 - P0; L = np.hypot(D[:, 0], D[:, 1]); ok = L > 1e-9
    ang = np.mod(np.arctan2(D[:, 1], D[:, 0]), math.pi)
    ang = np.where(ang > math.pi - 1e-4, 0.0, ang)
    nx, ny = -np.sin(ang), np.cos(ang)
    off = P0[:, 0] * nx + P0[:, 1] * ny
    span = max(float(np.ptp(np.vstack([P0, P1]), axis=0).max()), 1.0); q = span * 2e-6
    groups = {}
    for i in np.flatnonzero(ok):
        l = lines[i]
        groups.setdefault((int(round(ang[i] / 2e-3)), int(round(off[i] / q)), str(l.color), l.layer), []).append(i)
    drop = set(); new = []
    for key, idx in groups.items():
        if len(idx) < min_run:
            continue
        a = ang[idx[0]]; ux, uy = math.cos(a), math.sin(a)
        t0 = P0[idx, 0] * ux + P0[idx, 1] * uy; t1 = P1[idx, 0] * ux + P1[idx, 1] * uy
        lo = np.minimum(t0, t1); hi = np.maximum(t0, t1); order = np.argsort(lo)
        run = [order[0]]
        def flush(run):
            if len(run) < min_run:
                return
            ln = hi[run] - lo[run]; gp = lo[run[1:]] - hi[run[:-1]]
            if ln.max() > 3.0 * max(np.median(ln), 1e-12) or gp.min() <= 0:
                return
            first = lines[idx[run[0]]]; last = lines[idx[run[-1]]]
            a_pt = np.array([ux * lo[run[0]] - np.sin(a) * off[idx[run[0]]], uy * lo[run[0]] + np.cos(a) * off[idx[run[0]]], first.p0[2]])
            b_pt = np.array([ux * hi[run[-1]] - np.sin(a) * off[idx[run[0]]], uy * hi[run[-1]] + np.cos(a) * off[idx[run[0]]], first.p0[2]])
            e = E.Line(a_pt, b_pt); e.layer, e.color, e.lw = first.layer, first.color, first.lw
            per = float(np.median(ln) + np.median(gp)); e.ltype = "Dashed"; e.lts = max(per / 19.05, 1e-6)
            new.append(e); drop.update(idx[k] for k in run)
        for k in order[1:]:
            prev = run[-1]; gap = lo[k] - hi[prev]; l_prev = hi[prev] - lo[prev]; l_k = hi[k] - lo[k]
            if 0 < gap <= 2.5 * max(l_prev, l_k) and 0.4 <= l_k / max(l_prev, 1e-12) <= 2.5:
                run.append(k)
            else:
                flush(run); run = [k]
        flush(run)
    if not drop:
        return ents
    keep = {id(lines[i]) for i in drop}
    return [e for e in ents if id(e) not in keep] + new
