"""DXF import / export (ezdxf, loaded only when used), DWG via the free ODA File Converter, STL / OBJ export."""
import math
import os
import shutil
import subprocess
import tempfile
import numpy as np
from .geom import v3, unit, norm, arbitrary_x, Plane
from . import entities as E
from .document import Layer


def _color(e):
    try:
        if e.dxf.hasattr("true_color"):
            r, g, b = e.rgb
            return "#%02x%02x%02x" % (r, g, b)
    except Exception:
        pass
    return int(e.dxf.get("color", 256))


_CTX = {"lt": {}, "lay": {}, "styles": {}}     # of the file being imported: linetype length ratios, layer linetypes, text styles

SHX = ("txt", "simplex", "romans", "romand", "romanc", "romant", "italic", "italicc", "italict", "monotxt", "isocp", "isocp2", "isocp3",
       "isoct", "isoct2", "isoct3", "complex", "gothice", "gothicg", "gothici", "greekc", "greeks", "scriptc", "scripts", "symap",
       "symath", "symeteo", "symusic", "syastro", "bigfont", "gdt", "ltypeshp", "hztxt", "gbcbig", "gbenor", "gbeitc", "tssdeng")
TTF_FAMILY = {"arial": "Arial", "arialbd": "Arial", "ariali": "Arial", "arialn": "Arial Narrow", "ariblk": "Arial Black", "times": "Times New Roman",
              "timesbd": "Times New Roman", "cour": "Courier New", "calibri": "Calibri", "calibrib": "Calibri", "cambria": "Cambria",
              "tahoma": "Tahoma", "verdana": "Verdana", "consola": "Consolas", "segoeui": "Segoe UI", "swiss": "Swis721 BT",
              "isocpeur": "ISOCPEUR", "isocteur": "ISOCTEUR", "romans": "romans", "simplex": "simplex", "century": "Century",
              "gothic": "Century Gothic", "georgia": "Georgia", "trebuc": "Trebuchet MS", "comic": "Comic Sans MS"}


def _scan_file(d):
    """Linetype pattern lengths (against ours), layer linetypes and text style fonts of the DXF being read."""
    from .document import LINETYPES, BUILTIN_LT
    lt = {}; lay = {}; st = {}
    ltmap = {}; newlt = {}
    def shape(pat):
        a = np.abs(np.asarray(pat, float)); t = float(a.sum())
        return (a / t) if t > 0 else a
    try:
        for t in d.linetypes:
            n = t.dxf.name; un = n.upper()
            if un in ("BYLAYER", "BYBLOCK", "CONTINUOUS"):
                continue
            try:
                pat = [float(g.value) for g in t.pattern_tags.tags if g.code == 49]
                L = float(next((g.value for g in t.pattern_tags.tags if g.code == 40), 0.0) or 0.0)
            except Exception:
                pat = []; L = 0.0
            if not pat or L <= 0 or len(pat) < 2:
                ltmap[un] = "Continuous"; continue
            sh = shape(pat); hit = None
            cands = [k for k in LINETYPES if k.upper() == un.replace("ACAD_ISO", "").replace("_", "")] + list(LINETYPES)
            for k in cands:                                   # ours with the same dash proportions (any name: DASH, CENTRO ...)
                o = LINETYPES.get(k)
                if o and len(o) == len(pat) and float(np.abs(shape(o) - sh).max()) < 0.02 and all((x > 0) == (y > 0) or (x == 0 and y == 0) for x, y in zip(o, pat)):
                    hit = k; break
            if hit is not None:
                r = L / float(sum(abs(x) for x in LINETYPES[hit]))
                ltmap[un] = hit; lt[un] = 1.0 if abs(r - 1.0) < 0.03 else r
                if hit not in BUILTIN_LT:
                    newlt[hit] = list(LINETYPES[hit])
            else:                                             # a linetype we do not have: keep the definition of the file
                name = n if not any(k.upper() == un for k in LINETYPES) else n + "_DWG"
                tpat = tuple(float(x) for x in pat)
                LINETYPES[name] = tpat; newlt[name] = list(tpat); ltmap[un] = name
    except Exception:
        import traceback; traceback.print_exc()
    _CTX["ltmap"] = ltmap; _CTX["newlt"] = newlt
    try:
        for L in d.layers:
            lay[L.dxf.name] = (L.dxf.get("linetype", "Continuous") or "Continuous").upper()
    except Exception:
        pass
    try:
        for x in d.styles:
            fam = None
            try:
                fam = x.get_extended_font_data()[0] or None
            except Exception:
                fam = None
            f = (x.dxf.get("font", "") or "").strip(); base = f.rsplit(".", 1)[0].lower()
            if not fam:
                fam = TTF_FAMILY.get(base) or (base if (f.lower().endswith(".shx") or base in SHX or not f) and base else (base.title() if base else None))
            st[x.dxf.name] = (fam or "Arial", float(x.dxf.get("width", 1.0) or 1.0))
    except Exception:
        pass
    _CTX["lt"] = lt; _CTX["lay"] = lay; _CTX["styles"] = st


def _base(src, dst):
    dst.layer = src.dxf.get("layer", "0") or "0"
    dst.color = _color(src)
    lt = src.dxf.get("linetype", "BYLAYER")
    dst.ltype = "ByLayer" if lt.upper() == "BYLAYER" else _lt_name(lt)
    dst.lw = int(src.dxf.get("lineweight", -1)) if src.dxf.get("lineweight", -1) >= 0 else -1
    try:
        dst.lts = float(src.dxf.get("ltscale", 1.0) or 1.0)
        # the file's linetype may be defined with another pattern length than ours (inch / mm linetype files):
        # the object's linetype scale takes the difference, so the dashes look as in the original
        key = lt.upper() if lt.upper() not in ("BYLAYER", "BYBLOCK") else _CTX["lay"].get(dst.layer, "")
        r = _CTX["lt"].get(key, 1.0)
        if r != 1.0:
            dst.lts *= r
    except Exception:
        pass
    return dst


def _style(e, t):
    """Font and width factor of the entity's text style."""
    try:
        fam, wf = _CTX["styles"].get(e.dxf.get("style", "Standard"), (None, 1.0))
        if fam:
            t.font = fam
        return wf
    except Exception:
        return 1.0


def _lt_name(n):
    from .document import LINETYPES
    m = (_CTX.get("ltmap") or {}).get(str(n).upper())
    if m:
        return m
    u = n.upper().replace("ACAD_ISO", "").replace("_", "")
    for k in LINETYPES:                                   # exact names first (DASHED2, CENTERX2 ...)
        if k.upper() == u:
            return k
    for k in ("DASHDOT", "DASHED", "HIDDEN", "CENTER", "PHANTOM", "DIVIDE", "BORDER", "DOT"):
        if k in u:
            return {"DASHDOT": "DashDot", "DASHED": "Dashed", "HIDDEN": "Hidden", "CENTER": "Center", "PHANTOM": "Phantom", "DOT": "Dot",
                    "DIVIDE": "Divide", "BORDER": "Border"}[k]
    return "Continuous"


def convert_entity(e, warn):
    """ezdxf entity -> list of our entities."""
    t = e.dxftype()
    ext = v3(e.dxf.get("extrusion", (0, 0, 1))) if e.dxf.hasattr("extrusion") else np.array([0, 0, 1.0])
    try:
        if t == "LINE":
            return [_base(e, E.Line(e.dxf.start, e.dxf.end))]
        if t in ("XLINE", "RAY"):
            p = v3(e.dxf.start); d = v3(e.dxf.unit_vector)
            return [_base(e, E.make_xline(p, d, ray=(t == "RAY")))]
        if t == "POINT":
            return [_base(e, E.PointE(e.dxf.location))]
        if t == "CIRCLE":
            c = e.ocs().to_wcs(e.dxf.center)
            return [_base(e, E.Circle(c, e.dxf.radius, ext))]
        if t == "ARC":
            c = e.ocs().to_wcs(e.dxf.center)
            return [_base(e, E.Arc(c, e.dxf.radius, math.radians(e.dxf.start_angle), math.radians(e.dxf.end_angle), ext))]
        if t == "ELLIPSE":
            return [_base(e, E.Ellipse(e.dxf.center, e.dxf.major_axis, e.dxf.ratio, e.dxf.extrusion, e.dxf.start_param, e.dxf.end_param))]
        if t == "LWPOLYLINE":
            ocs = e.ocs(); elev = e.dxf.get("elevation", 0.0)
            pts = []; bul = []
            for x, y, s, ee, b in e.get_points("xyseb"):
                pts.append(ocs.to_wcs((x, y, elev))); bul.append(b)
            return [_base(e, E.Polyline(np.array(pts), e.closed, bul, ext))]
        if t == "POLYLINE":
            if e.is_polygon_mesh or e.is_poly_face_mesh:
                return _mesh_from(e)
            ocs = e.ocs()
            pts = []; bul = []
            for v in e.vertices:
                p = v.dxf.location
                pts.append(p if e.is_3d_polyline else ocs.to_wcs(p)); bul.append(v.dxf.get("bulge", 0.0))
            return [_base(e, E.Polyline(np.array(pts), e.is_closed, bul, ext, is3d=e.is_3d_polyline))]
        if t == "SPLINE":
            ctrl = np.array(e.control_points) if len(e.control_points) else None
            if ctrl is None or len(ctrl) < 2:
                fit = np.array(e.fit_points)
                return [_base(e, E.Spline.through(fit))]
            w = list(e.weights) if len(e.weights) else None
            return [_base(e, E.Spline(ctrl, list(e.knots), e.dxf.degree, w, None, e.closed))]
        if t in ("TEXT", "ATTRIB"):
            ha = {0: 0, 1: 1, 2: 2, 4: 1}.get(e.dxf.get("halign", 0), 0)
            va = e.dxf.get("valign", 0)
            p = e.dxf.align_point if (ha or va) and e.dxf.hasattr("align_point") else e.dxf.insert
            ocs = e.ocs(); p = ocs.to_wcs(p)
            rot = math.radians(e.dxf.get("rotation", 0))
            ax = arbitrary_x(ext); ay = np.cross(ext, ax)
            x = math.cos(rot) * ax + math.sin(rot) * ay
            tx = E.Text(p, e.dxf.text, e.dxf.get("height", 2.5), x, ext, ha, min(va, 3), wf=e.dxf.get("width", 1.0))
            _style(e, tx)
            return [_base(e, tx)]
        if t == "MTEXT":
            s = e.plain_text()
            ap = e.dxf.get("attachment_point", 1)
            ha = (ap - 1) % 3; va = {0: 3, 1: 2, 2: 1}[(ap - 1) // 3]
            x = v3(e.dxf.get("text_direction", (1, 0, 0)))
            if e.dxf.hasattr("rotation") and not e.dxf.hasattr("text_direction"):
                r = math.radians(e.dxf.rotation); x = np.array([math.cos(r), math.sin(r), 0])
            tx = E.Text(e.dxf.insert, s, e.dxf.get("char_height", 2.5), x, ext, ha, va)
            tx.width = e.dxf.get("width", 0.0)
            swf = _style(e, tx)
            if swf and abs(swf - 1.0) > 1e-6:
                tx.wf = swf
            try:
                raw = e.text                                  # keep the formatting codes (bold, colours, stacked text ...)
                from . import mtext as MT
                if MT.has_codes(raw.replace("\\P", "")):
                    tx.rich = raw; tx.s = MT.plain(raw)
                    ha_ = MT.dominant_abs(raw)                # \H<n>; inside the text overrides the height of the object
                    if ha_ and ha_ > 0 and abs(ha_ - tx.hm) > 1e-9 * max(ha_, tx.hm):
                        tx.hm = float(ha_)
                f = e.dxf.get("line_spacing_factor", 1.0)
                tx.lsf = float(f) if 0.25 <= float(f) <= 4.0 else 1.0
            except Exception:
                pass
            return [_base(e, tx)]
        if t in ("SOLID", "TRACE", "3DFACE"):
            pts = [v3(e.dxf.get(f"vtx{i}")) for i in range(4)]
            if t == "3DFACE":
                F = [[0, 1, 2]] + ([[0, 2, 3]] if norm(pts[3] - pts[2]) > 1e-12 else [])
                return [_base(e, E.Body(np.array(pts), np.array(F), "mesh"))]
            pts = [e.ocs().to_wcs(p) for p in pts]
            loop = [pts[0], pts[1], pts[3], pts[2]] if norm(pts[3] - pts[2]) > 1e-12 else pts[:3]
            return [_base(e, E.Hatch([np.array(loop)], ext, "SOLID"))]
        if t == "HATCH":
            loops = []
            for path in e.paths:
                try:
                    from ezdxf.path import from_hatch_boundary_path
                    pp = from_hatch_boundary_path(path, e.ocs(), e.dxf.elevation.z)
                    pts = np.array(list(pp.flattening(0.01 * max(1.0, 1.0))))
                except Exception:
                    continue
                if len(pts) >= 3:
                    loops.append(pts)
            if not loops:
                return []
            pname = (e.dxf.pattern_name or "ANSI31").upper(); pdef = None
            grad = None
            try:
                if e.has_gradient_data and e.gradient is not None and e.gradient.kind:
                    gd = e.gradient; nm = str(gd.name or "LINEAR").upper()
                    c1 = "#%02x%02x%02x" % tuple(gd.color1); c2 = "#%02x%02x%02x" % tuple(gd.color2)
                    grad = {"name": "SPHERICAL" if "SPHER" in nm else ("CYLINDER" if "CYL" in nm else "LINEAR"), "c1": c1, "c2": c2,
                            "angle": float(gd.rotation or 0.0)}
            except Exception:
                grad = None
            if e.dxf.solid_fill:
                pat = "SOLID"
            elif pname in E.HATCH_PATTERNS:
                pat = pname
            else:                                          # a pattern we do not know: take its definition from the file
                pat = pname
                try:
                    import math as _m
                    sc = float(e.dxf.get("pattern_scale", 1.0) or 1.0); an = _m.radians(float(e.dxf.get("pattern_angle", 0.0) or 0.0))
                    ca, sa = _m.cos(-an), _m.sin(-an); pdef = []
                    for ln in e.pattern.lines:             # stored scaled and rotated: back to the unit definition
                        a = float(ln.angle) - _m.degrees(an); bx, by = ln.base_point[0] / sc, ln.base_point[1] / sc
                        ox, oy = ln.offset[0] / sc, ln.offset[1] / sc
                        bx, by = bx * ca - by * sa, bx * sa + by * ca
                        t = _m.radians(a); ux, uy = _m.cos(t + an), _m.sin(t + an)
                        # DXF offsets are in world axes; PAT offsets along / across the line
                        dx = (ox * _m.cos(t + an) + oy * _m.sin(t + an)); dy = (-ox * _m.sin(t + an) + oy * _m.cos(t + an))
                        pdef.append((a, bx, by, dx, dy, tuple(float(x) / sc for x in ln.dash_length_items)))
                    if not pdef:
                        pat, pdef = "ANSI31", None
                except Exception:
                    pat, pdef = "ANSI31", None
            h = E.Hatch(loops, ext, pat, e.dxf.get("pattern_scale", 1.0), e.dxf.get("pattern_angle", 0.0)); h.pdef = pdef
            if grad and pat == "SOLID":
                h.grad = grad
            return [_base(e, h)]
        if t == "MESH":
            V = np.array(e.vertices); F = []
            for f in e.faces:
                f = list(f)
                for k in range(1, len(f) - 1):
                    F.append([f[0], f[k], f[k + 1]])
            return [_base(e, E.Body(V, np.array(F), "mesh"))]
        if t == "INSERT":
            M = np.array([list(r) for r in e.matrix44().rows()], float).T
            ins = _base(e, E.Insert(e.dxf.name, M))
            out = [ins]
            for a in e.attribs:
                out += convert_entity(a, warn)
            return out
        if t in ("DIMENSION", "LEADER", "MLEADER", "MULTILEADER", "ARC_DIMENSION", "ACAD_TABLE"):
            out = []
            for v in e.virtual_entities():
                out += convert_entity(v, warn)
            for o in out:
                if o.layer == "0":
                    o.layer = e.dxf.get("layer", "0")
            return out
        if t in ("3DSOLID", "BODY", "REGION", "SURFACE"):
            warn[t] = warn.get(t, 0) + 1
            return []
        warn[t] = warn.get(t, 0) + 1
    except Exception as ex:
        warn["error " + t] = warn.get("error " + t, 0) + 1
    return []


def _mesh_from(e):
    V = []; F = []
    try:
        from ezdxf.render import MeshBuilder
        mb = MeshBuilder.from_polyface(e)
        V = np.array(mb.vertices)
        for f in mb.faces:
            for k in range(1, len(f) - 1):
                F.append([f[0], f[k], f[k + 1]])
    except Exception:
        return []
    return [_base(e, E.Body(V, np.array(F), "mesh"))] if len(F) else []


def import_dxf(doc, path):
    import ezdxf
    from ezdxf import recover
    try:
        d = ezdxf.readfile(path)
    except Exception:
        d, auditor = recover.readfile(path)
    warn = {}
    _scan_file(d)
    for L in d.layers:
        n = L.dxf.name
        if n not in doc.layers:
            doc.layers[n] = Layer(n, abs(L.color) if L.color else 7, _lt_name(L.dxf.get("linetype", "Continuous")),
                                  L.dxf.get("lineweight", 25) if L.dxf.get("lineweight", 25) >= 0 else 25, on=L.color >= 0,
                                  frozen=L.is_frozen(), locked=L.is_locked())
            if L.rgb:
                doc.layers[n].color = "#%02x%02x%02x" % L.rgb
    emap = {}
    for b in d.blocks:
        if b.name.startswith("*") and not b.name.upper().startswith("*U"):
            continue
        if b.is_any_layout:
            continue
        ents = []; em = []
        for be in b:
            if be.dxf.get("invisible", 0):               # hidden by the visibility state of a dynamic block
                em.append((be.dxf.handle, [])); continue
            ce = convert_entity(be, warn)
            ents += ce; em.append((be.dxf.handle, ce))
        doc.blocks[b.name] = E.Block(b.name, b.block.dxf.base_point, ents)
        emap[b.name] = em
    E.Insert.blocks = doc.blocks
    try:                                                  # dynamic blocks of AutoCAD / ZWCAD: stretch grips keep working
        from . import dyndxf
        nd = dyndxf.attach(d, doc, emap)
        if nd:
            warn["_dynamic"] = nd
    except Exception:
        import traceback; traceback.print_exc()
    count = 0
    was_empty = not doc.ents
    if _CTX.get("newlt"):                                 # linetypes defined by the file are stored with the drawing
        doc.settings.setdefault("ltypes", {}).update(_CTX["newlt"])
    doc.begin("import")
    for e in d.modelspace():
        if e.dxf.get("invisible", 0):
            continue
        for o in convert_entity(e, warn):
            if o.layer not in doc.layers:
                doc.layers[o.layer] = Layer(o.layer)
            doc.add_keep(o); count += 1
    doc.end()
    try:
        if was_empty:                                     # opening a drawing: take its global linetype scale
            doc.settings["ltscale"] = float(d.header.get("$LTSCALE", 1.0) or 1.0)
    except Exception:
        pass
    units = d.header.get("$INSUNITS", 4)
    return count, warn, units


# ------------------------------------------------------------------------------------------------ export
def _aci_or_rgb(c):
    if isinstance(c, str) and c.startswith("#"):
        return {"true_color": int(c[1:], 16)}
    return {"color": int(c)}


def export_dxf(doc, path, ents=None, version="R2018"):
    import ezdxf
    from .document import LINETYPES, LT_DESC
    d = ezdxf.new(version, setup=True)
    msp = d.modelspace()
    # our linetype definitions (metric pattern lengths, like acadiso.lin) replace the inch patterns ezdxf sets up:
    # otherwise the dashes come out 25.4 times finer in AutoCAD and every linetype scale has to be redone
    for name, pat in LINETYPES.items():
        if not pat:
            continue
        un = name.upper()
        try:
            if un in d.linetypes:
                d.linetypes.remove(un)
            d.linetypes.add(un, pattern=[float(sum(abs(x) for x in pat))] + [float(x) for x in pat], description=LT_DESC.get(name, name))
        except Exception:
            pass
    d._acp_styles = {}
    for L in doc.layers.values():
        if L.name in d.layers:
            lay = d.layers.get(L.name)
        else:
            lay = d.layers.add(L.name)
        if isinstance(L.color, str):
            lay.rgb = tuple(int(L.color[i:i + 2], 16) for i in (1, 3, 5))
        else:
            lay.color = int(L.color)
        lt = (L.ltype or "Continuous").upper()
        if lt in d.linetypes:
            lay.dxf.linetype = lt
        lay.dxf.lineweight = int(L.lw) if L.lw in (0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211) else 25
        if not L.on:
            lay.off()
        if L.frozen:
            lay.freeze()
    for b in doc.blocks.values():
        if b.name in d.blocks:
            continue
        blk = d.blocks.new(b.name, base_point=tuple(b.base))
        for e in b.ents:
            _write(blk, e, d)
    for e in (ents if ents is not None else doc.ents.values()):
        _write(msp, e, d)
    try:
        d.header["$LTSCALE"] = float(doc.settings.get("ltscale", 1.0) or 1.0)
    except Exception:
        pass
    for hk, hv in (("$CELTSCALE", 1.0), ("$PSLTSCALE", 0), ("$MSLTSCALE", 0), ("$MEASUREMENT", 1)):     # dashes exactly as drawn here; metric
        try:
            d.header[hk] = hv
        except Exception:
            pass
    d.header["$INSUNITS"] = {"mm": 4, "cm": 5, "m": 6, "in": 1, "ft": 2}.get(doc.settings.get("units", "mm"), 4)
    d.saveas(path)


def _text_style(d, font):
    """Name of the text style for a font (created on first use), so the text keeps its font in AutoCAD / ZWCAD."""
    font = (font or "Arial").strip() or "Arial"
    m = getattr(d, "_acp_styles", None)
    if m is None:
        m = d._acp_styles = {}
    if font in m:
        return m[font]
    low = font.lower()
    try:
        if low in SHX or low.endswith(".shx"):
            name = low.replace(".shx", "").upper()
            if name not in d.styles:
                d.styles.add(name, font=low if low.endswith(".shx") else low + ".shx")
        else:
            name = font
            if name not in d.styles:
                files = {"arial": "arial.ttf", "arial narrow": "arialn.ttf", "times new roman": "times.ttf", "courier new": "cour.ttf",
                         "calibri": "calibri.ttf", "cambria": "cambria.ttc", "tahoma": "tahoma.ttf", "verdana": "verdana.ttf",
                         "consolas": "consola.ttf", "segoe ui": "segoeui.ttf", "century gothic": "gothic.ttf", "georgia": "georgia.ttf"}
                st = d.styles.add(name, font=files.get(low, low.replace(" ", "") + ".ttf"))
                try:
                    st.set_extended_font_data(family=font, italic=False, bold=False)
                except Exception:
                    pass
    except Exception:
        name = "Standard"
    m[font] = name
    return name


def _attrs(e, d):
    a = {"layer": e.layer}
    a.update(_aci_or_rgb(e.color))
    if e.ltype not in ("ByLayer", None):
        lt = str(e.ltype).upper()
        if lt and lt in d.linetypes:
            a["linetype"] = lt
    if getattr(e, "lts", 1.0) != 1.0:
        a["ltscale"] = float(e.lts)
    if e.lw is not None and e.lw >= 0:
        a["lineweight"] = int(e.lw)
    return a


def _write(space, e, d):
    a = _attrs(e, d)
    k = e.kind
    try:
        if k == "line" and e.xd and e.xd.get("inf"):
            dd = e.p1 - e.p0; dd = dd / max(1e-12, float(np.linalg.norm(dd)))
            if e.xd["inf"] == "ray":
                space.add_ray(tuple(e.p0), tuple(dd), dxfattribs=a)
            else:
                space.add_xline(tuple((e.p0 + e.p1) / 2), tuple(dd), dxfattribs=a)
        elif k == "line":
            space.add_line(tuple(e.p0), tuple(e.p1), dxfattribs=a)
        elif k == "point":
            space.add_point(tuple(e.p), dxfattribs=a)
        elif k == "circle":
            pl = Plane.from_normal(e.c, e.n)
            from ezdxf.math import OCS
            ocs = OCS(tuple(e.n))
            a["extrusion"] = tuple(e.n)
            space.add_circle(ocs.from_wcs(tuple(e.c)), e.r, dxfattribs=a)
        elif k == "arc":
            from ezdxf.math import OCS
            ocs = OCS(tuple(e.n)); a["extrusion"] = tuple(e.n)
            space.add_arc(ocs.from_wcs(tuple(e.c)), e.r, math.degrees(e.a0), math.degrees(e.a1), dxfattribs=a)
        elif k == "ellipse":
            a["extrusion"] = tuple(e.n)
            space.add_ellipse(tuple(e.c), tuple(e.major), e.ratio, e.t0, e.t1, dxfattribs=a)
        elif k == "polyline":
            if e.is3d:
                space.add_polyline3d([tuple(p) for p in e.pts], close=e.closed, dxfattribs=a)
            else:
                from ezdxf.math import OCS
                ocs = OCS(tuple(e.n)); q = [ocs.from_wcs(tuple(p)) for p in e.pts]
                a["extrusion"] = tuple(e.n); a["elevation"] = q[0][2] if q else 0
                pts = [(p[0], p[1], 0, 0, b) for p, b in zip(q, e.bulges)]
                pl = space.add_lwpolyline(pts, format="xyseb", close=e.closed, dxfattribs=a)
        elif k == "spline":
            if e.fit is not None and len(e.fit) >= 2 and e.weights is None:
                space.add_spline(fit_points=[tuple(p) for p in e.fit], degree=3, dxfattribs=a)
            else:
                s = space.add_spline(dxfattribs=a)
                s.dxf.degree = e.deg
                s.control_points = [tuple(p) for p in e.ctrl]; s.knots = list(e.knots)
                if e.weights:
                    s.weights = list(e.weights)
        elif k == "text":
            from ezdxf.enums import TextEntityAlignment
            if "\n" in e.s or e.width > 0 or e.rich:
                ap = (3 - e.valign if e.valign else 3) * 3 - 2 + e.halign if e.valign else 7 + e.halign
                ap = {3: 1, 2: 4, 1: 7, 0: 7}.get(e.valign, 7) + e.halign
                mt = space.add_mtext(e.rich or e.s.replace("\n", "\\P"), dxfattribs=dict(a, char_height=e.h, insert=tuple(e.p), style=_text_style(d, e.font),
                                                                                 text_direction=tuple(e.xdir), attachment_point=ap,
                                                                                 extrusion=tuple(e.n)))
                if e.width > 0:
                    mt.dxf.width = e.width
                if e.lsf != 1.0:
                    mt.dxf.line_spacing_factor = float(e.lsf)
            else:
                from ezdxf.math import OCS
                ocs = OCS(tuple(e.n))
                a.update(height=e.h, rotation=math.degrees(e.rotation()), extrusion=tuple(e.n), width=e.wf, style=_text_style(d, e.font))
                t = space.add_text(e.s, dxfattribs=a)
                al = {(0, 0): "LEFT", (1, 0): "CENTER", (2, 0): "RIGHT", (0, 1): "BOTTOM_LEFT", (1, 1): "BOTTOM_CENTER",
                      (2, 1): "BOTTOM_RIGHT", (0, 2): "MIDDLE_LEFT", (1, 2): "MIDDLE_CENTER", (2, 2): "MIDDLE_RIGHT",
                      (0, 3): "TOP_LEFT", (1, 3): "TOP_CENTER", (2, 3): "TOP_RIGHT"}[(e.halign, e.valign)]
                t.set_placement(ocs.from_wcs(tuple(e.p)), align=TextEntityAlignment[al])
        elif k == "hatch":
            from ezdxf.math import OCS
            ocs = OCS(tuple(e.n))
            h = space.add_hatch(dxfattribs=dict(a, extrusion=tuple(e.n)))
            if e.pattern == "SOLID":
                h.set_solid_fill(color=a.get("color", 256) if "color" in a else 256)
                if getattr(e, "grad", None):
                    try:
                        g = e.grad; rgb = lambda c: tuple(int(round(x * 255)) for x in E.color_rgb(c))
                        nm = {"LINEAR": "LINEAR", "CYLINDER": "CYLINDER", "SPHERICAL": "SPHERICAL"}.get(str(g.get("name", "LINEAR")).upper(), "LINEAR")
                        h.set_gradient(color1=rgb(g.get("c1", 5)), color2=rgb(g.get("c2", 7)), rotation=float(g.get("angle", 0.0) or 0.0),
                                       centered=0.0 if nm == "LINEAR" else 1.0, name=nm)
                    except Exception:
                        pass
            else:
                import math as _m
                from . import hatchpat as HP
                fams = HP.families(e.pattern, e.pdef); dfn = []
                for f in fams:                             # PAT offsets (along / across the line) -> DXF offsets (x / y)
                    t = _m.radians(f[0]); ux, uy = _m.cos(t), _m.sin(t)
                    dfn.append([f[0], (f[1], f[2]), (f[3] * ux - f[4] * uy, f[3] * uy + f[4] * ux), list(f[5])])
                h.set_pattern_fill(e.pattern, color=a.get("color", 256), scale=e.scale, angle=e.angle, definition=dfn)
            for i, l in enumerate(e.loops):
                q = [ocs.from_wcs(tuple(p)) for p in l]
                h.paths.add_polyline_path([(p[0], p[1]) for p in q], is_closed=True, flags=1 if i == 0 else 0)
                h.dxf.elevation = (0, 0, q[0][2])
        elif k == "insert":
            M = e.M
            from ezdxf.math import Matrix44
            if e.name not in d.blocks:
                return
            ref = space.add_blockref(e.name, (0, 0, 0), dxfattribs=a)
            ref.transform(Matrix44(M.T.ravel().tolist()))
        elif k in ("dimension", "leader", "table", "detailview", "array", "attdef"):
            for x in e.explode():
                x.layer = e.layer; x.color = e.color
                _write(space, x, d)
        elif k == "body":
            V = e.V; F = e.F
            if len(F) > 32000:
                for f in F:
                    space.add_3dface([tuple(V[i]) for i in f] + [tuple(V[f[2]])], dxfattribs=a)
            else:
                pf = space.add_polyface(dxfattribs=a)
                pf.append_faces([[tuple(V[i]) for i in f] for f in F], dxfattribs={"layer": e.layer})
                pf.optimize()
    except Exception:
        pass


def export_stl(path, bodies):
    with open(path, "w") as f:
        f.write("solid ALIEF_CADPRO\n")
        for b in bodies:
            fn = b.normals()
            for (i, j, k), n in zip(b.F, fn):
                f.write(f"facet normal {n[0]:.6g} {n[1]:.6g} {n[2]:.6g}\n outer loop\n")
                for v in (b.V[i], b.V[j], b.V[k]):
                    f.write(f"  vertex {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
                f.write(" endloop\nendfacet\n")
        f.write("endsolid ALIEF_CADPRO\n")


def export_obj(path, bodies):
    with open(path, "w") as f:
        f.write("# ALIEF CAD PRO\n")
        off = 1
        for n, b in enumerate(bodies):
            f.write(f"o {b.label.replace(' ', '_')}_{n + 1}\n")
            for v in b.V:
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            for t in b.F:
                f.write(f"f {t[0] + off} {t[1] + off} {t[2] + off}\n")
            off += len(b.V)


def import_mesh(path):
    """STL (ascii / binary) or OBJ -> Body."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".obj":
        V = []; F = []
        for line in open(path, errors="ignore"):
            p = line.split()
            if not p:
                continue
            if p[0] == "v":
                V.append([float(x) for x in p[1:4]])
            elif p[0] == "f":
                idx = [int(x.split("/")[0]) for x in p[1:]]
                idx = [i - 1 if i > 0 else len(V) + i for i in idx]
                for k in range(1, len(idx) - 1):
                    F.append([idx[0], idx[k], idx[k + 1]])
        return E.Body(np.array(V), np.array(F), "mesh")
    data = open(path, "rb").read()
    if data[:5] == b"solid" and b"facet" in data[:400]:
        P = []
        for line in data.decode(errors="ignore").splitlines():
            s = line.strip().split()
            if s and s[0] == "vertex":
                P.append([float(x) for x in s[1:4]])
        P = np.array(P)
    else:
        n = int.from_bytes(data[80:84], "little")
        rec = np.frombuffer(data[84:84 + n * 50], dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
        P = rec["v"].reshape(-1, 3).astype(float)
    key = np.round(P, 6)
    V, inv = np.unique(key, axis=0, return_inverse=True)
    return E.Body(V, inv.reshape(-1, 3), "mesh")


# ------------------------------------------------------------------------------------------------ DWG
ODA_PATH = None          # set from Options > Files


def find_oda():
    if ODA_PATH and os.path.exists(ODA_PATH):
        return ODA_PATH
    cands = []
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        d = os.path.join(root, "ODA")
        if os.path.isdir(d):
            for sub in sorted(os.listdir(d), reverse=True):
                exe = os.path.join(d, sub, "ODAFileConverter.exe")
                if os.path.exists(exe):
                    cands.append(exe)
    w = shutil.which("ODAFileConverter")
    if w:
        cands.append(w)
    return cands[0] if cands else None


def dwg_convert(src, out_dir, to_fmt="DXF", ver="ACAD2018"):
    exe = find_oda()
    if not exe:
        raise RuntimeError("ODA File Converter is not installed")
    in_dir = tempfile.mkdtemp(prefix="cadpro_in_")
    shutil.copy(src, in_dir)
    args = [exe, in_dir, out_dir, ver, to_fmt, "0", "1", "*." + os.path.splitext(src)[1][1:].upper()]
    subprocess.run(args, check=False, timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    base = os.path.splitext(os.path.basename(src))[0]
    out = os.path.join(out_dir, base + "." + to_fmt.lower())
    if not os.path.exists(out):
        raise RuntimeError("ODA File Converter produced no output")
    return out
