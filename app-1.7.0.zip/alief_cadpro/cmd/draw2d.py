"""2D drawing and annotation commands."""
import math
import numpy as np
from ..core import entities as E
from ..core.geom import unit, norm, arc_from_3p, Plane, ang_in_plane, TAU, v3
from .engine import Cancel


def _plane_n(c):
    return c.ucs.z


def cmd_line(c):
    p0 = yield c.pt("LINE  Specify first point")
    if p0 is None:
        return
    start = p0; pts = [p0]; made = []
    while True:
        opts = ["Undo"] + (["Close"] if len(pts) >= 3 else [])
        p1 = yield c.pt("Specify next point or [" + "/".join(opts) + "]", base=pts[-1],
                        preview=lambda q, a=pts[-1]: [E.Line(a, q)], options=opts)
        if p1 is None:
            return
        if p1 == "Undo":
            if made:
                c.doc.remove(made.pop()); pts.pop()
            continue
        if p1 == "Close":
            made.append(c.add(E.Line(pts[-1], start))); return
        made.append(c.add(E.Line(pts[-1], p1))); pts.append(p1)


def cmd_xline(c):
    """Construction line (infinite): through two points, or Hor / Ver / Ang / Bisect / Offset like AutoCAD."""
    import math
    x, y, n = c.ucs.x, c.ucs.y, c.ucs.z
    opts = ["Hor", "Ver", "Ang", "Bisect", "Offset"]
    p = yield c.pt("XLINE  Specify a point or [Hor/Ver/Ang/Bisect/Offset]", options=opts)
    if p is None:
        return
    def many(d, label):
        while True:
            q = yield c.pt(f"Specify through point ({label}), Enter to finish", preview=lambda q, d=d: [E.make_xline(q, d)])
            if q is None or isinstance(q, str):
                return
            c.add(E.make_xline(q, d))
    if isinstance(p, str):
        if p == "Hor":
            yield from many(x, "horizontal"); return
        if p == "Ver":
            yield from many(y, "vertical"); return
        if p == "Ang":
            a = yield c.num("Enter angle of the construction line <0>", 0.0)
            if a is None:
                return
            a = math.radians(float(a)); yield from many(x * math.cos(a) + y * math.sin(a), f"{math.degrees(a):g} deg"); return
        if p == "Bisect":
            v0 = yield c.pt("Specify angle vertex point")
            if v0 is None or isinstance(v0, str):
                return
            a = yield c.pt("Specify angle start point", base=v0)
            if a is None or isinstance(a, str):
                return
            while True:
                b = yield c.pt("Specify angle end point, Enter to finish", base=v0,
                               preview=lambda q: ([E.make_xline(v0, unit(unit(a - v0) + unit(q - v0)))] if norm(q - v0) > 1e-9 and norm(unit(a - v0) + unit(q - v0)) > 1e-9 else []))
                if b is None or isinstance(b, str):
                    return
                d = unit(a - v0) + unit(b - v0)
                if norm(d) > 1e-9:
                    c.add(E.make_xline(v0, d))
        if p == "Offset":
            dist = yield c.dist("Specify offset distance", None)
            if dist is None:
                return
            while True:
                s = yield c.ent("Select a line object, Enter to finish", filt=lambda e: e.kind == "line")
                if s is None:
                    return
                ln = s[0]; d = unit(ln.p1 - ln.p0); side = np.cross(n, d)
                q = yield c.pt("Specify side to offset", preview=lambda q: [E.make_xline(ln.p0 + side * (float(dist) if np.dot(q - ln.p0, side) >= 0 else -float(dist)), d)])
                if q is None or isinstance(q, str):
                    return
                c.add(E.make_xline(ln.p0 + side * (float(dist) if np.dot(q - ln.p0, side) >= 0 else -float(dist)), d))
        return
    while True:
        q = yield c.pt("Specify through point, Enter to finish", base=p, preview=lambda q: ([E.make_xline(p, q - p)] if norm(q - p) > 1e-9 else []))
        if q is None or isinstance(q, str):
            return
        if norm(q - p) > 1e-9:
            c.add(E.make_xline(p, q - p))


def cmd_ray(c):
    """Ray: starts at a point and runs to infinity through the next points."""
    p = yield c.pt("RAY  Specify start point")
    if p is None:
        return
    while True:
        q = yield c.pt("Specify through point, Enter to finish", base=p, preview=lambda q: ([E.make_xline(p, q - p, ray=True)] if norm(q - p) > 1e-9 else []))
        if q is None or isinstance(q, str):
            return
        if norm(q - p) > 1e-9:
            c.add(E.make_xline(p, q - p, ray=True))


def cmd_pline(c):
    p0 = yield c.pt("PLINE  Specify start point")
    if p0 is None:
        return
    pts = [p0]; bul = []; arc = False; n = _plane_n(c)
    def build(extra=None, closed=False):
        P = pts + ([extra] if extra is not None else [])
        B = bul + ([_bulge(P[-2], P[-1], n, _tangent(pts, bul, n)) if arc and extra is not None else 0.0] if extra is not None else []) + [0.0]
        return E.Polyline(np.array(P), closed, B[:len(P)], n)
    while True:
        opts = ["Arc" if not arc else "Line", "Undo"] + (["Close"] if len(pts) >= 3 else [])
        q = yield c.pt("Specify next point or [" + "/".join(opts) + "]", base=pts[-1], preview=lambda q: [build(q)], options=opts)
        if q is None:
            break
        if q == "Arc":
            arc = True; continue
        if q == "Line":
            arc = False; continue
        if q == "Undo":
            if len(pts) > 1:
                pts.pop(); bul.pop()
            continue
        if q == "Close":
            pl = build(None, True); pl.bulges = np.array(bul + [0.0]); c.add(pl); return
        bul.append(_bulge(pts[-1], q, n, _tangent(pts, bul, n)) if arc else 0.0)
        pts.append(q)
    if len(pts) >= 2:
        c.add(E.Polyline(np.array(pts), False, bul + [0.0], n))


def _tangent(pts, bul, n):
    if len(pts) < 2:
        return None
    a, b = pts[-2], pts[-1]; bb = bul[-1] if bul else 0.0
    d = unit(b - a)
    if abs(bb) < 1e-12:
        return d
    th = 4 * math.atan(bb)
    from ..core.geom import m_rotate
    R = m_rotate((0, 0, 0), n, th / 2)[:3, :3]
    return unit(R @ d)


def _bulge(a, b, n, t):
    """Tangent-continuous arc from a to b (start tangent t)."""
    if t is None:
        t = unit(b - a)
    ch = b - a
    if norm(ch) < 1e-12:
        return 0.0
    ang = math.atan2(np.dot(np.cross(t, ch), n), np.dot(t, ch))
    return math.tan(ang / 2)


def cmd_circle(c):
    p = yield c.pt("CIRCLE  Specify center point or [2P/3P/TTR]", options=["2P", "3P"])
    n = _plane_n(c)
    if p is None:
        return
    if p == "2P":
        a = yield c.pt("Specify first end point of diameter")
        b = yield c.pt("Specify second end point of diameter", base=a, preview=lambda q: [E.Circle((a + q) / 2, norm(q - a) / 2, n)])
        if a is not None and b is not None and norm(b - a) > 0:
            c.add(E.Circle((a + b) / 2, norm(b - a) / 2, n))
        return
    if p == "3P":
        a = yield c.pt("Specify first point on circle")
        b = yield c.pt("Specify second point on circle", base=a)
        def pv(q):
            r = arc_from_3p(a, b, q)
            return [E.Circle(r[0], r[1], r[2] if np.dot(r[2], n) >= 0 else -r[2])] if r else []
        q = yield c.pt("Specify third point on circle", base=b, preview=pv)
        r = arc_from_3p(a, b, q) if q is not None else None
        if r:
            c.add(E.Circle(r[0], r[1], r[2] if np.dot(r[2], n) >= 0 else -r[2]))
        return
    r = yield c.dist("Specify radius of circle or [Diameter]", base=p, options=["Diameter"],
                     preview=lambda q: [E.Circle(p, norm(q - p), n)])
    if r == "Diameter":
        d = yield c.dist("Specify diameter of circle", base=p, preview=lambda q: [E.Circle(p, norm(q - p) / 2, n)])
        r = d / 2 if isinstance(d, float) else None
    if isinstance(r, float) and r > 0:
        c.add(E.Circle(p, r, n))


def cmd_arc(c):
    a = yield c.pt("ARC  Specify start point of arc or [Center]", options=["Center"])
    n = _plane_n(c)
    if a is None:
        return
    if a == "Center":
        cen = yield c.pt("Specify center point of arc")
        s = yield c.pt("Specify start point of arc", base=cen)
        u = Plane.from_normal(cen, n)
        def mk(q):
            a0 = ang_in_plane(cen, n, u.x, s); a1 = ang_in_plane(cen, n, u.x, q)
            return E.Arc(cen, norm(s - cen), a0 - ang_in_plane(cen, n, E.Arc(cen, 1, 0, 1, n).u(), cen + u.x) + 0, a1, n)
        def mk2(q):
            arc = E.Arc(cen, norm(s - cen), 0, 1, n); uu = arc.u()
            arc.a0 = ang_in_plane(cen, n, uu, s) % TAU; a1 = ang_in_plane(cen, n, uu, q) % TAU
            arc.a1 = a1 if a1 > arc.a0 else a1 + TAU
            return arc
        e = yield c.pt("Specify end point of arc", base=cen, preview=lambda q: [mk2(q)])
        if e is not None:
            c.add(mk2(e))
        return
    b = yield c.pt("Specify second point of arc", base=a)
    e = yield c.pt("Specify end point of arc", base=b, preview=lambda q: [E.Arc.through(a, b, q)])
    if e is not None:
        arc = E.Arc.through(a, b, e)
        if arc:
            c.add(arc)


def cmd_rect(c):
    a = yield c.pt("RECTANG  Specify first corner point")
    if a is None:
        return
    pl = c.ucs
    def mk(q):
        A = pl.to_local(a); B = pl.to_local(q)
        pts = [A, [B[0], A[1], A[2]], [B[0], B[1], A[2]], [A[0], B[1], A[2]]]
        return E.Polyline(pl.to_world(np.array(pts, float)), True, None, pl.z)
    b = yield c.corner("Specify other corner point or type @width,height", a, preview=lambda q: [mk(q)])
    if b is not None:
        c.add(mk(b))


def cmd_polygon(c):
    nside = yield c.num("POLYGON  Enter number of sides <6>", 6)
    nside = int(nside or 6)
    if nside < 3:
        return
    cen = yield c.pt("Specify center of polygon")
    mode = yield c.opt("Enter an option [Inscribed in circle/Circumscribed about circle] <I>", ["Inscribed", "Circumscribed"], "Inscribed")
    pl = c.ucs
    def mk(q):
        d = pl.to_local(q) - pl.to_local(cen); r = math.hypot(d[0], d[1]); a0 = math.atan2(d[1], d[0])
        if mode == "Circumscribed":
            r = r / math.cos(math.pi / nside); a0 += math.pi / nside
        P = [pl.to_local(cen) + [r * math.cos(a0 + 2 * math.pi * k / nside), r * math.sin(a0 + 2 * math.pi * k / nside), 0] for k in range(nside)]
        return E.Polyline(pl.to_world(np.array(P)), True, None, pl.z)
    q = yield c.height("Specify radius of circle (point or value)", cen, preview=lambda q: [mk(q)])
    if isinstance(q, (int, float)):
        q = cen + pl.x * q
    if q is not None:
        c.add(mk(q))


def cmd_ellipse(c):
    a = yield c.pt("ELLIPSE  Specify center of ellipse")
    if a is None:
        return
    n = _plane_n(c)
    b = yield c.pt("Specify endpoint of axis", base=a)
    if b is None:
        return
    def mk(q):
        maj = b - a; r2 = norm(np.cross(unit(maj), q - a))
        return E.Ellipse(a, maj, max(1e-6, min(1, r2 / max(norm(maj), 1e-12))), n)
    q = yield c.dist("Specify distance to other axis", base=a, preview=lambda q: [mk(q)])
    if isinstance(q, float):
        maj = b - a
        c.add(E.Ellipse(a, maj, max(1e-6, q / norm(maj)), n))


def cmd_spline(c):
    pts = []
    p = yield c.pt("SPLINE  Specify first point")
    if p is None:
        return
    pts.append(p)
    while True:
        q = yield c.pt("Enter next point or [Undo/Close] <done>", base=pts[-1], options=["Undo", "Close"],
                       preview=lambda q: [E.Spline.through(pts + [q])] if len(pts) >= 1 else [])
        if q is None:
            break
        if q == "Undo":
            if len(pts) > 1:
                pts.pop()
            continue
        if q == "Close":
            pts.append(pts[0]); break
        pts.append(q)
    if len(pts) >= 2:
        c.add(E.Spline.through(pts))


def cmd_point(c):
    while True:
        p = yield c.pt("POINT  Specify a point")
        if p is None:
            return
        c.add(E.PointE(p))


def _text_h(c):
    return c.doc.settings.get("text_paper", 2.5)


def cmd_text(c):
    from .misc import ensure_scale; ensure_scale(c)
    p = yield c.pt("TEXT  Specify start point of text or [Justify]", options=["Justify"])
    just = 0
    if p == "Justify":
        o = yield c.opt("Enter an option [Left/Center/Right/Middle]", ["Left", "Center", "Right", "Middle"], "Left")
        just = {"Left": 0, "Center": 1, "Right": 2, "Middle": 3}.get(o, 0)
        p = yield c.pt("Specify insertion point")
    if p is None:
        return
    k = E.Entity.anno_scale
    hp = _text_h(c)
    h = yield c.dist(f"Specify paper height (mm, annotative 1:{k:g}) <{hp:g}>", base=None, default=hp)
    ang = yield c.angle("Specify rotation angle of text <0>", base=p, default=0.0)
    while True:
        s = yield c.text("Enter text (empty = finish)")
        if not s:
            return
        a = math.radians(ang or 0)
        x = c.ucs.x * math.cos(a) + c.ucs.y * math.sin(a)
        t = E.Text(p, s, 2.5, x, c.ucs.z, 1 if just in (1, 3) else (2 if just == 2 else 0), 2 if just == 3 else 0)
        t.anno = float(h); t.layer = "TEXT" if c.doc.cur_layer == "0" else c.doc.cur_layer
        c.doc.add_keep(t)
        p = p - c.ucs.y * t.h * 1.666


def cmd_mtext(c):
    """MTEXT: two corners give the place and the width of the text box, then the Text Formatting editor opens."""
    from .misc import ensure_scale; ensure_scale(c)
    p = yield c.pt("MTEXT  Specify first corner")
    if p is None:
        return
    def box(q):
        la, lq = c.ucs.to_local(p), c.ucs.to_local(q)
        return [E.Polyline([c.ucs.to_world(np.array(v)) for v in ((la[0], la[1], la[2]), (lq[0], la[1], la[2]), (lq[0], lq[1], la[2]), (la[0], lq[1], la[2]))], True)]
    q = yield c.corner("Specify opposite corner (width of the text box) or <Enter = no wrapping>", p, preview=box)
    s = c.app.dialog_mtext()
    if not s or not s["text"].strip():
        return
    width = 0.0; ins = np.asarray(p, float)
    if q is not None:
        la, lq = c.ucs.to_local(p), c.ucs.to_local(q)
        width = abs(lq[0] - la[0])
        x0, x1 = sorted((la[0], lq[0])); y0, y1 = sorted((la[1], lq[1]))
        ax = [x0, (x0 + x1) / 2, x1][s["halign"]]; ay = {3: y1, 2: (y0 + y1) / 2, 1: y0}.get(s["valign"], y1)
        ins = c.ucs.to_world(np.array([ax, ay, la[2]]))
    t = E.Text(ins, s["text"], 2.5, c.ucs.x, c.ucs.z, s["halign"], s["valign"], s.get("font", "Arial"))
    t.anno = s["height"]; t.width = width; t.lsf = s.get("lsf", 1.0); t.set_rich(s["rich"])
    if not t.rich:
        t.s = s["text"]
    t.layer = "TEXT" if c.doc.cur_layer == "0" else c.doc.cur_layer
    c.doc.add_keep(t)


def cmd_hatch(c):
    from .misc import ensure_scale; ensure_scale(c)
    opt = c.app.dialog_hatch()
    if not opt:
        return
    ents = yield c.sel("Select closed boundary objects (outer + inner islands)", filt=lambda e: getattr(e, "closed", False))
    if not ents:
        return
    from ..core.solids import regions_from_curves
    for plane, loops in regions_from_curves(ents, c.ucs):
        h = E.Hatch([plane.to_world(l) for l in loops], plane.z, opt["pattern"], opt["scale"] * E.Entity.anno_scale, opt["angle"])
        h.layer = "HATCH" if c.doc.cur_layer == "0" else c.doc.cur_layer
        c.doc.add_keep(h)


def _dimstyle(c):
    from ..ui.dialogs15 import styles_of
    stl = styles_of(c.doc); name = c.doc.settings.get("dimstyle", "Standard")
    st = dict(stl.get(name) or c.doc.settings.get("dim", {})); st["name"] = name
    st.setdefault("anno", True)
    return st


def _dim_add(c, d):
    d.layer = "DIMENSION" if c.doc.cur_layer == "0" else c.doc.cur_layer
    c.doc.add_keep(d)


def cmd_dimlinear(c):
    from .misc import ensure_scale; ensure_scale(c)
    a = yield c.pt("DIMLINEAR  Specify first extension line origin")
    b = yield c.pt("Specify second extension line origin", base=a)
    if a is None or b is None:
        return
    pl = c.ucs
    def mk(q):
        la, lb, lq = pl.to_local(a), pl.to_local(b), pl.to_local(q)
        dx, dy = abs(lb[0] - la[0]), abs(lb[1] - la[1])
        mx, my = (la[0] + lb[0]) / 2, (la[1] + lb[1]) / 2
        horiz = abs(lq[1] - my) * max(dx, 1e-9) >= abs(lq[0] - mx) * max(dy, 1e-9) if (dx > 1e-9 and dy > 1e-9) else dx >= dy
        st = _dimstyle(c); st["rot"] = 0 if horiz else 90
        return E.Dimension("linear", [a, b, q], pl.z, pl.x, st)
    q = yield c.pt("Specify dimension line location", base=b, preview=lambda q: [mk(q)])
    if q is not None:
        _dim_add(c, mk(q))


def cmd_dimaligned(c):
    from .misc import ensure_scale; ensure_scale(c)
    a = yield c.pt("DIMALIGNED  Specify first extension line origin")
    b = yield c.pt("Specify second extension line origin", base=a)
    if a is None or b is None:
        return
    mk = lambda q: E.Dimension("aligned", [a, b, q], c.ucs.z, c.ucs.x, _dimstyle(c))
    q = yield c.pt("Specify dimension line location", base=b, preview=lambda q: [mk(q)])
    if q is not None:
        _dim_add(c, mk(q))


def _pick_circle(c, prompt):
    r = yield c.ent(prompt, filt=lambda e: e.kind in ("circle", "arc") or (e.kind == "polyline" and any(p[0] == "A" for p in e.prims())))
    return r


def cmd_dimradius(c, dia=False):
    from .misc import ensure_scale; ensure_scale(c)
    r = yield c.ent(("DIMDIAMETER" if dia else "DIMRADIUS") + "  Select arc or circle", filt=lambda e: e.kind in ("circle", "arc"))
    if r is None:
        return
    e, pk = r
    def mk(q):
        u = unit(q - e.c); u = u if norm(u) > 0 else c.ucs.x
        p = e.c + u * e.r
        return E.Dimension("diameter" if dia else "radius", [e.c, p, q], e.n, c.ucs.x, _dimstyle(c))
    q = yield c.pt("Specify dimension line location", base=e.c, preview=lambda q: [mk(q)])
    if q is not None:
        _dim_add(c, mk(q))


def cmd_dimdiameter(c):
    yield from cmd_dimradius(c, True)


def cmd_dimangular(c):
    from .misc import ensure_scale; ensure_scale(c)
    r1 = yield c.ent("DIMANGULAR  Select first line", filt=lambda e: e.kind == "line")
    if r1 is None:
        return
    r2 = yield c.ent("Select second line", filt=lambda e: e.kind == "line")
    if r2 is None:
        return
    l1, p1 = r1; l2, p2 = r2
    from ..core.geom import line_line_3d
    r = line_line_3d(l1.p0, l1.p1 - l1.p0, l2.p0, l2.p1 - l2.p0)
    if r is None:
        c.msg("Lines are parallel"); return
    X = l1.p0 + r[0] * (l1.p1 - l1.p0)
    q1 = l1.p0 if norm(l1.p0 - X) > norm(l1.p1 - X) else l1.p1
    q2 = l2.p0 if norm(l2.p0 - X) > norm(l2.p1 - X) else l2.p1
    if norm(p1 - X) > 1e-9:
        q1 = p1
    if norm(p2 - X) > 1e-9:
        q2 = p2
    mk = lambda q: E.Dimension("angular", [X, q1, q2, q], c.ucs.z, c.ucs.x, _dimstyle(c))
    q = yield c.pt("Specify dimension arc line location", base=X, preview=lambda q: [mk(q)])
    if q is not None:
        _dim_add(c, mk(q))


def cmd_leader(c):
    from .misc import ensure_scale; ensure_scale(c)
    pts = []
    p = yield c.pt("LEADER  Specify leader arrow point")
    if p is None:
        return
    pts.append(p)
    while True:
        q = yield c.pt("Specify next point <text>", base=pts[-1], preview=lambda q: [E.Leader(pts + [q], "", 2.5, c.ucs.z)])
        if q is None:
            break
        pts.append(q)
    if len(pts) < 2:
        return
    s = yield c.text("Enter annotation text")
    L = E.Leader(pts, s or "", c.doc.settings.get("text_paper", 2.5), c.ucs.z, _leader_style(c)[1])
    L.arrow = _leader_style(c)[3]
    L.anno = True; L.layer = "DIMENSION" if c.doc.cur_layer == "0" else c.doc.cur_layer
    c.doc.add_keep(L)


def _leader_style(c):
    st = c.doc.settings
    return (float(st.get("text_paper", 2.5)), float(st.get("mleader_asz", st.get("dim", {}).get("asz", 2.5))), float(st.get("mleader_land", 2.0)),
            st.get("mleader_arrow", "closed"))


def cmd_mleader(c):
    """MLEADER: arrowhead point, landing point, text.  Options: arrowhead size and type, landing distance.
    More leader lines: select the multileader, hover the landing grip > Add Leader, or MLEADEREDIT."""
    from .misc import ensure_scale; ensure_scale(c)
    while True:
        th, asz, land, arrow = _leader_style(c)
        def mk(pts, s=""):
            L = E.Leader(pts, s, th, c.ucs.z, asz); L.anno = True; L.land0 = land; L.arrow = arrow
            return L
        p = yield c.pt(f"MLEADER  Specify leader arrowhead location or [Arrow size <{asz:g}>/arrow Type <{arrow}>/Landing <{land:g}>]",
                       options=["Arrow size", "Type", "Landing"])
        if p is None:
            return
        if isinstance(p, str):
            if p == "Arrow size":
                v = yield c.num(f"Arrowhead size on paper (mm) <{asz:g}>", default=asz)
                if v is not None and float(v) >= 0:
                    c.doc.settings["mleader_asz"] = float(v)
            elif p == "Type":
                o = yield c.opt(f"Arrowhead [Closed/Open/Dot/Tick/None] <{arrow}>", ["Closed", "Open", "Dot", "Tick", "None"], arrow.capitalize())
                if o:
                    c.doc.settings["mleader_arrow"] = o.lower()
            else:
                v = yield c.num(f"Landing distance on paper (mm, 0 = no landing) <{land:g}>", default=land)
                if v is not None and float(v) >= 0:
                    c.doc.settings["mleader_land"] = float(v)
            continue
        q = yield c.pt("Specify leader landing location", base=p, preview=lambda q: [mk([p, q])])
        if q is None:
            return
        s = yield c.text("Enter text  (\\P = new line)")
        L = mk([p, q], (s or "").replace("\\P", "\n")); L.layer = "DIMENSION" if c.doc.cur_layer == "0" else c.doc.cur_layer
        c.doc.add_keep(L)
        return


def cmd_mleaderedit(c):
    """MLEADEREDIT: add leader lines to a multileader, or remove them."""
    r = yield c.ent("MLEADEREDIT  Select the multileader", filt=lambda e: e.kind == "leader")
    if r is None:
        return
    L = r[0]
    mode = "Add"
    while True:
        if mode == "Add":
            def prev(q):
                n = L.copy(); n.extra.append(np.array([q], float)); return [n]
            p = yield c.pt("Specify leader arrowhead location or [Remove leaders] <done>", base=L.pts[-1], options=["Remove leaders"], preview=prev)
            if p is None:
                return
            if isinstance(p, str):
                mode = "Remove"; continue
            c.doc.modify(L)
            if not L.side:
                L.side = int(L._dir()[1])
            L.extra.append(np.array([p], float)); L.touch()
        else:
            if not L.extra:
                c.msg("Only one leader line is left"); mode = "Add"; continue
            p = yield c.pt("Pick near the arrowhead of the leader to remove or [Add leaders] <done>", options=["Add leaders"])
            if p is None:
                return
            if isinstance(p, str):
                mode = "Add"; continue
            tips = [L.pts[0]] + [x[0] for x in L.extra]
            k = int(np.argmin([norm(t - p) for t in tips]))
            c.doc.modify(L)
            if k == 0:
                x = L.extra.pop(0); L.pts = np.vstack([x, L.pts[-1:]])
            else:
                L.extra.pop(k - 1)
            L.touch()


def register(eng):
    R = eng.register
    R("MLEADER", cmd_mleader, ["MLD", "MLEA"], "Multileader: arrowhead, landing, text; Add Leader from the landing grip")
    R("MLEADEREDIT", cmd_mleaderedit, ["MLE", "AIMLEADEREDITADD"], "Add or remove leader lines of a multileader")
    R("LINE", cmd_line, ["L"], "Draw straight line segments")
    R("XLINE", cmd_xline, ["XL", "CONSTRUCTIONLINE"], "Construction line (infinite): 2 points, Hor, Ver, Ang, Bisect, Offset")
    R("RAY", cmd_ray, [], "Ray: half-infinite construction line")
    R("PLINE", cmd_pline, ["PL"], "Polyline with line and arc segments")
    R("CIRCLE", cmd_circle, ["C"], "Circle: center-radius, 2P, 3P")
    R("ARC", cmd_arc, ["A"], "Arc: 3 points or center-start-end")
    R("RECTANG", cmd_rect, ["REC", "RECTANGLE"], "Rectangle by two corners")
    R("POLYGON", cmd_polygon, ["POL"], "Regular polygon")
    R("ELLIPSE", cmd_ellipse, ["EL"], "Ellipse by center and axes")
    R("SPLINE", cmd_spline, ["SPL"], "Smooth spline through fit points")
    R("POINT", cmd_point, ["PO"], "Point objects")
    R("TEXT", cmd_text, ["DT", "DTEXT"], "Single-line annotative text")
    R("MTEXT", cmd_mtext, ["MT", "T"], "Multi-line annotative text")
    R("HATCH", cmd_hatch, ["H", "BH"], "Hatch / solid fill of closed areas")
    R("DIMLINEAR", cmd_dimlinear, ["DLI"], "Horizontal / vertical dimension")
    R("DIMALIGNED", cmd_dimaligned, ["DAL"], "Aligned dimension")
    R("DIMRADIUS", cmd_dimradius, ["DRA"], "Radius dimension")
    R("DIMDIAMETER", cmd_dimdiameter, ["DDI"], "Diameter dimension")
    R("DIMANGULAR", cmd_dimangular, ["DAN"], "Angular dimension")
    R("LEADER", cmd_leader, ["LE", "QLEADER"], "Leader with text")
