"""Commands added / rebuilt in 1.5: FILLET, CHAMFER, PEDIT, SCALE (free drag, Reference, Fit to frame), HATCH with pick internal
point, BOUNDARY, SELECTSIMILAR, clipboard (COPYCLIP, COPYBASE, CUTCLIP, PASTECLIP, PASTEBLOCK, PASTEORIG), TCOUNT, TNUMBER, VPORTS,
POLAR, SELECTIONCYCLING, DSETTINGS, DIMSTYLE."""
import json
import math
import numpy as np
from ..core import entities as E, editops as X, fillet2 as F
from ..core.geom import unit, norm, m_translate, m_scale, Plane, v3, bulge_arc, arc_pts
from .engine import Req
from .misc import T

CURVE = ("line", "arc", "circle", "polyline")


def _mods():
    from PySide6.QtWidgets import QApplication
    return QApplication.keyboardModifiers()


def _shift():
    from PySide6.QtCore import Qt
    return bool(_mods() & Qt.ShiftModifier)


# ===================================================================================================== FILLET / CHAMFER
def _chamfer_all(pl, d1, d2):
    n = len(pl.pts); P = [p.copy() for p in pl.pts]; B = list(np.asarray(pl.bulges, float)) + [0.0] * (n - len(pl.bulges))
    outP, outB = [], []; cnt = 0
    for k in range(n):
        if (not pl.closed and (k == 0 or k == n - 1)) or abs(B[k - 1]) > 1e-12 or abs(B[k]) > 1e-12:
            outP.append(P[k]); outB.append(B[k]); continue
        a, v, c = P[k - 1], P[k], P[(k + 1) % n]
        if d1 >= norm(a - v) * 0.999 or d2 >= norm(c - v) * 0.999:
            outP.append(v); outB.append(B[k]); continue
        outP += [v + unit(a - v) * d1, v + unit(c - v) * d2]; outB += [0.0, B[k]]; cnt += 1
    pl.pts = np.array(outP); pl.bulges = np.array(outB, float); pl.touch()
    return cnt


def cmd_fillet(c, chamfer=False):
    st = c.doc.settings
    name = "CHAMFER" if chamfer else "FILLET"
    multiple = False
    filt = lambda e: e.kind in CURVE and not getattr(e, "is3d", False)
    while True:
        r = float(st.get("fillet_r", 0.0)); d1 = float(st.get("cham_d1", 5.0)); d2 = float(st.get("cham_d2", d1)); trim = st.get("fillet_trim", True)
        info = f"Mode = {'TRIM' if trim else 'NOTRIM'}, " + (f"Dist1 = {d1:g}, Dist2 = {d2:g}" if chamfer else f"Radius = {r:g}")
        key = "Distance" if chamfer else "Radius"
        opts = ["Polyline", key, "Trim", "Multiple"]
        s = yield c.ent(f"{name}  ({info})  Select first object or [Polyline/{key}/Trim/Multiple]", filt=filt, options=opts)
        if s is None:
            return
        if s == "Radius":
            v = yield c.dist(f"Specify fillet radius <{r:g}>", default=r)
            if v is not None:
                st["fillet_r"] = abs(float(v))
            continue
        if s == "Distance":
            v1 = yield c.dist(f"Specify first chamfer distance <{d1:g}>", default=d1)
            if v1 is None:
                continue
            v2 = yield c.dist(f"Specify second chamfer distance <{float(v1):g}>", default=float(v1))
            st["cham_d1"] = abs(float(v1)); st["cham_d2"] = abs(float(v2 if v2 is not None else v1)); continue
        if s == "Trim":
            o = yield c.opt(f"Enter Trim mode option [Trim/No trim] <{'Trim' if trim else 'No trim'}>", ["Trim", "No trim"], "Trim" if trim else "No trim")
            if o is not None:
                st["fillet_trim"] = o == "Trim"
            continue
        if s == "Multiple":
            multiple = True; c.msg(f"{name}: several pairs one after the other - Enter or Esc to finish"); continue
        if s == "Polyline":
            p = yield c.ent("Select 2D polyline", filt=lambda e: e.kind == "polyline" and not e.is3d)
            if p is None:
                return
            c.doc.modify(p[0])
            n = _chamfer_all(p[0], d1, d2) if chamfer else F.fillet_all(p[0], r)
            c.msg(f"{n} line(s) were {'chamfered' if chamfer else 'filleted'}")
            if not multiple:
                return
            continue
        e1, p1 = s
        c.view.highlight_extra = [e1]; c.view.update()
        s2 = yield c.ent(f"Select second object, or shift-select to apply corner", filt=filt)
        c.view.highlight_extra = []
        if s2 is None:
            return
        if isinstance(s2, str):
            continue
        e2, p2 = s2
        R = 0.0 if (_shift() and not chamfer) else r
        ch = None if not chamfer else ((0.0, 0.0) if _shift() else (d1, d2))
        if p1 is None:
            p1 = e1.snaps().get("mid", [np.zeros(3)])[0]
        if p2 is None:
            p2 = e2.snaps().get("mid", [np.zeros(3)])[0]
        ok, msg, new = F.fillet(c.doc, e1, np.asarray(p1, float), e2, np.asarray(p2, float), R, trim, ch)
        if not ok:
            c.msg(msg)
            continue
        for n_ in new:
            c.doc.add_keep(n_)
        if not multiple:
            return


def cmd_chamfer(c):
    yield from cmd_fillet(c, True)


# ===================================================================================================== PEDIT
def to_polyline(e):
    """Line or arc -> polyline (None when not possible)."""
    if e.kind == "line":
        pl = E.Polyline([e.p0, e.p1], False)
    elif e.kind == "arc":
        a, b = e.ends(); u = e.u(); v = np.cross(e.n, u); t = (e.a0 + e.a1) / 2
        m = e.c + e.r * (math.cos(t) * u + math.sin(t) * v)
        ccw = float(np.cross(a - e.c, m - e.c)[2]) > 0
        pl = E.Polyline([a, b], False, [F.bulge_of(e.c, a, b, ccw), 0.0])
    else:
        return None
    pl.layer, pl.color, pl.ltype, pl.lw = e.layer, e.color, e.ltype, e.lw
    return pl


def _fit_points(P, closed, n_per=8):
    """Catmull-Rom curve through the vertices (PEDIT Fit)."""
    P = np.asarray(P, float); m = len(P)
    if m < 3:
        return P
    out = []
    rng = range(m) if closed else range(m - 1)
    for i in rng:
        p0 = P[(i - 1) % m] if (closed or i > 0) else P[i]
        p1 = P[i]; p2 = P[(i + 1) % m]
        p3 = P[(i + 2) % m] if (closed or i + 2 < m) else P[(i + 1) % m]
        for t in np.linspace(0, 1, n_per, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    if not closed:
        out.append(P[-1])
    return np.array(out)


def _spline_points(P, closed, n=12):
    """Uniform quadratic / cubic B-spline using the vertices as control frame (PEDIT Spline)."""
    P = np.asarray(P, float); m = len(P)
    if m < 3:
        return P
    if closed:
        Q = np.vstack([P, P[:3]])
    else:
        Q = np.vstack([P[:1], P[:1], P, P[-1:], P[-1:]])
    out = []
    for i in range(len(Q) - 3):
        p0, p1, p2, p3 = Q[i:i + 4]
        for t in np.linspace(0, 1, n, endpoint=False):
            b0 = (1 - t) ** 3 / 6; b1 = (3 * t ** 3 - 6 * t ** 2 + 4) / 6; b2 = (-3 * t ** 3 + 3 * t ** 2 + 3 * t + 1) / 6; b3 = t ** 3 / 6
            out.append(b0 * p0 + b1 * p1 + b2 * p2 + b3 * p3)
    if not closed:
        out.append(P[-1])
    return np.array(out)


def _pedit_apply(c, pl, o, fuzz=0.0, extra=None):
    """One PEDIT option on one polyline. Returns the (possibly new) polyline."""
    if o in ("Close", "Open"):
        c.doc.modify(pl)
        if o == "Close" and not pl.closed:
            if len(pl.pts) > 2 and norm(pl.pts[0] - pl.pts[-1]) < 1e-9:
                pl.pts = pl.pts[:-1]; pl.bulges = pl.bulges[:-1]
            pl.closed = True
        elif o == "Open":
            pl.closed = False
        pl.touch()
    elif o == "Width":
        c.doc.modify(pl); pl.width = float(extra or 0.0); pl.touch()
    elif o == "Reverse":
        c.doc.modify(pl)
        n = len(pl.pts); B = np.asarray(pl.bulges, float)
        if pl.closed:
            segs = [B[i] for i in range(n)]
            pl.pts = pl.pts[::-1].copy()
            # segment i of the reversed polyline is old segment (n-2-i) traversed backwards
            nb = np.zeros(n)
            for i in range(n):
                nb[i] = -segs[(n - 2 - i) % n]
            pl.bulges = nb
        else:
            nb = np.zeros(n)
            for i in range(n - 1):
                nb[i] = -B[n - 2 - i]
            pl.pts = pl.pts[::-1].copy(); pl.bulges = nb
        pl.touch()
    elif o in ("Fit", "Spline"):
        c.doc.modify(pl)
        xd = dict(pl.xd or {})
        src = np.array(xd.get("pedit_ctrl")) if xd.get("pedit_ctrl") is not None else pl.pts.copy()
        xd["pedit_ctrl"] = src.tolist(); xd["pedit_closed"] = pl.closed
        pts = _fit_points(src, pl.closed) if o == "Fit" else _spline_points(src, pl.closed)
        pl.pts = pts; pl.bulges = np.zeros(len(pts)); pl.xd = xd; pl.touch()
    elif o == "Decurve":
        c.doc.modify(pl)
        xd = dict(pl.xd or {})
        if xd.get("pedit_ctrl") is not None:
            pl.pts = np.array(xd.pop("pedit_ctrl"), float); xd.pop("pedit_closed", None); pl.xd = xd or None
        pl.bulges = np.zeros(len(pl.pts)); pl.touch()
    return pl


def _join_into(c, pl, others, fuzz):
    """PEDIT Join: lines / arcs / polylines touching the ends (within fuzz) become part of the polyline."""
    cand = [e for e in others if e is not pl and e.kind in ("line", "arc", "polyline") and not getattr(e, "closed", False)]
    if pl.closed or not cand:
        return pl, 0
    if fuzz > 0:                                            # close small gaps by snapping the nearest ends together
        ends = lambda e: (e.p0, e.p1) if e.kind == "line" else (tuple(e.ends()) if e.kind == "arc" else (e.pts[0], e.pts[-1]))
        for e in cand:
            for q in ends(e):
                for i in (0, -1):
                    if 1e-9 < norm(pl.pts[i] - q) <= fuzz:
                        c.doc.modify(pl); pl.pts[i] = np.array(q, float); pl.touch()
    res, used = X.join([pl] + cand, tol=max(1e-6, fuzz * 1e-3))
    if not res or pl not in used:
        return pl, 0
    new = [r for r in res if any(u is pl for u in used)]
    big = max(res, key=lambda r: len(r.pts))
    for u in used:
        c.doc.remove(u)
    for r in res:
        r.layer, r.color, r.ltype, r.lw = pl.layer, pl.color, pl.ltype, pl.lw
        c.doc.add_keep(r)
    return big, len(used) - 1


def _vertex_marker(c, P, i):
    s = c.view.cam.px() * 9
    q = P[i]
    return [E.Line(q + np.array([-s, -s, 0]), q + np.array([s, s, 0])), E.Line(q + np.array([-s, s, 0]), q + np.array([s, -s, 0]))]


def _edit_vertex(c, pl):
    i = 0
    while True:
        P = pl.pts
        c.view.highlight_extra = _vertex_marker(c, P, i); c.view.update()
        opts = ["Next", "Previous", "Insert", "Move", "Remove", "Arc", "Straighten", "eXit"]
        o = yield c.opt(f"Vertex {i + 1}/{len(P)}  Enter a vertex editing option [Next/Previous/Insert/Move/Remove/Arc/Straighten/eXit] <N>",
                        opts, "Next")
        if o is None or o == "eXit":
            c.view.highlight_extra = []; return
        n = len(P)
        if o == "Next":
            i = (i + 1) % n
        elif o == "Previous":
            i = (i - 1) % n
        elif o == "Insert":
            q = yield c.pt("Specify location for new vertex", base=P[i])
            if q is not None:
                c.doc.modify(pl); B = np.asarray(pl.bulges, float).copy(); B[i] = 0
                pl.pts = np.insert(P, i + 1, q, axis=0); pl.bulges = np.insert(B, i + 1, 0.0); pl.touch(); i += 1
        elif o == "Move":
            q = yield c.pt("Specify new location for marked vertex", base=P[i])
            if q is not None:
                c.doc.modify(pl); pl.pts[i] = q; pl.touch()
        elif o == "Remove" and n > 2:
            c.doc.modify(pl); pl.pts = np.delete(P, i, axis=0); pl.bulges = np.delete(np.asarray(pl.bulges, float), i); pl.touch()
            i = min(i, len(pl.pts) - 1)
        elif o in ("Arc", "Straighten"):
            if not pl.closed and i == n - 1:
                c.msg("The last vertex of an open polyline has no following segment"); continue
            if o == "Straighten":
                c.doc.modify(pl); pl.bulges[i] = 0.0; pl.touch()
            else:
                j = (i + 1) % n
                q = yield c.pt("Specify a point the arc passes through", base=P[i],
                               preview=lambda q: [E.Arc.through(P[i], q, P[j])] if E.Arc.through(P[i], q, P[j]) is not None else [])
                if q is not None:
                    from ..ui.viewport import bulge_3p
                    c.doc.modify(pl); pl.bulges[i] = bulge_3p(P[i], q, P[j], pl.n); pl.touch()


def cmd_pedit(c):
    filt = lambda e: e.kind in ("polyline", "line", "arc") and not getattr(e, "is3d", False)
    pre = [c.doc.ents[i] for i in list(c.view.selection) if i in c.doc.ents]      # pick-first: use the selected objects
    pre = [e for e in pre if filt(e)]
    if len(pre) == 1:
        s = (pre[0], pre[0].pts[0] if pre[0].kind == "polyline" else None)
    elif len(pre) > 1:
        s = "Multiple"
    else:
        s = yield c.ent("PEDIT  Select polyline or [Multiple]", filt=filt, options=["Multiple"])
    if s is None:
        return
    if s == "Multiple":
        ents = pre if len(pre) > 1 else (yield c.sel("Select polylines, lines and arcs", filt=filt))
        c.app.clear_selection(silent=True)
        if not ents:
            return
        if any(e.kind != "polyline" for e in ents):
            a = yield c.opt("Convert Lines, Arcs and Splines to polylines [Yes/No]? <Y>", ["Yes", "No"], "Yes")
            if a == "Yes":
                conv = []
                for e in ents:
                    if e.kind == "polyline":
                        conv.append(e); continue
                    pl = to_polyline(e)
                    if pl is not None:
                        c.doc.remove(e); c.doc.add_keep(pl); conv.append(pl)
                ents = conv
        ents = [e for e in ents if e.kind == "polyline"]
        while ents:
            opts = ["Close", "Open", "Join", "Width", "Fit", "Spline", "Decurve", "Reverse"]
            o = yield c.opt("Enter an option [Close/Open/Join/Width/Fit/Spline/Decurve/Reverse]", opts, None)
            if o is None:
                return
            if o == "Join":
                fz = yield c.dist("Enter fuzz distance <0>", default=0.0)
                fz = float(fz or 0.0); total = 0; pool = list(ents); keep = []
                while pool:
                    pl = pool.pop(0)
                    if pl.id not in c.doc.ents:
                        continue
                    big, k = _join_into(c, pl, [e for e in pool if e.id in c.doc.ents], fz); total += k; keep.append(big)
                ents = [e for e in keep if e.id in c.doc.ents]
                c.msg(f"{total} segment(s) joined"); continue
            w = None
            if o == "Width":
                w = yield c.dist("Specify new width for all segments", default=0.0)
            for pl in ents:
                _pedit_apply(c, pl, o, extra=w)
        return
    e = s[0]
    if e.kind != "polyline":
        a = yield c.opt("Object selected is not a polyline. Do you want to turn it into one? [Yes/No] <Y>", ["Yes", "No"], "Yes")
        if a != "Yes":
            return
        pl = to_polyline(e)
        if pl is None:
            return
        c.doc.remove(e); c.doc.add_keep(pl); e = pl
    pl = e
    c.app.clear_selection(silent=True)
    while True:
        c.view.highlight_extra = [pl]; c.view.update()          # show which polyline is edited (not a selection: Join asks for one)
        opts = ["Open" if pl.closed else "Close", "Join", "Width", "Edit vertex", "Fit", "Spline", "Decurve", "Reverse"]
        o = yield c.opt(f"Enter an option [{'/'.join(opts)}]", opts, None)
        if o is None:
            c.view.highlight_extra = []; return
        if o == "Join":
            others = yield c.sel("Select objects to join (lines, arcs, polylines touching the ends)")
            fz = 0.0
            if others:
                big, k = _join_into(c, pl, others, fz)
                pl = big; c.msg(f"{k} segment(s) added to the polyline")
            continue
        if o == "Edit vertex":
            yield from _edit_vertex(c, pl); continue
        w = None
        if o == "Width":
            w = yield c.dist(f"Specify new width for all segments <{pl.width:g}>", default=pl.width)
        pl = _pedit_apply(c, pl, o, extra=w)


def cmd_plquick(c):
    """Shortcut-menu polyline operations on the selected objects: Close, Open, Join, Reverse, Width, Fit, Spline, Decurve."""
    o = getattr(c.app, "_plq", None) or "Close"; c.app._plq = None
    filt = lambda e: e.kind in ("polyline", "line", "arc") and not getattr(e, "is3d", False)
    ents = [c.doc.ents[i] for i in list(c.view.selection) if i in c.doc.ents and filt(c.doc.ents[i])]
    if not ents:
        ents = yield c.sel(f"Polyline {o}: select polylines", filt=filt)
        if not ents:
            return
    c.app.clear_selection(silent=True)
    conv = []
    for e in ents:
        if e.kind != "polyline":
            pl = to_polyline(e)
            if pl is None:
                continue
            c.doc.remove(e); c.doc.add_keep(pl); e = pl
        conv.append(e)
    if o == "Join":
        pool = list(conv); total = 0; keep = []
        while pool:
            pl = pool.pop(0)
            if pl.id not in c.doc.ents:
                continue
            big, k = _join_into(c, pl, [e for e in pool if e.id in c.doc.ents], 0.0); total += k; keep.append(big)
        c.msg(f"{total} segment(s) joined"); c.app.set_selection([e.id for e in keep if e.id in c.doc.ents]); return
    w = None
    if o == "Width":
        w = yield c.dist(f"Specify new width for all segments <{conv[0].width:g}>", default=conv[0].width)
        if w is None:
            return
    out = [_pedit_apply(c, pl, o, extra=w) for pl in conv]
    c.msg(f"{o}: {len(out)} polyline(s)")
    c.app.set_selection([e.id for e in out if e is not None and e.id in c.doc.ents])


# ===================================================================================================== SCALE
def _copies(ents, M):
    out = []
    for e in ents:
        k = e.copy(); k.transform(M); out.append(k)
    return out


def _bbox(ents):
    bb = None
    for e in ents:
        try:
            b = e.bbox()
        except Exception:
            b = None
        if b is None:
            continue
        bb = (np.minimum(bb[0], b[0]), np.maximum(bb[1], b[1])) if bb else (np.array(b[0], float), np.array(b[1], float))
    return bb


def cmd_scale(c):
    ents = yield c.sel("SCALE  Select objects")
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    bb = _bbox(ents)
    ref = 1.0
    if bb is not None:
        corners = np.array([[bb[i][0], bb[j][1], b[2]] for i in (0, 1) for j in (0, 1)])
        ref = max(float(np.max(np.linalg.norm(corners - b, axis=1))), 1e-9)
    copy = False
    def label(q, f):
        h = c.view.cam.px() * 13
        t = E.Text(q + np.array([h * 1.2, h * 0.8, 0]), f"x{f:.4g}", h, (1, 0, 0), (0, 0, 1), 0, 0)
        return t
    while True:
        def pv(q):
            f = max(norm(q - b) / ref, 1e-6)
            return _copies(ents, m_scale(b, f)) + [E.Line(b, q), label(q, f)]
        r = c.pt(f"Specify scale factor or [Copy/Reference/Fit]  (drag: the farthest corner of the selection follows the cursor)",
                 base=b, preview=pv, options=["Copy", "Reference", "Fit"])
        r.numeric = True
        f = yield r
        if f is None:
            return
        if f == "Copy":
            copy = True; c.msg("Scaling a copy of the selected objects"); continue
        if f == "Reference":
            r1 = yield c.dist("Specify reference length <1> (or pick 2 points)", default=1.0)
            if r1 is None or float(r1) <= 0:
                return
            r1 = float(r1)
            def pv2(q):
                ff = max(norm(q - b) / r1, 1e-6)
                return _copies(ents, m_scale(b, ff)) + [E.Line(b, q), label(q, ff)]
            q = c.pt("Specify new length or [Points]", base=b, preview=pv2, options=["Points"]); q.numeric = True
            r2 = yield q
            if r2 is None:
                return
            if r2 == "Points":
                a1 = yield c.pt("Specify first point")
                if a1 is None:
                    return
                a2 = yield c.pt("Specify second point", base=a1, preview=lambda z: [E.Line(a1, z)])
                if a2 is None:
                    return
                r2 = norm(a2 - a1)
            elif not isinstance(r2, (int, float)):
                r2 = norm(np.asarray(r2, float) - b)
            f = float(r2) / r1
        elif f == "Fit":
            if bb is None:
                return
            c.msg("Fit: give the frame the selection must fit into (e.g. the inside of a title block border)")
            f1 = yield c.pt("Specify first corner of the target frame")
            if f1 is None:
                return
            f2 = yield c.corner("Specify opposite corner of the target frame", f1)
            if f2 is None:
                return
            W = abs(f2[0] - f1[0]); H = abs(f2[1] - f1[1]); w = bb[1][0] - bb[0][0]; h = bb[1][1] - bb[0][1]
            if w <= 0 and h <= 0:
                return
            f = min(W / w if w > 1e-12 else 1e30, H / h if h > 1e-12 else 1e30)
            ctr_t = (np.asarray(f1, float) + np.asarray(f2, float)) / 2; ctr_s = (bb[0] + bb[1]) / 2
            M = m_translate(np.array([ctr_t[0] - ctr_s[0] * 1.0, ctr_t[1] - ctr_s[1] * 1.0, 0])) @ m_scale(np.array([ctr_s[0], ctr_s[1], b[2]]), f)
            targets = [e.copy() for e in ents] if copy else ents
            for e in targets:
                if not copy:
                    c.doc.modify(e)
                e.transform(M)
                if copy:
                    c.doc.add_keep(e)
            c.msg(f"Scaled by {f:.6g} and centred in the frame"); return
        elif not isinstance(f, (int, float)):
            f = norm(np.asarray(f, float) - b) / ref
        f = float(f)
        if f <= 0:
            c.msg("The scale factor must be greater than zero"); continue
        M = m_scale(b, f)
        if copy:
            for k in _copies(ents, M):
                c.doc.add_keep(k)
        else:
            for e in ents:
                c.doc.modify(e); e.transform(M)
        c.msg(f"Scale factor {f:.6g}")
        return


# ===================================================================================================== HATCH (pick points) / BOUNDARY
def _area_curves(c, pl):
    """Line work of the visible objects in the UCS plane, as 2D polylines (local coordinates)."""
    out = []
    v = c.view
    try:
        x0, y0, x1, y1 = 0, 0, v.width(), v.height()
        corners = [v.cam.screen_to_plane(x, y, pl) for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))]
        loc = np.array([pl.to_local(q)[:2] for q in corners if q is not None])
        win = (loc.min(axis=0), loc.max(axis=0)) if len(loc) == 4 else None
    except Exception:
        win = None
    for e in c.doc.visible_ents():
        if e.kind not in ("line", "arc", "circle", "polyline", "spline", "ellipse", "insert", "leader"):
            continue
        if e.kind == "line" and ((e.xd and e.xd.get("inf")) or float(np.abs(e.p1 - e.p0).max()) > 1.0e6):
            # construction line (XLINE / RAY): only its part inside the view (+ margin) bounds the area
            if win is None:
                continue
            Q = pl.to_local(np.array([e.p0, e.p1], float))
            if np.max(np.abs(Q[:, 2])) > 1e-4 * max(1.0, float(np.ptp(Q[:, :2]))):
                continue
            pad = (win[1] - win[0]) * 0.5; lo = win[0] - pad; hi = win[1] + pad
            a = Q[0, :2]; d = Q[1, :2] - a; t0, t1 = 0.0, 1.0; ok = True
            for k in (0, 1):                                  # Liang-Barsky clip
                if abs(d[k]) < 1e-300:
                    ok = ok and lo[k] <= a[k] <= hi[k]
                else:
                    ta, tb = (lo[k] - a[k]) / d[k], (hi[k] - a[k]) / d[k]
                    t0, t1 = max(t0, min(ta, tb)), min(t1, max(ta, tb))
            if ok and t1 > t0:
                out.append(np.array([a + d * t0, a + d * t1]))
            continue
        try:
            wires = e.wire() if not (e.kind == "insert" and e.heavy()) else list(e.full_segments())
        except Exception:
            continue
        for w in wires:
            Q = pl.to_local(np.asarray(w, float))
            if len(Q) < 2 or np.max(np.abs(Q[:, 2])) > 1e-4 * max(1.0, float(np.ptp(Q[:, :2]))):
                continue
            if win is not None:
                mn = Q[:, :2].min(axis=0); mx = Q[:, :2].max(axis=0)
                pad = (win[1] - win[0]) * 0.5
                if mx[0] < win[0][0] - pad[0] or mn[0] > win[1][0] + pad[0] or mx[1] < win[0][1] - pad[1] or mn[1] > win[1][1] + pad[1]:
                    continue
            out.append(Q[:, :2])
    return out


def boundary_at(c, p):
    from ..core.boundary import find_boundary
    pl = Plane(c.ucs.o, c.ucs.x, c.ucs.y)
    curves = _area_curves(c, pl)
    q = pl.to_local(np.asarray(p, float))[:2]
    loops = find_boundary(curves, q)
    if not loops:
        return None, pl
    return [pl.to_world(np.column_stack([L, np.zeros(len(L))])) for L in loops], pl


def cmd_hatch(c):
    from .misc import ensure_scale
    ensure_scale(c)
    opt = c.app.dialog_hatch()
    if not opt:
        return
    made = []
    while True:
        s = yield c.pt("HATCH  Pick internal point or [Select objects/Undo]  (Enter = done)", options=["Select objects", "Undo"])
        if s is None:
            break
        if s == "Undo":
            if made:
                c.doc.remove(made.pop())
            continue
        if s == "Select objects":
            ents = yield c.sel("Select closed boundary objects (outer + inner islands)", filt=lambda e: getattr(e, "closed", False))
            if ents:
                from ..core.solids import regions_from_curves
                from ..core import assoc
                regs = regions_from_curves(ents, c.ucs)
                for plane, loops in regs:
                    h = E.Hatch([plane.to_world(l) for l in loops], plane.z, opt["pattern"], opt["scale"] * E.Entity.anno_scale, opt["angle"])
                    h.layer = "HATCH" if c.doc.cur_layer == "0" else c.doc.cur_layer
                    c.doc.add_keep(h); made.append(h)
                    if opt.get("assoc", True):                 # associative: the hatch follows its boundary objects
                        pl2 = Plane(plane.o, plane.x, plane.y)
                        src = assoc.sources_of(c.doc, [plane.to_world(l) for l in loops], pl2, ents)
                        c.doc.modify(h); assoc.attach(h, src, pl2, None, "objects" if len(regs) == 1 else "pick")
            continue
        loops, pl = boundary_at(c, s)
        if not loops:
            c.msg("No closed boundary around that point - check for gaps, or use Select objects"); continue
        h = E.Hatch(loops, pl.z, opt["pattern"], opt["scale"] * E.Entity.anno_scale, opt["angle"])
        h.layer = "HATCH" if c.doc.cur_layer == "0" else c.doc.cur_layer
        c.doc.add_keep(h); made.append(h)
        if opt.get("assoc", True):                             # associative: the hatch follows its boundary objects
            from ..core import assoc
            src = assoc.sources_of(c.doc, loops, pl)
            c.doc.modify(h); assoc.attach(h, src, pl, s, "pick")
        c.msg(f"Boundary found: {len(loops) - 1} island(s), area {abs(h.area()):.6g}")
    if made:
        c.msg(f"{len(made)} hatch(es) created")


def cmd_boundary(c):
    n = 0
    while True:
        s = yield c.pt("BOUNDARY  Pick internal point  (Enter = done)")
        if s is None:
            break
        loops, pl = boundary_at(c, s)
        if not loops:
            c.msg("No closed boundary around that point"); continue
        for L in loops:
            p = E.Polyline(L, True); c.add(p); n += 1
    c.msg(f"BOUNDARY created {n} polyline(s)")


# ===================================================================================================== SELECT SIMILAR
def _sim_key(e, keys):
    k = [e.kind]
    for x in keys:
        if x == "color":
            k.append(str(e.color))
        elif x == "layer":
            k.append(e.layer)
        elif x == "ltype":
            k.append(e.ltype)
        elif x == "lw":
            k.append(str(e.lw))
        elif x == "name":
            if e.kind == "insert":
                k.append(e.name)
            elif e.kind == "text":
                k.append(f"{getattr(e, 'font', '')}|{round(float(getattr(e, 'hm', 0)), 6)}")
            elif e.kind == "hatch":
                k.append(e.pattern)
            elif e.kind == "body":
                k.append(f"{e.role}|{(e.meta or {}).get('thk', '')}|{(e.meta or {}).get('profile', '')}")
            elif e.kind == "image":
                k.append(e.name)
        elif x == "style":
            if e.kind == "dimension":
                k.append(e.style.get("name", "Standard"))
    return tuple(k)


def cmd_selectsimilar(c):
    keys = list(c.view.opt.get("simsel") or ["layer", "name"])
    while True:
        r = Req("select", "SELECTSIMILAR  Select objects or [SEttings]", options=["SEttings"])
        ents = yield r
        if ents == "SEttings":
            from ..ui.dialogs15 import SimilarSettingsDialog
            d = SimilarSettingsDialog(c.app, keys)
            if d.exec():
                keys = d.value(); c.view.opt["simsel"] = keys; c.app._sync_options()
            continue
        break
    if not ents:
        return
    want = {_sim_key(e, keys) for e in ents}
    hits = [e.id for e in c.doc.visible_ents() if c.doc.selectable(e) and _sim_key(e, keys) in want]
    c.app.after_command(lambda: c.app.set_selection(hits))
    c.msg(f"{len(hits)} similar object(s) selected (same type + {', '.join(keys) or 'type only'})")


# ===================================================================================================== CLIPBOARD
MIME = "application/x-aliefcad-ents"


def _blocks_used(doc, ents):
    names = set(); stack = [e for e in ents]
    while stack:
        e = stack.pop()
        if e.kind == "insert" and e.name in doc.blocks and e.name not in names:
            names.add(e.name); stack.extend(doc.blocks[e.name].ents)
        if e.kind == "array":
            stack.extend(getattr(e, "src", []) or [])
    return names


def clip_put(doc, ents, base):
    from PySide6.QtCore import QMimeData
    from PySide6.QtWidgets import QApplication
    blocks = _blocks_used(doc, ents)
    data = {"base": [float(v) for v in base], "ents": [e.to_dict() for e in ents],
            "blocks": [doc.blocks[n].to_dict() for n in blocks],
            "layers": [doc.layers[l].to_dict() for l in {e.layer for e in ents} | {"0"} if l in doc.layers]}
    md = QMimeData(); md.setData(MIME, json.dumps(data).encode("utf-8"))
    md.setText(f"ALIEF CAD PRO: {len(ents)} object(s)")
    QApplication.clipboard().setMimeData(md)


def clip_get():
    from PySide6.QtWidgets import QApplication
    md = QApplication.clipboard().mimeData()
    if md is None or not md.hasFormat(MIME):
        return None
    try:
        return json.loads(bytes(md.data(MIME)).decode("utf-8"))
    except Exception:
        return None


def _paste_ents(doc, data):
    from ..core.document import Layer
    for ld in data.get("layers", []):
        if ld.get("name") not in doc.layers:
            try:
                doc.layers[ld["name"]] = Layer.from_dict(ld)
            except Exception:
                pass
    for bd in data.get("blocks", []):
        if bd["name"] not in doc.blocks:
            doc.add_block(E.Block.from_dict(bd))
    out = []
    for d in data["ents"]:
        e = E.from_dict(d); e.id = 0; out.append(e)
    return out


def _sel_or_ask(c, prompt):
    ents = yield c.sel(prompt)
    return ents or []


def cmd_copyclip(c, base_pt=False, cut=False):
    ents = yield from _sel_or_ask(c, "Select objects")
    if not ents:
        return
    if base_pt:
        b = yield c.pt("Specify base point")
        if b is None:
            return
    else:
        bb = _bbox(ents); b = bb[0] if bb is not None else np.zeros(3)
    clip_put(c.doc, ents, b)
    if cut:
        for e in ents:
            c.doc.remove(e)
    c.msg(f"{len(ents)} object(s) {'cut' if cut else 'copied'} to the clipboard" + (" with base point" if base_pt else ""))


def cmd_copybase(c):
    yield from cmd_copyclip(c, True)


def cmd_cutclip(c):
    yield from cmd_copyclip(c, False, True)


def cmd_pasteclip(c, as_block=False, original=False):
    data = clip_get()
    if not data:
        c.msg("The clipboard holds no ALIEF CAD PRO objects (copy with Ctrl+C or Ctrl+Shift+C first)"); return
    ents = _paste_ents(c.doc, data); base = np.array(data["base"], float)
    if not ents:
        return
    if original:
        for e in ents:
            c.doc.add_keep(e)
        c.app.after_command(lambda: c.app.set_selection([e.id for e in ents])); c.msg(f"{len(ents)} object(s) pasted at the original position"); return
    if as_block:
        import time
        name = "A$C" + format(int(time.time() * 1000) & 0xFFFFFFFF, "08X")
        while name in c.doc.blocks:
            name += "_"
        loc = []
        for e in ents:
            k = e.copy(); k.transform(m_translate(-base)); loc.append(k)
        c.doc.add_block(E.Block(name, (0, 0, 0), loc))
        ins = E.Insert(name, np.eye(4))
        p = yield c.pt(f"PASTEBLOCK  Specify insertion point (block {name})", preview=lambda q: [_moved(ins, q)])
        if p is None:
            c.doc.blocks.pop(name, None); return
        ins = _moved(ins, p); c.doc.add(ins)
        c.app.after_command(lambda: c.app.set_selection([ins.id]))
        c.msg(f'Pasted as block "{name}" (rename it with RENAME or edit it with a double-click)')
        return
    p = yield c.pt("PASTECLIP  Specify insertion point", preview=lambda q: [_moved(e, q - base) for e in ents])
    if p is None:
        return
    M = m_translate(np.asarray(p, float) - base); ids = []
    for e in ents:
        e.transform(M); c.doc.add_keep(e); ids.append(e.id)
    c.app.after_command(lambda: c.app.set_selection(ids))
    c.msg(f"{len(ents)} object(s) pasted")


def _moved(e, d):
    k = e.copy(); k.transform(m_translate(np.asarray(d, float))); return k


def cmd_pasteblock(c):
    yield from cmd_pasteclip(c, True)


def cmd_pasteorig(c):
    yield from cmd_pasteclip(c, False, True)


# ===================================================================================================== TCOUNT / TNUMBER
def _numfmt(start_txt, n):
    s = str(start_txt).strip()
    width = len(s) if (s.isdigit() and s.startswith("0") and len(s) > 1) else 0
    if abs(n - round(n)) < 1e-9:
        return str(int(round(n))).zfill(width)
    return f"{n:g}"


def cmd_tcount(c):
    ents = yield c.sel("TCOUNT  Select text objects to number", filt=lambda e: e.kind in ("text", "attdef"))
    if not ents:
        return
    srt = yield c.opt("Sort selected objects by [X/Y/Select-order] <Y>", ["X", "Y", "Select-order"], "Y")
    if srt is None:
        return
    s = yield c.text("Specify starting number and increment (Start,increment) <1,1>", "1,1")
    try:
        parts = [p.strip() for p in str(s or "1,1").split(",")]
        start_txt = parts[0] or "1"; start = float(start_txt); inc = float(parts[1]) if len(parts) > 1 and parts[1] else 1.0
    except ValueError:
        c.msg("Use start,increment - for example 1,1 or 101,2"); return
    mode = yield c.opt("Placement of numbers in text [Overwrite/Prefix/Suffix/Find&replace] <Prefix>",
                       ["Overwrite", "Prefix", "Suffix", "Find&replace"], "Prefix")
    if mode is None:
        return
    find = None
    if mode == "Find&replace":
        find = yield c.text("Enter string to find and replace by the numbers", "#")
        if not find:
            return
    def pos(e):
        return np.asarray(getattr(e, "p", np.zeros(3)), float)
    if srt == "X":
        ents = sorted(ents, key=lambda e: (round(pos(e)[0], 6), -pos(e)[1]))
    elif srt == "Y":
        ents = sorted(ents, key=lambda e: (-round(pos(e)[1], 6), pos(e)[0]))
    n = start
    for e in ents:
        num = _numfmt(start_txt, n); c.doc.modify(e)
        attr = "s" if e.kind == "text" else "default"
        old = getattr(e, attr)
        if mode == "Overwrite":
            new = num
        elif mode == "Prefix":
            new = f"{num} {old}"
        elif mode == "Suffix":
            new = f"{old} {num}"
        else:
            new = old.replace(find, num)
        setattr(e, attr, new); e.touch(); n += inc
    c.msg(f"TCOUNT: {len(ents)} text(s) numbered {_numfmt(start_txt, start)} .. {_numfmt(start_txt, n - inc)}")


def cmd_tnumber(c):
    """Place automatic consecutive numbers by clicking (optionally in a circle bubble)."""
    from .misc import ensure_scale
    ensure_scale(c)
    st = c.doc.settings.setdefault("tnumber", {"start": "1", "inc": 1.0, "prefix": "", "suffix": "", "h": 3.5, "bubble": False})
    n = float(st.get("start", "1") or 1); start_txt = st.get("start", "1")
    while True:
        h = float(st.get("h", 3.5)); k = E.Entity.anno_scale
        txt = f"{st.get('prefix', '')}{_numfmt(start_txt, n)}{st.get('suffix', '')}"
        def mk(q, txt=txt):
            t = E.Text(q, txt, h, c.ucs.x, c.ucs.z, 1, 1); t.anno = h; out = [t]
            if st.get("bubble"):
                r = h * k * max(1.0, 0.45 * len(txt) + 0.35)
                out.append(E.Circle(q, r, c.ucs.z))
            return out
        p = yield c.pt(f"TNUMBER  Click position for {txt}  or [Start/Increment/Prefix/Suffix/Height/Bubble]  (Enter = done)",
                       preview=mk, options=["Start", "Increment", "Prefix", "Suffix", "Height", "Bubble"])
        if p is None:
            return
        if isinstance(p, str):
            if p == "Start":
                v = yield c.text(f"Next number <{_numfmt(start_txt, n)}>", _numfmt(start_txt, n))
                try:
                    n = float(v); start_txt = str(v).strip(); st["start"] = start_txt
                except (TypeError, ValueError):
                    pass
            elif p == "Increment":
                v = yield c.num(f"Increment <{st.get('inc', 1.0):g}>", st.get("inc", 1.0))
                if v is not None:
                    st["inc"] = float(v)
            elif p in ("Prefix", "Suffix"):
                v = yield c.text(f"{p} text <{st.get(p.lower(), '')}>", st.get(p.lower(), ""))
                st[p.lower()] = v or ""
            elif p == "Height":
                v = yield c.num(f"Text height on paper (mm) <{h:g}>", h)
                if v:
                    st["h"] = float(v)
            elif p == "Bubble":
                st["bubble"] = not st.get("bubble"); c.msg(f"Bubble {'on' if st['bubble'] else 'off'}")
            continue
        for e in mk(p):
            e.layer = c.doc.cur_layer; c.doc.add(e)
        n += float(st.get("inc", 1.0)); st["start"] = _numfmt(start_txt, n); start_txt = st["start"]


# ===================================================================================================== VIEWPORTS, TOGGLES, SETTINGS
def cmd_vports(c):
    o = yield c.opt("VPORTS  Enter a configuration [Single/2Vertical/2Horizontal/3Right/3Left/3Vertical/3Horizontal/4] <4>",
                    ["Single", "2Vertical", "2Horizontal", "3Right", "3Left", "3Vertical", "3Horizontal", "4"], "4")
    if o is None:
        return
    cfg = {"Single": "Single", "2Vertical": "2V", "2Horizontal": "2H", "3Right": "3R", "3Left": "3L", "3Vertical": "3V",
           "3Horizontal": "3H", "4": "4"}[o]
    c.app.after_command(lambda: c.app.set_vports(cfg))


def _toggle(attr, label):
    @T
    def f(c):
        c.app._set_view_flag(attr, not getattr(c.view, attr))
        c.msg(f"<{label} {'on' if getattr(c.view, attr) else 'off'}>")
    return f


def register(eng):
    R = eng.register
    R("FILLET", cmd_fillet, ["F"], "Fillet lines, arcs, circles, polyline segments; Radius / Trim / Multiple / Polyline; Shift = corner")
    R("CHAMFER", cmd_chamfer, ["CHA"], "Chamfer lines and straight polyline segments; Distance / Trim / Multiple / Polyline")
    R("PLQUICK", cmd_plquick, [], "Polyline shortcut-menu operation on the selection")
    R("PEDIT", cmd_pedit, ["PE"], "Edit polyline: Close / Open / Join / Width / Edit vertex / Fit / Spline / Decurve / Reverse")
    R("SCALE", cmd_scale, ["SC"], "Scale: drag freely, type a factor, Reference (fit a length) or Fit (fit a frame), Copy")
    R("HATCH", cmd_hatch, ["H", "BH", "BHATCH"], "Hatch: pick internal points (islands found automatically) or select objects")
    R("BOUNDARY", cmd_boundary, ["BO", "BPOLY"], "Closed polyline around a picked point")
    R("SELECTSIMILAR", cmd_selectsimilar, ["SSM"], "Select every object similar to the selected ones (type + layer + name ...)")
    R("COPYCLIP", cmd_copyclip, [], "Copy objects to the clipboard (Ctrl+C)")
    R("COPYBASE", cmd_copybase, [], "Copy with base point (Ctrl+Shift+C)")
    R("CUTCLIP", cmd_cutclip, [], "Cut objects to the clipboard (Ctrl+X)")
    R("PASTECLIP", cmd_pasteclip, [], "Paste objects (Ctrl+V)")
    R("PASTEBLOCK", cmd_pasteblock, [], "Paste as a block (Ctrl+Shift+V)")
    R("PASTEORIG", cmd_pasteorig, [], "Paste at the original coordinates")
    R("TCOUNT", cmd_tcount, ["TC", "TCO"], "Number text objects: sort X / Y, start + increment, overwrite / prefix / suffix / find & replace")
    R("TNUMBER", cmd_tnumber, ["TNUM", "AUTONUM"], "Place consecutive numbers by clicking (prefix, suffix, bubble)")
    R("VPORTS", cmd_vports, ["VIEWPORTS", "VPORT"], "Tiled viewports: Single / 2 / 3 / 4 views of the drawing")
    R("POLAR", _toggle("polar_on", "Polar"), ["F10"], "Toggle polar tracking")
    R("OTRACK", _toggle("otrack_on", "Object snap tracking"), ["F11"], "Toggle object snap tracking")
    R("SELECTIONCYCLING", _toggle("sel_cycling", "Selection cycling"), ["SELCYCLE"], "Toggle selection cycling (Ctrl+W)")
    R("DSETTINGS", T(lambda c: c.app.drafting_settings()), ["DS", "SE", "OS", "DDOSNAP", "OSNAPSETTINGS"], "Drafting Settings: snap & grid, polar, object snap, selection")
    R("DIMSTYLE", T(lambda c: c.app.dimstyle_manager()), ["D", "DST", "DDIM", "DSTYLE", "DIMSTY"], "Dimension Style Manager")
