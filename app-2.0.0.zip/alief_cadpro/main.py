"""ALIEF CAD PRO - application entry."""
import os
import sys


def run(boot=None, argv=None):
    argv = list(argv if argv is not None else sys.argv)
    boot = boot or {}
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("AliefEnergy.ALIEF_CADPRO")
        except Exception:
            pass
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    from PySide6.QtCore import Qt, QCoreApplication
    from PySide6.QtGui import QSurfaceFormat, QGuiApplication
    from PySide6.QtWidgets import QApplication, QSplashScreen
    from .ui.viewport import default_format
    fmt = default_format()
    try:
        from PySide6.QtCore import QSettings
        from .ui import options as _opt
        fmt.setSamples(int(_opt.load(QSettings("AliefEnergy", "ALIEF_CADPRO"))[0].get("msaa", 4)))
    except Exception:
        pass
    QSurfaceFormat.setDefaultFormat(fmt)
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication(argv)
    try:
        from .ui.textgeom import load_bundled_fonts
        load_bundled_fonts()
    except Exception:
        pass
    app.setApplicationName("ALIEF CAD PRO"); app.setOrganizationName("AliefEnergy")
    from .ui.brand import splash_pixmap, app_icon
    from .core.document import APP_VERSION
    app.setWindowIcon(app_icon())
    sp = QSplashScreen(splash_pixmap(APP_VERSION)); sp.show(); app.processEvents()
    from .ui import textgeom
    textgeom.install()
    from .ui.mainwindow import MainWindow
    files = [a for a in argv[1:] if os.path.isfile(a)]
    w = MainWindow(boot, files)
    w.resize(1500, 920)
    if os.environ.get("CADPRO_NO_MAX") != "1":
        w.showMaximized()
    else:
        w.show()
    sp.finish(w)
    if boot.get("on_window"):
        boot["on_window"](w)
    if os.environ.get("CADPRO_SELFTEST"):
        from PySide6.QtCore import QTimer
        from . import selftest
        QTimer.singleShot(2500, lambda: selftest.run(w, os.environ["CADPRO_SELFTEST"]))
    return app.exec()


if __name__ == "__main__":
    sys.exit(run())
