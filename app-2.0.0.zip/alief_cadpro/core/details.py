"""Standard structural connection details (frame connections) - parametric 2D detail drawings + bracket sizing.

Bracket scantlings follow the BKI / IACS-type bracket formula (BKI Rules Pt.1 Vol.II Sec.3 D.2, same structure in
DNV / ABS / LR rules); workmanship details (slots, collars, scallops, snipes) follow IACS Recommendation 47
(Shipbuilding and Repair Quality Standard). Always check the result against the rule edition of the project."""
import math
import numpy as np
from .ship import section_loops, loops_area_centroid, MATERIALS, size_label
from .entities import Line, Arc, Circle, Polyline, Text, Hatch, Dimension, Leader, Entity
from .geom import Plane

K_FACTOR = {235: 1.0, 315: 0.78, 355: 0.72, 390: 0.68, 245: 1.0}


def material_k(grade):
    reh = MATERIALS.get(grade, (7850, 235))[1]
    return K_FACTOR.get(reh, 235.0 / max(reh, 1))


def section_modulus(ptype, dims, plate_t=10.0, plate_b=600.0):
    """Section modulus (cm3) of the profile with attached plating, about the neutral axis (plate at t<0)."""
    loops = [np.asarray(l, float) for l in section_loops(ptype, dims)]
    pts = []
    # numerical integration on polygons: A, Sy, Iyy (about s-axis, i.e. bending of the web)
    def props(loop):
        x, y = loop[:, 0], loop[:, 1]; x1, y1 = np.roll(x, -1), np.roll(y, -1)
        cr = x * y1 - x1 * y
        A = cr.sum() / 2; Sy = ((y + y1) * cr).sum() / 6; Iy = ((y * y + y * y1 + y1 * y1) * cr).sum() / 12
        return A, Sy, Iy
    A = Sy = Iy = 0.0
    for l in loops:
        a, s, i = props(l); A += a; Sy += s; Iy += i
    top = max(l[:, 1].max() for l in loops)
    # attached plate
    if plate_t > 0 and plate_b > 0:
        Ap = plate_t * plate_b; yp = -plate_t / 2
        A += Ap; Sy += Ap * yp; Iy += plate_b * plate_t ** 3 / 12 + Ap * yp * yp
    yc = Sy / A
    I = Iy - A * yc * yc
    e = max(top - yc, yc + plate_t)
    return I / e / 1000.0, I / 1e4, A / 100.0       # W cm3, I cm4, A cm2


def bracket_size(W, grade="A (NS)", t_asbuilt=None, flanged=False, tk=1.5):
    """Return dict(t_req, t, l, b_flange, need_flange) for a bracket connecting a member with modulus W (cm3)."""
    k = material_k(grade)
    c = 0.95 if flanged else 1.2
    t_req = c * (W / k) ** (1 / 3) + tk
    t_req = max(t_req, 6.0)
    t = t_asbuilt or math.ceil(t_req * 2) / 2
    ct = math.sqrt(t_req / t)
    l = max(100.0, 46.2 * (W / k) ** (1 / 3) * ct)
    l = math.ceil(l / 5) * 5
    b = min(90.0, max(50.0, 40 + W / 30))
    need = (l * math.sqrt(2)) > 50 * t       # free edge length > 50 t -> flange or edge stiffener
    return {"t_req": round(t_req, 2), "t": t, "l": l, "b": math.ceil(b / 5) * 5, "need_flange": need, "k": k}


DETAIL_TYPES = ["Knee bracket (frame - beam)", "Bilge bracket (frame - floor)", "Tripping bracket", "End bracket to bulkhead",
                "Slot - open (stiffener through web)", "Slot with lug / collar plate", "Watertight collar",
                "Scallop / drain hole", "Stiffener end snipe"]


class DetailBuilder:
    """Geometry at true size; text / dimensions sized for the detail scale 1:ds (block is scaled when inserted)."""
    def __init__(self, pl, ds=10.0):
        self.pl = pl; self.out = []; self.ds = float(ds)

    def P(self, x, y):
        return self.pl.to_world(np.array([x, y, 0.0]))

    def line(self, x1, y1, x2, y2, layer="DETAIL", color=256):
        e = Line(self.P(x1, y1), self.P(x2, y2)); e.layer = layer; e.color = color; self.out.append(e); return e

    def poly(self, pts, closed=False, layer="DETAIL", color=256, bulges=None):
        e = Polyline(np.array([self.P(x, y) for x, y in pts]), closed, bulges, self.pl.z); e.layer = layer; e.color = color
        self.out.append(e); return e

    def hatch(self, pts, layer="DETAIL", color=8, pattern="ANSI31", scale=0.5):
        e = Hatch([np.array([self.P(x, y) for x, y in pts])], self.pl.z, pattern, scale * self.ds); e.layer = layer; e.color = color
        self.out.append(e); return e

    def text(self, x, y, s, h=2.5, ha=0, va=0, layer="TEXT", color=256):
        t = Text(self.P(x, y), s, h * self.ds, self.pl.x, self.pl.z, ha, va)
        t.layer = layer; t.color = color; self.out.append(t); return t

    def dim(self, a, b, loc, layer="DIMENSION"):
        k = self.ds
        st = {"anno": False, "th": 2.5 * k, "asz": 2.5 * k, "exo": 1.25 * k, "exe": 1.25 * k, "gap": 0.8 * k}
        d = Dimension("aligned", [self.P(*a), self.P(*b), self.P(*loc)], self.pl.z, self.pl.x, st); d.layer = layer
        self.out.append(d); return d

    def leader(self, pts, s, layer="DIMENSION"):
        L = Leader([self.P(x, y) for x, y in pts], s, 2.5 * self.ds, self.pl.z, 2.5 * self.ds); L.layer = layer
        self.out.append(L); return L

    def section(self, ptype, dims, x0, y0, rot=0.0, flip=False, color=30):
        """Draw a profile cross section outline + hatch at (x0, y0)."""
        loops = section_loops(ptype, dims)
        ca, sa = math.cos(math.radians(rot)), math.sin(math.radians(rot))
        for l in loops:
            q = np.asarray(l, float)
            if flip:
                q = q * [-1, 1]
            q = np.stack([ca * q[:, 0] - sa * q[:, 1] + x0, sa * q[:, 0] + ca * q[:, 1] + y0], axis=1)
            self.poly([tuple(p) for p in q], True, "DETAIL", color)
        q = np.asarray(loops[0], float)
        if flip:
            q = q * [-1, 1]
        q = np.stack([ca * q[:, 0] - sa * q[:, 1] + x0, sa * q[:, 0] + ca * q[:, 1] + y0], axis=1)
        self.hatch([tuple(p) for p in q], color=8, pattern="SOLID" if max(dims.values()) < 40 else "ANSI31", scale=0.4)


def build_detail(kind, pl, ptype, dims, grade, plate_t, web_t, t_br=None, flanged=None, rule="BKI / IACS", ds=10.0):
    """Return (entities, info dict). ds = detail scale 1:ds (text / dimension size)."""
    B = DetailBuilder(pl, ds)
    W, I, A = section_modulus(ptype, dims, plate_t)
    br = bracket_size(W, grade, t_br, bool(flanged))
    if flanged is None:
        flanged = br["need_flange"]
        br = bracket_size(W, grade, t_br, flanged)
    h = float(dims.get("h", dims.get("D", 100))); tw = float(dims.get("t", dims.get("tw", 10)))
    sz = size_label(ptype, dims)
    l = br["l"]; t = br["t"]; bf = br["b"]
    info = {"W": W, "I": I, "A": A, **br, "size": sz}
    title = kind.upper()
    notes = []
    if kind.startswith("Knee") or kind.startswith("Bilge") or kind.startswith("End bracket"):
        L = max(2.6 * l, l + 2.2 * h)
        # vertical member (frame) along x = 0 .. h (web seen in elevation: thickness drawn as band)
        if kind.startswith("Bilge"):
            # floor plate: horizontal band of height = floor height
            fh = max(h * 2.5, l * 1.1)
            B.poly([(0, 0), (L, 0), (L, fh), (0, fh)], True); B.text(L * 0.6, fh / 2, "FLOOR PLATE", 2.5, 1, 2)
            B.poly([(-plate_t, 0), (0, 0), (0, L + fh), (-plate_t, L + fh)], True); B.text(-plate_t - 6, fh + L * 0.6, "SHELL", 2.5, 2, 2)
            y0 = fh
            B.poly([(0, y0), (h, y0), (h, y0 + L), (0, y0 + L)], True); B.text(h / 2, y0 + L * 0.85, "FRAME " + sz, 2.0, 1, 2)
            tri = [(h, y0 + l), (h, y0), (h + l, y0)]
            ox, oy = h, y0
        else:
            B.poly([(-plate_t, -plate_t), (L, -plate_t), (L, 0), (0, 0), (0, L), (-plate_t, L)], True)
            B.hatch([(-plate_t, -plate_t), (L, -plate_t), (L, 0), (0, 0), (0, L), (-plate_t, L)], pattern="SOLID", color=8)
            B.poly([(0, 0), (h, 0), (h, L), (0, L)], True)
            B.poly([(h, 0), (L, 0), (L, h), (h, h)], True)
            lab1 = "FRAME " if kind.startswith("Knee") else "STIFFENER "
            B.text(h / 2, L * 0.82, lab1 + sz, 2.0, 1, 2); B.text(L * 0.8, h / 2, ("BEAM " if kind.startswith("Knee") else "BULKHEAD STIFF. ") + sz, 2.0, 1, 2)
            B.text(-plate_t - 8, L * 0.5, "SHELL / BHD PLATE", 2.0, 2, 2)
            tri = [(h, h + l), (h, h), (h + l, h)]
            ox, oy = h, h
        snip = min(25.0, max(15.0, t * 1.5))
        a1 = (ox, oy + l); a2 = (ox + l, oy)
        # bracket with sniped toes
        pts = [(ox, oy + l), (ox, oy), (ox + l, oy), (ox + l, oy + snip), (ox + snip, oy + l)]
        B.poly(pts, True, "DETAIL", 4)
        B.hatch(pts, color=4, pattern="ANSI31", scale=0.6)
        if flanged:
            d = bf * 0.7071
            B.poly([(ox + l, oy + snip), (ox + l + d * 0.25, oy + snip + d * 0.25), (ox + snip + d * 0.25, oy + l + d * 0.25), (ox + snip, oy + l)], True, "DETAIL", 4)
        B.dim((ox, oy), (ox + l, oy), (ox + l / 2, oy - 0.25 * l))
        B.dim((ox, oy), (ox, oy + l), (ox - 0.25 * l, oy + l / 2))
        B.leader([(ox + l * 0.45, oy + l * 0.25), (ox + l * 1.2, oy + l * 1.25), (ox + l * 1.5, oy + l * 1.25)],
                 f"BKT {t:g} mm {grade}" + (f" FL {bf:g}x{t:g}" if flanged else ""))
        notes = [f"Member: {sz}, attached plate {plate_t:g} mm, W = {W:.1f} cm3 (incl. plating 600 mm)",
                 f"Bracket: t_req = {br['t_req']:.2f} mm -> t = {t:g} mm, arm l = {l:g} mm" + (f", flange b = {bf:g} mm" if flanged else ""),
                 f"Rule: t = c x (W/k)^1/3 + tK, l = 46.2 x (W/k)^1/3 x (t_req/t)^0.5 (c = {0.95 if flanged else 1.2}, k = {br['k']:.2f}) - {rule}",
                 "Toes sniped " + f"{snip:g} mm; free edge flanged / stiffened when free edge > 50 t",
                 "Weld: double continuous fillet, a = 0.35 t (min 3.5 mm) all round",
                 "Ref: IACS Rec. 47 - shipbuilding & repair quality standard"]
    elif kind == "Tripping bracket":
        H = h * 1.8
        B.poly([(-h * 1.6, -plate_t), (h * 2.6, -plate_t), (h * 2.6, 0), (-h * 1.6, 0)], True)
        B.hatch([(-h * 1.6, -plate_t), (h * 2.6, -plate_t), (h * 2.6, 0), (-h * 1.6, 0)], pattern="SOLID", color=8)
        B.section(ptype, dims, 0, 0)
        bh = h * 0.95; bl = max(h * 1.0, l * 0.6)
        flange_out = float(dims.get("b", dims.get("c", 0)))
        x0 = max(tw, flange_out) + 1
        pts = [(tw, 0), (tw + bl, 0), (tw + bl, min(25, bl * 0.15)), (tw + 15, bh), (tw, bh)]
        B.poly(pts, True, "DETAIL", 4); B.hatch(pts, color=4, scale=0.6)
        B.dim((tw, 0), (tw + bl, 0), (tw + bl / 2, -plate_t - 0.3 * bh))
        B.dim((tw + bl, 0), (tw + bl, bh), (tw + bl + 0.3 * bl, bh / 2))
        B.leader([(tw + bl * 0.4, bh * 0.35), (tw + bl * 1.3, bh * 1.2), (tw + bl * 1.6, bh * 1.2)], f"TRIPPING BKT {t:g} mm")
        notes = [f"Stiffener {sz} on {plate_t:g} mm plate; tripping bracket t = {t:g} mm", "Spacing of tripping brackets per rule (approx. every 3 m / 4 frames)",
                 "Bracket toe sniped, weld double continuous fillet", "Ref: IACS Rec. 47 / " + rule]
    elif kind.startswith("Slot") or kind == "Watertight collar":
        gap = 2.0
        Wf = max(h * 3.2, 260); Hf = h * 2.4
        flange_w = float(dims.get("b", 0)) if ptype in ("L", "T", "C") else (float(dims.get("c", 0)) + tw if ptype == "BP" else tw)
        if ptype == "T":
            s0, s1 = -flange_w / 2 - gap, flange_w / 2 + gap
        else:
            s0, s1 = -gap, max(flange_w, tw) + gap
        top = h + gap + 25 if kind.startswith("Slot - open") else h + gap
        R = min(25.0, (s1 - s0) / 2)
        wx0, wx1 = -Wf / 2, Wf / 2
        # web frame outline with slot (bottom on plating)
        out = [(wx0, 0), (s0 - 20 if kind != "Watertight collar" else s0, 0)]
        if kind == "Watertight collar":
            out = [(wx0, 0), (s0, 0), (s0, top), (s1, top), (s1, 0), (wx1, 0)]
        else:
            out += [(s0 - 20, 0), (s0, 20)] if False else []
            out += [(s0, 0), (s0, top - R), (s0 + R, top), (s1 - R, top), (s1, top - R), (s1, 0), (wx1, 0)]
        out += [(wx1, Hf), (wx0, Hf)]
        B.poly(out, True, "DETAIL", 3)
        B.text(wx0 + 10, Hf - 12, "WEB FRAME / FLOOR t = " + f"{web_t:g}", 2.0, 0, 1)
        B.poly([(wx0 - 20, -plate_t), (wx1 + 20, -plate_t), (wx1 + 20, 0), (wx0 - 20, 0)], True)
        B.hatch([(wx0 - 20, -plate_t), (wx1 + 20, -plate_t), (wx1 + 20, 0), (wx0 - 20, 0)], pattern="SOLID", color=8)
        B.section(ptype, dims, 0, 0)
        if kind.startswith("Slot with lug") or kind == "Watertight collar":
            lap = 50.0
            if kind == "Watertight collar":
                cl = [(s0 - lap, 0), (s0, 0), (s0, top), (s1, top), (s1, 0), (s1 + lap, 0), (s1 + lap, top + lap), (s0 - lap, top + lap)]
                B.poly(cl, True, "DETAIL", 6); B.text(s1 + lap + 6, top + lap - 4, f"COLLAR PLATE t = {web_t:g}, lap {lap:g}", 2.0, 0, 1, color=6)
            else:
                lug = [(s1, 0), (s1 + lap + 20, 0), (s1 + lap + 20, top + 20), (tw + gap, top + 20), (tw + gap, top)]
                B.poly(lug, False, "DETAIL", 6); B.text(s1 + lap + 26, top + 10, f"LUG / COLLAR t = {web_t:g}", 2.0, 0, 1, color=6)
        B.dim((s0, 0), (s1, 0), ((s0 + s1) / 2, -plate_t - 30))
        B.dim((s1, 0), (s1, top), (s1 + 40, top / 2))
        notes = [f"Stiffener {sz}: slot width = profile + 2 x {gap:g} mm clearance, slot height = {top:g} mm, R{R:g}",
                 "Max gap between collar / lug and stiffener 2 mm (IACS Rec. 47 standard), lap >= 50 mm",
                 "Web / lug welded to stiffener web and plating, double continuous fillet",
                 "Watertight collar: full penetration or double fillet all round, tested" if kind == "Watertight collar" else
                 "Open slots in way of high shear areas to be collared per rule", "Ref: IACS Rec. 47 / " + rule]
    elif kind.startswith("Scallop"):
        R = 35.0 if h <= 200 else 50.0
        B.poly([(-200, -plate_t), (200, -plate_t), (200, 0), (-200, 0)], True); B.hatch([(-200, -plate_t), (200, -plate_t), (200, 0), (-200, 0)], pattern="SOLID", color=8)
        B.poly([(-200, 0), (-R, 0)]); B.poly([(R, 0), (200, 0)])
        arc = Arc(B.P(0, 0), R, 0, math.pi, pl.z); arc.layer = "DETAIL"; B.out.append(arc)
        B.poly([(-200, 0), (-200, h * 1.4), (200, h * 1.4), (200, 0)], False, "DETAIL", 3)
        B.text(-190, h * 1.4 - 10, "WEB / FLOOR", 2.0, 0, 1)
        B.leader([(R * 0.7, R * 0.7), (R * 2.6, R * 2.6), (R * 3.4, R * 2.6)], f"SCALLOP / DRAIN HOLE R{R:g}")
        notes = [f"Scallop / drain hole R{R:g} mm (R35 for h <= 200, R50 above)", "Not in way of end connections / high stress areas, min. 200 mm from butts",
                 "Ref: IACS Rec. 47"]
    elif kind.startswith("Stiffener end snipe"):
        land = min(30.0, max(15.0, tw * 1.5)); ang = 30.0
        L = h * 3
        x_end = L
        xs = x_end - (h - land) / math.tan(math.radians(ang))
        B.poly([(-50, -plate_t), (L + 80, -plate_t), (L + 80, 0), (-50, 0)], True); B.hatch([(-50, -plate_t), (L + 80, -plate_t), (L + 80, 0), (-50, 0)], pattern="SOLID", color=8)
        B.poly([(0, 0), (x_end, 0), (x_end, land), (xs, h), (0, h)], False, "DETAIL", 30)
        B.dim((x_end, 0), (x_end, land), (x_end + 40, land / 2))
        B.text(xs + 4, h + 6, f"{ang:g}° max", 2.0, 0, 0)
        notes = [f"Snipe angle <= {ang:g}°, land = {land:g} mm (15 mm min., max 30 mm)", f"Stiffener {sz}", "Ref: IACS Rec. 47"]
    # title and notes block
    bb_pts = np.array([e.p0 if hasattr(e, "p0") else (e.pts[0] if hasattr(e, "pts") and len(e.pts) else pl.o) for e in B.out if hasattr(e, "p0") or (hasattr(e, "pts") and len(e.pts))])
    loc = pl.to_local(bb_pts)
    x0, y0 = loc[:, 0].min(), loc[:, 1].min()
    k = ds
    B.text(x0, y0 - 14 * k, "DETAIL : " + title + f"   (SCALE 1:{ds:g})", 3.5, 0, 0)
    for i, n in enumerate(notes):
        B.text(x0, y0 - (22 + 6 * i) * k, f"{i + 1}. {n}", 2.0, 0, 0)
    return B.out, info
