"""Geometry kernel helpers (numpy, float64).

Curves are described by *primitives*:
    ('L', p0, p1)                        straight segment
    ('A', c, r, n, u, a0, a1)            circular arc, CCW about n from a0 to a1 (a1 > a0), v = n x u
Every curve entity returns its primitives in traversal order, so arc-length parameters are consistent.
"""
import math
import numpy as np

EPS = 1e-9
TAU = 2 * math.pi
X = np.array([1.0, 0, 0]); Y = np.array([0, 1.0, 0]); Z = np.array([0, 0, 1.0])


def v3(p):
    a = np.asarray(p, dtype=float).ravel()
    if a.size == 2:
        return np.array([a[0], a[1], 0.0])
    return a[:3].astype(float).copy()


def unit(v):
    v = np.asarray(v, dtype=float)
    n = math.sqrt(float(v @ v)) if v.ndim == 1 else np.linalg.norm(v)
    return v / n if n > EPS else v * 0.0


def norm(v):
    v = np.asarray(v, dtype=float)
    if v.ndim == 1:
        return math.sqrt(float(v @ v))
    return float(np.linalg.norm(v))


def cross(a, b):
    """Cross product; much faster than np.cross for two single 3-vectors (the usual case here)."""
    if getattr(a, "ndim", 0) == 1 and getattr(b, "ndim", 0) == 1 and len(a) == 3 and len(b) == 3:
        a0, a1, a2 = a; b0, b1, b2 = b
        return np.array([a1 * b2 - a2 * b1, a2 * b0 - a0 * b2, a0 * b1 - a1 * b0])
    return np.cross(a, b)


def is_translation(M):
    R = M[:3, :3]
    return R[0, 0] == 1.0 and R[1, 1] == 1.0 and R[2, 2] == 1.0 and R[0, 1] == 0.0 and R[0, 2] == 0.0 and R[1, 0] == 0.0 \
        and R[1, 2] == 0.0 and R[2, 0] == 0.0 and R[2, 1] == 0.0


def arbitrary_x(n):
    """AutoCAD 'arbitrary axis algorithm' - x direction of the OCS for normal n."""
    n = unit(n)
    if n[0] == 0.0 and n[1] == 0.0 and n[2] != 0.0:          # the usual 2D case
        return np.array([1.0 if n[2] > 0 else -1.0, 0.0, 0.0])
    if abs(n[0]) < 1 / 64 and abs(n[1]) < 1 / 64:
        ax = cross(Y, n)
    else:
        ax = cross(Z, n)
    return unit(ax)


class Plane:
    """Coordinate system (UCS / work plane / OCS)."""
    __slots__ = ("o", "x", "y", "z")

    def __init__(self, o=(0, 0, 0), x=(1, 0, 0), y=(0, 1, 0)):
        self.o = v3(o)
        self.x = unit(v3(x))
        z = unit(cross(self.x, v3(y)))
        if norm(z) < EPS:
            z = Z.copy()
        self.z = z
        self.y = unit(cross(z, self.x))

    @classmethod
    def from_normal(cls, o, n, x=None):
        n = unit(v3(n))
        if x is None or norm(cross(v3(x), n)) < 1e-9:
            x = arbitrary_x(n)
        x = unit(v3(x) - np.dot(v3(x), n) * n)
        return cls(o, x, cross(n, x))

    def copy(self):
        return Plane(self.o, self.x, self.y)

    def to_local(self, p):
        d = np.asarray(p, float) - self.o
        return np.stack([d @ self.x, d @ self.y, d @ self.z], axis=-1)

    def to_world(self, q):
        q = np.asarray(q, float)
        if q.shape[-1] == 2:
            return self.o + q[..., :1] * self.x + q[..., 1:2] * self.y
        return self.o + q[..., :1] * self.x + q[..., 1:2] * self.y + q[..., 2:3] * self.z

    def project(self, p):
        p = np.asarray(p, float)
        d = (p - self.o) @ self.z
        return p - np.multiply.outer(d, self.z) if p.ndim > 1 else p - d * self.z

    def matrix(self):
        """4x4 local->world."""
        m = np.eye(4)
        m[:3, 0], m[:3, 1], m[:3, 2], m[:3, 3] = self.x, self.y, self.z, self.o
        return m

    def ray_hit(self, ro, rd):
        den = np.dot(rd, self.z)
        if abs(den) < 1e-12:
            return None
        t = np.dot(self.o - ro, self.z) / den
        return ro + t * rd

    def to_dict(self):
        return {"o": self.o.tolist(), "x": self.x.tolist(), "y": self.y.tolist()}

    @classmethod
    def from_dict(cls, d):
        return cls(d["o"], d["x"], d["y"])

    def transformed(self, M):
        o = xform_pt(M, self.o)
        x = xform_vec(M, self.x)
        y = xform_vec(M, self.y)
        return Plane(o, x, y)


WORLD = Plane()


# ----------------------------------------------------------------------------------------------- transforms
def m_translate(d):
    m = np.eye(4); m[:3, 3] = v3(d); return m


def m_rotate(axis_pt, axis_dir, ang):
    a = unit(v3(axis_dir)); c, s = math.cos(ang), math.sin(ang)
    x, y, z = a
    R = np.array([[c + x * x * (1 - c), x * y * (1 - c) - z * s, x * z * (1 - c) + y * s],
                  [y * x * (1 - c) + z * s, c + y * y * (1 - c), y * z * (1 - c) - x * s],
                  [z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)]])
    m = np.eye(4); m[:3, :3] = R
    p = v3(axis_pt)
    m[:3, 3] = p - R @ p
    return m


def m_scale(base, s):
    m = np.eye(4) * s; m[3, 3] = 1; p = v3(base); m[:3, 3] = p - s * p
    return m


def m_mirror(pt, normal):
    n = unit(v3(normal)); m = np.eye(4); m[:3, :3] -= 2 * np.outer(n, n)
    p = v3(pt); m[:3, 3] = 2 * np.dot(p, n) * n
    return m


def xform_pt(M, p):
    p = np.asarray(p, float)
    return p @ M[:3, :3].T + M[:3, 3]


def xform_vec(M, v):
    return np.asarray(v, float) @ M[:3, :3].T


def m_det(M):
    return float(np.linalg.det(M[:3, :3]))


def m_scale_factor(M):
    return abs(m_det(M)) ** (1 / 3)


# ----------------------------------------------------------------------------------------------- arcs
def arc_pt(c, r, n, u, a):
    v = cross(n, u)
    return c + r * (math.cos(a) * u + math.sin(a) * v)


def arc_pts(c, r, n, u, a0, a1, seg=None):
    sweep = a1 - a0
    if seg is None:
        seg = max(4, int(math.ceil(abs(sweep) / TAU * 96)))
    t = np.linspace(a0, a1, seg + 1)
    v = cross(n, u)
    return c + r * (np.cos(t)[:, None] * u + np.sin(t)[:, None] * v)


def bulge_arc(p0, p1, b, n):
    """Arc data (c, r, n', u, a0, a1) of a polyline bulge segment, traversed p0 -> p1."""
    ch = p1 - p0; L = norm(ch)
    if L < EPS or abs(b) < 1e-12:
        return None
    th = 4 * math.atan(b)
    m = (p0 + p1) / 2
    d = L / 2 * (1 - b * b) / (2 * b)
    c = m + unit(cross(n, ch)) * d
    r = norm(p0 - c)
    nn = n if th > 0 else -n
    u = unit(p0 - c)
    return c, r, nn, u, 0.0, abs(th)


def arc_from_3p(p1, p2, p3):
    """Circle through 3 points: (c, r, n) or None."""
    a = p1 - p3; b = p2 - p3
    axb = cross(a, b); d = 2 * np.dot(axb, axb)
    if d < 1e-18:
        return None
    c = p3 + cross(np.dot(a, a) * b - np.dot(b, b) * a, axb) / d
    return c, norm(p1 - c), unit(axb)


def ang_in_plane(c, n, u, p):
    v = cross(n, u); d = p - c
    return math.atan2(np.dot(d, v), np.dot(d, u))


def norm_ang(a):
    return a % TAU


# ----------------------------------------------------------------------------------------------- primitives
def prim_len(pr):
    if pr[0] == 'L':
        return norm(pr[2] - pr[1])
    return pr[2] * (pr[6] - pr[5])


def prim_point(pr, s):
    """Point at arc length s from the primitive start."""
    if pr[0] == 'L':
        L = norm(pr[2] - pr[1])
        return pr[1] + (pr[2] - pr[1]) * (s / L if L > EPS else 0)
    c, r, n, u, a0, a1 = pr[1:]
    return arc_pt(c, r, n, u, a0 + s / r)


def prim_tangent(pr, s):
    if pr[0] == 'L':
        return unit(pr[2] - pr[1])
    c, r, n, u, a0, a1 = pr[1:]
    a = a0 + s / r
    return unit(cross(n, arc_pt(c, 1, n, u, a) - c))


def prim_ends(pr):
    if pr[0] == 'L':
        return pr[1], pr[2]
    c, r, n, u, a0, a1 = pr[1:]
    return arc_pt(c, r, n, u, a0), arc_pt(c, r, n, u, a1)


def prim_tess(pr):
    if pr[0] == 'L':
        return np.array([pr[1], pr[2]])
    return arc_pts(*pr[1:])


def prim_closest(pr, p):
    """(s, point) closest on primitive to p."""
    if pr[0] == 'L':
        a, b = pr[1], pr[2]; d = b - a; L2 = np.dot(d, d)
        t = 0 if L2 < EPS else min(1, max(0, np.dot(p - a, d) / L2))
        return t * math.sqrt(L2), a + t * d
    c, r, n, u, a0, a1 = pr[1:]
    a = ang_in_plane(c, n, u, p)
    a = a0 + (a - a0) % TAU
    if a > a1:   # outside: nearest end
        e0 = abs(((a0 - a + math.pi) % TAU) - math.pi); e1 = abs(((a - a1 + math.pi) % TAU) - math.pi)
        a = a0 if e0 < e1 else a1
    return r * (a - a0), arc_pt(c, r, n, u, a)


def line_line_3d(p1, d1, p2, d2):
    """Closest params (t,s) of infinite lines p1+t d1, p2+s d2; None if parallel."""
    w = p1 - p2; a = np.dot(d1, d1); b = np.dot(d1, d2); c = np.dot(d2, d2)
    d = np.dot(d1, w); e = np.dot(d2, w); den = a * c - b * b
    if abs(den) < 1e-14 * max(1.0, a * c):
        return None
    return (b * e - c * d) / den, (a * e - b * d) / den


def _line_circle(p, d, c, r, n, tol):
    """Intersections of line p+t d with circle (c,r,n): list of t (line must be ~coplanar)."""
    if abs(np.dot(p - c, n)) > tol or abs(np.dot(unit(d), n)) > 1e-6:
        # line crosses plane: single point check
        den = np.dot(d, n)
        if abs(den) < 1e-14:
            return []
        t = np.dot(c - p, n) / den
        q = p + t * d
        return [t] if abs(norm(q - c) - r) < tol else []
    f = p - c; a = np.dot(d, d); b = 2 * np.dot(f, d); cc = np.dot(f, f) - r * r
    disc = b * b - 4 * a * cc
    if disc < -tol * a:
        return []
    disc = math.sqrt(max(0.0, disc))
    if disc < 1e-12:
        return [-b / (2 * a)]
    return [(-b - disc) / (2 * a), (-b + disc) / (2 * a)]


def _on_arc(pr, q, tol=1e-7):
    c, r, n, u, a0, a1 = pr[1:]
    a = ang_in_plane(c, n, u, q)
    a = a0 + (a - a0) % TAU
    if a <= a1 + tol / max(r, EPS):
        return a
    if (a - TAU) >= a0 - tol / max(r, EPS):
        return a0
    return None


def prim_intersect(pa, pb, extend_a=False, extend_b=False, tol=1e-6):
    """Intersection points of two primitives. Returns list of (sa, sb, point); s may lie outside [0,L] when extended."""
    out = []
    if pa[0] == 'L' and pb[0] == 'L':
        da = pa[2] - pa[1]; db = pb[2] - pb[1]
        r = line_line_3d(pa[1], da, pb[1], db)
        if r is None:
            return out
        t, s = r
        qa = pa[1] + t * da; qb = pb[1] + s * db
        sc = max(1.0, norm(da), norm(db))
        if norm(qa - qb) > tol * sc:
            return out
        if (extend_a or -1e-9 <= t <= 1 + 1e-9) and (extend_b or -1e-9 <= s <= 1 + 1e-9):
            out.append((t * norm(da), s * norm(db), (qa + qb) / 2))
        return out
    if pa[0] == 'A' and pb[0] == 'L':
        return [(sa, sb, q) for sb, sa, q in prim_intersect(pb, pa, extend_b, extend_a, tol)]
    if pa[0] == 'L' and pb[0] == 'A':
        c, r, n, u, a0, a1 = pb[1:]
        d = pa[2] - pa[1]; L = norm(d)
        for t in _line_circle(pa[1], d, c, r, n, tol * max(1, r)):
            q = pa[1] + t * d
            if not extend_a and not (-1e-9 <= t <= 1 + 1e-9):
                continue
            if extend_b:
                a = ang_in_plane(c, n, u, q); s = r * (a - a0)
            else:
                a = _on_arc(pb, q)
                if a is None:
                    continue
                s = r * (a - a0)
            out.append((t * L, s, q))
        return out
    # arc - arc (coplanar)
    c1, r1, n1, u1, a01, a11 = pa[1:]
    c2, r2, n2, u2, a02, a12 = pb[1:]
    if abs(abs(np.dot(n1, n2)) - 1) > 1e-6 or abs(np.dot(c2 - c1, n1)) > tol * max(1, r1):
        return out
    d = norm(c2 - c1)
    if d < EPS or d > r1 + r2 + tol or d < abs(r1 - r2) - tol:
        return out
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, r1 * r1 - a * a))
    ex = (c2 - c1) / d; ey = cross(n1, ex)
    pts = [c1 + a * ex + h * ey] + ([c1 + a * ex - h * ey] if h > 1e-9 else [])
    for q in pts:
        if extend_a:
            sa = r1 * (ang_in_plane(c1, n1, u1, q) - a01)
        else:
            aa = _on_arc(pa, q)
            if aa is None:
                continue
            sa = r1 * (aa - a01)
        if extend_b:
            sb = r2 * (ang_in_plane(c2, n2, u2, q) - a02)
        else:
            ab = _on_arc(pb, q)
            if ab is None:
                continue
            sb = r2 * (ab - a02)
        out.append((sa, sb, q))
    return out


def prim_sub(pr, s0, s1):
    """Sub-primitive between arc lengths s0 < s1."""
    if pr[0] == 'L':
        return ('L', prim_point(pr, s0), prim_point(pr, s1))
    c, r, n, u, a0, a1 = pr[1:]
    return ('A', c, r, n, u, a0 + s0 / r, a0 + s1 / r)


def prims_length(prims):
    return sum(prim_len(p) for p in prims)


def prims_point(prims, s):
    for p in prims:
        L = prim_len(p)
        if s <= L + 1e-12:
            return prim_point(p, max(0, s))
        s -= L
    return prim_ends(prims[-1])[1] if prims else None


def prims_closest(prims, p):
    best = (1e300, 0, None); acc = 0
    for pr in prims:
        s, q = prim_closest(pr, p)
        d = norm(q - p)
        if d < best[0]:
            best = (d, acc + s, q)
        acc += prim_len(pr)
    return best[1], best[2]


def prims_sub(prims, s0, s1):
    out = []; acc = 0
    for pr in prims:
        L = prim_len(pr)
        a, b = max(s0, acc), min(s1, acc + L)
        if b - a > 1e-10:
            out.append(prim_sub(pr, a - acc, b - acc))
        acc += L
    return out


def prims_tess(prims):
    if not prims:
        return np.zeros((0, 3))
    pts = [prim_tess(prims[0])]
    for p in prims[1:]:
        pts.append(prim_tess(p)[1:])
    return np.vstack(pts)


# ----------------------------------------------------------------------------------------------- 2D polygons
def poly_area2(pts2):
    x, y = pts2[:, 0], pts2[:, 1]
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(np.roll(x, -1), y))


def poly_centroid2(pts2):
    x, y = pts2[:, 0], pts2[:, 1]; x1, y1 = np.roll(x, -1), np.roll(y, -1)
    cr = x * y1 - x1 * y; A = cr.sum() / 2
    if abs(A) < 1e-18:
        return pts2.mean(axis=0), 0.0
    return np.array([((x + x1) * cr).sum() / (6 * A), ((y + y1) * cr).sum() / (6 * A)]), A


def point_in_poly(pt, poly):
    x, y = pt; inside = False; n = len(poly); j = n - 1
    for i in range(n):
        xi, yi = poly[i]; xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-300) + xi:
            inside = not inside
        j = i
    return inside


def dedupe_ring(pts, tol=1e-9):
    out = [pts[0]]
    for p in pts[1:]:
        if norm(p - out[-1]) > tol:
            out.append(p)
    if len(out) > 1 and norm(out[0] - out[-1]) <= tol:
        out.pop()
    return np.array(out)


def plane_of_points(pts):
    """Best-fit plane of points: (centroid, normal) or None if collinear."""
    P = np.asarray(pts, float)
    if len(P) < 3:
        return None
    c = P.mean(axis=0)
    u, s, vt = np.linalg.svd(P - c)
    if s[1] < 1e-9 * max(1, s[0]):
        return None
    n = vt[2]
    return c, unit(n), float(s[2] / max(1e-12, s[0]))


# ----------------------------------------------------------------------------------------------- B-splines
def bspline_eval(ctrl, knots, deg, ts, weights=None):
    """Evaluate (rational) B-spline at params ts (de Boor)."""
    P = np.asarray(ctrl, float); U = np.asarray(knots, float)
    if weights is not None:
        w = np.asarray(weights, float)
        P = np.hstack([P * w[:, None], w[:, None]])
    n = len(P) - 1
    out = []
    for t in ts:
        k = np.searchsorted(U, t, side='right') - 1
        k = min(max(k, deg), n)
        d = [P[j + k - deg].copy() for j in range(deg + 1)]
        for r in range(1, deg + 1):
            for j in range(deg, r - 1, -1):
                i = j + k - deg
                den = U[i + deg - r + 1] - U[i]
                a = 0 if den == 0 else (t - U[i]) / den
                d[j] = (1 - a) * d[j - 1] + a * d[j]
        out.append(d[deg])
    out = np.array(out)
    if weights is not None:
        out = out[:, :3] / out[:, 3:4]
    return out


def bspline_interp(pts, deg=3):
    """Global cubic interpolation through points (chord-length params). Returns ctrl, knots."""
    Q = np.asarray(pts, float); n = len(Q) - 1
    if n < 1:
        return Q, [0, 1]
    deg = min(deg, n)
    d = np.linalg.norm(np.diff(Q, axis=0), axis=1); tot = d.sum()
    u = np.concatenate([[0], np.cumsum(d) / tot]) if tot > 0 else np.linspace(0, 1, n + 1)
    U = np.concatenate([np.zeros(deg + 1), [u[j:j + deg].mean() for j in range(1, n - deg + 1)], np.ones(deg + 1)])
    A = np.zeros((n + 1, n + 1))
    for i, t in enumerate(u):
        A[i] = basis_all(U, deg, n, t)
    ctrl = np.linalg.solve(A, Q)
    return ctrl, U.tolist()


def basis_all(U, p, n, t):
    N = np.zeros(n + 1)
    if t >= U[n + 1]:
        N[n] = 1.0
        return N
    k = np.searchsorted(U, t, side='right') - 1
    k = min(max(k, p), n)
    Nk = np.zeros(p + 1); Nk[0] = 1.0
    left = np.zeros(p + 1); right = np.zeros(p + 1)
    for j in range(1, p + 1):
        left[j] = t - U[k + 1 - j]; right[j] = U[k + j] - t
        saved = 0.0
        for r in range(j):
            temp = Nk[r] / (right[r + 1] + left[j - r])
            Nk[r] = saved + right[r + 1] * temp
            saved = left[j - r] * temp
        Nk[j] = saved
    N[k - p:k + 1] = Nk
    return N


# ----------------------------------------------------------------------------------------------- misc
def fmt(v, dec=4):
    s = f"{v:.{dec}f}".rstrip('0').rstrip('.')
    return "0" if s in ("-0", "") else s


def fmt_pt(p, dec=4):
    return ", ".join(fmt(c, dec) for c in p)


def bbox_union(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return np.minimum(a[0], b[0]), np.maximum(a[1], b[1])
