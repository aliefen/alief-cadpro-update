"""Exact conversion of lines, arcs, ellipses and splines to one NURBS curve (rational Bezier pieces).
Used by JOIN (any mix of curves becomes one spline without changing its shape), SPLIT and non-uniform SCALE."""
import math
import numpy as np

from .geom import v3, unit, norm, arc_pt, TAU


def _hom(P, w):
    P = np.asarray(P, float).reshape(-1, 3); w = np.asarray(w, float).reshape(-1)
    return np.hstack([P * w[:, None], w[:, None]])


def elevate(B, p):
    """Raise a (homogeneous) Bezier segment to degree p."""
    B = np.asarray(B, float)
    while len(B) - 1 < p:
        n = len(B) - 1; Q = np.zeros((n + 2, B.shape[1]))
        Q[0] = B[0]; Q[-1] = B[-1]
        for i in range(1, n + 1):
            a = i / (n + 1.0)
            Q[i] = a * B[i - 1] + (1 - a) * B[i]
        B = Q
    return B


def line_bezier(a, b):
    return _hom([a, b], [1, 1])


def arc_beziers(c, r, n, u, a0, a1):
    """Rational quadratic Bezier pieces (each <= 90 deg) of the arc a0 -> a1 (a1 may be smaller: clockwise)."""
    sw = a1 - a0; k = max(1, int(math.ceil(abs(sw) / (math.pi / 2) - 1e-9))); out = []
    for i in range(k):
        t0 = a0 + sw * i / k; t1 = a0 + sw * (i + 1) / k; h = (t1 - t0) / 2
        p0 = arc_pt(c, r, n, u, t0); p2 = arc_pt(c, r, n, u, t1)
        pm = np.asarray(c, float) + (arc_pt(c, r, n, u, (t0 + t1) / 2) - np.asarray(c, float)) / math.cos(h)
        out.append(_hom([p0, pm, p2], [1, math.cos(h), 1]))
    return out


def spline_beziers(e):
    """Bezier pieces (homogeneous) of a Spline entity: knot insertion to full multiplicity."""
    p = e.deg; U = list(e.knots); n = len(e.ctrl)
    w = np.ones(n) if e.weights is None else np.asarray(e.weights, float)
    Pw = _hom(e.ctrl, w)
    inner = sorted(set(U[p + 1:len(U) - p - 1]))
    for u in inner:
        while True:
            s = sum(1 for x in U if abs(x - u) < 1e-12)
            if s >= p:
                break
            k = max(i for i in range(len(U) - 1) if U[i] <= u + 1e-12 and i < len(U) - p - 1)
            Q = np.zeros((len(Pw) + 1, 4))
            for i in range(len(Pw) + 1):
                if i <= k - p:
                    Q[i] = Pw[i]
                elif i >= k - s + 1:
                    Q[i] = Pw[i - 1]
                else:
                    den = U[i + p] - U[i]; al = (u - U[i]) / den if abs(den) > 1e-14 else 0.0
                    Q[i] = al * Pw[i] + (1 - al) * Pw[i - 1]
            Pw = Q; U = U[:k + 1] + [u] + U[k + 1:]
    nseg = (len(Pw) - 1) // p if p > 0 else 0
    return [Pw[i * p:i * p + p + 1].copy() for i in range(nseg)]


def entity_beziers(e):
    """Bezier pieces of any curve entity in drawing order, or None when it cannot be converted."""
    k = e.kind
    if k == "spline":
        if e.closed and e.fit is None and len(e.ctrl) and norm(e.ctrl[0] - e.ctrl[-1]) > 1e-9:
            return None
        return spline_beziers(e)
    if k == "ellipse":
        a = norm(e.major); u = unit(e.major); v = np.cross(e.n, u); b = a * e.ratio
        out = []
        for B in arc_beziers(np.zeros(3), 1.0, np.array([0, 0, 1.0]), np.array([1.0, 0, 0]), e.t0, e.t1):
            w = B[:, 3:4]; xy = B[:, :3] / w
            P = e.c + xy[:, 0:1] * a * u + xy[:, 1:2] * b * v
            out.append(np.hstack([P * w, w]))
        return out
    if k in ("line", "arc", "circle", "polyline"):
        out = []
        for pr in e.prims():
            if pr[0] == "L":
                out.append(line_bezier(pr[1], pr[2]))
            else:
                out += arc_beziers(pr[1], pr[2], pr[3], pr[4], pr[5], pr[6])
        return out
    return None


def reverse(segs):
    return [s[::-1].copy() for s in segs[::-1]]


def compose(segs, closed=False):
    """One Spline entity from Bezier pieces that follow each other."""
    from .entities import Spline
    p = max(len(s) - 1 for s in segs); p = max(p, 1)
    S = [elevate(s, p) for s in segs]
    Pw = [S[0][0]]
    for s in S:
        Pw += list(s[1:])
    Pw = np.array(Pw); n = len(S)
    knots = [0.0] * (p + 1)
    for i in range(1, n):
        knots += [float(i)] * p
    knots += [float(n)] * (p + 1)
    w = Pw[:, 3]; P = Pw[:, :3] / w[:, None]
    rat = bool(np.abs(w - 1.0).max() > 1e-12)
    return Spline(P, [k / n for k in knots], p, list(w) if rat else None, None, closed)


def seg_point(B, t):
    """Point of a homogeneous Bezier segment at t (de Casteljau)."""
    Q = np.array(B, float)
    while len(Q) > 1:
        Q = (1 - t) * Q[:-1] + t * Q[1:]
    return Q[0, :3] / Q[0, 3]


def seg_split(B, t):
    L = []; R = []; Q = np.array(B, float)
    while True:
        L.append(Q[0].copy()); R.append(Q[-1].copy())
        if len(Q) == 1:
            break
        Q = (1 - t) * Q[:-1] + t * Q[1:]
    return np.array(L), np.array(R[::-1])


def ends(segs):
    return segs[0][0, :3] / segs[0][0, 3], segs[-1][-1, :3] / segs[-1][-1, 3]


def affine(segs, M):
    out = []
    for B in segs:
        Q = B.copy(); Q[:, :3] = B[:, :3] @ M[:3, :3].T + B[:, 3:4] * M[:3, 3]
        out.append(Q)
    return out


def simplify(segs, closed=False):
    """Entity for a chain of Bezier pieces: a Polyline when every piece is a straight line, else one Spline."""
    from .entities import Polyline
    if all(len(s) == 2 for s in segs):
        P = [segs[0][0, :3] / segs[0][0, 3]] + [s[1, :3] / s[1, 3] for s in segs]
        if closed and norm(P[0] - P[-1]) < 1e-9:
            P = P[:-1]
        return Polyline(np.array(P), closed)
    return compose(segs, closed)
