"""Raster redrawing: binarise, despeckle, centre-line thinning (Zhang-Suen), skeleton tracing to polylines,
Douglas-Peucker simplification, straightening, gap joining. Pure numpy (no OpenCV needed)."""
import math
import numpy as np


def gray_from_bytes(data, max_side=None):
    from PySide6.QtGui import QImage
    from PySide6.QtCore import Qt
    img = QImage.fromData(data)
    if img.isNull():
        raise ValueError("cannot read image")
    W0, H0 = img.width(), img.height()
    if max_side and max(W0, H0) > max_side:
        img = img.scaled(max_side, max_side, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    img = img.convertToFormat(QImage.Format_Grayscale8)
    a = np.frombuffer(img.constBits(), np.uint8, img.sizeInBytes()).reshape(img.height(), img.bytesPerLine())[:, :img.width()].copy()
    return a, (W0, H0)


def otsu(g):
    h = np.bincount(g.ravel(), minlength=256).astype(float); p = h / h.sum()
    w = np.cumsum(p); mu = np.cumsum(p * np.arange(256)); mt = mu[-1]
    sb = (mt * w - mu) ** 2 / np.maximum(w * (1 - w), 1e-12)
    return int(np.argmax(sb))


def _shift(a, dy, dx):
    out = np.zeros_like(a)
    H, W = a.shape
    ys = slice(max(dy, 0), H + min(dy, 0)); xs = slice(max(dx, 0), W + min(dx, 0))
    yd = slice(max(-dy, 0), H + min(-dy, 0)); xd = slice(max(-dx, 0), W + min(-dx, 0))
    out[ys, xs] = a[yd, xd]
    return out


def neighbours(m):
    m = m.astype(np.uint8)
    return [_shift(m, dy, dx) for dy, dx in ((1, 0), (1, -1), (0, -1), (-1, -1), (-1, 0), (-1, 1), (0, 1), (1, 1))]


def erode(m, it=1):
    for _ in range(it):
        n = neighbours(m); s = m.astype(np.uint8)
        for k in (0, 2, 4, 6):
            s = s & n[k]
        m = s.astype(bool)
    return m


def dilate(m, it=1):
    for _ in range(it):
        n = neighbours(m); s = m.astype(np.uint8)
        for k in range(8):
            s = s | n[k]
        m = s.astype(bool)
    return m


def despeckle(m, level=1):
    """Remove isolated dots / fill pin holes (majority filter + opening)."""
    if level <= 0:
        return m
    n = sum(x.astype(np.int16) for x in neighbours(m))
    m = (m & (n >= 2)) | (~m & (n >= 7))
    if level >= 2:
        m = dilate(erode(m, 1), 1)
    return m


def thin(m, max_iter=200):
    """Zhang-Suen thinning (vectorised)."""
    img = m.astype(np.uint8).copy()
    img[0, :] = img[-1, :] = 0; img[:, 0] = img[:, -1] = 0
    for _ in range(max_iter):
        changed = False
        for step in (0, 1):
            P2 = _shift(img, 1, 0); P3 = _shift(img, 1, -1); P4 = _shift(img, 0, -1); P5 = _shift(img, -1, -1)
            P6 = _shift(img, -1, 0); P7 = _shift(img, -1, 1); P8 = _shift(img, 0, 1); P9 = _shift(img, 1, 1)
            # note _shift(img,1,0) gives pixel above (y-1) at current position
            ns = [P2, P3, P4, P5, P6, P7, P8, P9]
            B = sum(x.astype(np.int16) for x in ns)
            seq = ns + [P2]
            A = sum(((seq[i] == 0) & (seq[i + 1] == 1)).astype(np.int16) for i in range(8))
            if step == 0:
                c1 = (P2 * P4 * P6) == 0; c2 = (P4 * P6 * P8) == 0
            else:
                c1 = (P2 * P4 * P8) == 0; c2 = (P2 * P6 * P8) == 0
            rm = (img == 1) & (B >= 2) & (B <= 6) & (A == 1) & c1 & c2
            if rm.any():
                img[rm] = 0; changed = True
        if not changed:
            break
    return img.astype(bool)


OFFS = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]


def trace(sk, min_len=4):
    """Skeleton -> list of polylines (Nx2 float arrays in pixel (x, y))."""
    ys, xs = np.nonzero(sk)
    if not len(ys):
        return []
    S = set(zip(ys.tolist(), xs.tolist()))
    nb = {}
    for p in S:
        y, x = p
        nb[p] = [(y + dy, x + dx) for dy, dx in OFFS if (y + dy, x + dx) in S]
    # prefer 4-connected neighbours to avoid diagonal duplicates
    deg = {p: len(v) for p, v in nb.items()}
    visited_edges = set()
    lines = []
    def walk(a, b):
        path = [a, b]; visited_edges.add((a, b)); visited_edges.add((b, a))
        prev, cur = a, b
        while deg.get(cur, 0) == 2:
            nxt = [q for q in nb[cur] if q != prev and (cur, q) not in visited_edges]
            if not nxt:
                break
            q = nxt[0]
            visited_edges.add((cur, q)); visited_edges.add((q, cur))
            path.append(q); prev, cur = cur, q
        return path
    nodes = [p for p, d in deg.items() if d != 2]
    for p in nodes:
        for q in nb[p]:
            if (p, q) not in visited_edges:
                lines.append(walk(p, q))
    for p in list(S):           # remaining loops
        if deg[p] == 2:
            for q in nb[p]:
                if (p, q) not in visited_edges:
                    lines.append(walk(p, q))
    out = []
    for l in lines:
        if len(l) >= min_len:
            a = np.array(l, float)[:, ::-1]
            out.append(a)
    return out


def rdp(P, eps):
    if len(P) < 3:
        return P
    a, b = P[0], P[-1]; d = b - a; L = math.hypot(*d)
    if L < 1e-12:
        dist = np.hypot(*(P - a).T)
    else:
        dist = np.abs(d[0] * (P[:, 1] - a[1]) - d[1] * (P[:, 0] - a[0])) / L
    i = int(np.argmax(dist))
    if dist[i] > eps:
        return np.vstack([rdp(P[:i + 1], eps)[:-1], rdp(P[i:], eps)])
    return np.array([a, b])


def straighten(P, ang_tol=3.0, min_seg=25.0):
    Q = P.copy()
    for i in range(len(Q) - 1):
        d = Q[i + 1] - Q[i]
        if math.hypot(*d) < min_seg:
            continue
        a = math.degrees(math.atan2(d[1], d[0])) % 180
        if min(a, 180 - a) < ang_tol:
            Q[i + 1, 1] = Q[i, 1]
        elif abs(a - 90) < ang_tol:
            Q[i + 1, 0] = Q[i, 0]
    return Q


def join_gaps(lines, gap):
    lines = [l for l in lines if len(l) >= 2]
    changed = True
    while changed and gap > 0:
        changed = False
        for i in range(len(lines)):
            if lines[i] is None:
                continue
            for j in range(i + 1, len(lines)):
                if lines[j] is None:
                    continue
                a, b = lines[i], lines[j]
                for ra, rb, pa, pb in ((False, False, a[-1], b[0]), (False, True, a[-1], b[-1]), (True, False, a[0], b[0]), (True, True, a[0], b[-1])):
                    if math.hypot(*(pa - pb)) <= gap:
                        A = a[::-1] if ra else a; Bb = b[::-1] if rb else b
                        lines[i] = np.vstack([A, Bb]); lines[j] = None; changed = True; break
                if lines[j] is None:
                    a = lines[i]
        lines = [l for l in lines if l is not None]
    return lines


def vectorize(gray, thr=None, invert=False, speck=1, simplify=1.2, straight=True, ang_tol=3.0, gap=3.0, min_len=8, thick=0):
    """Full pipeline. Returns (polylines in pixel coords, threshold used, mask)."""
    if thr is None:
        thr = otsu(gray)
    m = gray > thr if invert else gray < thr
    m = despeckle(m, speck)
    if thick > 0:
        m = dilate(m, thick)
    sk = thin(m)
    lines = trace(sk, max(2, int(min_len / 2)))
    out = []
    for l in lines:
        q = rdp(l, simplify)
        if straight:
            q = straighten(q, ang_tol)
        out.append(q)
    out = join_gaps(out, gap)
    out = [l for l in out if np.sum(np.hypot(*np.diff(l, axis=0).T)) >= min_len]
    return out, thr, sk


_sk_cache = {}


def skeleton_cached(e):
    k = (e.id, len(e.data))
    if k in _sk_cache:
        return _sk_cache[k]
    try:
        g, _ = gray_from_bytes(e.data, 1600)
        m = despeckle(g < otsu(g), 1)
        sk = thin(m)
    except Exception:
        sk = None
    _sk_cache[k] = sk
    return sk


def nearest_on(sk, x, y, r):
    H, W = sk.shape
    r = int(math.ceil(r))
    x0, x1 = max(0, int(x) - r), min(W, int(x) + r + 1); y0, y1 = max(0, int(y) - r), min(H, int(y) + r + 1)
    if x0 >= x1 or y0 >= y1:
        return None
    sub = sk[y0:y1, x0:x1]
    ys, xs = np.nonzero(sub)
    if not len(ys):
        return None
    d = (xs + x0 - x) ** 2 + (ys + y0 - y) ** 2
    k = int(np.argmin(d))
    if d[k] > r * r:
        return None
    return xs[k] + x0 + 0.5, ys[k] + y0 + 0.5
