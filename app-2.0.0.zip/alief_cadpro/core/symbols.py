"""2D symbol library: marine Electrical (IEC 60617 style) and Piping (ISO 14617 / P&ID style).
Every symbol is drawn in a local frame (mm at scale 1, nominal size about 10 mm), base point (0, 0) = connection
point / centre, inserted as a block reference."""
import math
import numpy as np
from .entities import Line, Circle, Arc, Polyline, Text, Hatch, Block

S = {}          # name -> (category, description, builder)


def sym(name, cat, desc):
    def deco(fn):
        S[name] = (cat, desc, fn)
        return fn
    return deco


# --------------------------------------------------------------------------------- tiny drawing DSL
def L(x1, y1, x2, y2):
    return Line((x1, y1, 0), (x2, y2, 0))


def C(x, y, r):
    return Circle((x, y, 0), r)


def A(x, y, r, a0, a1):
    return Arc((x, y, 0), r, math.radians(a0), math.radians(a1))


def P(pts, closed=False):
    return Polyline([(x, y, 0) for x, y in pts], closed)


def FILL(pts):
    return [Hatch([np.array([(x, y, 0) for x, y in pts], float)], pattern="SOLID"), P(pts, True)]


def FC(x, y, r, n=24):
    a = np.linspace(0, 2 * math.pi, n, endpoint=False)
    return [Hatch([np.stack([x + r * np.cos(a), y + r * np.sin(a), np.zeros(n)], axis=1)], pattern="SOLID"), C(x, y, r)]


def T(x, y, s, h=2.2):
    return Text((x, y, 0), s, h, (1, 0, 0), (0, 0, 1), 1, 2)


def RECT(x0, y0, x1, y1):
    return P([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], True)


def flat(*items):
    out = []
    for it in items:
        if isinstance(it, (list, tuple)):
            out.extend(flat(*it))
        else:
            out.append(it)
    return out


def bowtie(w=5, h=3):
    return [P([(-w, -h), (-w, h), (0, 0)], True), P([(w, -h), (w, h), (0, 0)], True)]


def stem(h=5, wheel=1.8):
    return [L(0, 0, 0, h), L(-wheel, h, wheel, h)]


# ===================================================================================== ELECTRICAL
E = "Electrical 2D"


@sym("Lamp", E, "Light fitting (incandescent / LED)")
def _():
    r = 4; k = r * 0.7071
    return [C(0, 0, r), L(-k, -k, k, k), L(-k, k, k, -k)]


@sym("Lamp watertight", E, "Watertight light fitting")
def _():
    r = 4; k = r * 0.7071
    return flat(C(0, 0, r), C(0, 0, r + 1.2), L(-k, -k, k, k), L(-k, k, k, -k))


@sym("Emergency lamp", E, "Emergency light fitting")
def _():
    r = 4; k = r * 0.7071
    return flat(C(0, 0, r), L(-k, -k, k, k), L(-k, k, k, -k), FC(0, 0, 1.3))


@sym("Fluorescent 1x", E, "Fluorescent / LED tube fitting, single")
def _():
    return [L(-6, 0, 6, 0), L(-6, -1.5, -6, 1.5), L(6, -1.5, 6, 1.5)]


@sym("Fluorescent 2x", E, "Fluorescent / LED tube fitting, double")
def _():
    return [L(-6, 0.8, 6, 0.8), L(-6, -0.8, 6, -0.8), L(-6, -2, -6, 2), L(6, -2, 6, 2)]


@sym("Navigation light", E, "Navigation / signal light")
def _():
    return flat(C(0, 0, 4), T(0, 0, "NL", 2.4))


@sym("Searchlight", E, "Searchlight / floodlight")
def _():
    r = 3; k = r * 0.7071
    return [C(0, 0, r), L(-k, -k, k, k), L(-k, k, k, -k), L(r, 0.8, 8, 3), L(r, -0.8, 8, -3)]


@sym("Switch 1-way", E, "Switch, single pole one-way")
def _():
    return [C(0, 0, 1), L(0.7, 0.7, 5, 5), L(5, 5, 6.2, 3.8)]


@sym("Switch 2-way", E, "Switch, two-way")
def _():
    return [C(0, 0, 1), L(0.7, 0.7, 5, 5), L(5, 5, 6.2, 3.8), L(-0.7, -0.7, -5, -5), L(-5, -5, -6.2, -3.8)]


@sym("Switch watertight", E, "Switch, watertight")
def _():
    return flat(FC(0, 0, 1.1), L(0.7, 0.7, 5, 5), L(5, 5, 6.2, 3.8))


@sym("Push button", E, "Push button")
def _():
    return flat(C(0, 0, 2.6), FC(0, 0, 1))


@sym("Emergency stop", E, "Emergency stop push button")
def _():
    return flat(C(0, 0, 3.4), FC(0, 0, 2), T(0, -5.5, "E-STOP", 1.8))


@sym("Socket outlet", E, "Socket outlet, single")
def _():
    return [A(0, 0, 4, 0, 180), L(-4, 0, 4, 0), L(0, 0, 0, -3)]


@sym("Socket outlet double", E, "Socket outlet, double")
def _():
    return [A(0, 0, 4, 0, 180), L(-4, 0, 4, 0), L(0, 0, 0, -3), L(-1.6, 3.7, -2.2, 5.6), L(1.6, 3.7, 2.2, 5.6)]


@sym("Socket watertight", E, "Socket outlet, watertight")
def _():
    a = np.linspace(0, math.pi, 16)
    pts = [(4 * math.cos(t), 4 * math.sin(t)) for t in a]
    return flat(FILL(pts), L(0, 0, 0, -3))


@sym("Junction box", E, "Junction box")
def _():
    return flat(C(0, 0, 3), FC(0, 0, 1.2))


@sym("Distribution board", E, "Distribution board / panel")
def _():
    return flat(RECT(-6, -3, 6, 3), FILL([(-6, -3), (6, -3), (6, 3)]))


@sym("Main switchboard", E, "Main / emergency switchboard")
def _():
    return flat(RECT(-9, -4, 9, 4), L(-9, -2, 9, -2), T(0, 1, "MSB", 2.6))


@sym("Circuit breaker", E, "Circuit breaker (MCB / MCCB)")
def _():
    return [L(-6, 0, -2.5, 0), L(-2.5, 0, 2.8, 2.6), L(3, 0, 6, 0), L(2.2, -0.8, 3.8, 0.8), L(2.2, 0.8, 3.8, -0.8)]


@sym("Air circuit breaker", E, "Air circuit breaker (ACB)")
def _():
    return [RECT(-4, -2.5, 4.6, 3.6), L(-8, 0, -2.5, 0), L(-2.5, 0, 2.8, 2.6), L(3, 0, 8, 0), L(2.2, -0.8, 3.8, 0.8), L(2.2, 0.8, 3.8, -0.8)]


@sym("Fuse", E, "Fuse")
def _():
    return [L(-6, 0, 6, 0), RECT(-3, -1.2, 3, 1.2)]


@sym("Contactor", E, "Contactor (main contact)")
def _():
    return [L(-6, 0, -2.5, 0), L(-2.5, 0, 2.8, 2.6), L(3.6, 0, 6, 0), A(3, 0, 0.6, 0, 180)]


@sym("Isolator", E, "Isolator / disconnector")
def _():
    return [L(-6, 0, -2.5, 0), L(-2.5, 0, 2.8, 2.6), L(3, 0, 6, 0), L(3, -1.2, 3, 1.2)]


@sym("Transformer", E, "Transformer, two winding")
def _():
    return [C(-2, 0, 3.2), C(2, 0, 3.2), L(-8, 0, -5.2, 0), L(5.2, 0, 8, 0)]


@sym("Current transformer", E, "Current transformer")
def _():
    return [L(-6, 0, 6, 0), C(0, 0, 2.2)]


@sym("Motor", E, "Motor")
def _():
    return flat(C(0, 0, 4), T(0, 0, "M", 3.2))


@sym("Generator", E, "Generator (AC)")
def _():
    return flat(C(0, 0, 4.5), T(0, 0.6, "G", 3.2), A(-0.8, -2.4, 0.8, 0, 180), A(0.8, -2.4, 0.8, 180, 360))


@sym("Earth", E, "Earth / ground connection")
def _():
    return [L(0, 4, 0, 0), L(-4, 0, 4, 0), L(-2.7, -1.2, 2.7, -1.2), L(-1.3, -2.4, 1.3, -2.4)]


@sym("Battery", E, "Battery / cell")
def _():
    return [L(-6, 0, -1, 0), L(-1, -4, -1, 4), L(1, -2, 1, 2), L(1, 0, 6, 0), T(-3, 3, "+", 2), T(3, 3, "-", 2)]


@sym("Bell", E, "Bell / general alarm bell")
def _():
    return [A(0, 0, 4, 180, 360), L(-4, 0, 4, 0), L(-2, 0, -2, 3), L(2, 0, 2, 3)]


@sym("Horn", E, "Horn / siren")
def _():
    return [P([(-2, -1.5), (-2, 1.5), (3, 4), (3, -4)], True), L(-6, 0, -2, 0)]


@sym("Buzzer", E, "Buzzer")
def _():
    return [A(0, 0, 4, 0, 180), L(-4, 0, 4, 0), L(-2, 0, -2, -3), L(2, 0, 2, -3)]


@sym("Smoke detector", E, "Fire detector, smoke")
def _():
    return flat(RECT(-4, -4, 4, 4), T(0, 0, "S", 3))


@sym("Heat detector", E, "Fire detector, heat")
def _():
    return flat(RECT(-4, -4, 4, 4), T(0, 0, "H", 3))


@sym("Flame detector", E, "Fire detector, flame")
def _():
    return flat(RECT(-4, -4, 4, 4), T(0, 0, "F", 3))


@sym("Manual call point", E, "Manual fire alarm call point")
def _():
    return flat(RECT(-4, -4, 4, 4), C(0, 0, 2.4), FC(0, 0, 1))


@sym("Telephone", E, "Telephone / sound-powered telephone")
def _():
    return flat(RECT(-5, -3.5, 5, 3.5), T(0, 0, "TEL", 2.4))


@sym("Loudspeaker", E, "Loudspeaker (PA / GA)")
def _():
    return [RECT(-4, -2, -1, 2), P([(-1, -2), (3, -4.5), (3, 4.5), (-1, 2)], True)]


@sym("Fan", E, "Fan / ventilator")
def _():
    out = [C(0, 0, 4.5)]
    for k in range(3):
        a = math.radians(90 + 120 * k)
        out.append(A(math.cos(a) * 1.6, math.sin(a) * 1.6, 1.6, math.degrees(a) + 180, math.degrees(a) + 360))
    return out


@sym("Ammeter", E, "Ammeter")
def _():
    return flat(C(0, 0, 4), T(0, 0, "A", 3))


@sym("Voltmeter", E, "Voltmeter")
def _():
    return flat(C(0, 0, 4), T(0, 0, "V", 3))


@sym("Frequency meter", E, "Frequency meter")
def _():
    return flat(C(0, 0, 4), T(0, 0, "Hz", 2.6))


@sym("kW meter", E, "Wattmeter (kW)")
def _():
    return flat(C(0, 0, 4), T(0, 0, "kW", 2.6))


@sym("Indicator lamp", E, "Indicator / pilot lamp")
def _():
    k = 2.6 * 0.7071
    return [C(0, 0, 2.6), L(-k, -k, k, k), L(-k, k, k, -k), L(-6, 0, -2.6, 0), L(2.6, 0, 6, 0)]


@sym("Shore connection", E, "Shore connection box")
def _():
    return flat(RECT(-6, -3.5, 6, 3.5), T(0, 0, "SC", 2.6))


@sym("Starter", E, "Motor starter (DOL / Y-D)")
def _():
    return flat(RECT(-5, -3.5, 5, 3.5), T(0, 0, "ST", 2.6))


@sym("Battery charger", E, "Rectifier / battery charger")
def _():
    return flat(RECT(-5, -5, 5, 5), L(-5, -5, 5, 5), T(-2.3, 2.3, "~", 2.4), T(2.3, -2.3, "=", 2.4))


@sym("Wire junction", E, "Conductor junction (dot)")
def _():
    return FC(0, 0, 0.8)


@sym("Cable gland", E, "Cable gland / cable entry")
def _():
    return [RECT(-1.5, -2.5, 1.5, 2.5), L(-6, 0, -1.5, 0), L(1.5, 0, 6, 0), L(-1.5, -2.5, 1.5, 2.5)]


# ===================================================================================== PIPING
PP = "Piping 2D"


@sym("Gate valve", PP, "Gate valve")
def _():
    return bowtie() + stem()


@sym("Globe valve", PP, "Globe valve (screw-down)")
def _():
    return flat(bowtie(), stem(), FC(0, 0, 1.2))


@sym("Ball valve", PP, "Ball valve")
def _():
    return flat(bowtie(), C(0, 0, 1.8), L(0, 1.8, 0, 5), L(0, 5, 3, 5))


@sym("Butterfly valve", PP, "Butterfly valve")
def _():
    return flat(L(-2.5, -3.5, -2.5, 3.5), L(2.5, -3.5, 2.5, 3.5), L(-2.5, -3.5, 2.5, 3.5), FC(0, 0, 0.9), L(0, 3.5, 0, 5.5), L(0, 5.5, 3, 5.5))


@sym("Check valve", PP, "Non-return / check valve (flow left to right)")
def _():
    return flat(FILL([(-5, -3), (-5, 3), (0, 0)]), P([(5, -3), (5, 3), (0, 0)], True))


@sym("SDNR valve", PP, "Screw-down non-return valve")
def _():
    return flat(FILL([(-5, -3), (-5, 3), (0, 0)]), P([(5, -3), (5, 3), (0, 0)], True), stem())


@sym("Needle valve", PP, "Needle valve")
def _():
    return flat(bowtie(), stem(), FILL([(-0.9, 1.5), (0.9, 1.5), (0, 0)]))


@sym("Plug cock", PP, "Plug valve / cock")
def _():
    return flat(bowtie(), FILL([(-0.8, -1.8), (0.8, -1.8), (0.8, 1.8), (-0.8, 1.8)]))


@sym("Three-way valve", PP, "Three-way valve")
def _():
    return bowtie() + [P([(-3, -5), (3, -5), (0, 0)], True)] + stem()


@sym("Angle valve", PP, "Angle valve")
def _():
    return [P([(-5, -3), (-5, 3), (0, 0)], True), P([(-3, -5), (3, -5), (0, 0)], True)] + stem()


@sym("Safety valve", PP, "Safety / relief valve (spring loaded)")
def _():
    zig = [(0, 0), (0, 1.5), (1.5, 2.2), (-1.5, 3.4), (1.5, 4.6), (-1.5, 5.8), (0, 6.5), (0, 7.5)]
    return [P([(-5, -3), (-5, 3), (0, 0)], True), P([(-3, -5), (3, -5), (0, 0)], True), P(zig)]


@sym("Reducing valve", PP, "Pressure reducing valve")
def _():
    return bowtie() + [L(-4, -4.5, 4, 4.5), P([(4, 4.5), (2.4, 4.3), (3.4, 3.1)], True)]


@sym("Solenoid valve", PP, "Solenoid operated valve")
def _():
    return flat(bowtie(), L(0, 0, 0, 4), RECT(-2.2, 4, 2.2, 7.6), T(0, 5.8, "S", 2.2))


@sym("Pneumatic valve", PP, "Pneumatic / diaphragm actuated valve")
def _():
    return bowtie() + [L(0, 0, 0, 4), A(0, 4, 3.2, 0, 180), L(-3.2, 4, 3.2, 4)]


@sym("Motor valve", PP, "Motor operated valve")
def _():
    return flat(bowtie(), L(0, 0, 0, 4), C(0, 6.6, 2.6), T(0, 6.6, "M", 2.4))


@sym("Quick-closing valve", PP, "Quick-closing valve (remote)")
def _():
    return flat(bowtie(), L(0, 0, 0, 4.5), FILL([(-1.8, 4.5), (1.8, 4.5), (0, 7.5)]))


@sym("Storm valve", PP, "Storm valve (non-return, overboard)")
def _():
    return flat(FILL([(-5, -3), (-5, 3), (0, 0)]), P([(5, -3), (5, 3), (0, 0)], True), T(0, -5.5, "SV", 2))


@sym("Y-strainer", PP, "Y-type strainer")
def _():
    return [L(-6, 0, 6, 0), L(-2, 0, 2, -4.5), L(1, 0, 5, -4.5), L(2, -4.5, 5, -4.5), L(-2.5, -1.5, 2.5, -1.5)]


@sym("Mud box", PP, "Mud box / basket strainer")
def _():
    return [RECT(-4, -4, 4, 4), L(-4, -4, 4, 4), L(-4, 4, 4, -4), L(-8, 0, -4, 0), L(4, 0, 8, 0)]


@sym("Filter", PP, "Filter")
def _():
    return [P([(-5, 0), (0, 5), (5, 0), (0, -5)], True), L(0, -5, 0, 5)]


@sym("Duplex filter", PP, "Duplex (change-over) filter")
def _():
    return [P([(-7, 0), (-3.5, 4), (0, 0), (-3.5, -4)], True), P([(0, 0), (3.5, 4), (7, 0), (3.5, -4)], True),
            L(-3.5, -4, -3.5, 4), L(3.5, -4, 3.5, 4)]


@sym("Centrifugal pump", PP, "Centrifugal pump")
def _():
    return [C(0, 0, 5), L(-9, 0, -5, 0), L(0, 5, 8, 5), L(0, 5, 3.5, 3.6), L(-3.5, -5.5, 3.5, -5.5)]


@sym("Gear pump", PP, "Gear / positive displacement pump")
def _():
    return [C(0, 0, 5), C(-1.7, 0, 1.7), C(1.7, 0, 1.7), L(-9, 0, -5, 0), L(5, 0, 9, 0)]


@sym("Hand pump", PP, "Hand pump")
def _():
    return flat(C(0, 0, 5), T(0, 0, "H", 3.2), L(-9, 0, -5, 0), L(5, 0, 9, 0))


@sym("Ejector", PP, "Ejector / eductor")
def _():
    return [P([(-6, -3), (-6, 3), (0, 1), (6, 3), (6, -3), (0, -1)], True), L(0, -1, 0, -5)]


@sym("Concentric reducer", PP, "Concentric reducer")
def _():
    return [P([(-3, -3), (3, -1.6), (3, 1.6), (-3, 3)], True)]


@sym("Eccentric reducer", PP, "Eccentric reducer (flat bottom)")
def _():
    return [P([(-3, -3), (3, -3), (3, 0.2), (-3, 3)], True)]


@sym("Flange pair", PP, "Flanged joint")
def _():
    return [L(-0.6, -4, -0.6, 4), L(0.6, -4, 0.6, 4), L(-5, 0, -0.6, 0), L(0.6, 0, 5, 0)]


@sym("Blind flange", PP, "Blind flange")
def _():
    return flat(FILL([(-0.7, -4), (0.7, -4), (0.7, 4), (-0.7, 4)]), L(-5, 0, -0.7, 0))


@sym("Spectacle blind", PP, "Spectacle blind (figure 8)")
def _():
    return flat(C(0, 2.6, 2.2), FC(0, -2.6, 2.2), L(0, 0.4, 0, -0.4))


@sym("Elbow", PP, "Elbow 90 deg")
def _():
    return [L(-6, 0, -2, 0), A(-2, 2, 2, 270, 360), L(0, 2, 0, 6)]


@sym("Tee", PP, "Tee")
def _():
    return flat(L(-6, 0, 6, 0), L(0, 0, 0, 6), FC(0, 0, 0.8))


@sym("Cross", PP, "Cross connection")
def _():
    return flat(L(-6, 0, 6, 0), L(0, -6, 0, 6), FC(0, 0, 0.8))


@sym("Pipe crossing", PP, "Pipes crossing, not connected")
def _():
    return [L(-6, 0, 6, 0), L(0, -6, 0, -1.6), A(0, 0, 1.6, 270, 450), L(0, 1.6, 0, 6)]


@sym("Cap", PP, "Cap / end plug")
def _():
    return [L(-6, 0, 0, 0), L(0, -3, 0, 3), A(0, 0, 3, 270, 450)]


@sym("Expansion joint", PP, "Expansion joint / bellows")
def _():
    pts = [(-6, 0), (-3, 0)] + [(-3 + i * 1.0, 2.5 if i % 2 else -2.5) for i in range(1, 6)] + [(3, 0), (6, 0)]
    return [P(pts)]


@sym("Flexible hose", PP, "Flexible hose")
def _():
    t = np.linspace(0, 1, 41)
    pts = [(-6 + 12 * x, 1.5 * math.sin(x * 4 * math.pi)) for x in t]
    return [P(pts)]


@sym("Pressure gauge", PP, "Pressure gauge")
def _():
    return [L(0, 0, 0, 3.5), C(0, 6.5, 3), L(0, 6.5, 1.8, 8.3), L(-1.5, 3.5, 1.5, 3.5)]


@sym("Thermometer", PP, "Thermometer")
def _():
    return flat(L(0, 0, 0, 3.5), C(0, 6.5, 3), T(0, 6.5, "T", 2.6))


@sym("Flow meter", PP, "Flow meter")
def _():
    return flat(L(-7, 0, -3.5, 0), L(3.5, 0, 7, 0), C(0, 0, 3.5), T(0, 0, "FM", 2.2))


@sym("Level gauge", PP, "Level gauge (tank)")
def _():
    return [RECT(-1.5, -6, 1.5, 6), L(-1.5, 1, 1.5, 1), L(-3.5, 6, -1.5, 6), L(-3.5, -6, -1.5, -6)]


@sym("Sight glass", PP, "Sight glass / flow indicator")
def _():
    return [C(0, 0, 3), L(-6, 0, -3, 0), L(3, 0, 6, 0), L(-1, -2.2, -1, 2.2), L(1, -2.2, 1, 2.2)]


@sym("Air vent head", PP, "Air pipe head (gooseneck) with float")
def _():
    return [L(0, 0, 0, 6), A(2.5, 6, 2.5, 0, 180), L(5, 6, 5, 3.5), L(3.6, 3.5, 6.4, 3.5)]


@sym("Sounding pipe head", PP, "Sounding pipe head with cap")
def _():
    return flat(L(0, 0, 0, 3), C(0, 6, 3), T(0, 6, "SP", 2.2))


@sym("Filling connection", PP, "Deck filling connection")
def _():
    return flat(L(0, 0, 0, 3), C(0, 6, 3), T(0, 6, "FL", 2.2))


@sym("Drain valve", PP, "Drain valve / cock")
def _():
    return [L(0, 0, 0, -3), P([(-2, -3), (2, -3), (0, -6)], True)]


@sym("Bell mouth", PP, "Bell mouth / suction strum")
def _():
    return [L(0, 6, 0, 2), P([(-0.8, 2), (-3.5, -2), (3.5, -2), (0.8, 2)], True), L(-3.5, -3, 3.5, -3)]


@sym("Steam trap", PP, "Steam trap")
def _():
    return flat(P([(0, -4), (4, 0), (0, 4), (-4, 0)], True), T(0, 0, "T", 2.4), L(-8, 0, -4, 0), L(4, 0, 8, 0))


@sym("Hose connection", PP, "Hose connection")
def _():
    return [L(-6, 0, 0, 0), RECT(0, -2, 3, 2), L(3, -1.2, 6, -1.2), L(3, 1.2, 6, 1.2)]


@sym("Heat exchanger", PP, "Heat exchanger / cooler")
def _():
    zig = [(-6, 0), (-3, 0), (-2, 2), (0, -2), (2, 2), (3, 0), (6, 0)]
    return [C(0, 0, 4.5), P(zig)]


@sym("Tank", PP, "Tank")
def _():
    return flat(RECT(-9, -6, 9, 6), T(0, 0, "TANK", 2.6))


@sym("Flow arrow", PP, "Flow direction arrow")
def _():
    return flat(L(-6, 0, 6, 0), FILL([(1, -1.5), (1, 1.5), (5, 0)]))


@sym("Overboard", PP, "Overboard discharge")
def _():
    return flat(L(-6, 0, 2, 0), FILL([(2, -2), (2, 2), (6, 0)]), T(0, -3.5, "O/B", 2))


def categories():
    cats = {}
    for name, (cat, desc, fn) in S.items():
        cats.setdefault(cat, []).append(name)
    return cats


def block_name(name):
    return "SYM_" + name.upper().replace(" ", "_").replace("-", "_")


def make_block(name):
    cat, desc, fn = S[name]
    ents = fn()
    layer = "ELECTRICAL" if cat.startswith("Electrical") else "PIPING"
    for e in ents:
        e.layer = "0"; e.color = 0
    return Block(block_name(name), (0, 0, 0), ents), layer
