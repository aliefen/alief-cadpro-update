"""CAM: CNC cutting toolpaths (plasma / oxy-fuel / laser), G-code with G2/G3 arcs, kerf compensation, lead-in/out,
cut ordering (holes first), rectangular nesting on plates."""
import math
import numpy as np
from .geom import Plane, unit, norm, prim_ends, prim_tess, poly_area2, point_in_poly, TAU

MACHINES = {
    "Generic plasma (M03/M05)": {"on": "M03", "off": "M05", "pierce": 0.5, "feed": 2500, "kerf": 1.8, "lead": 6.0},
    "Hypertherm / ESAB plasma (M07/M08)": {"on": "M07", "off": "M08", "pierce": 0.6, "feed": 2200, "kerf": 2.0, "lead": 8.0},
    "Oxy-fuel (M07/M08, preheat)": {"on": "M07", "off": "M08", "pierce": 6.0, "feed": 450, "kerf": 2.5, "lead": 10.0},
    "Fiber laser (M03/M05)": {"on": "M03", "off": "M05", "pierce": 0.3, "feed": 3000, "kerf": 0.25, "lead": 3.0},
}


def loop_segments(ent, pl):
    """Closed curve -> list of 2D segments in plane pl: ('L', a, b) / ('A', c, r, a0, a1, ccw)."""
    segs = []
    if ent.kind in ("ellipse", "spline"):
        P = pl.to_local(ent.pts())[:, :2]
        return [("L", P[i], P[i + 1]) for i in range(len(P) - 1)]
    for pr in ent.prims():
        if pr[0] == "L":
            a, b = pl.to_local(np.array([pr[1], pr[2]]))[:, :2]
            segs.append(("L", a, b))
        else:
            c, r, n, u, a0, a1 = pr[1:]
            if abs(abs(np.dot(n, pl.z)) - 1) > 1e-6:
                P = pl.to_local(prim_tess(pr))[:, :2]
                segs += [("L", P[i], P[i + 1]) for i in range(len(P) - 1)]
                continue
            p0, p1 = prim_ends(pr)
            c2 = pl.to_local(c)[:2]; q0 = pl.to_local(p0)[:2]; q1 = pl.to_local(p1)[:2]
            ccw = np.dot(n, pl.z) > 0
            segs.append(("A", c2, r, q0, q1, ccw, a1 - a0))
    return segs


def seg_points(segs, n_arc=24):
    pts = []
    for s in segs:
        if s[0] == "L":
            pts.append(s[1])
        else:
            c, r, q0, q1, ccw, sw = s[1:]
            a0 = math.atan2(q0[1] - c[1], q0[0] - c[0])
            k = max(4, int(n_arc * sw / TAU) + 1)
            for i in range(k):
                a = a0 + (sw if ccw else -sw) * i / k
                pts.append(c + r * np.array([math.cos(a), math.sin(a)]))
    return np.array(pts)


def build_parts(ents, pl):
    loops = []
    for e in ents:
        if not getattr(e, "closed", False):
            continue
        segs = loop_segments(e, pl)
        P = seg_points(segs)
        if len(P) >= 3:
            loops.append({"segs": segs, "pts": P, "area": poly_area2(P), "ent": e})
    # containment depth
    for i, L in enumerate(loops):
        L["depth"] = sum(1 for j, M in enumerate(loops) if j != i and abs(M["area"]) > abs(L["area"]) and point_in_poly(L["pts"][0], M["pts"]))
    parts = []
    outers = [L for L in loops if L["depth"] % 2 == 0]
    for o in outers:
        holes = [L for L in loops if L["depth"] == o["depth"] + 1 and point_in_poly(L["pts"][0], o["pts"])]
        parts.append({"outer": o, "holes": holes})
    return parts


def offset_loop(P, d, outward):
    import manifold3d as m3
    Q = P if poly_area2(P) > 0 else P[::-1]
    cs = m3.CrossSection([Q], m3.FillRule.Positive).offset(d if outward else -d, m3.JoinType.Round, 2.0, 24)
    polys = [np.asarray(p, float) for p in cs.to_polygons()]
    if not polys:
        return None
    return max(polys, key=lambda p: abs(poly_area2(p)))


def toolpaths(parts, kerf=0.0, lead=5.0, comp="cam", order_start=(0, 0)):
    """Returns ordered list of contours: dict(kind outer/hole, segs or pts, lead_in point, start)."""
    out = []
    pos = np.array(order_start, float)
    remaining = list(parts)
    while remaining:
        k = min(range(len(remaining)), key=lambda i: norm(remaining[i]["outer"]["pts"].mean(axis=0) - pos))
        part = remaining.pop(k)
        items = [("hole", h) for h in part["holes"]] + [("outer", part["outer"])]
        # holes nearest-first
        hs = items[:-1]; seq = []
        while hs:
            j = min(range(len(hs)), key=lambda i: norm(hs[i][1]["pts"][0] - pos))
            kind, L = hs.pop(j); seq.append((kind, L)); pos = L["pts"][0]
        seq.append(items[-1])
        for kind, L in seq:
            P = L["pts"]
            if comp == "cam" and kerf > 0:
                Q = offset_loop(P, kerf / 2, outward=(kind == "outer"))
                if Q is None:
                    continue
                segs = None
            else:
                Q = P; segs = L["segs"]
            # start at the point nearest to the current position (outer: lowest-left corner region)
            i0 = int(np.argmin(np.linalg.norm(Q - pos, axis=1)))
            if segs is None:
                Q = np.roll(Q, -i0, axis=0)
            start = Q[0] if segs is None else _seg_start(segs)
            # lead-in direction: outward normal for outer, inward for holes
            nxt = Q[1] if segs is None else _seg_dir_point(segs)
            t = unit(np.append(nxt - start, 0))[:2]
            nrm = np.array([t[1], -t[0]])          # right of travel
            ccw = poly_area2(Q) > 0
            outward = nrm if ccw else -nrm
            lead_pt = start + (outward if kind == "outer" else -outward) * lead
            out.append({"kind": kind, "pts": Q, "segs": segs, "start": start, "lead": lead_pt, "ccw": ccw})
            pos = start
    return out


def _seg_start(segs):
    s = segs[0]
    return s[1] if s[0] == "L" else s[3]


def _seg_dir_point(segs):
    s = segs[0]
    if s[0] == "L":
        return s[2]
    c, r, q0, q1, ccw, sw = s[1:]
    a0 = math.atan2(q0[1] - c[1], q0[0] - c[0]) + (0.05 if ccw else -0.05)
    return c + r * np.array([math.cos(a0), math.sin(a0)])


def gcode(paths, m, name="ALIEF_CADPRO", comp="cam", kerf=0.0, dec=3, origin=(0, 0)):
    f = lambda v: f"{v:.{dec}f}"
    o = np.array(origin, float)
    L = [f"( {name} - generated by ALIEF CAD PRO )", "( units mm, absolute )", "G21 G90 G17 G40", "G00 X0 Y0"]
    for k, p in enumerate(paths):
        s = p["start"] - o; li = p["lead"] - o
        L.append(f"( contour {k + 1} {p['kind']} )")
        L.append(f"G00 X{f(li[0])} Y{f(li[1])}")
        L.append(m["on"]); L.append(f"G04 P{m['pierce']:g}")
        if comp == "g41" and kerf > 0:
            L.append(("G41" if p["kind"] == "outer" else "G42") + f" D1 ( kerf {kerf:g} )")
        L.append(f"G01 X{f(s[0])} Y{f(s[1])} F{m['feed']:g}")
        if p["segs"] is not None:
            for sg in p["segs"]:
                if sg[0] == "L":
                    b = sg[2] - o; L.append(f"G01 X{f(b[0])} Y{f(b[1])}")
                else:
                    c, r, q0, q1, ccw, sw = sg[1:]
                    if sw > TAU - 1e-6:
                        mid = 2 * c - q0
                        for a, b in ((q0, mid), (mid, q1)):
                            ij = c - a; bb = b - o
                            L.append(f"{'G03' if ccw else 'G02'} X{f(bb[0])} Y{f(bb[1])} I{f(ij[0])} J{f(ij[1])}")
                    else:
                        ij = c - q0; bb = q1 - o
                        L.append(f"{'G03' if ccw else 'G02'} X{f(bb[0])} Y{f(bb[1])} I{f(ij[0])} J{f(ij[1])}")
        else:
            for q in list(p["pts"][1:]) + [p["pts"][0]]:
                q = q - o; L.append(f"G01 X{f(q[0])} Y{f(q[1])}")
        if comp == "g41" and kerf > 0:
            L.append("G40")
        L.append(m["off"])
    L += ["G00 X0 Y0", "M30"]
    return "\n".join(L) + "\n"


def cut_length(paths):
    tot = 0.0; rap = 0.0; pos = np.zeros(2)
    for p in paths:
        P = seg_points(p["segs"]) if p["segs"] is not None else p["pts"]
        tot += float(np.sum(np.linalg.norm(np.diff(np.vstack([P, P[:1]]), axis=0), axis=1))) + norm(p["start"] - p["lead"])
        rap += norm(p["lead"] - pos); pos = p["start"]
    return tot, rap


# --------------------------------------------------------------------------------------------- nesting
def nest_rect(parts, W, H, gap=10.0, margin=10.0, rotate=True):
    """Shelf nesting by bounding boxes. Returns placements [(sheet, part_index, dx, dy, rot90)]."""
    items = []
    for i, p in enumerate(parts):
        P = p["outer"]["pts"]; mn = P.min(axis=0); mx = P.max(axis=0); w, h = mx - mn
        items.append((i, w, h, mn))
    items.sort(key=lambda t: -max(t[1], t[2]))
    sheets = []           # list of shelves per sheet: [ [y, height, x_used] ]
    out = []
    for i, w, h, mn in items:
        placed = False
        cands = [(w, h, False)] + ([(h, w, True)] if rotate and abs(w - h) > 1e-9 else [])
        for si, shelves in enumerate(sheets):
            for sh in shelves:
                for ww, hh, rot in cands:
                    if hh <= sh[1] + 1e-9 and sh[2] + ww <= W - margin + 1e-9:
                        out.append((si, i, sh[2], sh[0], rot, mn, w, h)); sh[2] += ww + gap; placed = True; break
                if placed:
                    break
            if not placed:
                y = (shelves[-1][0] + shelves[-1][1] + gap) if shelves else margin
                for ww, hh, rot in sorted(cands, key=lambda c: c[1]):
                    if y + hh <= H - margin + 1e-9 and margin + ww <= W - margin + 1e-9:
                        shelves.append([y, hh, margin + ww + gap]); out.append((si, i, margin, y, rot, mn, w, h)); placed = True; break
            if placed:
                break
        if not placed:
            for ww, hh, rot in sorted(cands, key=lambda c: c[1]):
                if hh <= H - 2 * margin and ww <= W - 2 * margin:
                    sheets.append([[margin, hh, margin + ww + gap]]); out.append((len(sheets) - 1, i, margin, margin, rot, mn, w, h)); placed = True; break
        if not placed:
            out.append((-1, i, 0, 0, False, mn, w, h))
    return out, len(sheets)
