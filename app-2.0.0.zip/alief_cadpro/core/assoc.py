"""Associative hatches: a hatch remembers its boundary objects and follows them when they are stretched, moved or edited."""
import numpy as np
from .geom import Plane

KINDS = ("line", "arc", "circle", "polyline", "spline", "ellipse")


def _plane(a):
    return Plane(np.array(a["o"], float), np.array(a["x"], float), np.array(a["y"], float))


def _curves(ents, pl):
    out = []
    for e in ents:
        try:
            wires = e.wire()
        except Exception:
            continue
        for w in wires:
            Q = pl.to_local(np.asarray(w, float))
            if len(Q) >= 2:
                out.append(Q[:, :2])
    return out


def _bbox(curves):
    P = np.vstack(curves)
    return np.array([P[:, 0].min(), P[:, 1].min(), P[:, 0].max(), P[:, 1].max()])


def _on_loops(Q, loops, tol):
    """True if a sample of the 2D polyline Q lies on one of the loops (the object is part of the boundary)."""
    S = []
    for i in range(len(Q) - 1):
        for t in (0.21, 0.5, 0.79):
            S.append(Q[i] + (Q[i + 1] - Q[i]) * t)
    if len(S) > 90:
        S = S[::max(1, len(S) // 90)]
    S = np.array(S)
    for L in loops:
        A = np.asarray(L, float)[:, :2]; B = np.roll(A, -1, axis=0); D = B - A
        L2 = np.maximum((D * D).sum(axis=1), 1e-30)
        for q in S:
            t = np.clip(((q - A) * D).sum(axis=1) / L2, 0, 1)
            d = np.linalg.norm(A + D * t[:, None] - q, axis=1)
            if d.min() <= tol:
                return True
    return False


def sources_of(doc, loops_w, pl, candidates=None):
    """Objects of the drawing that make up the boundary loops (world polylines) of a picked-point hatch."""
    loops = [pl.to_local(np.asarray(L, float))[:, :2] for L in loops_w]
    P = np.vstack(loops); mn = P.min(axis=0); mx = P.max(axis=0); size = float(max(mx - mn)); tol = max(size * 1e-6, 1e-9)
    out = []
    for e in (candidates if candidates is not None else doc.visible_ents()):
        if e.kind not in KINDS or (e.xd and e.xd.get("inf")):
            continue
        bb = e.bbox()
        if bb is None:
            continue
        b2 = pl.to_local(np.array([bb[0], bb[1]]))[:, :2]; lo = b2.min(axis=0); hi = b2.max(axis=0)
        if hi[0] < mn[0] - tol or lo[0] > mx[0] + tol or hi[1] < mn[1] - tol or lo[1] > mx[1] + tol:
            continue
        for Q in _curves([e], pl):
            if _on_loops(Q, loops, tol):
                out.append(e); break
    return out


def attach(h, src, pl, seed_w=None, mode="pick"):
    """Make hatch h (already in the document) associative to the source objects."""
    if not src:
        return False
    cur = _curves(src, pl)
    if not cur:
        return False
    a = {"hid": h.id, "src": [e.id for e in src], "mode": mode, "o": pl.o.tolist(), "x": pl.x.tolist(), "y": pl.y.tolist(),
         "box": _bbox(cur).tolist()}
    if seed_w is not None:
        a["seed"] = pl.to_local(np.asarray(seed_w, float))[:2].tolist()
    xd = dict(h.xd or {}); xd["assoc"] = a; h.xd = xd
    return True


def _recompute(doc, h, a):
    from .boundary import find_boundary
    pl = _plane(a)
    src = [doc.ents.get(i) for i in a["src"]]
    if any(e is None for e in src):
        return None
    cur = _curves(src, pl)
    if not cur:
        return None
    box = _bbox(cur); old = np.array(a.get("box", box), float)
    if a.get("mode") == "objects":
        from .solids import regions_from_curves
        regs = regions_from_curves(src, pl)
        if not regs:
            return None
        if len(regs) > 1:
            c0 = np.array([(old[0] + old[2]) / 2, (old[1] + old[3]) / 2])
            def far(r):
                L = np.asarray(r[1][0], float)[:, :2]
                return float(np.linalg.norm((L.min(axis=0) + L.max(axis=0)) / 2 - c0))
            regs = [min(regs, key=far)]
        plane, loops = regs[0]
        return [plane.to_world(l) for l in loops], box
    seed = np.array(a.get("seed", [(old[0] + old[2]) / 2, (old[1] + old[3]) / 2]), float)
    # the picked point keeps its relative place inside the box of the boundary objects (follows a stretch / move / scale)
    w0 = np.maximum(old[2:] - old[:2], 1e-12); rel = (seed - old[:2]) / w0
    cands = [box[:2] + rel * (box[2:] - box[:2]), seed, seed + ((box[:2] + box[2:]) - (old[:2] + old[2:])) / 2]
    for q in cands:
        loops = find_boundary(cur, np.asarray(q, float))
        if loops:
            a["seed"] = np.asarray(q, float).tolist()
            return [pl.to_world(np.column_stack([L, np.zeros(len(L))])) for L in loops], box
    return None


def update(doc, changed):
    """Called at the end of every command with the ids of the changed / removed objects."""
    if not changed:
        return
    for h in list(doc.ents.values()):
        if h.kind != "hatch" or not h.xd or "assoc" not in h.xd:
            continue
        a = h.xd["assoc"]
        if a.get("hid") != h.id:                           # a copy of an associative hatch is an ordinary hatch
            doc.modify(h); xd = dict(h.xd); xd.pop("assoc", None); h.xd = xd or None; continue
        if not (set(a["src"]) & changed):
            continue
        try:
            r = _recompute(doc, h, a)
        except Exception:
            r = None
        doc.modify(h)
        if r is None:
            if any(i not in doc.ents for i in a["src"]):   # boundary erased: the hatch stays, no longer associative
                xd = dict(h.xd); xd.pop("assoc", None); h.xd = xd or None
            continue
        loops, box = r
        h.loops = [np.asarray(l, float).reshape(-1, 3) for l in loops]
        a2 = dict(a); a2["box"] = np.asarray(box, float).tolist(); xd = dict(h.xd); xd["assoc"] = a2; h.xd = xd
        h.touch()
