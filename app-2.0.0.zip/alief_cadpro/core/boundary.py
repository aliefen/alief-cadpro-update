"""BOUNDARY / HATCH pick-point: the closed area around a point, found from any lines, arcs, circles, polylines, splines,
ellipses (the planar arrangement of their line work), with islands (closed shapes inside the area) as holes."""
import math
import numpy as np


def _segments(curves2d):
    """[polyline (k,2)] -> (N,2,2) segment array."""
    segs = []
    for P in curves2d:
        P = np.asarray(P, float)
        if len(P) >= 2:
            segs.append(np.stack([P[:-1], P[1:]], axis=1))
    if not segs:
        return np.zeros((0, 2, 2))
    S = np.vstack(segs)
    L = np.hypot(*(S[:, 1] - S[:, 0]).T)
    return S[L > 1e-12]


def _split_at_intersections(S, tol):
    """Split every segment where it crosses or touches another one. Returns list of (p, q) pieces."""
    n = len(S)
    if n == 0:
        return []
    mn = np.minimum(S[:, 0], S[:, 1]); mx = np.maximum(S[:, 0], S[:, 1])
    ext = mx - mn
    span = max(float((mx.max(axis=0) - mn.min(axis=0)).max()), 1e-9)
    cell = max(span / max(8, int(math.sqrt(n) * 1.5)), float(np.median(np.max(ext, axis=1))) * 2 + 1e-9)
    gmn = mn.min(axis=0)
    i0 = np.floor((mn - gmn) / cell).astype(np.int64); i1 = np.floor((mx - gmn) / cell).astype(np.int64)
    buckets = {}
    for k in range(n):
        for gx in range(i0[k, 0], i1[k, 0] + 1):
            for gy in range(i0[k, 1], i1[k, 1] + 1):
                buckets.setdefault((gx, gy), []).append(k)
    cuts = [[0.0, 1.0] for _ in range(n)]
    seen = set()
    for ids in buckets.values():
        if len(ids) < 2:
            continue
        ids = np.array(ids)
        A = S[ids, 0]; B = S[ids, 1]; D = B - A
        for ii in range(len(ids)):
            a = A[ii]; d = D[ii]; k = ids[ii]
            j = ids[ii + 1:]
            if not len(j):
                continue
            c = A[ii + 1:]; e = D[ii + 1:]
            den = d[0] * e[:, 1] - d[1] * e[:, 0]
            w = c - a
            ok = np.abs(den) > 1e-18
            t = np.where(ok, (w[:, 0] * e[:, 1] - w[:, 1] * e[:, 0]) / np.where(ok, den, 1), -1)
            u = np.where(ok, (w[:, 0] * d[1] - w[:, 1] * d[0]) / np.where(ok, den, 1), -1)
            Ld = math.hypot(*d); Le = np.hypot(e[:, 0], e[:, 1])
            et = tol / max(Ld, 1e-12); eu = tol / np.maximum(Le, 1e-12)
            hit = ok & (t >= -et) & (t <= 1 + et) & (u >= -eu) & (u <= 1 + eu)
            for m in np.flatnonzero(hit):
                key = (min(k, j[m]), max(k, j[m]))
                if key in seen:
                    continue
                seen.add(key)
                cuts[k].append(float(min(1.0, max(0.0, t[m])))); cuts[j[m]].append(float(min(1.0, max(0.0, u[m]))))
            # collinear overlaps: cut at the other segment's end points
            col = (~ok)
            if col.any():
                for m in np.flatnonzero(col):
                    cross = abs(w[m, 0] * d[1] - w[m, 1] * d[0]) / max(Ld, 1e-12)
                    if cross > tol:
                        continue
                    for pnt in (c[m], c[m] + e[m]):
                        tt = float(np.dot(pnt - a, d) / max(Ld * Ld, 1e-24))
                        if -1e-9 < tt < 1 + 1e-9:
                            cuts[k].append(min(1.0, max(0.0, tt)))
                    for pnt in (a, a + d):
                        uu = float(np.dot(pnt - c[m], e[m]) / max(Le[m] ** 2, 1e-24))
                        if -1e-9 < uu < 1 + 1e-9:
                            cuts[j[m]].append(min(1.0, max(0.0, uu)))
    pieces = []
    for k in range(n):
        ts = sorted(set(round(t, 12) for t in cuts[k]))
        a = S[k, 0]; d = S[k, 1] - S[k, 0]
        for t0, t1 in zip(ts[:-1], ts[1:]):
            if t1 - t0 > 1e-12:
                pieces.append((a + t0 * d, a + t1 * d))
    return pieces


def _graph(pieces, tol):
    key = {}
    pts = []
    def vid(p):
        k = (round(p[0] / tol), round(p[1] / tol))
        v = key.get(k)
        if v is None:
            # also look in the neighbouring cells so points that round differently still merge
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    v = key.get((k[0] + dx, k[1] + dy))
                    if v is not None and math.hypot(*(pts[v] - p)) <= tol * 1.5:
                        key[k] = v
                        return v
            v = len(pts); key[k] = v; pts.append(np.asarray(p, float))
        return v
    edges = set()
    for p, q in pieces:
        a = vid(p); b = vid(q)
        if a != b:
            edges.add((min(a, b), max(a, b)))
    return np.array(pts) if pts else np.zeros((0, 2)), edges


def _prune(edges):
    """Remove dangling edges (dead ends), repeatedly."""
    adj = {}
    for a, b in edges:
        adj.setdefault(a, set()).add(b); adj.setdefault(b, set()).add(a)
    stack = [v for v, s in adj.items() if len(s) < 2]
    while stack:
        v = stack.pop()
        for w in list(adj.get(v, ())):
            adj[w].discard(v); adj[v].discard(w)
            if len(adj[w]) < 2:
                stack.append(w)
        adj.pop(v, None)
    return adj


def _faces(P, adj):
    """All face cycles of the planar graph: list of vertex lists with signed area."""
    order = {}
    for v, nb in adj.items():
        nb = list(nb)
        ang = [math.atan2(P[w][1] - P[v][1], P[w][0] - P[v][0]) for w in nb]
        order[v] = [w for _, w in sorted(zip(ang, nb))]
    pos = {v: {w: i for i, w in enumerate(ws)} for v, ws in order.items()}
    used = set(); faces = []
    for v in order:
        for w in order[v]:
            if (v, w) in used:
                continue
            cyc = []; a, b = v, w
            guard = 0
            while (a, b) not in used and guard < 200000:
                used.add((a, b)); cyc.append(a)
                ws = order[b]; i = pos[b][a]
                c = ws[(i - 1) % len(ws)]                  # next edge clockwise from the reversed one = keep the face on the left
                a, b = b, c; guard += 1
            if len(cyc) >= 3:
                Q = P[cyc]
                area = 0.5 * float(np.sum(Q[:, 0] * np.roll(Q[:, 1], -1) - np.roll(Q[:, 0], -1) * Q[:, 1]))
                faces.append((area, cyc))
    return faces


def _inside(pt, Q):
    x, y = pt; inside = False
    n = len(Q); j = n - 1
    for i in range(n):
        xi, yi = Q[i]; xj, yj = Q[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-300) + xi:
            inside = not inside
        j = i
    return inside


def find_boundary(curves2d, pick, tol=None, islands=True):
    """-> [outer loop, hole loops ...] as (k,2) arrays, or None when the point is not inside a closed area."""
    S = _segments(curves2d)
    if not len(S):
        return None
    span = float(np.ptp(S.reshape(-1, 2), axis=0).max())
    tol = tol or max(span * 1e-9, 1e-7)
    pieces = _split_at_intersections(S, tol * 10)
    P, edges = _graph(pieces, tol * 10)
    adj = _prune(edges)
    if not adj:
        return None
    faces = _faces(P, adj)
    pick = np.asarray(pick, float)[:2]
    best = None
    for area, cyc in faces:
        if area <= 0:
            continue
        Q = P[cyc]
        if area < (best[0] if best else float("inf")) and _inside(pick, Q):
            best = (area, cyc)
    if best is None:
        return None
    outer = P[best[1]]
    loops = [outer]
    if islands:
        # outer contours (negative faces) of the other parts of the drawing that lie inside the area
        comp = {}
        cid = 0
        for v in adj:
            if v in comp:
                continue
            stack = [v]; comp[v] = cid
            while stack:
                x = stack.pop()
                for w in adj[x]:
                    if w not in comp:
                        comp[w] = cid; stack.append(w)
            cid += 1
        own = comp[best[1][0]]
        for area, cyc in faces:
            if area >= 0 or comp[cyc[0]] == own:
                continue
            Q = P[cyc]
            if all(_inside(q, outer) for q in Q[:: max(1, len(Q) // 8)]) and not _inside(pick, Q):
                loops.append(Q[::-1])
    return loops
