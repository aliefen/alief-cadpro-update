"""3D solid and surface construction on top of manifold3d (light, robust mesh booleans)."""
import math
import numpy as np
import manifold3d as m3
from .geom import Plane, unit, norm, v3, EPS, prims_tess, plane_of_points, poly_area2, point_in_poly, xform_pt
from .entities import Body

m3.set_circular_segments(48)


class SolidError(Exception):
    pass


# --------------------------------------------------------------------------------------------- conversion
def to_manifold(body):
    mesh = m3.Mesh64(np.ascontiguousarray(body.V, np.float64), np.ascontiguousarray(body.F, np.uint64))
    mesh.merge()
    m = m3.Manifold(mesh)
    if m.status() != m3.Error.NoError or m.is_empty():
        raise SolidError(f"object is not a closed solid ({m.status().name})")
    return m


def from_manifold(m, role="solid", meta=None):
    if m.is_empty():
        raise SolidError("result is empty")
    mesh = m.to_mesh64()
    V = np.asarray(mesh.vert_properties, float)[:, :3]
    F = np.asarray(mesh.tri_verts, np.int64)
    return Body(V.copy(), F.copy(), role, meta)


def place(m, plane):
    """Transform a manifold from plane-local to world."""
    M = plane.matrix()
    return m.transform(np.ascontiguousarray(M[:3, :4]))


def validate_mesh(V, F, role="solid", meta=None):
    """Return a Body built through manifold (merged, oriented) or raise."""
    b = Body(V, F, role, meta)
    m = to_manifold(b)
    if m.volume() < 0:
        b.F = b.F[:, ::-1]
        m = to_manifold(b)
    return from_manifold(m, role, meta)


# --------------------------------------------------------------------------------------------- primitives
def box(plane, x0, y0, x1, y1, z0, z1):
    a = np.array([min(x0, x1), min(y0, y1), min(z0, z1)]); b = np.array([max(x0, x1), max(y0, y1), max(z0, z1)])
    s = b - a
    if np.any(s < 1e-9):
        raise SolidError("box with zero size")
    m = m3.Manifold.cube(tuple(s)).translate(tuple(a))
    return from_manifold(place(m, plane))


def cylinder(plane, r, h, r_top=None, segs=48):
    if r_top is None:
        r_top = r
    z0 = 0.0
    if h < 0:
        h = -h; z0 = -h; r, r_top = r_top, r
    m = m3.Manifold.cylinder(h, r, r_top, segs).translate((0, 0, z0))
    return from_manifold(place(m, plane))


def sphere(c, r, segs=48):
    m = m3.Manifold.sphere(r, segs).translate(tuple(v3(c)))
    return from_manifold(m)


def torus(plane, R, r, segs=48):
    if r >= R:
        raise SolidError("tube radius must be smaller than torus radius")
    cs = m3.CrossSection.circle(r, 24).translate((R, 0))
    return from_manifold(place(m3.Manifold.revolve(cs, segs, 360.0), plane))


def wedge(plane, dx, dy, dz):
    pts = np.array([[0, 0], [dx, 0], [0, dz]]) if True else None
    # triangle in XZ extruded along Y
    cs = m3.CrossSection([np.array([[0, 0], [abs(dx), 0], [0, abs(dz)]])])
    m = m3.Manifold.extrude(cs, abs(dy))          # along Z -> rotate so that the triangle lies in XZ
    M = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0]], float)   # (x, y, z) -> (x, z, y)
    m = m.transform(M)
    sx, sy, sz = np.sign(dx) or 1, np.sign(dy) or 1, np.sign(dz) or 1
    m = m.scale((sx, sy, sz))
    if sx * sy * sz < 0:
        pass
    return from_manifold(place(m, plane))


def pyramid(plane, r, h, nside=4, r_top=0.0, rot=0.0):
    r_top = max(r_top, 0.0)
    m = m3.Manifold.cylinder(abs(h), r, r_top if r_top > 0 else 0.0, int(nside))
    m = m.rotate((0, 0, math.degrees(rot)))
    if h < 0:
        m = m.mirror((0, 0, 1))
    return from_manifold(place(m, plane))


# --------------------------------------------------------------------------------------------- profiles
def curve_loop_world(ent):
    """Closed curve entity -> Nx3 points (no repeated end)."""
    P = prims_tess(ent.prims()) if ent.kind not in ("ellipse", "spline") else ent.pts()
    if len(P) > 2 and norm(P[0] - P[-1]) < 1e-7 * max(1, norm(P[0])):
        P = P[:-1]
    return P


def regions_from_curves(ents, ref_plane=None):
    """Group closed planar curves into (plane, [loops2d]) by containment (outer + holes, even-odd)."""
    loops = []
    for e in ents:
        if not getattr(e, "closed", False):
            continue
        P = curve_loop_world(e)
        if len(P) < 3:
            continue
        pl = e.plane() if hasattr(e, "plane") else None
        if pl is None:
            r = plane_of_points(P)
            if r is None or r[2] > 1e-4:
                continue
            pl = Plane.from_normal(r[0], r[1])
        loops.append((P, pl))
    if not loops:
        return []
    base = ref_plane or loops[0][1]
    if ref_plane is None:
        # orient the plane normal like the UCS z if close to it
        pass
    groups = []
    used = [False] * len(loops)
    for i, (P, pl) in enumerate(loops):
        if used[i]:
            continue
        same = [j for j, (Q, ql) in enumerate(loops) if not used[j] and abs(abs(np.dot(ql.z, pl.z)) - 1) < 1e-6
                and abs(np.dot(Q[0] - pl.o, pl.z)) < 1e-6 * max(1.0, norm(Q[0]))]
        plane = Plane.from_normal(pl.o, pl.z if ref_plane is None or np.dot(pl.z, ref_plane.z) >= 0 else -pl.z,
                                  ref_plane.x if ref_plane is not None else None)
        L2 = []
        for j in same:
            used[j] = True
            L2.append(plane.to_local(loops[j][0])[:, :2])
        groups.append((plane, L2))
    return groups


def cross_section(loops2):
    cs = m3.CrossSection([np.asarray(l, float) for l in loops2], m3.FillRule.EvenOdd)
    if cs.is_empty():
        raise SolidError("closed region is empty")
    return cs


def extrude_region(plane, loops2, z0, z1, role="solid", meta=None):
    cs = cross_section(loops2)
    h = z1 - z0
    if abs(h) < 1e-12:
        raise SolidError("zero height")
    m = m3.Manifold.extrude(cs, abs(h)).translate((0, 0, min(z0, z1)))
    return from_manifold(place(m, plane), role, meta)


def revolve_region(plane, loops2, axis_p, axis_d, ang_deg, role="solid"):
    """Revolve region (in plane) about an axis lying in the plane."""
    ad = unit(axis_d)
    ax2 = plane.to_local(np.array([axis_p, axis_p + ad]))[:, :2]
    o2 = ax2[0]; d2 = unit(np.append(ax2[1] - ax2[0], 0))[:2]
    perp = np.array([d2[1], -d2[0]])     # right of the axis
    # local (r, z): r along perp, z along the axis
    loops_rz = []
    side = 0
    for l in loops2:
        q = l - o2
        rz = np.stack([q @ perp, q @ d2], axis=1)
        side += np.sign(rz[:, 0].mean())
        loops_rz.append(rz)
    if side < 0:
        loops_rz = [np.stack([-l[:, 0], l[:, 1]], axis=1)[::-1] for l in loops_rz]
        perp = -perp
    cs = m3.CrossSection(loops_rz, m3.FillRule.EvenOdd)
    m = m3.Manifold.revolve(cs, 64, float(ang_deg))
    # local frame: X = perp, Y = axis-normal..., Z = axis
    o = plane.to_world(o2); zx = unit(plane.to_world(o2 + perp) - o); zz = ad if np.dot(ad, plane.to_world(o2 + d2) - o) > 0 else -ad
    zz = unit(plane.to_world(o2 + d2) - o)
    fr = Plane(o, zx, np.cross(zz, zx))
    return from_manifold(place(m, fr), role)


# --------------------------------------------------------------------------------------------- sweep
def _frames(path, up):
    """Per-segment frames (t, s, w) along a polyline path; w ~ up projected."""
    T = np.array([unit(path[i + 1] - path[i]) for i in range(len(path) - 1)])
    up = unit(v3(up))
    fr = []
    prev_w = None
    for t in T:
        w = up - np.dot(up, t) * t
        if norm(w) < 1e-6:
            w = prev_w if prev_w is not None else np.cross(t, [1, 0, 0] if abs(t[0]) < 0.9 else [0, 1, 0])
            w = w - np.dot(w, t) * t
        w = unit(w); s = np.cross(t, w)
        fr.append((t, s, w)); prev_w = w
    return fr


def sweep_loops(loops_st, path, up, closed_path=False, scale=1.0):
    """Sweep 2D section loops (s, t) along a 3D polyline path with mitred corners. Returns (V, F)."""
    P = np.asarray(path, float)
    keep = [0]
    for i in range(1, len(P)):
        if norm(P[i] - P[keep[-1]]) > 1e-9:
            keep.append(i)
    P = P[keep]
    if closed_path and norm(P[0] - P[-1]) > 1e-9:
        P = np.vstack([P, P[:1]])
    if len(P) < 2:
        raise SolidError("path too short")
    fr = _frames(P, up)
    nseg = len(fr)
    loops = [np.asarray(l, float) * scale for l in loops_st]
    rings_all = []
    nj = len(P) if not closed_path else len(P) - 1
    for lp in loops:
        rings = []
        for j in range(nj):
            if closed_path:
                a = fr[(j - 1) % nseg]; b = fr[j % nseg]
            else:
                a = fr[max(j - 1, 0)]; b = fr[min(j, nseg - 1)]
            o1 = lp[:, :1] * a[1] + lp[:, 1:2] * a[2]
            o2 = lp[:, :1] * b[1] + lp[:, 1:2] * b[2]
            if a is b or np.dot(a[0], b[0]) > 1 - 1e-12:
                pts = P[j] + (o1 + o2) / 2
            else:
                ta, tb = a[0], b[0]
                w = o1 - o2
                aa = 1.0; bb = np.dot(ta, tb); cc = 1.0
                d = w @ ta; e = w @ tb; den = aa * cc - bb * bb
                lam = (bb * e - cc * d) / den; mu = (aa * e - bb * d) / den
                q1 = o1 + lam[:, None] * ta; q2 = o2 + mu[:, None] * tb
                pts = P[j] + (q1 + q2) / 2
            rings.append(pts)
        rings_all.append(rings)
    V = []; F = []
    base = 0
    nr = nj
    for lp_i, rings in enumerate(rings_all):
        k = len(rings[0])
        V.extend(rings)
        segs = nr if closed_path else nr - 1
        for j in range(segs):
            r0 = base + j * k; r1 = base + ((j + 1) % nr) * k
            for i in range(k):
                i1 = (i + 1) % k
                F.append([r0 + i, r0 + i1, r1 + i1]); F.append([r0 + i, r1 + i1, r1 + i])
        base += nr * k
    V = np.vstack(V); F = np.array(F, np.int64)
    if not closed_path:
        # caps
        tri = np.asarray(m3.triangulate([np.asarray(l, float) for l in loops]), np.int64)
        offs = []; acc = 0
        for lp_i, lp in enumerate(loops):
            offs.append(acc); acc += len(lp)
        # map triangulated index (concatenated loops) -> ring vertex index
        loop_of = np.concatenate([np.full(len(l), i) for i, l in enumerate(loops)])
        idx_in = np.concatenate([np.arange(len(l)) for l in loops])
        ring_base = []
        acc = 0
        for rings in rings_all:
            ring_base.append(acc); acc += nr * len(rings[0])
        def vid(t, j):
            li = loop_of[t]; return ring_base[li] + j * len(loops[li]) + idx_in[t]
        vfun = np.vectorize(vid)
        start = vfun(tri, 0); end = vfun(tri, nr - 1)
        F = np.vstack([F, start[:, ::-1], end])
    return V, F


def sweep_solid(loops_st, path, up, closed_path=False, role="solid", meta=None, scale=1.0):
    V, F = sweep_loops(loops_st, path, up, closed_path, scale)
    return validate_mesh(V, F, role, meta)


# --------------------------------------------------------------------------------------------- loft
def resample_loop(P, n, closed=True):
    P = np.asarray(P, float)
    Q = np.vstack([P, P[:1]]) if closed else P
    d = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(Q, axis=0), axis=1))])
    t = np.linspace(0, d[-1], n + (1 if closed else 0))
    if closed:
        t = t[:-1]
    return np.stack([np.interp(t, d, Q[:, k]) for k in range(3)], axis=1)


def loft_solid(loops3d, n=64):
    L = [resample_loop(l, n) for l in loops3d]
    # orientation & start alignment
    ref_n = None
    out = [L[0]]
    for l in L[1:]:
        prev = out[-1]
        best = None
        for cand in (l, l[::-1]):
            for sh in range(0, n, max(1, n // 64)):
                c = np.roll(cand, -sh, axis=0)
                d = np.sum(np.linalg.norm(c - prev, axis=1))
                if best is None or d < best[0]:
                    best = (d, c)
        out.append(best[1])
    k = n; nr = len(out)
    V = np.vstack(out); F = []
    for j in range(nr - 1):
        for i in range(k):
            a, b = j * k + i, j * k + (i + 1) % k
            F += [[a, b, b + k], [a, b + k, a + k]]
    F = np.array(F, np.int64)
    # caps
    for j, flip in ((0, True), (nr - 1, False)):
        r = plane_of_points(out[j])
        pl = Plane.from_normal(r[0], r[1]) if r else Plane()
        q = pl.to_local(out[j])[:, :2]
        if poly_area2(q) < 0:
            q = q[::-1]; idx = np.arange(k)[::-1]
        else:
            idx = np.arange(k)
        tri = np.asarray(m3.triangulate([q]), np.int64)
        tri = idx[tri] + j * k
        F = np.vstack([F, tri[:, ::-1] if flip else tri])
    try:
        return validate_mesh(V, F)
    except SolidError:
        F2 = F.copy()
        F2[:-(len(F) - (nr - 1) * k * 2)] = F2[:-(len(F) - (nr - 1) * k * 2), ::-1]
        return validate_mesh(V, F2)


# --------------------------------------------------------------------------------------------- booleans
def boolean(a_bodies, b_bodies, op):
    A = None
    for b in a_bodies:
        m = to_manifold(b)
        A = m if A is None else A + m
    if op == "union":
        for b in b_bodies:
            A = A + to_manifold(b)
    else:
        B = None
        for b in b_bodies:
            m = to_manifold(b); B = m if B is None else B + m
        if B is not None:
            A = A - B if op == "subtract" else A ^ B
    return A


def slice_body(body, p, n):
    m = to_manifold(body)
    n = unit(n)
    a, b = m.split_by_plane(tuple(n), float(np.dot(n, p)))
    out = []
    for part in (a, b):
        if not part.is_empty() and part.volume() > 1e-12:
            out.append(from_manifold(part, body.role, dict(body.meta)))
    return out


def thicken(V, F, t, both=False):
    """Thicken an open surface mesh into a closed solid (offset along vertex normals)."""
    V = np.asarray(V, float); F = np.asarray(F, np.int64)
    # merge duplicate vertices
    key = np.round(V, 8)
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    inv = inv.ravel(); V = uniq.astype(float); F = inv[F]
    a, b, c = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    fn = np.cross(b - a, c - a)
    vn = np.zeros_like(V)
    for k in range(3):
        np.add.at(vn, F[:, k], fn)
    vn = vn / np.maximum(np.linalg.norm(vn, axis=1, keepdims=True), 1e-18)
    if both:
        top = V + vn * t / 2; bot = V - vn * t / 2
    else:
        top = V + vn * t; bot = V.copy()
    n = len(V)
    VV = np.vstack([top, bot])
    FF = [F, F[:, ::-1] + n]
    e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    es = np.sort(e, axis=1)
    _, idx, cnt = np.unique(es, axis=0, return_index=True, return_counts=True)
    bnd = e[idx[cnt == 1]]
    side = []
    for i, j in bnd:
        side += [[j, i, i + n], [j, i + n, j + n]]
    if side:
        FF.append(np.array(side, np.int64))
    FF = np.vstack(FF)
    if t < 0:
        FF = FF[:, ::-1]
    return validate_mesh(VV, FF)


# --------------------------------------------------------------------------------------------- surfaces
def grid_surface(G, closed_u=False, closed_v=False, meta=None, iso_step=None):
    """G: (nu, nv, 3) grid -> surface Body with isolines."""
    G = np.asarray(G, float); nu, nv = G.shape[:2]
    V = G.reshape(-1, 3); F = []
    ru = nu if closed_u else nu - 1; rv = nv if closed_v else nv - 1
    for i in range(ru):
        for j in range(rv):
            a = i * nv + j; b = ((i + 1) % nu) * nv + j; c = ((i + 1) % nu) * nv + (j + 1) % nv; d = i * nv + (j + 1) % nv
            F += [[a, b, c], [a, c, d]]
    iso = []
    su = max(1, (nu - 1) // 8) if iso_step is None else iso_step
    sv = max(1, (nv - 1) // 8) if iso_step is None else iso_step
    for i in list(range(0, nu, su)) + ([nu - 1] if (nu - 1) % su else []):
        iso.append(G[i, :] if not closed_v else np.vstack([G[i, :], G[i, :1]]))
    for j in list(range(0, nv, sv)) + ([nv - 1] if (nv - 1) % sv else []):
        iso.append(G[:, j] if not closed_u else np.vstack([G[:, j], G[:1, j]]))
    return Body(V, np.array(F, np.int64), "surface", meta, iso)


def resample_open(P, n):
    return resample_loop(P, n, closed=False)


def curve_points(ent, n=None):
    if ent.kind in ("ellipse", "spline"):
        P = ent.pts()
    else:
        P = prims_tess(ent.prims())
    if n:
        P = resample_loop(P, n, closed=False) if not ent.closed else resample_loop(P[:-1] if norm(P[0] - P[-1]) < 1e-9 else P, n)
    return P


def extrude_surface(P, d, n=None):
    P = np.asarray(P, float)
    G = np.stack([P, P + d], axis=1)
    return grid_surface(G)


def revolve_surface(P, axis_p, axis_d, ang_deg, segs=48):
    from .geom import m_rotate
    nsteps = max(2, int(segs * abs(ang_deg) / 360) + 1)
    G = []
    for k in range(nsteps):
        a = math.radians(ang_deg) * k / (nsteps - 1)
        M = m_rotate(axis_p, axis_d, a)
        G.append(xform_pt(M, P))
    full = abs(abs(ang_deg) - 360) < 1e-6
    G = np.array(G)
    if full:
        G = G[:-1]
    return grid_surface(G, closed_u=full)


def loft_surface(curves_pts, n=48):
    L = [resample_open(c, n) for c in curves_pts]
    for i in range(1, len(L)):
        if norm(L[i][0] - L[i - 1][0]) > norm(L[i][-1] - L[i - 1][0]):
            L[i] = L[i][::-1]
    # smooth through sections with Catmull-Rom in the loft direction
    G = np.array(L)
    if len(L) > 2:
        G = _catmull_rows(G, 8)
    return grid_surface(G)


def _catmull_rows(G, sub):
    n = len(G); out = []
    for i in range(n - 1):
        p0 = G[max(i - 1, 0)]; p1 = G[i]; p2 = G[i + 1]; p3 = G[min(i + 2, n - 1)]
        for k in range(sub):
            t = k / sub
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    out.append(G[-1])
    return np.array(out)


def ruled_surface(P1, P2, n=48):
    a = resample_open(P1, n); b = resample_open(P2, n)
    if norm(a[0] - b[0]) + norm(a[-1] - b[-1]) > norm(a[0] - b[-1]) + norm(a[-1] - b[0]):
        b = b[::-1]
    return grid_surface(np.stack([a, b], axis=1))


def coons_surface(c1, c2, c3, c4, n=32):
    """Edge surface from 4 connected boundary curves (any order)."""
    curves = [resample_open(c, n) for c in (c1, c2, c3, c4)]
    # chain the curves into a loop c0 -> c1 -> c2 -> c3
    chain = [curves[0]]; rest = curves[1:]
    while rest:
        end = chain[-1][-1]
        best = min(range(len(rest)), key=lambda k: min(norm(rest[k][0] - end), norm(rest[k][-1] - end)))
        c = rest.pop(best)
        if norm(c[-1] - end) < norm(c[0] - end):
            c = c[::-1]
        chain.append(c)
    A, B, C, D = chain               # A: u-bottom, B: v-right, C: u-top (reversed), D: v-left (reversed)
    C = C[::-1]; D = D[::-1]
    u = np.linspace(0, 1, n)[:, None, None]; v = np.linspace(0, 1, n)[None, :, None]
    Au = A[:, None, :]; Cu = C[:, None, :]; Dv = D[None, :, :]; Bv = B[None, :, :]
    P00, P10, P01, P11 = A[0], A[-1], C[0], C[-1]
    G = (1 - v) * Au + v * Cu + (1 - u) * Dv + u * Bv - ((1 - u) * (1 - v) * P00 + u * (1 - v) * P10 + (1 - u) * v * P01 + u * v * P11)
    return grid_surface(G)


def planar_surface(plane, loops2):
    from .entities import triangulate_loops
    r = triangulate_loops(plane, loops2)
    if r is None:
        raise SolidError("no closed region")
    V, F = r
    iso = [plane.to_world(np.vstack([l, l[:1]])) for l in loops2]
    return Body(V, np.asarray(F, np.int64), "surface", None, iso)


def sweep_surface(profile_pts, path, up=None):
    """Open profile swept along path: grid (path stations x profile points)."""
    P = np.asarray(path, float)
    prof = np.asarray(profile_pts, float)
    r = plane_of_points(prof)
    p0 = P[0]; t0 = unit(P[1] - P[0])
    up = up if up is not None else (r[1] if r is not None and abs(np.dot(r[1], t0)) < 0.9 else np.array([0, 0, 1.0]))
    fr = _frames(P, up)
    t, s, w = fr[0]
    loc = np.stack([(prof - p0) @ s, (prof - p0) @ w, (prof - p0) @ t], axis=1)
    G = []
    for j in range(len(P)):
        a = fr[max(j - 1, 0)]; b = fr[min(j, len(fr) - 1)]
        ss = unit(a[1] + b[1]); ww = unit(a[2] + b[2]); tt = unit(a[0] + b[0])
        G.append(P[j] + loc[:, :1] * ss + loc[:, 1:2] * ww + loc[:, 2:3] * tt)
    return grid_surface(np.array(G))


# --------------------------------------------------------------------------------------------- Rhino-style surfaces
def _rot_between(a, b):
    """Rotation matrix turning unit vector a onto unit vector b (minimal rotation)."""
    a = unit(a); b = unit(b); v = np.cross(a, b); c = float(np.dot(a, b)); s = norm(v)
    if s < 1e-12:
        if c > 0:
            return np.eye(3)
        p = unit(np.cross(a, [1.0, 0, 0]) if abs(a[0]) < 0.9 else np.cross(a, [0, 1.0, 0]))
        return 2 * np.outer(p, p) - np.eye(3)
    k = v / s; K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return np.eye(3) + s * K + (1 - c) * (K @ K)


def _arclen(P):
    d = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
    return d / d[-1] if d[-1] > 0 else d


def _eval_at(P, t):
    s = _arclen(P)
    return np.stack([np.interp(t, s, P[:, k]) for k in range(3)], axis=1)


def _closest_pair(A, B):
    """Closest points of two dense polylines: (param on A, param on B, point A, point B, distance)."""
    D = np.linalg.norm(A[:, None, :] - B[None, :, :], axis=2)
    i, j = np.unravel_index(np.argmin(D), D.shape)
    return _arclen(A)[i], _arclen(B)[j], A[i], B[j], float(D[i, j])


def spline_weights(knots, x):
    """Weights W (len(x), len(knots)) of the natural cubic spline interpolation operator: f(x) = W @ f(knots)."""
    k = np.asarray(knots, float); x = np.asarray(x, float); n = len(k)
    if n == 1:
        return np.ones((len(x), 1))
    if n == 2:
        t = (x - k[0]) / (k[1] - k[0]); return np.stack([1 - t, t], axis=1)
    h = np.diff(k)
    A = np.zeros((n, n)); A[0, 0] = A[-1, -1] = 1.0
    B = np.zeros((n, n))
    for i in range(1, n - 1):
        A[i, i - 1] = h[i - 1]; A[i, i] = 2 * (h[i - 1] + h[i]); A[i, i + 1] = h[i]
        B[i, i - 1] = 6 / h[i - 1]; B[i, i] = -6 / h[i - 1] - 6 / h[i]; B[i, i + 1] = 6 / h[i]
    M2 = np.linalg.solve(A, B)                      # second derivatives as a linear map of the values
    idx = np.clip(np.searchsorted(k, x, side="right") - 1, 0, n - 2)
    W = np.zeros((len(x), n))
    for r, (xi, i) in enumerate(zip(x, idx)):
        hi = h[i]; a = (k[i + 1] - xi) / hi; b = (xi - k[i]) / hi
        W[r, i] += a; W[r, i + 1] += b
        W[r] += ((a ** 3 - a) * M2[i] + (b ** 3 - b) * M2[i + 1]) * hi * hi / 6
    return W


def sort_sections(curves):
    """Order section curves along their main direction (like Rhino's automatic loft ordering)."""
    C = np.array([np.mean(c, axis=0) for c in curves])
    if len(C) < 3:
        return list(range(len(C)))
    u, s, vt = np.linalg.svd(C - C.mean(axis=0))
    return list(np.argsort((C - C.mean(axis=0)) @ vt[0]))


def loft_surface_ex(curves_pts, style="Normal", closed=False, n=48, sort=True):
    cur = [np.asarray(c, float) for c in curves_pts]
    if sort:
        cur = [cur[i] for i in sort_sections(cur)]
    L = [resample_open(c, n) for c in cur]
    for i in range(1, len(L)):
        if norm(L[i][0] - L[i - 1][0]) + norm(L[i][-1] - L[i - 1][-1]) > norm(L[i][-1] - L[i - 1][0]) + norm(L[i][0] - L[i - 1][-1]):
            L[i] = L[i][::-1]
    G = np.array(L)
    if closed and len(L) >= 3:
        if style != "Straight":
            k = np.arange(len(L) + 1, dtype=float); x = np.linspace(0, len(L), len(L) * 8, endpoint=False)
            Gc = np.concatenate([G, G[:1]]); Gp = np.concatenate([G[-2:], Gc, G[1:3]])        # periodic padding
            W = spline_weights(np.arange(-2, len(L) + 3, dtype=float), x)
            G = np.einsum("xk,kjd->xjd", W, Gp)
        return grid_surface(G, closed_u=True)
    if style != "Straight" and len(L) > 2:
        t = np.arange(len(L), dtype=float)
        W = spline_weights(t, np.linspace(0, len(L) - 1, (len(L) - 1) * 8 + 1))
        G = np.einsum("xk,kjd->xjd", W, G)
    return grid_surface(G)


def srf_pt(pts, n=9):
    """Surface from 3 or 4 corner points (bilinear)."""
    P = [np.asarray(p, float) for p in pts]
    if len(P) == 3:
        P = [P[0], P[1], P[2], P[2]]
    u = np.linspace(0, 1, n)[:, None, None]; v = np.linspace(0, 1, n)[None, :, None]
    G = (1 - u) * (1 - v) * P[0] + u * (1 - v) * P[1] + u * v * P[2] + (1 - u) * v * P[3]
    return grid_surface(G)


def edge_surface(curves, n=32):
    """Rhino EdgeSrf: surface from 2, 3 or 4 edge curves."""
    if len(curves) == 2:
        return ruled_surface(curves[0], curves[1], n)
    if len(curves) == 3:
        cs = [resample_open(c, n) for c in curves]
        # the missing 4th edge is the degenerate point where the chain closes
        chain = [cs[0]]; rest = cs[1:]
        while rest:
            end = chain[-1][-1]
            k = min(range(len(rest)), key=lambda i: min(norm(rest[i][0] - end), norm(rest[i][-1] - end)))
            c = rest.pop(k)
            chain.append(c[::-1] if norm(c[-1] - end) < norm(c[0] - end) else c)
        apex = (chain[2][-1] + chain[0][0]) / 2
        return coons_surface(chain[0], chain[1], chain[2], np.repeat(apex[None, :], 2, axis=0), n)
    if len(curves) == 4:
        return coons_surface(*curves, n=n)
    raise SolidError("select 2, 3 or 4 edge curves")


def extrude_along(P, path):
    """Rhino ExtrudeCrvAlongCrv: translate the curve along the path (no rotation)."""
    P = np.asarray(P, float); Q = np.asarray(path, float)
    return grid_surface(Q[:, None, :] - Q[0] + P[None, :, :])


def extrude_to_point(P, apex, n=9):
    P = np.asarray(P, float); t = np.linspace(0, 1, n)[:, None, None]
    return grid_surface(P[None, :, :] * (1 - t) + np.asarray(apex, float) * t)


def sweep2(rail1, rail2, sections, nu=64, nv=40):
    """Rhino Sweep2: cross sections follow two rails (each station is turned and scaled to span the rails)."""
    R1 = resample_open(rail1, nu); R2 = resample_open(rail2, nu)
    if norm(R1[0] - R2[0]) + norm(R1[-1] - R2[-1]) > norm(R1[0] - R2[-1]) + norm(R1[-1] - R2[0]):
        R2 = R2[::-1]
    secs = []
    for sp in sections:
        Sx = resample_open(sp, nv)
        i1 = int(np.argmin(np.linalg.norm(R1 - Sx[0], axis=1))); i2 = int(np.argmin(np.linalg.norm(R1 - Sx[-1], axis=1)))
        if np.linalg.norm(R1[i2] - Sx[-1]) < np.linalg.norm(R1[i1] - Sx[0]):
            Sx = Sx[::-1]; i1 = i2
        secs.append((i1, Sx))
    secs.sort(key=lambda s: s[0])
    def mapped(Sx, i):
        a, b = Sx[0], Sx[-1]; ch = b - a; L = norm(ch)
        a2, b2 = R1[i], R2[i]; ch2 = b2 - a2; L2 = norm(ch2)
        if L < 1e-12:
            return Sx - a + a2
        Rm = _rot_between(ch, ch2) if L2 > 1e-12 else np.eye(3)
        return a2 + ((Sx - a) @ Rm.T) * (L2 / L)
    G = []
    for i in range(nu):
        if len(secs) == 1 or i <= secs[0][0]:
            G.append(mapped(secs[0][1], i))
        elif i >= secs[-1][0]:
            G.append(mapped(secs[-1][1], i))
        else:
            k = max(j for j in range(len(secs)) if secs[j][0] <= i); k = min(k, len(secs) - 2)
            i0, i1 = secs[k][0], secs[k + 1][0]; t = (i - i0) / max(1, i1 - i0)
            G.append((1 - t) * mapped(secs[k][1], i) + t * mapped(secs[k + 1][1], i))
    return grid_surface(np.array(G))


def rail_revolve(profile, rail, axis_p, axis_d, nu=72, nv=40, scale_height=False):
    """Rhino RailRevolve: the profile revolves about the axis while its radius follows the rail curve."""
    from .geom import m_rotate
    axis_p = np.asarray(axis_p, float); d = unit(axis_d)
    Pf = resample_open(profile, nv); R = resample_open(rail, nu)
    def cyl(X):
        w = X - axis_p; h = w @ d; rad = w - np.outer(h, d)
        return h, rad, np.linalg.norm(rad, axis=1)
    hr, radr, rr = cyl(R)
    hp, radp, rp = cyl(Pf)
    # the profile end that touches the rail defines the reference radius / height
    k = 0 if norm(Pf[0] - R[0]) <= norm(Pf[-1] - R[0]) else len(Pf) - 1
    r0 = max(rp[k], 1e-9); e0 = radr[0] / max(rr[0], 1e-12); h0 = hr[0]
    v0 = unit(np.cross(d, e0))
    G = []
    for i in range(nu):
        e = radr[i] / max(rr[i], 1e-12)
        ang = math.atan2(float(np.dot(e, v0)), float(np.dot(e, e0)))
        M = m_rotate(axis_p, d, ang)
        Q = xform_pt(M, Pf)
        h, rad, r = cyl(Q)
        f = rr[i] / r0
        hh = h if not scale_height else h0 + (h - h0) * f + (hr[i] - h0)
        G.append(axis_p + np.outer(hh, d) + rad * f)
    closed = norm(R[0] - R[-1]) < 1e-6 * max(1.0, rr.max())
    G = np.array(G)
    return grid_surface(G[:-1] if closed else G, closed_u=closed)


def network_surface(curves, nu=40, nv=40):
    """Rhino NetworkSrf: Gordon surface through a network of curves in two directions (auto-sorted)."""
    C = [resample_open(c, 160) for c in curves]
    if len(C) < 3:
        raise SolidError("select at least 3 curves forming a network")
    allp = np.vstack(C); diag = norm(allp.max(axis=0) - allp.min(axis=0)); tol = 0.03 * diag
    # split into two families: curves that cross curve 0 belong to the other family
    fam = {0: 0}; todo = [0]
    while todo:
        i = todo.pop()
        for j in range(len(C)):
            if j in fam:
                continue
            if _closest_pair(C[i], C[j])[4] < tol:
                fam[j] = 1 - fam[i]; todo.append(j)
    if len(fam) < len(C):
        raise SolidError("the curves do not form one connected network")
    U = [C[i] for i in range(len(C)) if fam[i] == 0]; V = [C[i] for i in range(len(C)) if fam[i] == 1]
    if not V or not U:
        raise SolidError("curves in two directions are required")
    if len(U) < 2 and len(V) < 2:
        raise SolidError("at least two curves are needed in one direction")
    # orient + order: U sorted along V[0], V sorted along U[0]
    U.sort(key=lambda c: _closest_pair(c, V[0])[1]); V.sort(key=lambda c: _closest_pair(c, U[0])[1])
    for i in range(len(U)):
        if len(V) > 1 and _closest_pair(U[i], V[0])[0] > _closest_pair(U[i], V[-1])[0]:
            U[i] = U[i][::-1]
    for j in range(len(V)):
        if len(U) > 1 and _closest_pair(V[j], U[0])[0] > _closest_pair(V[j], U[-1])[0]:
            V[j] = V[j][::-1]
    k, l = len(U), len(V)
    s = np.zeros((k, l)); t = np.zeros((k, l)); Q = np.zeros((k, l, 3))
    for i in range(k):
        for j in range(l):
            a, b, pa, pb, dd = _closest_pair(U[i], V[j]); s[i, j] = a; t[i, j] = b; Q[i, j] = (pa + pb) / 2
    ub = s.mean(axis=0); vb = t.mean(axis=1)            # ub[j]: where V_j crosses the U curves; vb[i]: where U_i crosses the V curves
    if l > 1 and np.any(np.diff(ub) <= 1e-6) or k > 1 and np.any(np.diff(vb) <= 1e-6):
        raise SolidError("could not sort the network (curves must cross like a grid)")
    def span(b):
        return (b[0], b[-1]) if len(b) > 1 else (0.0, 1.0)
    u = np.linspace(*span(ub), nu); v = np.linspace(*span(vb), nv)
    def remap(x, bar, own):
        if len(bar) == 1:
            return x
        return np.interp(x, np.concatenate([[min(0.0, bar[0] - 1e-9)], bar, [max(1.0, bar[-1] + 1e-9)]]),
                         np.concatenate([[0.0 if bar[0] > 1e-9 else own[0]], own, [1.0 if bar[-1] < 1 - 1e-9 else own[-1]]]))
    Uc = np.array([_eval_at(U[i], remap(u, ub, s[i])) for i in range(k)])            # (k, nu, 3)
    Vc = np.array([_eval_at(V[j], remap(v, vb, t[:, j])) for j in range(l)])         # (l, nv, 3)
    Wv = spline_weights(vb, v) if k > 1 else np.ones((nv, 1))                        # (nv, k)
    Wu = spline_weights(ub, u) if l > 1 else np.ones((nu, 1))                        # (nu, l)
    L1 = np.einsum("vk,kud->uvd", Wv, Uc)
    L2 = np.einsum("ul,lvd->uvd", Wu, Vc)
    T = np.einsum("ul,vk,kld->uvd", Wu, Wv, Q)
    if k == 1:
        G = L2 + (L1 - np.einsum("ul,kld->ud", Wu, Q)[:, None, :])
    elif l == 1:
        G = L1 + (L2 - np.einsum("vk,kld->vd", Wv, Q)[None, :, :])
    else:
        G = L1 + L2 - T
    return grid_surface(G)


def chain_loop(curves, tol=None):
    """Join open curves end to end into one closed loop of points."""
    cs = [np.asarray(c, float) for c in curves]
    chain = list(cs[0]); rest = cs[1:]
    while rest:
        end = chain[-1]
        k = min(range(len(rest)), key=lambda i: min(norm(rest[i][0] - end), norm(rest[i][-1] - end)))
        c = rest.pop(k)
        if norm(c[-1] - end) < norm(c[0] - end):
            c = c[::-1]
        chain += list(c[1:] if norm(c[0] - end) < 1e-9 else c)
    P = np.array(chain)
    if norm(P[0] - P[-1]) < 1e-9:
        P = P[:-1]
    return P


def patch_surface(loop_pts, nb=96, rings=16, inner=()):
    """Rhino Patch: smooth (harmonic) surface filling a closed 3D boundary; optional interior points pull the surface."""
    B = resample_loop(loop_pts, nb)
    r = plane_of_points(B)
    if r is None:
        raise SolidError("boundary is degenerate")
    c0, n = r[0], r[1]
    x = unit(B[0] - c0 - np.dot(B[0] - c0, n) * n); y = np.cross(n, x)
    bx = (B - c0) @ x; by = (B - c0) @ y; bh = (B - c0) @ n
    m = rings
    X = np.zeros((m + 1, nb)); Y = np.zeros((m + 1, nb)); H = np.zeros((m + 1, nb))
    for j in range(m + 1):
        f = j / m; X[j] = bx * f; Y[j] = by * f; H[j] = bh * f
    fixed = np.zeros((m + 1, nb), bool); fixed[m] = True
    for q in inner:
        q = np.asarray(q, float); qx, qy, qh = (q - c0) @ x, (q - c0) @ y, (q - c0) @ n
        d = (X - qx) ** 2 + (Y - qy) ** 2; j, i = np.unravel_index(np.argmin(d[1:m]), d[1:m].shape); j += 1
        H[j, i] = qh; fixed[j, i] = True
    hc = float(H[1].mean())
    for it in range(600):
        up = np.vstack([np.full((1, nb), hc), H[:-1]]); dn = np.vstack([H[1:], H[-1:]])
        new = 0.25 * (up + dn + np.roll(H, 1, axis=1) + np.roll(H, -1, axis=1))
        new[0] = hc
        H = np.where(fixed, H, new); hc = float(H[1].mean())
    H[0] = hc
    V = [c0 + n * hc]
    for j in range(1, m + 1):
        V += list(c0 + np.outer(X[j], x) + np.outer(Y[j], y) + np.outer(H[j], n))
    V = np.array(V); F = []
    ring = lambda j, i: 1 + (j - 1) * nb + (i % nb)
    for i in range(nb):
        F.append([0, ring(1, i), ring(1, i + 1)])
    for j in range(1, m):
        for i in range(nb):
            a, b, c, d = ring(j, i), ring(j + 1, i), ring(j + 1, i + 1), ring(j, i + 1)
            F += [[a, b, c], [a, c, d]]
    iso = [np.vstack([V[1 + (m - 1) * nb:1 + m * nb], V[1 + (m - 1) * nb]])]
    for i in range(0, nb, nb // 8):
        iso.append(np.vstack([V[0]] + [V[ring(j, i)] for j in range(1, m + 1)]))
    iso.append(np.vstack([V[1 + (m // 2 - 1) * nb:1 + (m // 2) * nb], V[1 + (m // 2 - 1) * nb]]))
    return Body(V, np.array(F, np.int64), "surface", None, iso)


def _weld(V, F):
    V = np.asarray(V, float); F = np.asarray(F, np.int64)
    scale = max(1.0, float(np.abs(V).max())) if len(V) else 1.0
    uniq, inv = np.unique(np.round(V / scale, 9), axis=0, return_inverse=True)
    inv = inv.ravel()
    V2 = np.zeros((len(uniq), 3)); V2[inv] = V
    return V2, inv[F]


def vertex_normals(V, F):
    a, b, c = V[F[:, 0]], V[F[:, 1]], V[F[:, 2]]
    fn = np.cross(b - a, c - a); vn = np.zeros_like(V)
    for k in range(3):
        np.add.at(vn, F[:, k], fn)
    return vn / np.maximum(np.linalg.norm(vn, axis=1, keepdims=True), 1e-18)


def offset_surface(body, dist):
    """Rhino OffsetSrf: copy of the surface moved along its normals."""
    V, F = _weld(body.V, body.F)
    vn = vertex_normals(V, F)
    iso = None
    if body.iso is not None:
        # move the isolines with the nearest vertex normal
        iso = []
        for L in body.iso:
            L = np.asarray(L, float); idx = [int(np.argmin(np.linalg.norm(V - p, axis=1))) for p in L]
            iso.append(L + vn[idx] * dist)
    return Body(V + vn * dist, F, "surface", dict(body.meta), iso)


def flip_surface(body):
    body.F = body.F[:, ::-1].copy()
    return body


def boundary_loops(V, F):
    """Naked-edge loops of a mesh (Rhino DupBorder)."""
    V, F = _weld(V, F)
    e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]); es = np.sort(e, axis=1)
    _, idx, cnt = np.unique(es, axis=0, return_index=True, return_counts=True)
    return _chain_segments([(int(a), int(b)) for a, b in e[idx[cnt == 1]]], V)


def _chain_segments(segs, V):
    from collections import defaultdict
    adj = defaultdict(list)
    for k, (a, b) in enumerate(segs):
        adj[a].append((b, k)); adj[b].append((a, k))
    used = set(); out = []
    starts = [a for a in adj if len(adj[a]) == 1] + list(adj)
    for s in starts:
        if all(k in used for _, k in adj[s]):
            continue
        path = [s]; cur = s
        while True:
            nxt = [(b, k) for b, k in adj[cur] if k not in used]
            if not nxt:
                break
            b, k = nxt[0]; used.add(k); path.append(b); cur = b
        if len(path) >= 2:
            out.append(V[path])
    return out


def mesh_section(V, F, p, n):
    """Polylines where plane (p, n) cuts a mesh (works for open surfaces and solids)."""
    V = np.asarray(V, float); F = np.asarray(F, np.int64); n = unit(n)
    d = (V - np.asarray(p, float)) @ n
    d = np.where(np.abs(d) < 1e-9, 1e-9, d)
    pts = {}; P = []; segs = []
    def cut(i, j):
        key = (min(i, j), max(i, j))
        if key not in pts:
            t = d[i] / (d[i] - d[j]); pts[key] = len(P); P.append(V[i] + t * (V[j] - V[i]))
        return pts[key]
    sg = d[F] > 0
    for f in np.flatnonzero(sg.any(axis=1) & ~sg.all(axis=1)):
        a, b, c = F[f]; q = []
        for i, j in ((a, b), (b, c), (c, a)):
            if (d[i] > 0) != (d[j] > 0):
                q.append(cut(int(i), int(j)))
        if len(q) == 2 and q[0] != q[1]:
            segs.append((q[0], q[1]))
    if not segs:
        return []
    P = np.array(P)
    # weld coincident cut points (shared mesh vertices that were duplicated)
    scale = max(1.0, float(np.abs(P).max()))
    uniq, inv = np.unique(np.round(P / scale, 9), axis=0, return_inverse=True); inv = inv.ravel()
    P2 = np.zeros((len(uniq), 3)); P2[inv] = P
    segs = list({(min(inv[a], inv[b]), max(inv[a], inv[b])) for a, b in segs if inv[a] != inv[b]})
    return _chain_segments(segs, P2)
