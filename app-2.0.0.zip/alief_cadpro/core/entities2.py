"""Attribute definitions and associative arrays (registered entity kinds), plus the stretch helper of dynamic blocks."""
import math
import numpy as np
from . import entities as E
from .entities import Entity, register, arr, from_dict, Text
from .geom import unit, norm, v3, xform_pt, xform_vec, m_translate, m_rotate, Plane


def stretch_entity(e, frame, d):
    """Move the defining points of e that lie inside frame = [xmin, ymin, xmax, ymax] (block XY) by vector d."""
    if not frame:
        e.transform(m_translate(d)); return
    x0, y0, x1, y1 = frame
    ins = lambda p: x0 - 1e-9 <= p[0] <= x1 + 1e-9 and y0 - 1e-9 <= p[1] <= y1 + 1e-9
    k = e.kind
    if k == "line":
        if ins(e.p0):
            e.p0 = e.p0 + d
        if ins(e.p1):
            e.p1 = e.p1 + d
    elif k == "polyline":
        m = np.array([ins(p) for p in e.pts], bool)
        e.pts = e.pts + np.where(m[:, None], d, 0)
    elif k in ("circle", "arc", "ellipse"):
        if ins(e.c):
            e.c = e.c + d
    elif k in ("text", "attdef", "point", "table"):
        if ins(e.p):
            e.p = e.p + d
    elif k == "dimension":
        e.dpts = [p + d if ins(p) else p for p in e.dpts]
    elif k == "hatch":
        e.loops = [np.asarray(l) + np.where(np.array([ins(p) for p in l], bool)[:, None], d, 0) for l in e.loops]
    elif k == "spline":
        if e.fit is not None:
            f = np.asarray(e.fit) + np.where(np.array([ins(p) for p in e.fit], bool)[:, None], d, 0)
            s = E.Spline.through(f); e.ctrl, e.knots, e.deg, e.fit = s.ctrl, s.knots, s.deg, s.fit
        else:
            e.ctrl = np.asarray(e.ctrl) + np.where(np.array([ins(p) for p in e.ctrl], bool)[:, None], d, 0)
    else:
        bb = e.bbox()
        if bb is not None and ins(bb[0]) and ins(bb[1]):
            e.transform(m_translate(d))
    e.touch()


E.stretch_entity = stretch_entity


@register
class AttDef(Entity):
    """Attribute definition inside a block: shows its TAG in the block editor, the value of each reference outside."""
    kind = "attdef"; label = "Attribute definition"

    def __init__(self, p=(0, 0, 0), tag="TAG", prompt="", default="", h=2.5, xdir=(1, 0, 0), n=(0, 0, 1), halign=0, valign=0):
        super().__init__(); self.p = v3(p); self.tag = str(tag).upper().replace(" ", "_"); self.prompt = prompt; self.default = str(default)
        self.hm = float(h); self.anno = 0.0; self.xdir = unit(v3(xdir)); self.n = unit(v3(n)); self.halign = int(halign); self.valign = int(valign)
        self.invisible = False

    def _text(self):
        t = Text(self.p, self.tag, self.hm, self.xdir, self.n, self.halign, self.valign); t.anno = self.anno
        return t

    def to_dict(self):
        d = self.base_dict(); d.update(p=arr(self.p), tag=self.tag, prompt=self.prompt, default=self.default, h=self.hm, anno=self.anno,
                                       xdir=arr(self.xdir), n=arr(self.n), halign=self.halign, valign=self.valign, invisible=self.invisible)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"], d["tag"], d.get("prompt", ""), d.get("default", ""), d.get("h", 2.5), d.get("xdir", (1, 0, 0)), d.get("n", (0, 0, 1)),
                d.get("halign", 0), d.get("valign", 0)); e.anno = d.get("anno", 0.0); e.invisible = d.get("invisible", False); e.load_base(d); return e

    def wire(self):
        return self._text().wire()

    def tris(self):
        return self._text().tris()

    def bbox(self):
        return self._text().bbox()

    def snaps(self):
        return {"ins": [self.p.copy()]}

    def transform(self, M):
        from .geom import m_scale_factor
        self.p = xform_pt(M, self.p); self.xdir = unit(xform_vec(M, self.xdir)); self.n = unit(xform_vec(M, self.n))
        self.hm *= m_scale_factor(M); self.touch()

    def info(self):
        return [("Tag", self.tag), ("Prompt", self.prompt), ("Default", self.default)]

    def props(self):
        return [("Tag", self.tag, lambda v: self._s("tag", str(v).upper().replace(" ", "_"))), ("Prompt", self.prompt, lambda v: self._s("prompt", str(v))),
                ("Default", self.default, lambda v: self._s("default", str(v))), ("Height", self.anno or self.hm, lambda v: self._h(float(v))),
                ("Invisible (0 / 1)", 1 if self.invisible else 0, lambda v: self._s("invisible", bool(float(v))))]

    def _s(self, k, v):
        setattr(self, k, v); self.touch()

    def _h(self, v):
        if self.anno:
            self.anno = v
        else:
            self.hm = v
        self.touch()


@register
class ArrayE(Entity):
    """Associative array (rectangular or polar): one object whose items follow its parameters."""
    kind = "array"; label = "Array"

    def __init__(self, src=(), atype="rect", base=(0, 0, 0), x=(1, 0, 0), y=(0, 1, 0)):
        super().__init__(); self.src = list(src); self.atype = atype; self.base = v3(base); self.x = unit(v3(x)); self.y = unit(v3(y))
        self.cols = 4; self.rows = 3; self.levels = 1; self.dx = 100.0; self.dy = 100.0; self.dz = 1.0
        self.center = v3(base); self.items = 6; self.fill = 360.0; self.rotate = True; self.ccw = True
        self._kids = None

    @property
    def z(self):
        return np.cross(self.x, self.y)

    PAR = ("atype", "cols", "rows", "levels", "dx", "dy", "dz", "items", "fill", "rotate", "ccw")

    def to_dict(self):
        d = self.base_dict(); d.update(src=[e.to_dict() for e in self.src], base=arr(self.base), x=arr(self.x), y=arr(self.y), center=arr(self.center))
        d.update({k: getattr(self, k) for k in self.PAR}); return d

    @classmethod
    def from_dict(cls, d):
        e = cls([from_dict(x) for x in d["src"]], d.get("atype", "rect"), d["base"], d["x"], d["y"])
        for k in cls.PAR:
            if k in d:
                setattr(e, k, d[k])
        e.center = v3(d.get("center", d["base"])); e.load_base(d); return e

    def touch(self):
        self._cache = {}; self._kids = None

    def count(self):
        return (self.items if self.atype == "polar" else self.cols) * self.rows * self.levels

    def matrices(self):
        out = []
        z = self.z
        if self.atype == "polar":
            n = max(1, int(self.items)); fill = math.radians(self.fill) * (1 if self.ccw else -1)
            step = fill / (n if abs(abs(self.fill) - 360) < 1e-9 else max(1, n - 1))
            rad = self.base - self.center; rad = rad - np.dot(rad, z) * z
            ru = unit(rad) if norm(rad) > 1e-12 else self.x
            for k in range(n):
                R = m_rotate(self.center, z, step * k)
                for r in range(max(1, int(self.rows))):
                    for l in range(max(1, int(self.levels))):
                        T = m_translate(ru * self.dy * r + z * self.dz * l)
                        M = R @ T
                        if not self.rotate:
                            b = xform_pt(M, self.base); M = m_translate(b - self.base)
                        out.append(M)
        else:
            for l in range(max(1, int(self.levels))):
                for r in range(max(1, int(self.rows))):
                    for c in range(max(1, int(self.cols))):
                        out.append(m_translate(self.x * self.dx * c + self.y * self.dy * r + z * self.dz * l))
        return out

    def children(self):
        if self._kids is None:
            kids = []
            Ms = self.matrices()
            if len(Ms) * max(1, len(self.src)) > 20000:
                Ms = Ms[:max(1, 20000 // max(1, len(self.src)))]
            for M in Ms:
                for e in self.src:
                    c = e.copy(); c.transform(M)
                    if c.layer == "0":
                        c.layer = self.layer
                    kids.append(c)
            self._kids = kids
        return self._kids

    def wire(self):
        return self.cached("wire", lambda: [w for c in self.children() for w in c.wire()])

    def tris(self):
        def mk():
            V, F, off = [], [], 0
            for c in self.children():
                t = c.tris()
                if t is not None and len(t[0]):
                    V.append(t[0]); F.append(np.asarray(t[1]) + off); off += len(t[0])
            return (np.vstack(V), np.vstack(F)) if V else None
        return self.cached("tris", mk)

    def prims(self):
        return self.cached("prims", lambda: [p for c in self.children() for p in c.prims()])

    def bbox(self):
        bb = None
        from .geom import bbox_union
        for c in self.children():
            b = c.bbox()
            if b is not None:
                bb = bbox_union(bb, b)
        return bb

    def snaps(self):
        s = {"ins": [self.base.copy()]}
        for c in self.children()[:400]:
            for k, v in c.snaps().items():
                s.setdefault(k, []).extend(v)
        return s

    def transform(self, M):
        for e in self.src:
            e.transform(M)
        self.base = xform_pt(M, self.base); self.center = xform_pt(M, self.center)
        from .geom import m_scale_factor
        sf = m_scale_factor(M)
        self.x = unit(xform_vec(M, self.x)); self.y = unit(xform_vec(M, self.y)); self.dx *= sf; self.dy *= sf; self.dz *= sf
        self.touch()

    def explode(self):
        return [c.copy() for c in self.children()]

    # ---- grips: 0 base (move), then spacing / count grips
    def grips(self):
        if self.atype == "polar":
            return [self.center.copy(), self.base.copy()]
        g = [self.base.copy(), self.base + self.x * self.dx, self.base + self.y * self.dy]
        g.append(self.base + self.x * self.dx * max(1, self.cols - 1) if self.cols > 2 else self.base + self.x * self.dx * 2)
        g.append(self.base + self.y * self.dy * max(1, self.rows - 1) if self.rows > 2 else self.base + self.y * self.dy * 2)
        return g

    def grip_set(self, gi, p):
        if self.atype == "polar":
            if gi == 0:
                self.center = np.asarray(p, float).copy()
            else:
                self.transform(m_translate(p - self.base))
            self.touch(); return
        d = np.asarray(p, float) - self.base
        if gi == 0:
            self.transform(m_translate(d))
        elif gi == 1 and abs(np.dot(d, self.x)) > 1e-9:
            self.dx = float(np.dot(d, self.x))
        elif gi == 2 and abs(np.dot(d, self.y)) > 1e-9:
            self.dy = float(np.dot(d, self.y))
        elif gi == 3 and abs(self.dx) > 1e-9:
            self.cols = max(1, int(round(np.dot(d, self.x) / self.dx)) + 1)
        elif gi == 4 and abs(self.dy) > 1e-9:
            self.rows = max(1, int(round(np.dot(d, self.y) / self.dy)) + 1)
        self.touch()

    def info(self):
        if self.atype == "polar":
            return [("Type", "Polar"), ("Items", self.items), ("Fill angle", self.fill), ("Rows", self.rows), ("Levels", self.levels), ("Objects", self.count() * len(self.src))]
        return [("Type", "Rectangular"), ("Columns", self.cols), ("Rows", self.rows), ("Levels", self.levels), ("Column spacing", self.dx),
                ("Row spacing", self.dy), ("Objects", self.count() * len(self.src))]

    def props(self):
        S = lambda k, cast: (lambda v: (setattr(self, k, cast(v)), self.touch()))
        I = lambda v: max(1, int(round(float(v))))
        if self.atype == "polar":
            return [("Items", self.items, S("items", I)), ("Fill angle", self.fill, S("fill", float)), ("Rows", self.rows, S("rows", I)),
                    ("Row spacing", self.dy, S("dy", float)), ("Levels", self.levels, S("levels", I)), ("Level spacing", self.dz, S("dz", float)),
                    ("Rotate items (0 / 1)", 1 if self.rotate else 0, S("rotate", lambda v: bool(float(v))))]
        return [("Columns", self.cols, S("cols", I)), ("Column spacing", self.dx, S("dx", float)), ("Rows", self.rows, S("rows", I)),
                ("Row spacing", self.dy, S("dy", float)), ("Levels", self.levels, S("levels", I)), ("Level spacing", self.dz, S("dz", float))]


def _attdef_explode(self):
    return [self._text()]


AttDef.explode = _attdef_explode
