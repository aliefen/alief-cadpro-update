"""Dynamic blocks: parameters (Point, Linear, Polar, XY, Rotation, Flip, Visibility) and actions (Move, Stretch, Scale,
Rotate, Array, Flip) like the AutoCAD Block Editor, evaluated for every block reference.

Block.params  : [{"type", "name", "p0", "p1", "base", "min", "max", "inc", "list", ...}]
Block.actions : [{"type", "param", "tags": [entity tags], "frame": [x0, y0, x1, y1], "spacing": [sx, sy], "name"}]
Block entities carry a tag in e.xd["bk"] so actions keep pointing at them after editing / saving.
Insert.dyn    : {param name: value}  (linear/rotation float, polar [dist, angle], xy/point [x, y], flip bool, visibility str)
"""
import math
import numpy as np
from .geom import unit, norm, v3, m_translate, m_scale, m_rotate

PARAM_TYPES = ("point", "linear", "polar", "xy", "rotation", "flip", "visibility")
ACTION_TYPES = ("move", "stretch", "scale", "rotate", "array", "flip")
# which actions each parameter accepts (AutoCAD rules)
ACTIONS_FOR = {"point": ("move", "stretch"), "linear": ("move", "stretch", "scale", "array"),
               "polar": ("move", "stretch", "scale", "array"), "xy": ("move", "stretch", "scale", "array"),
               "rotation": ("rotate",), "flip": ("flip",), "visibility": ()}
Z = np.array([0.0, 0.0, 1.0])


def p0(p):
    return v3(p.get("p0", (0, 0, 0)))


def p1(p):
    return v3(p.get("p1", p.get("p0", (0, 0, 0))))


def base_value(p):
    t = p["type"]
    if t == "linear":
        return float(p.get("base", norm(p1(p) - p0(p))))
    if t == "polar":
        d = p1(p) - p0(p)
        return [float(norm(d[:2])), math.degrees(math.atan2(d[1], d[0]))]
    if t == "xy":
        d = p1(p) - p0(p)
        return [float(d[0]), float(d[1])]
    if t == "rotation":
        d = p1(p) - p0(p)
        return float(p.get("base", math.degrees(math.atan2(d[1], d[0]))))
    if t == "point":
        return [0.0, 0.0]
    if t == "flip":
        return False
    if t == "visibility":
        return (p.get("states") or [""])[0]
    return None


def _snap(p, v):
    """Value set: list of allowed values, increment from the minimum, minimum / maximum."""
    lst = p.get("list")
    if lst:
        try:
            return float(min((float(x) for x in lst), key=lambda x: abs(x - v)))
        except (TypeError, ValueError):
            pass
    lo, hi, inc = p.get("min"), p.get("max"), p.get("inc")
    if inc:
        o = float(lo) if lo not in (None, "") else 0.0
        v = o + round((v - o) / float(inc)) * float(inc)
    if lo not in (None, ""):
        v = max(float(lo), v)
    if hi not in (None, ""):
        v = min(float(hi), v)
    return v


def value(p, raw):
    """Clean / constrained value of a parameter (raw = stored value or None)."""
    t = p["type"]; b = base_value(p)
    if t == "visibility":
        st = p.get("states") or [""]
        return raw if raw in st else st[0]
    if t == "flip":
        return bool(raw)
    if t in ("linear", "rotation"):
        try:
            v = float(raw)
        except (TypeError, ValueError):
            v = b
        return _snap(p, v) if t == "linear" else (v if not (p.get("inc") or p.get("list")) else _snap(p, v))
    try:
        v = [float(raw[0]), float(raw[1])]
    except (TypeError, ValueError, IndexError):
        v = list(b)
    if t == "polar":
        v[0] = max(0.0, _snap(p, v[0]))
    elif t == "xy":
        if p.get("inc") or p.get("min") is not None or p.get("max") is not None or p.get("list"):
            v = [_snap(p, v[0]), _snap(p, v[1])]
    return v


def parse(p, text):
    """Text typed in Properties / the dialog -> value."""
    t = p["type"]
    if t == "visibility":
        st = p.get("states") or []
        m = [s for s in st if s.lower() == str(text).lower()] or [s for s in st if s.lower().startswith(str(text).lower())]
        return m[0] if m else None
    if t == "flip":
        return str(text).strip().lower() in ("1", "yes", "y", "true", "flipped", "on")
    if t in ("linear", "rotation"):
        return float(text)
    parts = str(text).replace(";", ",").replace("<", ",").split(",")
    return [float(parts[0]), float(parts[1])]


def fmt(p, v):
    t = p["type"]
    if t in ("polar",):
        return f"{v[0]:g} < {v[1]:g}"
    if t in ("xy", "point"):
        return f"{v[0]:g}, {v[1]:g}"
    if t == "flip":
        return "Flipped" if v else "Not flipped"
    if t in ("linear", "rotation"):
        return float(v)
    return v


# ------------------------------------------------------------------------------------------- actions
def effective_actions(blk):
    """Explicit actions + the implicit ones of blocks made before 1.5 (linear param with frame = stretch, flip = flip all)."""
    acts = list(getattr(blk, "actions", None) or [])
    used = {a.get("param") for a in acts}
    for p in blk.params:
        if p["name"] in used:
            continue
        if p["type"] == "linear" and p.get("frame"):
            acts.append({"type": "stretch", "param": p["name"], "all": True, "frame": p["frame"]})
        elif p["type"] == "flip":
            acts.append({"type": "flip", "param": p["name"], "all": True})
    return acts


def _delta(p, v):
    """Displacement of the parameter's moving point for value v (relative to its base)."""
    t = p["type"]; a, b = p0(p), p1(p)
    if t == "linear":
        return unit(b - a) * (float(v) - base_value(p))
    if t == "polar":
        r = math.radians(v[1]); q = a + np.array([math.cos(r), math.sin(r), 0.0]) * v[0]
        return q - b
    if t == "xy":
        bv = base_value(p)
        return np.array([v[0] - bv[0], v[1] - bv[1], 0.0])
    if t == "point":
        return np.array([v[0], v[1], 0.0])
    return np.zeros(3)


def _factor(p, v):
    t = p["type"]; bv = base_value(p)
    if t == "linear":
        return float(v) / bv if abs(bv) > 1e-12 else 1.0
    if t == "polar":
        return v[0] / bv[0] if abs(bv[0]) > 1e-12 else 1.0
    if t == "xy":
        L = math.hypot(*bv)
        return math.hypot(*v) / L if L > 1e-12 else 1.0
    return 1.0


def _mirror(p):
    a = p0(p); ax = unit(p1(p) - a)
    k = np.cross(Z, ax); M = np.eye(4)
    M[:3, :3] = np.eye(3) - 2 * np.outer(k, k); M[:3, 3] = a - M[:3, :3] @ a
    return M


def evaluate(blk, ins, stretch_entity):
    """[(source entity, evaluated copy)] for the reference ins (visibility, actions applied in order)."""
    params = {p["name"]: p for p in blk.params}
    vis = [p for p in blk.params if p["type"] == "visibility"]
    state = value(vis[0], ins.dyn.get(vis[0]["name"])) if vis else None
    items = []
    for e in blk.ents:
        xs = (e.xd or {}).get("vis")
        if state is not None and xs is not None and state not in xs:
            continue
        items.append((e, [e.copy()], (e.xd or {}).get("bk")))
    for act in effective_actions(blk):
        p = params.get(act.get("param"))
        if p is None:
            continue
        v = value(p, ins.dyn.get(p["name"]))
        tags = set(act.get("tags") or []); every = act.get("all", False)
        t = act["type"]
        for k, (e, copies, tag) in enumerate(items):
            if not (every or (tag is not None and tag in tags)):
                continue
            if t == "move":
                d = _delta(p, v) * float(act.get("mult", 1.0))
                if norm(d) > 1e-12:
                    M = m_translate(d)
                    for c in copies:
                        c.transform(M)
            elif t == "stretch":
                d = _delta(p, v) * float(act.get("mult", 1.0))
                if norm(d) > 1e-12:
                    pm = act.get("pts")
                    for c in copies:
                        if pm is not None:                 # imported AutoCAD action: the points to move are listed
                            stretch_points(c, pm.get(tag), d)
                        else:
                            stretch_entity(c, act.get("frame"), d)
            elif t == "scale":
                f = _factor(p, v)
                if abs(f - 1.0) > 1e-12 and f > 0:
                    M = m_scale(p0(p), f)
                    for c in copies:
                        c.transform(M)
            elif t == "rotate" and p["type"] == "rotation":
                da = math.radians(float(v) - base_value(p))
                if abs(da) > 1e-12:
                    M = m_rotate(p0(p), Z, da)
                    for c in copies:
                        c.transform(M)
            elif t == "flip" and p["type"] == "flip":
                if v:
                    M = _mirror(p)
                    for c in copies:
                        c.transform(M)
            elif t == "array":
                sx, sy = (list(act.get("spacing") or [0, 0]) + [0, 0])[:2]
                new = []
                if p["type"] in ("linear", "polar"):
                    L = float(v) if p["type"] == "linear" else v[0]
                    if p["type"] == "linear":
                        u = unit(p1(p) - p0(p))
                    else:
                        r = math.radians(v[1]); u = np.array([math.cos(r), math.sin(r), 0.0])
                    s = abs(float(sx)) or 1.0
                    n = max(1, min(500, int(math.floor(L / s + 1e-9))))
                    for i in range(n):
                        for c in copies:
                            q = c.copy(); q.transform(m_translate(u * s * i)) if i else None; new.append(q)
                elif p["type"] == "xy":
                    sx = abs(float(sx)) or 1.0; sy = abs(float(sy)) or sx
                    nx = max(1, min(200, int(math.floor(abs(v[0]) / sx + 1e-9)))); ny = max(1, min(200, int(math.floor(abs(v[1]) / sy + 1e-9))))
                    gx = math.copysign(sx, v[0] or 1.0); gy = math.copysign(sy, v[1] or 1.0)
                    for i in range(nx):
                        for j in range(ny):
                            for c in copies:
                                q = c.copy()
                                if i or j:
                                    q.transform(m_translate(np.array([gx * i, gy * j, 0.0])))
                                new.append(q)
                if new:
                    items[k] = (e, new, tag)
    out = []
    for e, copies, tag in items:
        for c in copies:
            c.xd = None
            out.append((e, c))
    return out


def stretch_points(e, idx, d):
    """Move the listed points of e by d (idx: vertex numbers, [[loop, vertex], ...] of a hatch, or "all")."""
    if not idx:
        return
    k = e.kind
    if idx == "all":
        e.transform(m_translate(d)); return
    if k == "polyline":
        P = np.array(e.pts, float)
        for i in idx:
            if 0 <= i < len(P):
                P[i] = P[i] + d
        e.pts = P
    elif k == "line":
        if 0 in idx:
            e.p0 = e.p0 + d
        if 1 in idx:
            e.p1 = e.p1 + d
    elif k == "hatch":
        L = [np.array(l, float) for l in e.loops]
        for li, vi in idx:
            if 0 <= li < len(L) and 0 <= vi < len(L[li]):
                L[li][vi] = L[li][vi] + d
        e.loops = L
    else:
        e.transform(m_translate(d)); return
    e.touch()


def param_shift(blk, ins):
    """{parameter name: (shift of p0, shift of p1)}: parameters that are moved by the stretch of another parameter."""
    sh = {}
    acts = [a for a in (getattr(blk, "actions", None) or []) if a.get("pmove")]
    if not acts:
        return sh
    params = {p["name"]: p for p in blk.params}
    for a in acts:
        p = params.get(a.get("param"))
        if p is None:
            continue
        d = _delta(p, value(p, ins.dyn.get(p["name"]))) * float(a.get("mult", 1.0))
        if norm(d) <= 1e-12:
            continue
        for nm, idx in a["pmove"].items():
            s = sh.setdefault(nm, [np.zeros(3), np.zeros(3)])
            for i in idx:
                if i in (0, 1):
                    s[i] = s[i] + d
    return sh


# ------------------------------------------------------------------------------------------- grips
def grips(blk, ins):
    """[(local point, param, kind)] of the grips a reference shows (kind: move / flip / visibility)."""
    out = []
    shift = param_shift(blk, ins)
    for p in blk.params:
        t = p["type"]; v = value(p, ins.dyn.get(p["name"]))
        a = p0(p)
        if t == "linear" and p["name"] in shift:
            s0, s1 = shift[p["name"]]
            p = dict(p); p["_p1s"] = [float(x) for x in (p1(p) + s1)]
            out.append((p1(p) + s1 + unit(p1(p) - a) * (float(v) - base_value(p)), p, "move")); continue
        if t == "linear":
            out.append((a + unit(p1(p) - a) * float(v), p, "move"))
        elif t == "polar":
            r = math.radians(v[1]); out.append((a + np.array([math.cos(r), math.sin(r), 0.0]) * v[0], p, "move"))
        elif t == "xy":
            out.append((a + np.array([v[0], v[1], 0.0]), p, "move"))
        elif t == "point":
            out.append((a + np.array([v[0], v[1], 0.0]), p, "move"))
        elif t == "rotation":
            R = norm((p1(p) - a)[:2]) or 1.0; r = math.radians(float(v))
            out.append((a + np.array([math.cos(r), math.sin(r), 0.0]) * R, p, "move"))
        elif t == "flip":
            out.append(((a + p1(p)) / 2, p, "flip"))
        elif t == "visibility":
            out.append((v3(p.get("p0", (0, 0, 0))), p, "visibility"))
    return out


def grip_value(p, q):
    """New value of parameter p when its grip is dragged to the local point q."""
    t = p["type"]; a = p0(p)
    if t == "linear" and "_p1s" in p:                   # the parameter was moved by the stretch of another one
        return value(p, max(1e-6, base_value(p) + float(np.dot(q - v3(p["_p1s"]), unit(p1(p) - a)))))
    if t == "linear":
        return value(p, max(1e-6, float(np.dot(q - a, unit(p1(p) - a)))))
    if t == "polar":
        d = q - a
        return value(p, [float(norm(d[:2])), math.degrees(math.atan2(d[1], d[0]))])
    if t in ("xy", "point"):
        d = q - a
        return value(p, [float(d[0]), float(d[1])])
    if t == "rotation":
        d = q - a
        return value(p, math.degrees(math.atan2(d[1], d[0])))
    return None


def describe(p):
    t = p["type"]
    if t == "visibility":
        return f"{p['name']}  [visibility]  states: {', '.join(p.get('states', []))}"
    s = f"{p['name']}  [{t}]"
    b = base_value(p)
    if t in ("linear", "rotation"):
        s += f"  base {b:g}"
    elif t in ("polar", "xy"):
        s += f"  base {b[0]:g}, {b[1]:g}"
    for k in ("min", "max", "inc"):
        if p.get(k) not in (None, ""):
            s += f"  {k} {float(p[k]):g}"
    if p.get("list"):
        s += "  list " + ", ".join(f"{float(x):g}" for x in p["list"])
    return s
