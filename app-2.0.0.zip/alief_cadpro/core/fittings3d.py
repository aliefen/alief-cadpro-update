"""3D piping fittings (ASME B16.9 / B16.5 / B16.10 and JIS B2220 10K data), 3D pipe routing and 3D electrical
equipment. All dimensions in mm. Fittings are built in a local frame: port 1 at the origin, run along +X,
branch along +Y; then placed with a Plane."""
import math
import numpy as np
import manifold3d as m3
from .geom import Plane, unit, norm, v3
from .solids import from_manifold, place, SolidError, sweep_solid
from .entities import Body

# DN: (NPS label, OD ASME, wall SCH40, wall SCH80, OD JIS SGP, wall SGP)
PIPES = {
    15: ('1/2"', 21.3, 2.77, 3.73, 21.7, 2.8), 20: ('3/4"', 26.7, 2.87, 3.91, 27.2, 2.8),
    25: ('1"', 33.4, 3.38, 4.55, 34.0, 3.2), 32: ('1-1/4"', 42.2, 3.56, 4.85, 42.7, 3.5),
    40: ('1-1/2"', 48.3, 3.68, 5.08, 48.6, 3.5), 50: ('2"', 60.3, 3.91, 5.54, 60.5, 3.8),
    65: ('2-1/2"', 73.0, 5.16, 7.01, 76.3, 4.2), 80: ('3"', 88.9, 5.49, 7.62, 89.1, 4.2),
    100: ('4"', 114.3, 6.02, 8.56, 114.3, 4.5), 125: ('5"', 141.3, 6.55, 9.53, 139.8, 4.5),
    150: ('6"', 168.3, 7.11, 10.97, 165.2, 5.0), 200: ('8"', 219.1, 8.18, 12.70, 216.3, 5.8),
    250: ('10"', 273.0, 9.27, 15.09, 267.4, 6.6), 300: ('12"', 323.8, 10.31, 17.48, 318.5, 6.9),
    350: ('14"', 355.6, 11.13, 19.05, 355.6, 7.9), 400: ('16"', 406.4, 12.70, 21.44, 406.4, 7.9),
    450: ('18"', 457.0, 14.27, 23.83, 457.2, 7.9), 500: ('20"', 508.0, 15.09, 26.19, 508.0, 7.9),
    600: ('24"', 610.0, 17.48, 30.96, 609.6, 9.5),
}
PIPE_STANDARDS = ["ASME B36.10 SCH40", "ASME B36.10 SCH80", "JIS G3452 SGP"]
# ASME B16.9: A (90 LR), B (45 LR), C (tee), H (reducer), E (cap)
B169 = {15: (38, 16, 25, 38, 25), 20: (38, 19, 29, 38, 25), 25: (38, 22, 38, 51, 38), 32: (48, 25, 48, 51, 38),
        40: (57, 29, 57, 64, 38), 50: (76, 35, 64, 76, 38), 65: (95, 44, 76, 89, 38), 80: (114, 51, 86, 89, 51),
        100: (152, 64, 105, 102, 64), 125: (190, 79, 124, 127, 76), 150: (229, 95, 143, 140, 89),
        200: (305, 127, 178, 152, 102), 250: (381, 159, 216, 178, 127), 300: (457, 190, 254, 203, 152),
        350: (533, 222, 279, 330, 165), 400: (610, 254, 305, 356, 178), 450: (686, 286, 343, 381, 203),
        500: (762, 318, 381, 508, 229), 600: (914, 381, 432, 508, 267)}
# flange: D outside, t thickness, K bolt circle, n bolts, d hole, hub dia, length through hub
FLANGES = {
    "ASME B16.5 Class 150": {
        15: (90, 11.2, 60.3, 4, 15.7, 30, 48), 20: (100, 12.7, 69.9, 4, 15.7, 38, 52), 25: (110, 14.2, 79.4, 4, 15.7, 49, 56),
        32: (115, 15.7, 88.9, 4, 15.7, 59, 57), 40: (125, 17.5, 98.4, 4, 15.7, 65, 62), 50: (150, 19.1, 120.7, 4, 19.1, 78, 62),
        65: (180, 22.4, 139.7, 4, 19.1, 90, 69), 80: (190, 23.9, 152.4, 4, 19.1, 108, 69), 100: (230, 23.9, 190.5, 8, 19.1, 135, 75),
        125: (255, 23.9, 215.9, 8, 22.4, 164, 87), 150: (280, 25.4, 241.3, 8, 22.4, 192, 87), 200: (345, 28.4, 298.5, 8, 22.4, 246, 100),
        250: (405, 30.2, 362.0, 12, 25.4, 305, 100), 300: (485, 31.8, 431.8, 12, 25.4, 365, 113), 350: (535, 35.1, 476.3, 12, 28.4, 400, 125),
        400: (595, 36.6, 539.8, 16, 28.4, 457, 125), 450: (635, 39.6, 577.9, 16, 31.8, 505, 138), 500: (700, 42.9, 635.0, 20, 31.8, 559, 143),
        600: (815, 47.8, 749.3, 20, 35.1, 663, 151)},
    "JIS B2220 10K": {
        15: (95, 12, 70, 4, 15, 30, 16), 20: (100, 14, 75, 4, 15, 36, 20), 25: (125, 14, 90, 4, 19, 44, 20), 32: (135, 16, 100, 4, 19, 54, 22),
        40: (140, 16, 105, 4, 19, 60, 22), 50: (155, 16, 120, 4, 19, 74, 24), 65: (175, 18, 140, 4, 19, 90, 26), 80: (185, 18, 150, 8, 19, 104, 26),
        100: (210, 18, 175, 8, 19, 130, 28), 125: (250, 20, 210, 8, 23, 155, 30), 150: (280, 22, 240, 8, 23, 180, 32), 200: (330, 22, 290, 12, 23, 230, 34),
        250: (400, 24, 355, 12, 25, 285, 36), 300: (445, 24, 400, 16, 25, 335, 38), 350: (490, 26, 445, 16, 25, 375, 40), 400: (560, 28, 510, 16, 27, 425, 42),
        450: (620, 30, 565, 20, 27, 480, 44), 500: (675, 30, 620, 20, 27, 530, 46), 600: (795, 32, 730, 24, 33, 630, 50)},
}
# ASME B16.10 class 150 face-to-face: gate, globe/check, butterfly (wafer)
B1610 = {15: (108, 108, 0), 20: (117, 117, 0), 25: (127, 127, 0), 32: (140, 140, 0), 40: (165, 165, 33), 50: (178, 203, 43),
         65: (190, 216, 46), 80: (203, 241, 46), 100: (229, 292, 52), 125: (254, 356, 56), 150: (267, 406, 56), 200: (292, 495, 60),
         250: (330, 622, 68), 300: (356, 698, 78), 350: (381, 787, 92), 400: (406, 914, 102), 450: (432, 978, 114), 500: (457, 978, 127),
         600: (508, 1295, 154)}

FITTING_TYPES = ["Elbow 90 LR", "Elbow 90 SR", "Elbow 45 LR", "Tee equal", "Reducer concentric", "Reducer eccentric", "Cap",
                 "Flange weld neck", "Flange slip-on", "Blind flange", "Gate valve", "Globe valve", "Ball valve",
                 "Butterfly valve", "Check valve (swing)", "Y-strainer", "Pipe (straight)"]
ELEC_TYPES = ["Junction box", "Light fitting (LED tube)", "Panel / switchboard", "Motor", "Socket outlet box", "Push button station"]
SEG = 32


def pipe_dims(dn, std=PIPE_STANDARDS[0]):
    p = PIPES[dn]
    if "SGP" in std:
        return p[4], p[5]
    return p[1], (p[3] if "80" in std else p[2])


def size_text(dn):
    return f"DN{dn} ({PIPES[dn][0]})"


def _cyl_x(r, x0, x1, r2=None):
    """Cylinder/cone along +X from x0 to x1."""
    h = x1 - x0
    m = m3.Manifold.cylinder(abs(h), r, r if r2 is None else r2, SEG)
    m = m.rotate((0, 90, 0))           # Z -> X
    return m.translate((min(x0, x1), 0, 0)) if h > 0 else m.mirror((1, 0, 0)).translate((x0, 0, 0))


def _cyl_y(r, y0, y1):
    m = m3.Manifold.cylinder(abs(y1 - y0), r, r, SEG).rotate((-90, 0, 0))   # Z -> Y
    return m.translate((0, min(y0, y1), 0))


def _annulus(ro, ri):
    return m3.CrossSection.circle(ro, SEG) - m3.CrossSection.circle(ri, SEG)


def bend(OD, ID, R, ang_deg):
    """Hollow bend: starts at origin along +X, turns towards +Y with centre-line radius R."""
    cs = _annulus(OD / 2, ID / 2).translate((R, 0))
    m = m3.Manifold.revolve(cs, max(8, int(64 * ang_deg / 360)), float(ang_deg))
    return m.rotate((0, 0, -90)).translate((0, R, 0))


def pipe_x(OD, ID, L):
    return _cyl_x(OD / 2, 0, L) - _cyl_x(ID / 2, -1, L + 1)


def flange_x(dn, std, kind="WN", pipe_std=PIPE_STANDARDS[0], x0=0.0, facing=1):
    """Flange with its face at x0; body towards +facing*X (hub side)."""
    D, t, K, n, d, hub, Lh = FLANGES[std][dn]
    OD, w = pipe_dims(dn, pipe_std); ID = OD - 2 * w
    m = _cyl_x(D / 2, 0, t)
    if kind == "WN":
        m = m + _cyl_x(hub / 2, t - 0.01, max(Lh, t + 5), OD / 2)
    elif kind == "SO":
        m = m + _cyl_x(hub / 2, t - 0.01, t + max(5.0, 0.35 * t))
    holes = None
    for i in range(n):
        a = 2 * math.pi * (i + 0.5) / n
        h = _cyl_x(d / 2, -1, t + 1).translate((0, K / 2 * math.cos(a), K / 2 * math.sin(a)))
        holes = h if holes is None else holes + h
    m = m - holes
    if kind != "BL":
        m = m - _cyl_x((OD if kind == "SO" else ID) / 2, -1, Lh + t + 2)
    if facing < 0:
        m = m.mirror((1, 0, 0))
    return m.translate((x0, 0, 0)), (Lh if kind == "WN" else t)


def _valve(dn, std, pipe_std, kind):
    gate, globe, wafer = B1610[dn]
    D, t, K, n, d, hub, Lh = FLANGES[std][dn]
    OD, w = pipe_dims(dn, pipe_std)
    if kind == "Butterfly valve":
        L = wafer or max(40, 0.25 * D)
        m = _cyl_x(K / 2 - d * 0.7, 0, L) - _cyl_x(OD / 2 - w, -1, L + 1)
        m = m + _cyl_x(OD / 2 - w, L / 2 - 2, L / 2 + 2).rotate((0, 0, 0))   # disc
        m = m + _cyl_y(L * 0.35, K / 2 - d, K / 2 + 0.6 * D).translate((L / 2, 0, 0))
        m = m + m3.Manifold.cube((L * 0.25, L * 0.25, D * 0.9)).translate((L / 2 - L * 0.125, K / 2 + 0.6 * D, -D * 0.1))
        return m, L
    L = {"Gate valve": gate, "Ball valve": gate, "Y-strainer": globe}.get(kind, globe)
    f1, _ = flange_x(dn, std, "SO", pipe_std, 0, 1)
    f2, _ = flange_x(dn, std, "SO", pipe_std, L, -1)
    body_r = max(OD * 0.75, D * 0.38)
    m = f1 + f2 + _cyl_x(OD / 2 * 1.08, t * 0.5, L - t * 0.5)
    c = L / 2
    if kind in ("Gate valve", "Globe valve", "Check valve (swing)"):
        bulb = m3.Manifold.sphere(body_r if kind != "Gate valve" else body_r * 0.85, SEG).scale((1.0, 1.0, 0.85)).translate((c, 0, 0))
        m = m + bulb
    if kind == "Ball valve":
        m = m + m3.Manifold.sphere(body_r * 0.9, SEG).translate((c, 0, 0))
        m = m + _cyl_y(OD * 0.18 + 4, 0, body_r + D * 0.25).translate((c, 0, 0))
        m = m + m3.Manifold.cube((L * 0.9, 8 + D * 0.02, 18 + D * 0.05)).translate((c - L * 0.1, body_r + D * 0.25, -(9 + D * 0.025)))
    if kind in ("Gate valve", "Globe valve"):
        bonnet_h = (2.2 if kind == "Gate valve" else 1.5) * D * 0.6 + 40
        m = m + _cyl_y(D * 0.22, 0, body_r + bonnet_h * 0.45).translate((c, 0, 0))
        m = m + _cyl_y(D * 0.30, body_r + bonnet_h * 0.40, body_r + bonnet_h * 0.48).translate((c, 0, 0))
        m = m + _cyl_y(max(4, D * 0.04), 0, body_r + bonnet_h).translate((c, 0, 0))
        wr = max(40.0, D * 0.45)
        wheel = m3.Manifold.revolve(m3.CrossSection.circle(max(3, wr * 0.07), 16).translate((wr, 0)), 48, 360.0)
        wheel = wheel.rotate((90, 0, 0)).translate((c, body_r + bonnet_h, 0))
        spoke = m3.Manifold.cube((wr * 2, max(3, wr * 0.06), max(3, wr * 0.06)), True).translate((c, body_r + bonnet_h, 0))
        m = m + wheel + spoke
    if kind == "Check valve (swing)":
        m = m + _cyl_y(D * 0.33, 0, body_r + D * 0.12).translate((c, 0, 0))
        m = m + _cyl_y(D * 0.40, body_r + D * 0.08, body_r + D * 0.16).translate((c, 0, 0))
    if kind == "Y-strainer":
        br = _cyl_x(OD * 0.62, 0, OD * 2.2).rotate((0, 0, -45)).translate((c - OD * 0.3, 0, 0))
        m = m + br + m3.Manifold.sphere(OD * 0.7, SEG).translate((c, 0, 0))
    m = m - _cyl_x(OD / 2 - w, -1, L + 1)
    return m, L


def build_fitting(ftype, dn, std="ASME B16.5 Class 150", pipe_std=PIPE_STANDARDS[0], dn2=None, length=1000.0):
    """Return (manifold in local frame, meta)."""
    OD, w = pipe_dims(dn, pipe_std); ID = OD - 2 * w
    A, B, Ct, H, E = B169[dn]
    meta = {"ftype": ftype, "dn": dn, "size": size_text(dn), "std": std, "pipe_std": pipe_std}
    if ftype == "Pipe (straight)":
        m = pipe_x(OD, ID, length); meta["length"] = length
    elif ftype.startswith("Elbow"):
        ang = 45 if "45" in ftype else 90
        R = A if "LR" in ftype else A / 1.5
        m = bend(OD, ID, R, ang); meta["R"] = R
    elif ftype == "Tee equal":
        m = (_cyl_x(OD / 2, 0, 2 * Ct) + _cyl_y(OD / 2, 0, Ct).translate((Ct, 0, 0))) - \
            (_cyl_x(ID / 2, -1, 2 * Ct + 1) + _cyl_y(ID / 2, 0, Ct + 1).translate((Ct, 0, 0)))
    elif ftype.startswith("Reducer"):
        dn2 = dn2 or max([k for k in PIPES if k < dn] or [dn])
        OD2, w2 = pipe_dims(dn2, pipe_std); ID2 = OD2 - 2 * w2
        if "concentric" in ftype:
            m = _cyl_x(OD / 2, 0, H, OD2 / 2) - _cyl_x(ID / 2, -0.01, H + 0.01, ID2 / 2)
            m = m - _cyl_x(ID / 2, -1, 0.01) - _cyl_x(ID2 / 2, H - 0.01, H + 1)
        else:
            e = (OD - OD2) / 2
            def disk(r, x, z):
                return _cyl_x(r, x, x + 0.01).translate((0, 0, z))
            outer = m3.Manifold.batch_hull([disk(OD / 2, 0, 0), disk(OD2 / 2, H - 0.01, -e)])
            inner = m3.Manifold.batch_hull([disk(ID / 2, -1, 0), disk(ID2 / 2, H - 0.01 + 1, -e)])
            m = outer - inner
        meta["dn2"] = dn2; meta["size"] = f"{size_text(dn)} x {size_text(dn2)}"
    elif ftype == "Cap":
        cap = m3.Manifold.sphere(OD / 2, SEG).scale((E / (OD / 2) * 0.8, 1, 1))
        cap = cap.trim_by_plane((1, 0, 0), 0.0)
        inner = m3.Manifold.sphere(ID / 2, SEG).scale(((E * 0.8 - w) / (ID / 2), 1, 1)).trim_by_plane((1, 0, 0), 0.0)
        m = (cap.translate((E * 0.2, 0, 0)) + _cyl_x(OD / 2, 0, E * 0.2 + 0.01)) - (inner.translate((E * 0.2, 0, 0)) + _cyl_x(ID / 2, -1, E * 0.2 + 0.02))
    elif ftype in ("Flange weld neck", "Flange slip-on", "Blind flange"):
        kind = {"Flange weld neck": "WN", "Flange slip-on": "SO", "Blind flange": "BL"}[ftype]
        m, _ = flange_x(dn, std, kind, pipe_std)
    elif ftype in ("Gate valve", "Globe valve", "Ball valve", "Butterfly valve", "Check valve (swing)", "Y-strainer"):
        m, L = _valve(dn, std, pipe_std, ftype); meta["face_to_face"] = L
    else:
        raise SolidError(ftype)
    return m, meta


def fitting_body(ftype, dn, frame, **kw):
    m, meta = build_fitting(ftype, dn, **kw)
    role = "pipe" if ftype == "Pipe (straight)" else "fitting"
    return from_manifold(place(m, frame), role, meta)


# --------------------------------------------------------------------------------------------- pipe routing
def path_vertices(prims, max_sweep=math.radians(100.0)):
    """Corner points + bend radii of a path made of lines and arcs: every arc becomes a corner (the intersection of its
    end tangents) with the radius of the arc, so a pipe routed along the path follows the arc exactly."""
    from .geom import prim_ends, prim_tangent, prim_len, prim_point
    V = []; Rr = []
    for pr in prims:
        a, b = prim_ends(pr)
        if not V:
            V.append(v3(a)); Rr.append(None)
        if pr[0] == "L":
            if norm(v3(b) - V[-1]) > 1e-9:
                V.append(v3(b)); Rr.append(None)
            continue
        r = float(pr[2]); L = prim_len(pr); sweep = L / r if r > 1e-12 else 0.0
        n = max(1, int(math.ceil(sweep / max_sweep - 1e-9)))
        for k in range(n):
            s0 = L * k / n; s1 = L * (k + 1) / n
            p0 = v3(prim_point(pr, s0)); p1 = v3(prim_point(pr, s1)); t0 = unit(v3(prim_tangent(pr, s0 + 1e-9 * L)))
            V.append(p0 + t0 * r * math.tan(sweep / n / 2)); Rr.append(r)
            V.append(p1); Rr.append(None)
    return V, Rr


def route_pipe(path, dn, pipe_std=PIPE_STANDARDS[0], bend_R=None, flanges=None, flange_std="ASME B16.5 Class 150", radii=None):
    """Pipe along a polyline: straight pipes + bends at every corner (LR 1.5D by default). Returns [Body].
    radii: optional bend radius per path point (None = the default) - used for paths that contain arcs."""
    P0 = [v3(p) for p in path]
    keep = [i for i, p in enumerate(P0) if i == 0 or norm(p - P0[i - 1]) > 1e-6]
    P = [P0[i] for i in keep]
    radii = [radii[i] for i in keep] if radii is not None else [None] * len(P)
    if len(P) < 2:
        raise SolidError("pipe path too short")
    OD, w = pipe_dims(dn, pipe_std); ID = OD - 2 * w
    R = bend_R or B169[dn][0]
    out = []
    trims = [0.0] * len(P)          # trim length at each vertex
    bends = []
    for i in range(1, len(P) - 1):
        a = unit(P[i] - P[i - 1]); b = unit(P[i + 1] - P[i])
        ang = math.acos(max(-1, min(1, np.dot(a, b))))
        if ang < 1e-4:
            continue
        Ri = float(radii[i]) if radii[i] else R
        if Ri <= OD / 2 + 1e-6:
            raise SolidError(f"bend radius {Ri:g} mm is not larger than half the pipe diameter ({OD / 2:g} mm)")
        tr = Ri * math.tan(ang / 2)
        trims[i] = tr
        bends.append((i, a, b, ang, Ri))
    for i in range(len(P) - 1):
        a, b = P[i], P[i + 1]; d = unit(b - a); L = norm(b - a)
        s0 = trims[i]; s1 = trims[i + 1]
        if L - s0 - s1 < -1e-4 * max(1.0, L):
            raise SolidError(f"segment {i + 1} is shorter than the bends (bend radius {R:g} mm)")
        if L - s0 - s1 > 1e-3:
            fr = Plane.from_normal(a + d * s0, d)
            fr = Plane(a + d * s0, d, fr.x)
            m = pipe_x(OD, ID, L - s0 - s1)
            out.append(from_manifold(place(m, fr), "pipe", {"ftype": "Pipe (straight)", "dn": dn, "size": size_text(dn),
                                                             "pipe_std": pipe_std, "length": L - s0 - s1}))
    for i, a, b, ang, Ri in bends:
        start = P[i] - a * trims[i]
        y = unit(b - a * np.dot(b, a))
        fr = Plane(start, a, y)
        m = bend(OD, ID, Ri, math.degrees(ang))
        out.append(from_manifold(place(m, fr), "fitting", {"ftype": f"Bend {math.degrees(ang):.0f} deg R{Ri:g}", "dn": dn,
                                                            "size": size_text(dn), "pipe_std": pipe_std, "R": Ri}))
    if flanges in ("start", "both", "end"):
        ends = []
        if flanges in ("start", "both"):
            ends.append((P[0], unit(P[1] - P[0])))
        if flanges in ("end", "both"):
            ends.append((P[-1], unit(P[-2] - P[-1])))
        for p, d in ends:
            fr = Plane(p, d, Plane.from_normal(p, d).x)
            m, _ = flange_x(dn, flange_std, "SO", pipe_std, 0, 1)
            out.append(from_manifold(place(m, fr), "fitting", {"ftype": "Flange slip-on", "dn": dn, "size": size_text(dn),
                                                                "std": flange_std}))
    return out


# --------------------------------------------------------------------------------------------- electrical 3D
TRAY_SIZES = [(100, 50), (150, 50), (200, 50), (300, 50), (300, 100), (400, 100), (500, 100), (600, 100), (800, 100), (900, 100)]


def tray_loops(W, H, t=2.0, flange=15.0):
    """Cable tray (trough) section, open at the top: s across, t up."""
    return [np.array([[-W / 2, 0], [W / 2, 0], [W / 2, H], [W / 2 + flange, H], [W / 2 + flange, H + t], [W / 2 - t, H + t],
                      [W / 2 - t, t], [-W / 2 + t, t], [-W / 2 + t, H + t], [-W / 2 - flange, H + t], [-W / 2 - flange, H],
                      [-W / 2, H]])]


def cable_tray(path, W, H, up, t=2.0):
    loops = tray_loops(W, H, t)
    b = sweep_solid(loops, path, up, role="equipment",
                    meta={"ftype": "Cable tray", "size": f"Tray {W:g}x{H:g}", "length": float(sum(norm(np.subtract(path[i + 1], path[i])) for i in range(len(path) - 1)))})
    return b


def equipment(kind, dims):
    """Electrical equipment in local frame (base on XY plane, origin at base centre)."""
    g = lambda k, d: float(dims.get(k, d))
    if kind == "Junction box":
        W, D, H = g("W", 150), g("D", 100), g("H", 150)
        m = m3.Manifold.cube((W, D, H), True).translate((0, 0, H / 2))
        m = m + m3.Manifold.cube((W + 6, D * 0.18, H + 6), True).translate((0, D / 2, H / 2))
        for x in (-W / 4, W / 4):
            m = m + m3.Manifold.cylinder(18, 9, 9, 24).translate((x, -D * 0.1, -18))
    elif kind == "Light fitting (LED tube)":
        L, W, H = g("L", 1270), g("W", 120), g("H", 90)
        m = m3.Manifold.cube((L, W, H * 0.45), True).translate((0, 0, H - H * 0.225))
        dif = m3.Manifold.cylinder(L * 0.96, W * 0.45, W * 0.45, 32).rotate((0, 90, 0)).translate((-L * 0.48, 0, H * 0.55))
        m = m + dif.trim_by_plane((0, 0, 1), H * 0.0)
    elif kind == "Panel / switchboard":
        W, D, H = g("W", 800), g("D", 500), g("H", 2000)
        m = m3.Manifold.cube((W, D, H - 100), True).translate((0, 0, 100 + (H - 100) / 2))
        m = m + m3.Manifold.cube((W, D - 40, 100), True).translate((0, 0, 50))
        m = m + m3.Manifold.cube((W - 40, 20, H - 160), True).translate((0, -D / 2 - 10, 100 + (H - 100) / 2))
        m = m + m3.Manifold.cylinder(80, 10, 10, 16).rotate((90, 0, 0)).translate((W / 2 - 80, -D / 2 - 20, H * 0.55))
    elif kind == "Motor":
        L, Dm = g("L", 450), g("D", 280)
        body = m3.Manifold.cylinder(L, Dm / 2, Dm / 2, 40).rotate((0, 90, 0)).translate((-L / 2, 0, Dm / 2 + 40))
        feet = m3.Manifold.cube((L * 0.7, Dm * 1.0, 40), True).translate((0, 0, 20))
        shaft = m3.Manifold.cylinder(L * 0.25, Dm * 0.09, Dm * 0.09, 20).rotate((0, 90, 0)).translate((L / 2, 0, Dm / 2 + 40))
        tbox = m3.Manifold.cube((Dm * 0.5, Dm * 0.5, Dm * 0.35), True).translate((0, 0, Dm + 40 + Dm * 0.12))
        m = body + feet + shaft + tbox
    elif kind == "Socket outlet box":
        W, D, H = g("W", 90), g("D", 60), g("H", 120)
        m = m3.Manifold.cube((W, D, H), True).translate((0, 0, H / 2))
        m = m + m3.Manifold.cylinder(15, W * 0.32, W * 0.32, 32).rotate((90, 0, 0)).translate((0, -D / 2, H * 0.55))
    elif kind == "Push button station":
        W, D, H = g("W", 80), g("D", 70), g("H", 160)
        m = m3.Manifold.cube((W, D, H), True).translate((0, 0, H / 2))
        for z in (H * 0.35, H * 0.7):
            m = m + m3.Manifold.cylinder(12, 13, 13, 24).rotate((90, 0, 0)).translate((0, -D / 2, z))
    else:
        raise SolidError(kind)
    return m


def equipment_body(kind, dims, frame):
    m = equipment(kind, dims)
    return from_manifold(place(m, frame), "equipment", {"ftype": kind, "size": " x ".join(f"{k}{v:g}" for k, v in dims.items())})
