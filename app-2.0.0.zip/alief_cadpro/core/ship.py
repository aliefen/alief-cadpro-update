"""Ship structure data: IACS material grades, profile catalogue and section outlines for 3D Plate / 3D Profile."""
import math
import numpy as np

# grade: (density kg/m3, ReH MPa, Rm MPa text, group)
MATERIALS = {
    "A (NS)": (7850, 235, "400-520", "IACS normal strength"),
    "B (NS)": (7850, 235, "400-520", "IACS normal strength"),
    "D (NS)": (7850, 235, "400-520", "IACS normal strength"),
    "E (NS)": (7850, 235, "400-520", "IACS normal strength"),
    "AH32": (7850, 315, "440-570", "IACS high tensile"),
    "DH32": (7850, 315, "440-570", "IACS high tensile"),
    "EH32": (7850, 315, "440-570", "IACS high tensile"),
    "FH32": (7850, 315, "440-570", "IACS high tensile"),
    "AH36": (7850, 355, "490-630", "IACS high tensile"),
    "DH36": (7850, 355, "490-630", "IACS high tensile"),
    "EH36": (7850, 355, "490-630", "IACS high tensile"),
    "FH36": (7850, 355, "490-630", "IACS high tensile"),
    "AH40": (7850, 390, "510-660", "IACS high tensile"),
    "DH40": (7850, 390, "510-660", "IACS high tensile"),
    "EH40": (7850, 390, "510-660", "IACS high tensile"),
    "FH40": (7850, 390, "510-660", "IACS high tensile"),
    "SS400 / A36": (7850, 245, "400-510", "Structural steel (outfitting)"),
    "ASTM A106 Gr.B (pipe)": (7850, 240, "415 min", "Pipe steel"),
    "SUS 316L": (7980, 170, "485 min", "Stainless steel"),
    "AL 5083-H111": (2660, 125, "275-350", "Marine aluminium"),
    "AL 6061-T6": (2700, 240, "260 min", "Aluminium extrusion"),
}
DEFAULT_GRADE = "A (NS)"


def density(grade):
    return MATERIALS.get(grade, (7850,))[0]


# ------------------------------------------------------------------------------------------- profile catalogue
PROFILE_TYPES = {
    "FB": ("Flat bar", ["h", "t"]),
    "L": ("Angle (L) equal / unequal", ["h", "b", "t"]),
    "BP": ("Bulb flat (HP)", ["h", "t", "c", "bh"]),
    "T": ("T built-up", ["h", "tw", "b", "tf"]),
    "H": ("H-beam / I-beam", ["h", "b", "tw", "tf"]),
    "C": ("Channel (U)", ["h", "b", "tw", "tf"]),
    "PIPE": ("Pipe", ["D", "t"]),
    "RB": ("Round bar", ["D"]),
    "SHS": ("Square / rectangular hollow", ["h", "b", "t"]),
}
PARAM_TEXT = {"h": "Height h", "b": "Flange width b", "t": "Thickness t", "tw": "Web thickness tw",
              "tf": "Flange thickness tf", "c": "Bulb width c", "bh": "Bulb height bh", "D": "Outside diameter D"}


def _bp(h, t):
    return {"h": h, "t": t, "c": round(0.10 * h + 2, 1), "bh": round(0.17 * h, 1)}


CATALOGUE = {
    "FB": {f"FB {h}x{t}": {"h": h, "t": t} for h, t in
           [(50, 5), (50, 6), (60, 6), (65, 8), (75, 6), (75, 8), (80, 8), (100, 8), (100, 10), (100, 12), (125, 10),
            (125, 12), (150, 10), (150, 12), (150, 15), (175, 12), (200, 10), (200, 12), (200, 15), (250, 12),
            (250, 15), (300, 12), (300, 15), (350, 15), (400, 15), (400, 20)]},
    "L": {f"L {h}x{b}x{t}": {"h": h, "b": b, "t": t} for h, b, t in
          [(40, 40, 4), (40, 40, 5), (50, 50, 5), (50, 50, 6), (60, 60, 6), (65, 65, 6), (65, 65, 8), (75, 75, 6),
           (75, 75, 8), (75, 75, 9), (80, 80, 8), (90, 90, 9), (90, 90, 10), (100, 100, 10), (100, 100, 12),
           (120, 120, 12), (130, 130, 12), (150, 150, 12), (150, 150, 15), (75, 50, 6), (100, 65, 7), (100, 75, 7),
           (100, 75, 9), (125, 75, 7), (125, 75, 10), (125, 90, 10), (150, 90, 9), (150, 90, 12), (150, 100, 10),
           (200, 90, 9), (200, 100, 10), (200, 100, 12), (250, 90, 10), (250, 90, 12), (300, 90, 11)]},
    "BP": {f"HP {h}x{t}": _bp(h, t) for h, t in
           [(80, 6), (100, 6), (100, 7), (100, 8), (120, 6), (120, 7), (120, 8), (140, 7), (140, 8), (140, 10),
            (160, 7), (160, 8), (160, 9), (160, 11.5), (180, 8), (180, 9), (180, 10), (180, 11.5), (200, 9), (200, 10),
            (200, 11.5), (200, 12), (220, 10), (220, 11.5), (240, 10), (240, 11), (240, 12), (260, 10), (260, 11),
            (260, 12), (280, 11), (280, 12), (300, 11), (300, 12), (300, 13), (320, 12), (340, 12), (370, 13),
            (400, 14), (430, 15)]},
    "T": {f"T {h}x{tw} / {b}x{tf}": {"h": h, "tw": tw, "b": b, "tf": tf} for h, tw, b, tf in
          [(150, 8, 75, 10), (200, 8, 100, 10), (200, 10, 100, 12), (250, 10, 100, 12), (250, 10, 125, 12),
           (300, 10, 120, 12), (300, 10, 150, 12), (300, 12, 150, 15), (350, 10, 150, 12), (350, 12, 150, 15),
           (400, 10, 150, 12), (400, 12, 150, 15), (400, 12, 200, 15), (450, 12, 200, 16), (500, 12, 200, 16),
           (500, 12, 200, 20), (600, 12, 200, 20), (600, 14, 250, 20), (700, 14, 250, 20), (800, 14, 300, 20),
           (1000, 15, 300, 25)]},
    "H": {f"H {h}x{b}x{tw}x{tf}": {"h": h, "b": b, "tw": tw, "tf": tf} for h, b, tw, tf in
          [(100, 100, 6, 8), (125, 125, 6.5, 9), (150, 150, 7, 10), (175, 175, 7.5, 11), (200, 200, 8, 12),
           (250, 250, 9, 14), (300, 300, 10, 15), (350, 350, 12, 19), (400, 400, 13, 21), (100, 50, 5, 7),
           (125, 60, 6, 8), (150, 75, 5, 7), (200, 100, 5.5, 8), (250, 125, 6, 9), (300, 150, 6.5, 9),
           (350, 175, 7, 11), (400, 200, 8, 13), (450, 200, 9, 14), (500, 200, 10, 16), (600, 200, 11, 17),
           (588, 300, 12, 20), (700, 300, 13, 24)]},
    "C": {f"C {h}x{b}x{tw}x{tf}": {"h": h, "b": b, "tw": tw, "tf": tf} for h, b, tw, tf in
          [(75, 40, 5, 7), (100, 50, 5, 7.5), (125, 65, 6, 8), (150, 75, 6.5, 10), (150, 75, 9, 12.5),
           (180, 75, 7, 10.5), (200, 80, 7.5, 11), (200, 90, 8, 13.5), (250, 90, 9, 13), (250, 90, 11, 14.5),
           (300, 90, 9, 13), (300, 90, 10, 15.5), (380, 100, 10.5, 16), (380, 100, 13, 20)]},
    "PIPE": {f"Pipe {d}x{t}" + (f" ({n})" if n else ""): {"D": d, "t": t} for d, t, n in
             [(21.3, 2.77, '1/2" SCH40'), (26.7, 2.87, '3/4" SCH40'), (33.4, 3.38, '1" SCH40'),
              (42.2, 3.56, '1-1/4" SCH40'), (48.3, 3.68, '1-1/2" SCH40'), (60.3, 3.91, '2" SCH40'),
              (60.3, 5.54, '2" SCH80'), (73.0, 5.16, '2-1/2" SCH40'), (88.9, 5.49, '3" SCH40'),
              (88.9, 7.62, '3" SCH80'), (114.3, 6.02, '4" SCH40'), (114.3, 8.56, '4" SCH80'),
              (141.3, 6.55, '5" SCH40'), (168.3, 7.11, '6" SCH40'), (168.3, 10.97, '6" SCH80'),
              (219.1, 8.18, '8" SCH40'), (273.0, 9.27, '10" SCH40'), (323.8, 10.31, '12" SCH40'),
              (355.6, 11.13, '14" SCH40'), (406.4, 12.70, '16" SCH40'), (508.0, 15.09, '20" SCH40')]},
    "RB": {f"RB D{d}": {"D": d} for d in [10, 12, 16, 19, 20, 22, 25, 30, 32, 36, 40, 50, 60, 65, 75, 80, 100]},
    "SHS": {f"{'SHS' if h == b else 'RHS'} {h}x{b}x{t}": {"h": h, "b": b, "t": t} for h, b, t in
            [(40, 40, 2.3), (50, 50, 3.2), (60, 60, 3.2), (75, 75, 3.2), (75, 75, 4.5), (100, 100, 4.5),
             (100, 100, 6), (125, 125, 6), (150, 150, 6), (150, 150, 9), (200, 200, 9), (100, 50, 3.2),
             (125, 75, 4.5), (150, 100, 4.5), (150, 100, 6), (200, 100, 6), (250, 150, 9)]},
}
ALIGNMENTS = ["Base on path (stiffener)", "Centre on path (pillar / beam)", "Top on path"]


def _circle(cx, cy, r, n=28, cw=False):
    a = np.linspace(0, 2 * math.pi, n, endpoint=False)
    if cw:
        a = a[::-1]
    return np.stack([cx + r * np.cos(a), cy + r * np.sin(a)], axis=1)


def _bezier(p0, p1, p2, p3, n=8):
    t = np.linspace(0, 1, n)[:, None]
    return (1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t * t * p2 + t ** 3 * p3


def section_loops(ptype, d):
    """Section outline(s) in local (s, t) mm: t = web direction (away from the path), s = flange/toe side.
    Returns list of loops; first loop CCW outer, following loops CW holes."""
    g = lambda k, dv=0.0: float(d.get(k, dv))
    if ptype == "FB":
        h, t = g("h"), g("t")
        return [np.array([[0, 0], [t, 0], [t, h], [0, h]])]
    if ptype == "L":
        h, b, t = g("h"), g("b"), g("t")
        return [np.array([[0, 0], [t, 0], [t, h - t], [b, h - t], [b, h], [0, h]])]
    if ptype == "BP":
        h, t = g("h"), g("t")
        c = g("c", 0.10 * h + 2); bh = g("bh", 0.17 * h)
        r = min(0.3 * bh, 0.6 * c)
        p0 = np.array([t, h - bh]); p3 = np.array([t + c, h - r])
        curve = _bezier(p0, np.array([t + 0.15 * c, h - 0.62 * bh]), np.array([t + 0.85 * c, h - 0.75 * bh]), p3, 10)
        a = np.linspace(0, math.pi / 2, 7)[1:]
        top = np.stack([t + c - r + r * np.cos(a), h - r + r * np.sin(a)], axis=1)
        return [np.vstack([[[0, 0], [t, 0]], curve, top, [[0, h]]])]
    if ptype == "T":
        h, tw, b, tf = g("h"), g("tw"), g("b"), g("tf")
        return [np.array([[-tw / 2, 0], [tw / 2, 0], [tw / 2, h - tf], [b / 2, h - tf], [b / 2, h], [-b / 2, h],
                          [-b / 2, h - tf], [-tw / 2, h - tf]])]
    if ptype == "H":
        h, b, tw, tf = g("h"), g("b"), g("tw"), g("tf")
        return [np.array([[-b / 2, 0], [b / 2, 0], [b / 2, tf], [tw / 2, tf], [tw / 2, h - tf], [b / 2, h - tf],
                          [b / 2, h], [-b / 2, h], [-b / 2, h - tf], [-tw / 2, h - tf], [-tw / 2, tf], [-b / 2, tf]])]
    if ptype == "C":
        h, b, tw, tf = g("h"), g("b"), g("tw"), g("tf")
        return [np.array([[0, 0], [b, 0], [b, tf], [tw, tf], [tw, h - tf], [b, h - tf], [b, h], [0, h]])]
    if ptype == "PIPE":
        D, t = g("D"), g("t")
        return [_circle(0, D / 2, D / 2, 32), _circle(0, D / 2, D / 2 - t, 32, cw=True)]
    if ptype == "RB":
        D = g("D")
        return [_circle(0, D / 2, D / 2, 28)]
    if ptype == "SHS":
        h, b, t = g("h"), g("b"), g("t")
        return [np.array([[-b / 2, 0], [b / 2, 0], [b / 2, h], [-b / 2, h]]),
                np.array([[-b / 2 + t, t], [-b / 2 + t, h - t], [b / 2 - t, h - t], [b / 2 - t, t]])]
    raise ValueError(ptype)


def loops_area_centroid(loops):
    from .geom import poly_centroid2
    A = 0.0; S = np.zeros(2)
    for lp in loops:
        c, a = poly_centroid2(np.asarray(lp, float))
        A += a; S += c * a
    return A, (S / A if abs(A) > 1e-12 else np.zeros(2))


def placed_loops(ptype, dims, align=0, flip=False, rot_deg=0.0, off_s=0.0, off_t=0.0):
    """Loops after alignment, flip, rotation and offset (mm)."""
    loops = [np.asarray(l, float).copy() for l in section_loops(ptype, dims)]
    A, c = loops_area_centroid(loops)
    hgt = max(l[:, 1].max() for l in loops)
    sh = np.zeros(2)
    if align == 1:
        sh = -c
    elif align == 2:
        sh = np.array([0.0, -hgt])
    out = []
    ca, sa = math.cos(math.radians(rot_deg)), math.sin(math.radians(rot_deg))
    for l in loops:
        q = l + sh
        if flip:
            q = q * np.array([-1, 1])
            q = q[::-1]
        q = np.stack([ca * q[:, 0] - sa * q[:, 1], sa * q[:, 0] + ca * q[:, 1]], axis=1)
        out.append(q + np.array([off_s, off_t]))
    return out


def kg_per_m(ptype, dims, grade):
    A, _ = loops_area_centroid(section_loops(ptype, dims))
    return abs(A) * 1e-6 * density(grade)


def size_label(ptype, dims):
    g = lambda k: f"{float(dims.get(k, 0)):g}"
    if ptype == "FB":
        return f"FB {g('h')}x{g('t')}"
    if ptype == "L":
        return f"L {g('h')}x{g('b')}x{g('t')}"
    if ptype == "BP":
        return f"HP {g('h')}x{g('t')}"
    if ptype == "T":
        return f"T {g('h')}x{g('tw')} / {g('b')}x{g('tf')}"
    if ptype in ("H", "C"):
        return f"{ptype} {g('h')}x{g('b')}x{g('tw')}x{g('tf')}"
    if ptype == "PIPE":
        return f"Pipe {g('D')}x{g('t')}"
    if ptype == "RB":
        return f"RB D{g('D')}"
    if ptype == "SHS":
        return f"{'SHS' if dims.get('h') == dims.get('b') else 'RHS'} {g('h')}x{g('b')}x{g('t')}"
    return ptype


# colours used for "colour by thickness" display
def thickness_colour(t, tmin, tmax):
    if tmax - tmin < 1e-9:
        x = 0.5
    else:
        x = (t - tmin) / (tmax - tmin)
    stops = [(0.0, (0.18, 0.45, 0.95)), (0.33, (0.10, 0.80, 0.85)), (0.66, (0.98, 0.80, 0.20)), (1.0, (0.95, 0.30, 0.25))]
    for (x0, c0), (x1, c1) in zip(stops, stops[1:]):
        if x <= x1:
            f = (x - x0) / (x1 - x0)
            return tuple(a + (b - a) * f for a, b in zip(c0, c1))
    return stops[-1][1]
