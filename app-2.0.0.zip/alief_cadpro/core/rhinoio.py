"""Rhinoceros .3dm import / export (openNURBS through the rhino3dm library, loaded only when used).

Import : curves (line, arc, circle, polyline, NURBS, polycurve), points, text dots, meshes, breps / extrusions / SubD
         (through their stored render meshes, or their edge curves when the file has no meshes), blocks, layers.
Export : curves as exact Rhino curves, splines as NURBS, 3D bodies as meshes, everything else as its line work.
"""
import math
import numpy as np
from . import entities as E
from .aci import aci_rgb
from .geom import unit, norm

UNIT_MM = {"Millimeters": 1.0, "Centimeters": 10.0, "Decimeters": 100.0, "Meters": 1000.0, "Kilometers": 1e6, "Microns": 1e-3,
           "Inches": 25.4, "Feet": 304.8, "Yards": 914.4, "Mils": 0.0254}


def _r3():
    try:
        import rhino3dm
    except ImportError:                                   # the copy shipped inside the program (Windows)
        import os, sys
        v = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "_vendor")
        if v not in sys.path:
            sys.path.append(v)
        import rhino3dm
    return rhino3dm


def available():
    try:
        _r3(); return True
    except Exception:
        return False


def _p(q):
    return np.array([q.X, q.Y, q.Z], float)


def _hex(c):
    return "#%02x%02x%02x" % (int(c[0]), int(c[1]), int(c[2]))


# ------------------------------------------------------------------------------------------------ import
def _arc_ent(a, full):
    c = _p(a.Center); n = unit(_p(a.Plane.ZAxis)); r = float(a.Radius)
    if full:
        return E.Circle(c, r, n)
    e = E.Arc(c, r, 0.0, 1.0, n)
    u = e.u(); v = np.cross(n, u)
    def ang(q):
        d = _p(q) - c
        return math.atan2(float(np.dot(d, v)), float(np.dot(d, u)))
    a0 = ang(a.StartPoint); a1 = ang(a.EndPoint)
    while a1 <= a0 + 1e-12:
        a1 += 2 * math.pi
    e.a0, e.a1 = a0, a1
    return e


def _nurbs_ent(nc):
    n = len(nc.Points); deg = int(nc.Degree)
    ctrl = []; w = []
    for i in range(n):
        q = nc.Points[i]; ww = q.W if abs(q.W) > 1e-300 else 1.0
        ctrl.append([q.X / ww, q.Y / ww, q.Z / ww]); w.append(ww)       # openNURBS stores homogeneous control points
    k = [float(nc.Knots[i]) for i in range(len(nc.Knots))]
    knots = [k[0]] + k + [k[-1]]                                         # openNURBS omits the two superfluous end knots
    rational = bool(nc.IsRational) and max(w) - min(w) > 1e-12
    if deg == 1:
        P = np.array(ctrl); closed = n > 2 and norm(P[0] - P[-1]) < 1e-9
        return E.Polyline(P[:-1] if closed else P, closed, None, (0, 0, 1), True)
    s = E.Spline(ctrl, knots, deg, w if rational else None)
    s.closed = bool(nc.IsClosed)
    return s


def _curve_ents(g, r3):
    """Rhino curve -> list of entities."""
    if isinstance(g, r3.LineCurve):
        return [E.Line(_p(g.PointAtStart), _p(g.PointAtEnd))]
    if isinstance(g, r3.ArcCurve):
        full = bool(g.IsCompleteCircle) or bool(g.IsClosed) or abs(abs(g.AngleRadians) - 2 * math.pi) < 1e-9
        return [_arc_ent(g.Arc, full)]
    if isinstance(g, r3.PolylineCurve):
        P = np.array([_p(g.Point(i)) for i in range(g.PointCount)])
        if len(P) == 2:
            return [E.Line(P[0], P[1])]
        closed = len(P) > 2 and norm(P[0] - P[-1]) < 1e-9
        return [E.Polyline(P[:-1] if closed else P, closed, None, (0, 0, 1), True)]
    if isinstance(g, r3.PolyCurve):
        pl = _polycurve_polyline(g, r3)
        if pl is not None:
            return [pl]
        out = []
        for i in range(g.SegmentCount):
            s = g.SegmentCurve(i)
            if s is not None:
                out += _curve_ents(s, r3)
        return out
    if isinstance(g, r3.NurbsCurve):
        return [_nurbs_ent(g)]
    nc = g.ToNurbsCurve()
    return [_nurbs_ent(nc)] if nc is not None else []


def _polycurve_polyline(g, r3):
    """Planar chain of lines and arcs -> one polyline with bulges (None when it is anything else)."""
    segs = [g.SegmentCurve(i) for i in range(g.SegmentCount)]
    if not segs or any(not isinstance(s, (r3.LineCurve, r3.ArcCurve)) for s in segs):
        return None
    n = None
    for s in segs:
        if isinstance(s, r3.ArcCurve):
            if s.IsCompleteCircle or s.IsClosed:
                return None
            z = unit(_p(s.Arc.Plane.ZAxis))
            if n is None:
                n = z
            elif abs(abs(float(np.dot(n, z))) - 1) > 1e-6:
                return None
    if n is None:
        n = np.array([0, 0, 1.0])
    pts = []; bul = []
    for i, s in enumerate(segs):
        a = _p(s.PointAtStart)
        if pts and norm(a - last) > 1e-6:
            return None
        pts.append(a); last = _p(s.PointAtEnd)
        if isinstance(s, r3.ArcCurve):
            z = unit(_p(s.Arc.Plane.ZAxis)); sweep = abs(float(s.AngleRadians))
            # direction of travel: the arc runs counter-clockwise about its own plane normal
            mid = _p(s.PointAt((s.Domain.T0 + s.Domain.T1) / 2)); ch = last - a
            side = float(np.dot(np.cross(ch, mid - a), n))
            bul.append(math.tan(sweep / 4) * (-1.0 if side > 0 else 1.0))
        else:
            bul.append(0.0)
    P = np.array(pts)
    if abs(float(np.max(np.abs((P - P[0]) @ n)))) > 1e-6 or abs(float(np.dot(last - P[0], n))) > 1e-6:
        return None
    closed = norm(last - P[0]) < 1e-6
    if not closed:
        P = np.vstack([P, last]); bul.append(0.0)
    return E.Polyline(P, closed, bul, n)


def _mesh_arrays(m):
    V = np.array([[m.Vertices[i].X, m.Vertices[i].Y, m.Vertices[i].Z] for i in range(len(m.Vertices))], float).reshape(-1, 3)
    F = []
    for i in range(m.Faces.Count):
        a, b, c, d = m.Faces[i]
        F.append((a, b, c))
        if d != c:
            F.append((a, c, d))
    return V, np.array(F, np.int64).reshape(-1, 3)


def _join_meshes(parts):
    Vs, Fs, off = [], [], 0
    for V, F in parts:
        if len(V) and len(F):
            Vs.append(V); Fs.append(F + off); off += len(V)
    if not Vs:
        return None
    return np.vstack(Vs), np.vstack(Fs)


def _weld(V, F, tol=1e-6):
    """Merge coincident vertices so that separate face meshes become one connected body."""
    key = np.round(V / max(tol, 1e-12)).astype(np.int64)
    _, idx, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inv = np.asarray(inv).reshape(-1)
    F2 = inv[F]
    ok = (F2[:, 0] != F2[:, 1]) & (F2[:, 1] != F2[:, 2]) & (F2[:, 0] != F2[:, 2])
    return V[idx], F2[ok]


def _geom_ents(g, r3, stats):
    """Any Rhino geometry -> list of entities (instance references are handled by the caller)."""
    if isinstance(g, r3.Curve):
        return _curve_ents(g, r3)
    if isinstance(g, r3.Point):
        return [E.PointE(_p(g.Location))]
    if isinstance(g, r3.TextDot):
        return [E.Text(_p(g.Point), g.Text or "", 2.5)]
    if isinstance(g, r3.Mesh):
        V, F = _mesh_arrays(g)
        return [E.Body(V, F, "mesh")] if len(F) else []
    if isinstance(g, r3.Extrusion):
        m = g.GetMesh(r3.MeshType.Any)
        if m is not None and m.Faces.Count:
            V, F = _weld(*_mesh_arrays(m))
            return [E.Body(V, F, "solid" if g.IsSolid else "surface")]
        b = g.ToBrep(True)
        return _geom_ents(b, r3, stats) if b is not None else []
    if isinstance(g, r3.Brep):
        parts = []; missing = 0
        for i in range(len(g.Faces)):
            m = g.Faces[i].GetMesh(r3.MeshType.Any)
            if m is not None and m.Faces.Count:
                parts.append(_mesh_arrays(m))
            else:
                missing += 1
        j = _join_meshes(parts)
        if j is not None and not missing:
            V, F = _weld(*j)
            return [E.Body(V, F, "solid" if g.IsSolid else "surface")]
        stats["nomesh"] = stats.get("nomesh", 0) + 1          # no stored mesh: bring in the edge curves instead
        out = []
        for i in range(len(g.Edges)):
            try:
                out += _curve_ents(g.Edges[i], r3)
            except Exception:
                pass
        if j is not None:
            V, F = _weld(*j); out.append(E.Body(V, F, "surface"))
        return out
    sub = getattr(r3, "SubD", None)
    if sub is not None and isinstance(g, sub):
        stats["skipped"] = stats.get("skipped", 0) + 1; return []
    ann = getattr(r3, "AnnotationBase", None)
    if ann is not None and isinstance(g, ann):
        try:
            pl = g.Plane; t = E.Text(_p(pl.Origin), g.PlainText or "", 2.5, unit(_p(pl.XAxis)), unit(_p(pl.ZAxis)))
            return [t]
        except Exception:
            pass
    stats["skipped"] = stats.get("skipped", 0) + 1
    return []


def _xform(x):
    return np.array([[getattr(x, "M%d%d" % (i, j)) for j in range(4)] for i in range(4)], float)


def import_3dm(doc, path, to_mm=True):
    """Read a .3dm file into doc. -> (number of objects added, stats dict)."""
    r3 = _r3()
    model = r3.File3dm.Read(path)
    if model is None:
        raise RuntimeError("This is not a valid Rhino 3dm file")
    stats = {}
    us = str(model.Settings.ModelUnitSystem).split(".")[-1]
    k = UNIT_MM.get(us, 1.0) if to_mm else 1.0
    stats["units"] = us; stats["scale"] = k
    from .document import Layer
    lay = {}
    for i in range(len(model.Layers)):
        L = model.Layers[i]
        name = (L.FullPath or L.Name or "Layer %d" % i).replace("::", "-")
        lay[i] = name
        if name not in doc.layers:
            doc.layers[name] = Layer(name, _hex(L.Color), on=bool(L.Visible), locked=bool(L.Locked))
    S = np.eye(4); S[:3, :3] *= k

    def dress(e, at):
        e.layer = lay.get(at.LayerIndex, "0")
        if e.layer not in doc.layers:
            e.layer = "0"
        if at.ColorSource == r3.ObjectColorSource.ColorFromObject:
            e.color = _hex(at.ObjectColor)
        return e

    objs = {}
    for o in model.Objects:
        objs[str(o.Attributes.Id)] = o
    blocks = {}

    def block_for(idef_id, depth=0):
        key = str(idef_id)
        if key in blocks:
            return blocks[key]
        idef = model.InstanceDefinitions.FindId(idef_id)
        if idef is None or depth > 8:
            return None
        name = idef.Name or ("RHINO_BLOCK_%d" % (len(blocks) + 1))
        base = name; n = 1
        while name in doc.blocks:
            n += 1; name = "%s_%d" % (base, n)
        blocks[key] = name
        ents = []
        for oid in idef.GetObjectIds():
            o = objs.get(str(oid))
            if o is not None:
                ents += convert(o, depth + 1, scale=False)
        doc.add_block(E.Block(name, (0, 0, 0), ents))
        return name

    def convert(o, depth=0, scale=True):
        g = o.Geometry; at = o.Attributes
        if isinstance(g, r3.InstanceReference):
            name = block_for(g.ParentIdefId, depth)
            if name is None:
                stats["skipped"] = stats.get("skipped", 0) + 1; return []
            M = _xform(g.Xform)
            if scale:
                M = S @ M
            elif k != 1.0:
                pass
            return [dress(E.Insert(name, M), at)]
        out = []
        for e in _geom_ents(g, r3, stats):
            if scale and k != 1.0:
                e.transform(S)
            out.append(dress(e, at))
        return out

    n = 0
    for o in model.Objects:
        if o.Attributes.IsInstanceDefinitionObject:
            continue
        try:
            for e in convert(o):
                doc.add_keep(e); n += 1
        except Exception:
            stats["failed"] = stats.get("failed", 0) + 1
    return n, stats


# ------------------------------------------------------------------------------------------------ export
def _rgb(c):
    if isinstance(c, str) and c.startswith("#"):
        return tuple(int(c[i:i + 2], 16) for i in (1, 3, 5)) + (255,)
    try:
        v = aci_rgb(int(c))
    except (TypeError, ValueError):
        v = (1.0, 1.0, 1.0)
    return (int(round(v[0] * 255)), int(round(v[1] * 255)), int(round(v[2] * 255)), 255)


def _prim_curve(pr, r3):
    P3 = r3.Point3d
    if pr[0] == "L":
        return r3.LineCurve(P3(*pr[1]), P3(*pr[2]))
    _, c, r, n, u, a0, a1 = pr
    c = np.asarray(c, float); n = unit(np.asarray(n, float)); u = unit(np.asarray(u, float)); v = np.cross(n, u)
    pt = lambda a: P3(*(c + r * (math.cos(a) * u + math.sin(a) * v)))
    if abs(abs(a1 - a0) - 2 * math.pi) < 1e-9:
        ci = r3.Circle(P3(*c), float(r))
        ci.Plane = r3.Plane(P3(*c), r3.Vector3d(*u), r3.Vector3d(*v))
        return r3.ArcCurve.CreateFromCircle(ci)
    return r3.ArcCurve.CreateFromArc(r3.Arc(pt(a0), pt((a0 + a1) / 2), pt(a1)))


def _curves_of(e, r3):
    """Entity -> list of Rhino curves (exact where possible)."""
    P3 = r3.Point3d
    if e.kind == "spline":
        n = len(e.ctrl); deg = int(e.deg)
        rat = e.weights is not None
        nc = r3.NurbsCurve(3, bool(rat), deg + 1, n)
        for i in range(n):
            w = float(e.weights[i]) if rat else 1.0
            q = e.ctrl[i]
            nc.Points[i] = r3.Point4d(q[0] * w, q[1] * w, q[2] * w, w)
        kk = list(e.knots)[1:-1]
        for i in range(min(len(kk), len(nc.Knots))):
            nc.Knots[i] = float(kk[i])
        if nc.IsValid:
            return [nc]
        P = e.pts(); return [r3.PolylineCurve([P3(float(q[0]), float(q[1]), float(q[2])) for q in P])]
    if e.kind in ("line", "arc", "circle", "polyline"):
        try:
            prs = e.prims()
            cs = [_prim_curve(p, r3) for p in prs]
            if len(cs) == 1:
                return cs
            if cs:
                pc = r3.PolyCurve()
                for c in cs:
                    pc.Append(c)
                return [pc]
        except Exception:
            pass
    return None


def _wire_curves(e, r3):
    P3 = r3.Point3d; out = []
    try:
        W = e.wire()
    except Exception:
        return out
    for seg in (W or []):
        Q = np.asarray(seg, float).reshape(-1, 3)
        if len(Q) >= 2:
            out.append(r3.PolylineCurve([P3(float(q[0]), float(q[1]), float(q[2])) for q in Q]))
    return out


def export_3dm(doc, path, version=7):
    """Write the visible drawing to a Rhino .3dm file (millimetres). -> number of objects written."""
    r3 = _r3()
    f = r3.File3dm()
    f.Settings.ModelUnitSystem = r3.UnitSystem.Millimeters
    try:
        f.ApplicationName = "ALIEF CAD PRO"
    except Exception:
        pass
    lidx = {}
    for name, L in doc.layers.items():
        rl = r3.Layer(); rl.Name = name; rl.Color = _rgb(L.color)
        try:
            rl.Visible = bool(L.on and not L.frozen); rl.Locked = bool(L.locked)
        except Exception:
            pass
        f.Layers.Add(rl); lidx[name] = len(f.Layers) - 1
    count = 0

    def attrs(e, top):
        a = r3.ObjectAttributes()
        a.LayerIndex = lidx.get(top.layer if e.layer not in lidx else e.layer, 0)
        col = e.color if not (isinstance(e.color, int) and e.color in (0, 256)) else top.color
        if not (isinstance(col, int) and col in (0, 256)):
            a.ObjectColor = _rgb(col); a.ColorSource = r3.ObjectColorSource.ColorFromObject
        return a

    def put(e, top, depth=0):
        nonlocal count
        k = e.kind
        if k == "body":
            if len(e.F) == 0:
                return
            m = r3.Mesh()
            for v in e.V:
                m.Vertices.Add(float(v[0]), float(v[1]), float(v[2]))
            for a, b, c in e.F:
                m.Faces.AddFace(int(a), int(b), int(c))
            try:
                m.Normals.ComputeNormals()
            except Exception:
                pass
            at = attrs(e, top)
            nm = (e.meta or {}).get("mark") or (e.meta or {}).get("name")
            if nm:
                at.Name = str(nm)
            f.Objects.Add(m, at); count += 1; return
        if k == "point":
            f.Objects.AddPoint(float(e.p[0]), float(e.p[1]), float(e.p[2])); count += 1; return
        if k == "text":                              # text keeps its exact look as a small mesh (rhino3dm cannot write text objects)
            tr = None
            try:
                tr = e.tris()
            except Exception:
                pass
            if tr is not None and len(tr[1]):
                m = r3.Mesh()
                for v in np.asarray(tr[0], float).reshape(-1, 3):
                    m.Vertices.Add(float(v[0]), float(v[1]), float(v[2]))
                for a, b, c in np.asarray(tr[1]).reshape(-1, 3):
                    m.Faces.AddFace(int(a), int(b), int(c))
                at = attrs(e, top); at.Name = e.s.replace("\n", " ")[:80]
                f.Objects.Add(m, at); count += 1; return
            f.Objects.AddTextDot(e.s, r3.Point3d(float(e.p[0]), float(e.p[1]), float(e.p[2]))); count += 1; return
        cs = _curves_of(e, r3)
        if cs is not None:
            for c in cs:
                f.Objects.Add(c, attrs(e, top)); count += 1
            return
        kids = None
        if depth < 6:
            for getter in ("children", "explode"):
                fn = getattr(e, getter, None)
                if fn is not None and k in ("insert", "array", "detailview", "dimension", "leader", "table", "hatch", "attdef"):
                    try:
                        kids = list(fn())
                    except Exception:
                        kids = None
                    if kids:
                        break
        if kids:
            for c in kids:
                put(c, top, depth + 1)
            return
        for c in _wire_curves(e, r3):
            f.Objects.Add(c, attrs(e, top)); count += 1

    for e in doc.visible_ents():
        try:
            put(e, e)
        except Exception:
            pass
    if not f.Write(path, int(version)):
        raise RuntimeError("The 3dm file could not be written")
    return count
