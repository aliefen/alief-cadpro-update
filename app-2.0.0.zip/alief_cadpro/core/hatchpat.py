"""Hatch patterns in the standard PAT form (the format of AutoCAD / GstarCAD / ZWCAD .pat files), sizes in millimetres.

A pattern is a list of line families  (angle, x0, y0, dx, dy, dashes):
    a family is an endless set of parallel lines at `angle` through (x0, y0); the next line of the family is shifted by
    dx along the line direction and dy across it; dashes = (+ drawn, - gap, 0 dot ...) or () for a continuous line.

The built-in library carries the usual pattern names (ANSI, ISO and the common "other predefined" ones). Their geometry is
drawn up here; exact copies of another program's patterns can be loaded from its .pat file (Custom tab of the palette).
"""
import math
import numpy as np

# ------------------------------------------------------------------------------------------------ helpers
def _rep(fams, n, step_y=0.0, step_x=0.0):
    out = []
    for f in fams:
        for k in range(n):
            a, x0, y0, dx, dy, d = f
            out.append((a, x0 + k * step_x, y0 + k * step_y, dx, dy, d))
    return out


S = 3.175            # 1/8 inch: the base spacing of the ANSI section lining
Q = 0.5 * math.sqrt(2.0) * S

ANSI = {
    "ANSI31": ("ANSI Iron, Brick, Stone masonry", [(45, 0, 0, 0, S, ())]),
    "ANSI32": ("ANSI Steel", [(45, 0, 0, 0, 3 * S, ()), (45, 2 * Q, 0, 0, 3 * S, ())]),
    "ANSI33": ("ANSI Bronze, Brass, Copper", [(45, 0, 0, 0, 2 * S, ()), (45, 2 * Q, 0, 0, 2 * S, (S, -S / 2))]),
    "ANSI34": ("ANSI Plastic, Rubber", [(45, 0, 0, 0, 6 * S, ())] + [(45, 2 * Q * k, 0, 0, 6 * S, ()) for k in (1, 2, 3)]),
    "ANSI35": ("ANSI Fire brick, Refractory material", [(45, 0, 0, 0, 2 * S, ()), (45, 2 * Q, 0, 0, 2 * S, (2.5 * S, -S / 2, 0, -S / 2))]),
    "ANSI36": ("ANSI Marble, Slate, Glass", [(45, 0, 0, 1.75 * S, S, (2.5 * S, -S / 2, 0, -S / 2))]),
    "ANSI37": ("ANSI Lead, Zinc, Magnesium, Sound / Heat / Electric insulation", [(45, 0, 0, 0, S, ()), (135, 0, 0, 0, S, ())]),
    "ANSI38": ("ANSI Aluminium", [(45, 0, 0, 0, S, ()), (135, 0, 0, 2 * S, S, (2.5 * S, -1.5 * S))]),
}

ISO_LINES = {        # ISO 128 line types as hatch: dash sequences for a family of horizontal lines every 5 mm
    "ISO02W100": ("ISO dashed line", (12, -3)),
    "ISO03W100": ("ISO dashed, double gap", (12, -18)),
    "ISO04W100": ("ISO long-dash dotted", (24, -3, 0.5, -3)),
    "ISO05W100": ("ISO long-dash double-dotted", (24, -3, 0.5, -3, 0.5, -3)),
    "ISO06W100": ("ISO long-dash triple-dotted", (24, -3, 0.5, -3, 0.5, -6.5)),
    "ISO07W100": ("ISO dotted line", (0.5, -3)),
    "ISO08W100": ("ISO long-dash short-dash", (24, -3, 6, -3)),
    "ISO09W100": ("ISO long-dash double-short-dash", (24, -3, 6, -3, 6, -3)),
    "ISO10W100": ("ISO dash dotted", (12, -3, 0.5, -3)),
    "ISO11W100": ("ISO double-dash dotted", (12, -3, 12, -3, 0.5, -3)),
    "ISO12W100": ("ISO dash double-dotted", (12, -3, 0.5, -3, 0.5, -3)),
    "ISO13W100": ("ISO double-dash double-dotted", (12, -3, 12, -3, 0.5, -6.5)),
    "ISO14W100": ("ISO dash triple-dotted", (12, -3, 0.5, -3, 0.5, -6.5)),
    "ISO15W100": ("ISO double-dash triple-dotted", (12, -3, 12, -3, 0.5, -10)),
}
ISO = {k: (d, [(0, 0, 0, 0, 5, ds)]) for k, (d, ds) in ISO_LINES.items()}

B = 203.2            # 8 inch masonry module
OTHER = {
    "SOLID": ("Solid fill", []),
    "ANGLE": ("Angle steel", [(0, 0, 0, 0, 2.2 * S, (1.6 * S, -0.6 * S)), (90, 0, 0, 0, 2.2 * S, (1.6 * S, -0.6 * S))]),
    "AR-B816": ("8x16 block elevation, stretcher bond", [(0, 0, 0, 0, B, ()), (90, 0, 0, B, B, (B, -B))]),
    "AR-B816C": ("8x16 block elevation, stretcher bond with mortar joints",
                 [(0, 0, 0, B, B, (2 * B - 9.5, -9.5)), (0, -B, -9.5, B, B, (2 * B - 9.5, -9.5)),
                  (90, 0, 0, B, B, (B - 9.5, -B - 9.5)), (90, -9.5, 0, B, B, (B - 9.5, -B - 9.5))]),
    "AR-B88": ("8x8 block elevation, stretcher bond", [(0, 0, 0, 0, B, ()), (90, 0, 0, B, B / 2, (B, -B))]),
    "AR-BRELM": ("Standard brick elevation, English bond with mortar joints",
                 [(0, 0, 0, 0, B / 3, ()), (90, 0, 0, 0, B, (B / 3, -B / 3)), (90, B / 4, B / 3, 0, B / 2, (B / 3, -B / 3))]),
    "AR-BRSTD": ("Standard brick elevation", [(0, 0, 0, 0, B / 3, ()), (90, 0, 0, B / 3, B / 2, (B / 3, -B / 3))]),
    "AR-CONC": ("Random dot and stone pattern (concrete)",
                [(50, 0, 0, 104.8, 149.2, (19.0, -209.6)), (355, 0, 0, -51.4, 159.7, (15.2, -219.3)),
                 (100.5, 15.2, 1.3, 132.0, 165.2, (16.2, -189.8)), (46.2, 0, 50.8, 154.8, 130.1, (28.6, -314.3)),
                 (96.6, 21.9, 51.2, 203.3, 177.8, (22.9, -251.4)), (351.2, 0, 50.8, 193.8, 179.4, (22.9, -251.4)),
                 (21.0, 25.4, 38.1, 104.8, 149.2, (19.0, -209.6)), (326.0, 25.4, 38.1, -51.4, 159.7, (15.2, -219.3)),
                 (71.5, 22.3, 35.2, 132.0, 165.2, (16.2, -189.8)), (37.5, 0, 0, 52.0, 61.0, (0, -79.0, 0, -121.0, 0, -61.0)),
                 (7.5, 0, 0, 79.8, 70.6, (0, -119.0, 0, -46.0, 0, -80.0)), (-32.5, -57.0, 0, 64.0, 31.0, (0, -26.0, 0, -32.0, 0, -51.0)),
                 (-37.5, 0, 0, 40.0, 46.0, (0, -56.0, 0, -25.0, 0, -31.0))]),
    "AR-HBONE": ("Herringbone pattern, 4x8 brick", [(45, 0, 0, 101.6, 101.6, (304.8, -101.6)), (135, 71.8, 71.8, 101.6, -101.6, (304.8, -101.6))]),
    "AR-PARQ1": ("2x12 parquet flooring", [(90, 50.8 * i, 0, 304.8, 304.8, (304.8, -304.8)) for i in range(7)]
                 + [(0, 0, 304.8 + 50.8 * i, 304.8, -304.8, (304.8, -304.8)) for i in range(7)]),
    "AR-RROOF": ("Roof shingle texture", [(0, 0, 0, 55.9, 25.4, (380.0, -51.0, 127.0, -25.0)),
                                          (0, 33.9, 12.7, -25.4, 33.9, (152.0, -19.0, 76.0, -25.0)),
                                          (0, 12.7, 21.2, 132.0, 17.8, (203.0, -35.0, 102.0, -25.0))]),
    "AR-RSHKE": ("Roof wood shake texture", [(0, 0, 0, 0, 254.0, ()), (90, 0, 0, 254.0, 330.0, (254.0, -254.0)),
                                              (90, 101.6, 0, 254.0, 475.0, (254.0, -508.0)), (90, 190.5, 127.0, 254.0, 410.0, (127.0, -381.0))]),
    "AR-SAND": ("Random dot pattern (sand)", [(37.5, 0, 0, 28.6, 31.3, (0, -38.1, 0, -25.4, 0, -60.3)),
                                               (7.5, 0, 0, 62.5, 22.7, (0, -49.6, 0, -50.8, 0, -31.7)),
                                               (-32.5, -56.7, 0, 63.2, 32.0, (0, -26.4, 0, -31.7, 0, -50.9)),
                                               (-37.5, -0.3, 0, 40.2, 45.1, (0, -56.0, 0, -25.3, 0, -31.0))]),
    "BOX": ("Box steel", [(90, 0, 0, 0, 8 * S, ()), (90, 2 * S, 0, 0, 8 * S, ()), (0, 0, 0, 0, 8 * S, (-2 * S, 2 * S, -2 * S, 2 * S)),
                          (0, 0, 2 * S, 0, 8 * S, (-2 * S, 2 * S, -2 * S, 2 * S)), (0, 0, 4 * S, 0, 8 * S, (2 * S, -6 * S)),
                          (0, 0, 6 * S, 0, 8 * S, (2 * S, -6 * S)), (90, 4 * S, 0, 0, 8 * S, (2 * S, -2 * S)),
                          (90, 6 * S, 0, 0, 8 * S, (2 * S, -2 * S))]),
    "BRASS": ("Brass material", [(0, 0, 0, 0, 2 * S, ()), (0, 0, S, 0, 2 * S, (S, -S / 2))]),
    "BRICK": ("Brick or masonry-type surface", [(0, 0, 0, 0, 2 * S, ()), (90, 0, 0, 2 * S, 2 * S, (2 * S, -2 * S))]),
    "BRSTONE": ("Brick and stone", [(0, 0, 0, 0, 2.6 * S, ()), (90, 2.6 * S, 0, 2.6 * S, 4 * S, (2.6 * S, -2.6 * S)),
                                    (90, 2.2 * S, 0, 2.6 * S, 4 * S, (2.6 * S, -2.6 * S)),
                                    (0, 2.6 * S, 0.65 * S, 2.6 * S, 2.6 * S, (-2.6 * S, 1.4 * S)), (0, 2.6 * S, 1.3 * S, 2.6 * S, 2.6 * S, (-2.6 * S, 1.4 * S)),
                                    (0, 2.6 * S, 1.95 * S, 2.6 * S, 2.6 * S, (-2.6 * S, 1.4 * S))]),
    "CLAY": ("Clay material", [(0, 0, 0, 0, 1.5 * S, ()), (0, 0, 0.25 * S, 0, 1.5 * S, ()), (0, 0, 0.5 * S, 0, 1.5 * S, ()),
                               (0, 0, S, 0, 1.5 * S, (1.5 * S, -S))]),
    "CORK": ("Cork material", [(0, 0, 0, 0, S, ()), (135, S / 2, -S / 2, 0, 2 * math.sqrt(2) * S, (math.sqrt(2) * S, -math.sqrt(2) * S)),
                               (135, S * 0.75, -S / 2, 0, 2 * math.sqrt(2) * S, (math.sqrt(2) * S, -math.sqrt(2) * S)),
                               (135, S, -S / 2, 0, 2 * math.sqrt(2) * S, (math.sqrt(2) * S, -math.sqrt(2) * S))]),
    "CROSS": ("A series of crosses", [(0, 0, 0, 2 * S, 2 * S, (S, -3 * S)), (90, S / 2, -S / 2, 2 * S, 2 * S, (S, -3 * S))]),
    "DASH": ("Dashed lines", [(0, 0, 0, S, S, (S, -S))]),
    "DOLMIT": ("Geological rock layering", [(0, 0, 0, 0, 2 * S, ()), (45, 0, 0, 0, 4 * math.sqrt(2) * S, (2 * math.sqrt(2) * S, -4 * math.sqrt(2) * S))]),
    "DOTS": ("A series of dots", [(0, 0, 0, S / 4, S / 2, (0, -S / 2))]),
    "EARTH": ("Earth or ground (subterranean)", [(0, 0, 0, 2 * S, 2 * S, (2 * S, -2 * S)), (0, 0, 0.75 * S, 2 * S, 2 * S, (2 * S, -2 * S)),
                                                 (0, 0, 1.5 * S, 2 * S, 2 * S, (2 * S, -2 * S)), (90, 0.25 * S, 1.75 * S, 2 * S, 2 * S, (2 * S, -2 * S)),
                                                 (90, S, 1.75 * S, 2 * S, 2 * S, (2 * S, -2 * S)), (90, 1.75 * S, 1.75 * S, 2 * S, 2 * S, (2 * S, -2 * S))]),
    "FLEX": ("Flexible material", [(0, 0, 0, 0, 2 * S, (2 * S, -2 * S)), (45, 2 * S, 0, math.sqrt(2) * S, math.sqrt(2) * S, (S / 2, -1.83 * S, S / 2, -2.83 * S))]),
    "GRASS": ("Grass area", [(90, 0, 0, 5.66 * S, 5.66 * S, (1.5 * S, -9.8 * S)), (45, 0, 0, 0, 8 * S, (1.5 * S, -6.5 * S)),
                             (135, 0, 0, 0, 8 * S, (1.5 * S, -6.5 * S))]),
    "GRATE": ("Grated area", [(0, 0, 0, 0, S / 4, ()), (90, 0, 0, 0, S, ())]),
    "GRAVEL": ("Gravel pattern", [(228.0, 2.3, 4.6, 7.5, 9.1, (2.4, -24.0)), (184.0, 2.1, 1.9, 9.6, 9.8, (2.6, -31.8)),
                                  (132.0, 0.4, 1.3, 8.0, 7.6, (2.4, -26.4)), (267.0, 0.2, 5.0, 10.2, 9.5, (2.1, -34.4)),
                                  (300.0, 3.0, 4.6, 6.5, 10.5, (1.9, -30.2)), (21.0, 3.4, 3.1, 9.3, 8.6, (2.3, -26.6)),
                                  (346.0, 0.6, 3.8, 11.0, 7.3, (2.0, -36.0)), (72.0, 1.1, 2.2, 7.9, 8.9, (2.2, -26.0)),
                                  (0, 0, 0, 4.8, 5.3, (0, -9.6, 0, -12.1))]),
    "HEX": ("Hexagons", [(0, 0, 0, 0, math.sqrt(3) * S, (S, -2 * S)), (120, 0, 0, 0, math.sqrt(3) * S, (S, -2 * S)),
                         (60, S, 0, 0, math.sqrt(3) * S, (S, -2 * S))]),
    "HONEY": ("Honeycomb pattern", [(0, 0, 0, 1.5 * S, 0.866 * S, (S, -2 * S)), (120, 0, 0, 1.5 * S, 0.866 * S, (S, -2 * S)),
                                    (60, 0, 0, 1.5 * S, 0.866 * S, (-2 * S, S))]),
    "HOUND": ("Houndstooth check", [(0, 0, 0, 2 * S, S / 2, (8 * S, -4 * S)), (90, 0, 0, -2 * S, S / 2, (8 * S, -4 * S))]),
    "INSUL": ("Insulation material", [(0, 0, 0, 0, 3 * S, ()), (0, 0, S, 0, 3 * S, (S, -S)), (0, 0, 2 * S, 0, 3 * S, (S, -S))]),
    "LINE": ("Parallel horizontal lines", [(0, 0, 0, 0, S, ())]),
    "MUDST": ("Mud and sand", [(0, 0, 0, 4 * S, 2 * S, (2 * S, -2 * S, 0, -2 * S, 0, -2 * S))]),
    "NET": ("Horizontal / vertical grid", [(0, 0, 0, 0, S, ()), (90, 0, 0, 0, S, ())]),
    "NET3": ("Network pattern 0-60-120", [(0, 0, 0, 0, S, ()), (60, 0, 0, 0, S, ()), (120, 0, 0, 0, S, ())]),
    "PLAST": ("Plastic material", [(0, 0, 0, 0, 2 * S, ()), (0, 0, S / 4, 0, 2 * S, ()), (0, 0, S / 2, 0, 2 * S, ())]),
    "PLASTI": ("Plastic material", [(0, 0, 0, 0, 2 * S, ()), (0, 0, S / 4, 0, 2 * S, ()), (0, 0, S / 2, 0, 2 * S, ()), (0, 0, 1.25 * S, 0, 2 * S, ())]),
    "SACNCR": ("Concrete", [(45, 0, 0, 0, 0.75 * S, ()), (45, 0.53 * S, 0, 0, 0.75 * S, (0, -0.75 * S))]),
    "SQUARE": ("Small aligned squares", [(0, 0, 0, 0, S, (S, -S)), (90, 0, 0, 0, S, (S, -S))]),
    "STARS": ("Star of David", [(0, 0, 0, 0, math.sqrt(3) * S, (S, -S)), (60, 0, 0, 1.5 * S, 0.866 * S, (S, -S)),
                                (120, S / 2, 0.866 * S, 1.5 * S, 0.866 * S, (S, -S))]),
    "STEEL": ("Steel material", [(45, 0, 0, 0, S, ()), (45, 0, S / 2, 0, S, ())]),
    "SWAMP": ("Marshy area", [(0, 0, 0, 4 * S, 6.93 * S, (S, -7 * S)), (90, S / 2, 0, 6.93 * S, 4 * S, (S / 2, -13.36 * S)),
                              (90, 0.656 * S, 0, 6.93 * S, 4 * S, (S * 0.375, -13.48 * S)), (90, 0.344 * S, 0, 6.93 * S, 4 * S, (S * 0.375, -13.48 * S)),
                              (60, 0.625 * S, 0, 4 * S, 6.93 * S, (S / 4, -7.75 * S)), (120, 0.375 * S, 0, 4 * S, 6.93 * S, (S / 4, -7.75 * S))]),
    "TRANS": ("Heat transfer material", [(0, 0, 0, 0, 2 * S, ()), (0, 0, S, 0, 2 * S, (S, -S))]),
    "TRIANG": ("Equilateral triangles", [(60, 0, 0, 1.5 * S, 2.598 * S, (1.5 * S, -1.5 * S)), (120, 0, 0, 1.5 * S, 2.598 * S, (1.5 * S, -1.5 * S)),
                                         (0, -0.75 * S, 1.299 * S, 1.5 * S, 2.598 * S, (1.5 * S, -1.5 * S))]),
    "ZIGZAG": ("Staircase effect", [(0, 0, 0, S, S, (S, -S)), (90, S, 0, S, S, (S, -S))]),
}

CATEGORIES = (("ANSI", ANSI), ("ISO", ISO), ("Other Predefined", OTHER))
LIBRARY = {}
for _cat, _d in CATEGORIES:
    for _k, (_desc, _f) in _d.items():
        LIBRARY[_k] = (_cat, _desc, _f)

USER = {}            # patterns loaded from .pat files: name -> (description, families)


def families(name, pdef=None):
    """Line families of a pattern (a definition stored in the drawing wins)."""
    if pdef:
        return [tuple(f[:5]) + (tuple(f[5]) if len(f) > 5 else (),) for f in pdef]
    if name in LIBRARY:
        return LIBRARY[name][2]
    if name in USER:
        return USER[name][1]
    return LIBRARY["ANSI31"][2]


def description(name):
    if name in LIBRARY:
        return LIBRARY[name][1]
    if name in USER:
        return USER[name][0]
    return ""


def parse_pat(text):
    """Contents of a .pat file -> {NAME: (description, families)}.  Comments start with ';'."""
    out = {}; cur = None
    for raw in text.splitlines():
        line = raw.split(";", 1)[0].strip()
        if not line:
            continue
        if line.startswith("*"):
            head = line[1:].split(",", 1)
            cur = head[0].strip().upper()
            out[cur] = (head[1].strip() if len(head) > 1 else "", [])
            continue
        if cur is None:
            continue
        try:
            v = [float(x) for x in line.replace(" ", "").split(",") if x != ""]
        except ValueError:
            continue
        if len(v) >= 5:
            out[cur][1].append((v[0], v[1], v[2], v[3], v[4], tuple(v[5:])))
    return {k: v for k, v in out.items() if v[1] or k == "SOLID"}


def to_pat(name, desc, fams):
    lines = [f"*{name},{desc}"]
    for a, x0, y0, dx, dy, d in fams:
        lines.append(",".join(f"{x:g}" for x in (a, x0, y0, dx, dy) + tuple(d)))
    return "\n".join(lines) + "\n"


def segments(loops2, fams, scale=1.0, angle=0.0, max_segs=120000):
    """2D segments [(a, b)] of the pattern clipped (even-odd) to the 2D loops."""
    loops2 = [np.asarray(l, float)[:, :2] for l in loops2 if len(l) >= 3]
    if not loops2 or not fams or scale <= 0:
        return []
    E_ = np.vstack([np.stack([l, np.roll(l, -1, axis=0)], axis=1) for l in loops2])     # boundary edges (N, 2, 2)
    out = []; budget = max_segs
    ra = math.radians(angle); cr, sr = math.cos(ra), math.sin(ra)
    for fam in fams:
        a, x0, y0, dx, dy, dashes = fam
        th = math.radians(a) + ra
        u = np.array([math.cos(th), math.sin(th)]); n = np.array([-u[1], u[0]])
        o = np.array([x0 * cr - y0 * sr, x0 * sr + y0 * cr]) * scale
        dxs, dys = dx * scale, dy * scale
        if abs(dys) < 1e-12:
            continue
        # boundary in the family frame: s along the lines, t across them (t = k * dys)
        A = E_[:, 0] - o; Bv = E_[:, 1] - o
        sa, ta = A @ u, A @ n; sb, tb = Bv @ u, Bv @ n
        tmin, tmax = min(ta.min(), tb.min()), max(ta.max(), tb.max())
        k0, k1 = math.ceil(tmin / dys), math.floor(tmax / dys)
        if k1 < k0:
            k0, k1 = k1, k0
        nlines = k1 - k0 + 1
        if nlines > 6000:                                  # far too fine for the area: thin out (keeps the drawing usable)
            step = int(math.ceil(nlines / 6000.0))
        else:
            step = 1
        d = [float(x) * scale for x in dashes] if dashes else []
        T = sum(abs(x) for x in d) if d else 0.0
        dot = max(1e-6, 0.06 * scale) if d else 0.0
        for k in range(k0, k1 + 1, step):
            t = k * dys
            m = (ta > t) != (tb > t)
            if not m.any():
                continue
            xs = np.sort(sa[m] + (t - ta[m]) * (sb[m] - sa[m]) / (tb[m] - ta[m]))
            base = o + n * t                                # a point of this line ...
            ph = k * dxs                                    # ... and where its dash pattern starts (s coordinate)
            for i in range(0, len(xs) - 1, 2):
                s0, s1 = xs[i], xs[i + 1]
                if s1 - s0 < 1e-12:
                    continue
                if not d or T < 1e-12:
                    out.append((base + u * s0, base + u * s1)); budget -= 1
                else:
                    m0 = math.floor((s0 - ph) / T)
                    if (s1 - s0) / T > 4000:
                        out.append((base + u * s0, base + u * s1)); budget -= 1; continue
                    pos = ph + m0 * T
                    while pos < s1 and budget > 0:
                        for x in d:
                            L = abs(x)
                            if x > 0 or x == 0:
                                q0 = pos; q1 = pos + (L if x > 0 else dot)
                                a0, a1 = max(q0, s0), min(q1, s1)
                                if a1 > a0:
                                    out.append((base + u * a0, base + u * a1)); budget -= 1
                            pos += L
                            if pos >= s1:
                                break
                if budget <= 0:
                    return out
    return out
