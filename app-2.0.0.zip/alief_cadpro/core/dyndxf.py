"""Dynamic blocks of AutoCAD / ZWCAD / GstarCAD drawings.

A dynamic block reference is stored in the file as a reference to an anonymous block (*U...) that already holds the
geometry of its current state, with a link to the dynamic definition (parameters, actions, grips).  The reader below
takes the linear parameters with their stretch actions, the flip state and the visibility state from that data and
attaches them to the anonymous block in our own model (core/dynblock.py), so the stretch grips work on the reference
as they do in AutoCAD.  Entities hidden by the visibility state are not drawn.
"""
import numpy as np


def _tags(o):
    try:
        if hasattr(o, "xtags"):
            return [(t.code, t.value) for sub in o.xtags.subclasses for t in sub]
        if o.dxftype() == "XRECORD":
            return [(t.code, t.value) for t in o.tags]
    except Exception:
        pass
    return []


def _v(p):
    return [float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0]


def _parse_def(d, br):
    """{"lin": {node: {...}}, "str": [...], "order": [entity handles]} of a dynamic block definition, or None."""
    try:
        g = br.get_extension_dict().dictionary.get("ACAD_ENHANCEDBLOCK")
    except Exception:
        return None
    if g is None:
        return None
    lin = {}; strs = []; vis = None
    for c, h in _tags(g):
        if c != 360:
            continue
        o = d.entitydb.get(h)
        if o is None:
            continue
        tp = o.dxftype(); t = _tags(o)
        node = next((v for c2, v in t if c2 == 90), None)
        if tp == "BLOCKLINEARPARAMETER":
            i = next((k for k, x in enumerate(t) if x == (100, "AcDbBlock2PtParameter")), None)
            if i is None:
                continue
            base = next((v for c2, v in t[i:] if c2 == 1010), None); end = next((v for c2, v in t[i:] if c2 == 1011), None)
            n91 = [v for c2, v in t[i:] if c2 == 91][:4]            # grip nodes of: base, end, ...
            name = next((v for c2, v in t if c2 == 305), "") or next((v for c2, v in t if c2 == 300), "Linear")
            if base is None or end is None:
                continue
            lin[node] = {"name": str(name), "base": _v(base), "end": _v(end), "grips": [int(x) for x in n91], "handle": h}
        elif tp == "BLOCKSTRETCHACTION":
            i = next((k for k, x in enumerate(t) if x == (100, "AcDbBlockStretchAction")), None)
            if i is None:
                continue
            s = t[i + 1:]; prm = next((v for c2, v in s if c2 == 92), None)
            ents = []; nodes = []; k = 0; mult = 1.0
            while k < len(s):
                c2, v = s[k]
                if c2 == 331:                                # entity: 74 = number of points, then 94 ... indices
                    n = 0; idx = []
                    if k + 1 < len(s) and s[k + 1][0] == 74:
                        n = int(s[k + 1][1]); idx = [int(x[1]) for x in s[k + 2:k + 2 + n] if x[0] == 94]
                    ents.append((v, idx)); k += 2 + n; continue
                if c2 == 95 and k + 1 < len(s) and s[k + 1][0] == 76:      # parameter node moved with the stretch
                    n = int(s[k + 1][1]); idx = [int(x[1]) for x in s[k + 2:k + 2 + n] if x[0] == 94]
                    nodes.append((int(v), idx)); k += 2 + n; continue
                if c2 == 140:
                    mult = float(v) or 1.0
                k += 1
            strs.append({"param": prm, "ents": ents, "nodes": nodes, "mult": mult, "handle": h, "node": node})
        elif tp == "BLOCKVISIBILITYPARAMETER":
            i = next((k for k, x in enumerate(t) if x == (100, "AcDbBlockVisibilityParameter")), None)
            states = {}; cur = None
            for c2, v in t[i + 1:] if i is not None else []:
                if c2 == 303:
                    cur = str(v); states[cur] = set()
                elif c2 == 333 and cur is not None:
                    states[cur].add(v)
            vis = {"node": node, "states": states}
    if not lin:
        return None
    return {"lin": lin, "str": strs, "vis": vis}


def _stretch_points(e, idx):
    """World points of entity e that the stretch moves (idx = AutoCAD stretch point indices)."""
    k = e.kind
    if k == "polyline":
        return [e.pts[i] for i in idx if 0 <= i < len(e.pts)]
    if k == "line":
        return [(e.p0, e.p1)[i] for i in idx if i in (0, 1)]
    return []


def attach(d, doc, emap):
    """emap: block name -> [(DXF handle, [our entities])] in file order.  Returns the number of dynamic references."""
    defs = {}                                   # block record handle -> parsed definition
    order = {}
    for br in d.block_records:
        try:
            if not br.has_extension_dict:
                continue
            df = _parse_def(d, br)
        except Exception:
            df = None
        if df is not None:
            defs[br.dxf.handle] = df
            order[br.dxf.handle] = [e.dxf.handle for e in d.blocks.get(br.dxf.name)]
    if not defs:
        return 0
    done = set(); count = 0
    for ins in d.query("INSERT"):
        try:
            if not ins.has_extension_dict:
                continue
            xd = ins.get_extension_dict().dictionary
            rep = xd.get("AcDbBlockRepresentation")
            if rep is None:
                continue
            h = next((v for c, v in _tags(rep.get("AcDbRepData")) if c == 340), None)
            df = defs.get(h)
            name = ins.dxf.name
            if df is None or name not in doc.blocks or name not in emap:
                continue
            count += 1
            if name in done:
                continue
            done.add(name)
            cache = rep.get("AppDataCache"); data = cache.get("ACAD_ENHANCEDBLOCKDATA") if cache is not None else None
            if data is None:
                continue
            cur = {}
            for key, rec in data.items():
                try:
                    cur[int(key)] = [v for c, v in _tags(rec) if c == 10]
                except (TypeError, ValueError):
                    continue
            state = None
            if df["vis"] is not None:
                rec = data.get(str(df["vis"]["node"]))
                if rec is not None:
                    state = next((str(v) for c, v in _tags(rec) if c == 1), None)
            shown = df["vis"]["states"].get(state) if (df["vis"] is not None and state is not None) else None
            _build(doc.blocks[name], df, order[h], emap[name], cur, shown, d)
        except Exception:
            import traceback; traceback.print_exc()
    return count


def _build(blk, df, def_order, inst, cur, shown, d=None):
    """Linear parameters + stretch actions on the anonymous block blk (its geometry is the current state)."""
    if len(inst) != len(def_order):
        return                                             # the copy does not match the definition entity by entity
    by_handle = {h: i for i, h in enumerate(def_order)}
    params = []; actions = []; ntag = 0
    names = {}
    for node, lp in df["lin"].items():
        acts = [a for a in df["str"] if a["param"] == node]
        if not acts:
            continue
        if shown is not None and lp["handle"] not in shown:
            continue                                       # parameter of another visibility state
        pts = cur.get(node) or []
        if len(pts) < 2:
            continue
        p0, p1 = np.array(_v(pts[0])), np.array(_v(pts[1]))
        if float(np.abs(p1 - p0).max()) < 1e-9:
            continue
        nm = lp["name"]; k = 2
        while nm in names.values():
            nm = f'{lp["name"]}{k}'; k += 1
        names[node] = nm
        params.append({"type": "linear", "name": nm, "p0": [float(x) for x in p0], "p1": [float(x) for x in p1], "imported": True})
    if not params:
        return
    for a in df["str"]:
        if a["param"] not in names:
            continue
        moved = []; pmap = {}; tags = []; hatches = []
        for h, idx in a["ents"]:
            i = by_handle.get(h)
            if i is None:
                continue
            src = d.entitydb.get(inst[i][0]) if d is not None else None
            for e in inst[i][1]:
                if e.kind == "hatch" and (src is None or src.dxf.get("associative", 0)):
                    hatches.append(e); continue            # associative: follows its boundary (below)
                if e.xd is None:
                    e.xd = {}
                if "bk" not in e.xd:
                    ntag += 1; e.xd["bk"] = f"dx{ntag}"
                tg = e.xd["bk"]
                if e.kind in ("polyline", "line"):
                    ii = [j for j in idx if 0 <= j < (len(e.pts) if e.kind == "polyline" else 2)]
                    if ii:
                        pmap[tg] = ii; tags.append(tg); moved += _stretch_points(e, ii)
                elif idx:
                    pmap[tg] = "all"; tags.append(tg)       # circle, arc, text, nested block: moves as a whole
        if moved:                                          # hatches follow the boundary points they share
            Mv = np.array(moved, float)
            for e in hatches:
                sel = []
                for li, l in enumerate(e.loops):
                    l = np.asarray(l, float)
                    span = max(1e-9, float(np.abs(l.max(axis=0) - l.min(axis=0)).max()))
                    for vi, q in enumerate(l):
                        if float(np.abs(Mv - q).max(axis=1).min()) <= span * 1e-6 + 1e-9:
                            sel.append([li, vi])
                if sel:
                    if e.xd is None:
                        e.xd = {}
                    if "bk" not in e.xd:
                        ntag += 1; e.xd["bk"] = f"dx{ntag}"
                    pmap[e.xd["bk"]] = sel; tags.append(e.xd["bk"])
        if not tags:
            continue
        pm = {names[n]: idx for n, idx in a["nodes"] if n in names and names[n] != names[a["param"]]}
        actions.append({"type": "stretch", "param": names[a["param"]], "tags": tags, "pts": pmap, "pmove": pm, "mult": a["mult"]})
    used = {a["param"] for a in actions}
    blk.params = [p for p in params if p["name"] in used]
    blk.actions = actions
    for attr in ("_geo", "_plain"):
        if hasattr(blk, attr):
            try:
                delattr(blk, attr)
            except Exception:
                pass
