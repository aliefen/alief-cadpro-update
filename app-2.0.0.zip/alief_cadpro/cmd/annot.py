"""Annotate / measure additions: arc-length, continue, baseline, ordinate and jogged dimensions, centre marks and
centre lines, tables (create, edit, export, area table), find & replace, object-based DIST / AREA and VOLUME."""
import math
import numpy as np
from ..core import entities as E
from ..core.geom import unit, norm, prims_tess, prims_length, poly_centroid2 as _pc2, fmt, TAU
from .draw2d import _dimstyle, _dim_add

is_crv = lambda e: getattr(e, "is_curve", False)


def _scale(c):
    from .misc import ensure_scale; ensure_scale(c)


# ------------------------------------------------------------------------------------------------ dimensions
def _arc_of(e, p, n):
    """(centre, start point, end point, CCW sweep about n) of the arc picked on entity e near point p."""
    best = None
    for pr in e.prims():
        if pr[0] != "A":
            continue
        cen, r, an, u, a0, a1 = pr[1], pr[2], pr[3], pr[4], pr[5], pr[6]
        d = abs(norm(p - cen) - r) if p is not None else 0.0
        if best is None or d < best[0]:
            v = np.cross(an, u)
            s = cen + r * (math.cos(a0) * u + math.sin(a0) * v); t = cen + r * (math.cos(a1) * u + math.sin(a1) * v)
            sw = (a1 - a0) * (1 if np.dot(an, n) >= 0 else -1)
            best = (d, cen, s, t, sw)
    return best[1:] if best else None


def cmd_dimarc(c):
    _scale(c)
    r = yield c.ent("DIMARC  Select arc or polyline arc segment", filt=lambda e: e.kind in ("arc", "circle", "polyline"))
    if r is None:
        return
    a = _arc_of(r[0], r[1], c.ucs.z)
    if a is None:
        c.msg("The selected object has no arc segment"); return
    cen, s, t, sw = a
    if r[0].kind == "circle":
        sw = TAU - 1e-9
    def mk(q):
        st = _dimstyle(c); st["sweep"] = float(sw)
        return E.Dimension("arc", [cen, s, t, q], c.ucs.z, c.ucs.x, st)
    q = yield c.pt("Specify arc length dimension location", base=cen, preview=lambda q: [mk(q)])
    if q is not None:
        d = mk(q); _dim_add(c, d); c.msg(f"Arc length = {d.measure():.4f}")


def _last_linear(c):
    for e in reversed(list(c.doc.ents.values())):
        if e.kind == "dimension" and e.dtype in ("linear", "aligned") and len(e.dpts) >= 3:
            return e
    return None


def _chain(c, baseline):
    _scale(c)
    name = "DIMBASELINE" if baseline else "DIMCONTINUE"
    base = _last_linear(c)
    r = yield c.ent(f"{name}  Select base dimension" + (" <last dimension>" if base is not None else ""),
                    filt=lambda e: e.kind == "dimension" and e.dtype in ("linear", "aligned"))
    if r is not None:
        base = r[0]
    if base is None:
        c.msg("Create a linear or aligned dimension first"); return
    k = E.Entity.anno_scale if base.style.get("anno") else 1.0
    step = (base.style.get("th", 2.5) * 2.2 + base.style.get("gap", 0.8) * 2) * k        # baseline spacing
    cur = base; n = 0
    while True:
        P = cur.dpts
        org = P[0] if baseline else P[1]
        def mk(q, cur=cur, org=org):
            d = E.Dimension(cur.dtype, [org, q, cur.dpts[2]], cur.n, cur.xdir, dict(cur.style))
            if baseline:
                # push the dimension line one step further away from the measured points
                g = E._dim_geometry(cur)[0]
                dl = g[-1] if g else None
                if dl is not None:
                    away = unit(dl[0] - cur.dpts[0] - np.dot(dl[0] - cur.dpts[0], unit(dl[1] - dl[0])) * unit(dl[1] - dl[0]))
                    d.dpts[2] = cur.dpts[2] + away * step
            return d
        q = yield c.pt("Specify second extension line origin <done>", base=org, preview=lambda q: [mk(q)])
        if q is None:
            break
        d = mk(q); _dim_add(c, d); n += 1; cur = d
    if n:
        c.msg(f"{n} dimension(s) added")


def cmd_dimcontinue(c):
    yield from _chain(c, False)


def cmd_dimbaseline(c):
    yield from _chain(c, True)


def cmd_dimordinate(c):
    _scale(c)
    o = c.doc.settings.get("ord_origin")
    org = np.array(o, float) if o else c.ucs.o.copy()
    n = 0
    while True:
        f = yield c.pt("DIMORDINATE  Specify feature location or [Origin] <done>", options=["Origin"])
        if f is None:
            break
        if f == "Origin":
            q = yield c.pt("Specify the datum (0,0) point")
            if q is not None:
                org = q; c.doc.settings["ord_origin"] = [float(v) for v in q]
            continue
        def mk(q):
            d = c.ucs.to_local(q) - c.ucs.to_local(f)
            st = _dimstyle(c); st["axis"] = "x" if abs(d[1]) >= abs(d[0]) else "y"       # leader mostly vertical -> X datum
            return E.Dimension("ordinate", [org, f, q], c.ucs.z, c.ucs.x, st)
        q = yield c.pt("Specify leader endpoint (move up/down for X datum, left/right for Y datum)", base=f, preview=lambda q: [mk(q)])
        if q is None:
            break
        _dim_add(c, mk(q)); n += 1
    if n:
        c.msg(f"{n} ordinate dimension(s) added")


def cmd_dimjogged(c):
    _scale(c)
    r = yield c.ent("DIMJOGGED  Select arc or circle", filt=lambda e: e.kind in ("arc", "circle", "polyline"))
    if r is None:
        return
    e, p = r
    if e.kind in ("arc", "circle"):
        cen, rad = e.c, e.r
    else:
        a = _arc_of(e, p, c.ucs.z)
        if a is None:
            c.msg("No arc segment"); return
        cen, rad = a[0], norm(a[1] - a[0])
    onp = cen + unit(p - cen) * rad if p is not None and norm(p - cen) > 1e-9 else cen + c.ucs.x * rad
    mk = lambda q: E.Dimension("jogged", [cen, cen + unit(q - cen) * rad if norm(q - cen) > 1e-9 else onp, q], c.ucs.z, c.ucs.x, _dimstyle(c))
    q = yield c.pt("Specify dimension line location", base=onp, preview=lambda q: [mk(q)])
    if q is not None:
        _dim_add(c, mk(q))


# ------------------------------------------------------------------------------------------------ centre marks / lines
def _center_layer(c):
    if "CENTER" not in c.doc.layers:
        c.doc.ensure_layer("CENTER", 1)
        c.doc.layers["CENTER"].ltype = "Center"
    return "CENTER"


def cmd_centermark(c):
    _scale(c)
    ents = yield c.sel("CENTERMARK  Select circles or arcs", filt=lambda e: e.kind in ("circle", "arc"))
    lay = _center_layer(c) if ents else None
    for e in ents or []:
        pl = e.plane() if hasattr(e, "plane") and e.plane() is not None else c.ucs
        x, y = c.ucs.x, c.ucs.y
        ext = e.r + max(e.r * 0.15, 2.5 * E.Entity.anno_scale)
        for d in (x, y):
            l = E.Line(e.c - d * ext, e.c + d * ext); l.layer = lay; c.doc.add_keep(l)
    if ents:
        c.msg(f"{len(ents)} centre mark(s) on layer CENTER")


def cmd_centerline(c):
    a = yield c.ent("CENTERLINE  Select first line", filt=lambda e: e.kind == "line")
    if a is None:
        return
    b = yield c.ent("Select second line", filt=lambda e: e.kind == "line" and e is not a[0])
    if b is None:
        return
    l1, l2 = a[0], b[0]
    p0, p1 = l1.p0, l1.p1; q0, q1 = l2.p0, l2.p1
    if norm(p0 - q0) + norm(p1 - q1) > norm(p0 - q1) + norm(p1 - q0):
        q0, q1 = q1, q0
    m0, m1 = (p0 + q0) / 2, (p1 + q1) / 2
    if norm(m1 - m0) < 1e-9:
        c.msg("The lines have no centre line"); return
    d = unit(m1 - m0); ext = 3.0 * E.Entity.anno_scale
    l = E.Line(m0 - d * ext, m1 + d * ext); l.layer = _center_layer(c); c.doc.add_keep(l)


# ------------------------------------------------------------------------------------------------ tables
def cmd_table(c):
    _scale(c)
    opt = c.app.dialog_table()
    if not opt:
        return
    rows = [[""] * opt["cols"] for _ in range(opt["rows"])]
    for j in range(opt["cols"]):
        rows[0][j] = f"COLUMN {j + 1}"
    mk = lambda p: E.Table(p, rows, [opt["width"]] * opt["cols"], opt["title"], opt["th"], opt["rh"], c.ucs.x, c.ucs.z)
    p = yield c.pt("TABLE  Specify insertion point (top-left corner)", preview=lambda q: [mk(q)])
    if p is None:
        return
    t = mk(p); t.layer = "TEXT"; c.doc.add_keep(t)
    c.app.edit_table(t)


def cmd_tabledit(c):
    r = yield c.ent("TABLEDIT  Select table", filt=lambda e: e.kind == "table")
    if r is not None:
        c.app.edit_table(r[0])


def cmd_tableexport(c):
    r = yield c.ent("TABLEEXPORT  Select table to export to Excel / CSV", filt=lambda e: e.kind == "table")
    if r is not None:
        c.app.export_table(r[0])


def _loop2(e, c):
    """(plane, 2D points) of a closed curve."""
    P = prims_tess(e.prims()) if e.kind not in ("ellipse", "spline") else e.pts()
    pl = e.plane() or c.ucs
    return pl, pl.to_local(P)[:, :2]


def _area_of(e, c):
    """-> (area, perimeter, centroid world) for closed curves, hatches and surface / plate bodies."""
    if e.kind == "body":
        a = e.meta.get("area", e.area()); return float(a), 0.0, e.centroid()
    if e.kind == "hatch":
        return float(e.area()), 0.0, np.mean(np.vstack(e.loops), axis=0)
    if e.kind == "circle":                                # exact, not the tessellated polygon
        return math.pi * e.r * e.r, 2 * math.pi * e.r, np.asarray(e.c, float)
    pl, Q = _loop2(e, c)
    cen, A = _pc2(Q)
    per = float(np.sum(np.linalg.norm(np.diff(np.vstack([Q, Q[:1]]), axis=0), axis=1)))
    return abs(float(A)), per, pl.to_world(np.append(cen, 0))


def _closed(e):
    return (is_crv(e) and getattr(e, "closed", False)) or e.kind in ("hatch",) or (e.kind == "body")


def cmd_areatable(c):
    _scale(c)
    ents = yield c.sel("AREATABLE  Select closed objects (polylines, circles, hatches, plates)", filt=_closed)
    if not ents:
        return
    units = c.doc.settings.get("units", "mm"); k = E.Entity.anno_scale
    rows = [["NO", "OBJECT", f"AREA ({units}2)", f"PERIMETER ({units})"]]; tot = 0.0; marks = []
    for i, e in enumerate(ents, 1):
        A, per, cen = _area_of(e, c); tot += A
        rows.append([str(i), e.label, f"{A:,.2f}", f"{per:,.2f}" if per else "-"])
        marks.append((cen, str(i)))
    rows.append(["", "TOTAL", f"{tot:,.2f}", ""])
    p = yield c.pt("Specify insertion point (top-left corner) of the area table")
    if p is None:
        return
    for cen, s in marks:
        t = E.Text(cen, s, 2.5, c.ucs.x, c.ucs.z, 1, 2); t.anno = 3.5; t.layer = "TEXT"; c.doc.add_keep(t)
        r = E.Circle(cen, 3.2 * k, c.ucs.z); r.layer = "TEXT"; c.doc.add_keep(r)
    tb = E.Table(p, rows, E.Table.fit_widths(rows, [12, 34, 34, 34], 2.5), "AREA TABLE", 2.5, 7.0, c.ucs.x, c.ucs.z)
    tb.aligns = [1, 0, 2, 2]; tb.layer = "TEXT"; c.doc.add_keep(tb)
    c.msg(f"Total area = {tot:.4f} {units}2  ({len(ents)} objects)")


def cmd_find(c):
    c.app.dialog_find()


# ------------------------------------------------------------------------------------------------ measure
def _curve_len(e):
    if e.kind in ("spline", "ellipse"):
        P = e.pts(); return float(np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1)))
    return float(prims_length(e.prims()))


def cmd_dist(c):
    a = yield c.pt("DIST  Specify first point or [Object]", options=["Object"])
    if a is None:
        return
    if a == "Object":
        ents = yield c.sel("Select objects to measure (lines, arcs, polylines, splines ...)", filt=is_crv)
        if not ents:
            return
        tot = 0.0; lines = []
        for i, e in enumerate(ents, 1):
            L = _curve_len(e); tot += L; lines.append(f"{i:>3}  {e.label:<12} length = {L:.4f}")
        if len(ents) == 1:
            e = ents[0]
            extra = ""
            if e.kind == "line":
                q = c.ucs.to_local(e.p1) - c.ucs.to_local(e.p0)
                extra = f",  Angle in XY = {math.degrees(math.atan2(q[1], q[0])) % 360:.3f}°,  Delta X = {q[0]:.4f}, Delta Y = {q[1]:.4f}, Delta Z = {q[2]:.4f}"
            elif e.kind in ("circle", "arc"):
                extra = f",  Radius = {e.r:.4f}"
            c.msg(f"Length = {tot:.4f}{extra}")
        else:
            c.msg(f"Total length = {tot:.4f}  ({len(ents)} objects)")
            c.app.show_text("DIST - objects", "\n".join(lines) + f"\n\nTOTAL LENGTH = {tot:.4f} {c.doc.settings.get('units', 'mm')}")
        return
    b = yield c.pt("Specify second point", base=a, preview=lambda q: [E.Line(a, q)])
    if b is None:
        return
    d = b - a; q = c.ucs.to_local(b) - c.ucs.to_local(a)
    c.msg(f"Distance = {norm(d):.4f},  Angle in XY = {math.degrees(math.atan2(q[1], q[0])) % 360:.3f}°,  "
          f"Delta X = {q[0]:.4f}, Delta Y = {q[1]:.4f}, Delta Z = {q[2]:.4f}")


def cmd_area(c):
    units = c.doc.settings.get("units", "mm")
    o = yield c.pt("AREA  Specify first corner point or [Object]", options=["Object"])
    if o is None:
        return
    if o == "Object":
        ents = yield c.sel("Select closed objects (polylines, circles, ellipses, splines, hatches, plates, surfaces)", filt=_closed)
        if not ents:
            return
        tot = 0.0; lines = []; last = None
        for i, e in enumerate(ents, 1):
            A, per, cen = _area_of(e, c); tot += A; last = (A, per, cen)
            lines.append(f"{i:>3}  {e.label:<12} area = {A:.4f}" + (f"   perimeter = {per:.4f}" if per else ""))
        if len(ents) > 1:
            c.msg(f"Total area = {tot:.4f} {units}2  ({len(ents)} objects)")
            c.app.show_text("AREA - objects", "\n".join(lines) + f"\n\nTOTAL AREA = {tot:.4f} {units}2")
            return
        A, per, cw = last
    else:
        pts = [o]
        while True:
            q = yield c.pt("Specify next point <done>", base=pts[-1], preview=lambda q: [E.Polyline(np.array(pts + [q]), True, None, c.ucs.z)])
            if q is None:
                break
            pts.append(q)
        if len(pts) < 3:
            return
        Q = c.ucs.to_local(np.array(pts))[:, :2]
        cen, A = _pc2(Q); A = abs(float(A))
        per = float(np.sum(np.linalg.norm(np.diff(np.vstack([Q, Q[:1]]), axis=0), axis=1)))
        cw = c.ucs.to_world(np.append(cen, 0))
    from ..core.geom import fmt_pt
    c.msg(f"Area = {A:.4f},  Perimeter = {per:.4f},  Centroid = ({fmt_pt(c.ucs.to_local(cw))})")
    lab = yield c.opt("Place area / centroid label at the centroid? [Yes/No] <No>", ["Yes", "No"], "No")
    if lab == "Yes":
        t = E.Text(cw, f"A = {A:.2f}\nCG ({fmt(c.ucs.to_local(cw)[0], 2)}, {fmt(c.ucs.to_local(cw)[1], 2)})", 2.5, c.ucs.x, c.ucs.z, 1, 2)
        t.anno = 2.5; t.layer = "TEXT"; c.doc.add_keep(t)
        c.doc.add_keep(E.PointE(cw))


def cmd_volume(c):
    """Volume of 3D solids / plates / profiles / pipes, and of closed 2D outlines x height (tanks, compartments)."""
    units = c.doc.settings.get("units", "mm"); f3 = {"mm": 1e-9, "cm": 1e-6, "m": 1.0, "in": 1.6387064e-5, "ft": 0.028316846592}.get(units, 1e-9)
    o = yield c.pt("VOLUME  Specify first corner of the base or [Object] <Object>", options=["Object"], default="Object")
    rows = []; tot = 0.0; mass = 0.0
    from ..core.ship import density
    if o is None or o == "Object":
        ents = yield c.sel("Select 3D solids (or closed 2D outlines, which are then given a height)",
                           filt=lambda e: e.kind == "body" or (is_crv(e) and getattr(e, "closed", False)))
        if not ents:
            return
        flat = [e for e in ents if e.kind != "body"]
        h = 0.0
        if flat:
            h = yield c.dist(f"Height for the {len(flat)} closed 2D outline(s) <1000>", default=1000.0)
            h = abs(float(h or 0.0))
        for i, e in enumerate(ents, 1):
            if e.kind == "body":
                if e.role == "surface":
                    rows.append(f"{i:>3}  {e.label:<12} open surface - no volume"); continue
                v = abs(float(e.volume())); d = density(e.meta.get("grade", "")) if e.meta.get("grade") else None
                m = v * f3 * d if d else 0.0; mass += m
                rows.append(f"{i:>3}  {e.label:<12} volume = {v:,.4f} {units}3  = {v * f3:,.6f} m3" + (f"   mass = {m:,.2f} kg ({e.meta.get('grade')})" if d else ""))
            else:
                A = _area_of(e, c)[0]; v = A * h
                rows.append(f"{i:>3}  {e.label:<12} area {A:,.2f} x height {h:g} = {v:,.4f} {units}3  = {v * f3:,.6f} m3")
            tot += v
    else:
        pts = [o]
        while True:
            q = yield c.pt("Specify next corner of the base <done>", base=pts[-1], preview=lambda q: [E.Polyline(np.array(pts + [q]), True, None, c.ucs.z)])
            if q is None:
                break
            pts.append(q)
        if len(pts) < 3:
            return
        Q = c.ucs.to_local(np.array(pts))[:, :2]; A = abs(float(_pc2(Q)[1]))
        h = yield c.dist("Specify height <1000>", default=1000.0)
        h = abs(float(h or 0.0)); tot = A * h
        rows.append(f"  1  base area {A:,.2f} x height {h:g} = {tot:,.4f} {units}3")
    m3 = tot * f3
    c.msg(f"Volume = {tot:.4f} {units}3  = {m3:.6f} m3  = {m3 * 1000:.3f} litre")
    txt = "\n".join(rows) + f"\n\nTOTAL VOLUME = {tot:,.4f} {units}3\n             = {m3:,.6f} m3\n             = {m3 * 1000:,.3f} litre"
    txt += f"\n\nContents if filled:  fresh water {m3 * 1.000:,.3f} t   sea water {m3 * 1.025:,.3f} t   fuel oil (0.85) {m3 * 0.85:,.3f} t"
    if mass:
        txt += f"\nMaterial mass of the selected solids (by grade) = {mass:,.2f} kg"
    c.app.show_text("VOLUME", txt)


def register(eng):
    R = eng.register
    R("DIMARC", cmd_dimarc, ["DAR", "DIMARCLENGTH"], "Arc length dimension")
    R("DIMCONTINUE", cmd_dimcontinue, ["DCO", "DIMCONT"], "Continue a linear dimension (chain)")
    R("DIMBASELINE", cmd_dimbaseline, ["DBA", "DIMBASE"], "Baseline dimensions from the same origin")
    R("DIMORDINATE", cmd_dimordinate, ["DOR", "DIMORD"], "Ordinate (datum) dimensions")
    R("DIMJOGGED", cmd_dimjogged, ["DJO", "JOG"], "Jogged radius dimension")
    R("CENTERMARK", cmd_centermark, ["CM", "DIMCENTER"], "Centre marks on circles / arcs")
    R("CENTERLINE", cmd_centerline, ["CL"], "Centre line between two lines")
    R("TABLE", cmd_table, ["TB"], "Create a table"); R("TABLEDIT", cmd_tabledit, [], "Edit table cells")
    R("TABLEEXPORT", cmd_tableexport, [], "Export a table to Excel / CSV"); R("AREATABLE", cmd_areatable, [], "Table of areas of selected closed objects")
    R("FIND", cmd_find, [], "Find and replace text")
    R("DIST", cmd_dist, ["DI"], "Distance between two points, or length of selected objects")
    R("AREA", cmd_area, ["AA"], "Area / perimeter / centroid by points or of selected objects")
    R("VOLUME", cmd_volume, ["VOL"], "Volume of solids, or of a closed outline x height")
