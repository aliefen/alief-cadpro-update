"""Associative arrays, block attributes, the block editor and dynamic block parameters (visibility / linear stretch / flip)."""
import math
import numpy as np
from ..core import entities as E
from ..core.entities2 import ArrayE, AttDef
from ..core.geom import unit, norm, m_translate
from .misc import T


# ------------------------------------------------------------------------------------------------ associative array
def _make_array(c, ents, atype):
    bb = c.doc.extents(ents)
    if bb is None:
        return None
    pl = c.ucs
    lo, hi = pl.to_local(np.array(bb[0])), pl.to_local(np.array(bb[1]))
    w = abs(hi[0] - lo[0]) or abs(hi[1] - lo[1]) or 100.0; h = abs(hi[1] - lo[1]) or w
    base = (np.asarray(bb[0]) + np.asarray(bb[1])) / 2
    src = []
    for e in ents:
        k = e.copy(); k.layer = e.layer; k.color = e.color; src.append(k)
    a = ArrayE(src, atype, base, pl.x, pl.y)
    a.dx = round(w * 1.5, 4); a.dy = round(h * 1.5, 4); a.dz = 1.0
    return a


def cmd_arrayrect(c):
    ents = yield c.sel("ARRAYRECT  Select objects")
    if not ents:
        return
    a = _make_array(c, ents, "rect")
    if a is None:
        return
    for e in ents:
        c.doc.remove(e)
    a = c.doc.add_keep(a)
    c.app.after_command(lambda: c.app.set_selection([a.id]))
    c.msg("Associative array created: edit Columns / Rows / Levels on the Array ribbon tab, or drag the blue grips. Esc = finish.")


def cmd_arraypolar(c):
    ents = yield c.sel("ARRAYPOLAR  Select objects")
    if not ents:
        return
    a = _make_array(c, ents, "polar")
    if a is None:
        return
    def pv(q):
        k = E.from_dict(a.to_dict()); k.center = q; k.touch(); return [k]
    p = yield c.pt("Specify center point of array", preview=pv)
    if p is None:
        return
    a.center = p; a.rows = 1; a.dy = norm(a.base - p) * 0.5 or 100.0
    for e in ents:
        c.doc.remove(e)
    a = c.doc.add_keep(a)
    c.app.after_command(lambda: c.app.set_selection([a.id]))
    c.msg("Polar array created: edit Items / Fill / Rows on the Array ribbon tab. Esc = finish.")


def cmd_array(c):
    o = yield c.opt("ARRAY  Enter array type [Rectangular/POlar/PAth] <Rectangular>", ["Rectangular", "POlar", "PAth"], "Rectangular")
    if o == "POlar":
        yield from cmd_arraypolar(c)
    elif o == "PAth":
        from .modify import cmd_array as classic
        yield from classic(c)
    elif o is not None:
        yield from cmd_arrayrect(c)


# ------------------------------------------------------------------------------------------------ attributes
def cmd_attdef(c):
    from .misc import ensure_scale; ensure_scale(c)
    opt = c.app.dialog_attdef()
    if not opt:
        return
    def mk(p):
        a = AttDef(p, opt["tag"], opt["prompt"], opt["default"], 2.5, c.ucs.x, c.ucs.z, opt["halign"], 0)
        a.anno = opt["h"]; a.invisible = opt["invisible"]; return a
    p = yield c.pt(f"ATTDEF {opt['tag']}  Specify start point", preview=lambda q: [mk(q)])
    if p is not None:
        c.add(mk(p))
        c.msg("Attribute definition placed. Include it when you create the block (BLOCK), or add it inside the Block Editor.")


def cmd_insert(c, name=None):
    names = sorted(n for n in c.doc.blocks if not n.startswith("*"))
    if not names:
        c.msg("No blocks in this drawing. Create one with BLOCK, or use the Symbol library."); return
    name = name or c.app.choose("INSERT", "Block name", names)
    if not name or name not in c.doc.blocks:
        return
    blk = c.doc.blocks[name]
    sc = 1.0
    def mk(p, a=0.0):
        return E.Insert.make(name, p, sc, sc, sc, a, c.ucs.z)
    st = {"rot": 0.0}; n = 0
    while True:
        p = yield c.pt(f"INSERT {name}  Specify insertion point or [Scale/Rotate] (scale {sc:g}, rotation {math.degrees(st['rot']):g}) <done>",
                       preview=lambda q: [mk(q, st["rot"])], options=["Scale", "Rotate"])
        if p is None:
            break
        if p == "Scale":
            s = yield c.num(f"Scale factor <{sc:g}>", sc); sc = float(s or sc); continue
        if p == "Rotate":
            a = yield c.num(f"Rotation angle <{math.degrees(st['rot']):g}>", math.degrees(st["rot"])); st["rot"] = math.radians(float(a or 0.0)); continue
        ins = mk(p, st["rot"])
        if blk.attdefs() or blk.params:
            vals = c.app.dialog_blockprops(blk, ins, "Insert " + name)
            if vals is None:
                continue
            ins.attribs, ins.dyn = vals
        c.add(ins); n += 1
    if n:
        c.msg(f"{n} x {name} inserted")


def cmd_attedit(c):
    r = yield c.ent("ATTEDIT  Select block reference", filt=lambda e: e.kind == "insert")
    if r is None:
        return
    ins = r[0]; blk = c.doc.blocks.get(ins.name)
    if blk is None:
        return
    if not (blk.attdefs() or blk.params):
        c.msg(f"Block {ins.name} has no attributes - double click it (or BEDIT) to open the Block Editor"); return
    vals = c.app.dialog_blockprops(blk, ins, f"Edit attributes {ins.name}")
    if vals is None:
        return
    c.doc.modify(ins); ins.attribs, ins.dyn = vals; ins.touch()


def cmd_attext(c):
    """Attribute / data extraction: one table row per block reference."""
    from .misc import ensure_scale; ensure_scale(c)
    ents = yield c.sel("ATTEXT  Select block references <Enter = all>", filt=lambda e: e.kind == "insert")
    ents = ents or [e for e in c.doc.ents.values() if e.kind == "insert"]
    ents = [e for e in ents if e.name in c.doc.blocks and (c.doc.blocks[e.name].attdefs() or c.doc.blocks[e.name].params)]
    if not ents:
        c.msg("No block references with attributes or dynamic parameters found"); return
    tags = []
    for e in ents:
        b = c.doc.blocks[e.name]
        for t in [a.tag for a in b.attdefs()] + [p["name"].upper() for p in b.params]:
            if t not in tags:
                tags.append(t)
    rows = [["NO", "BLOCK"] + tags]
    for i, e in enumerate(ents, 1):
        b = c.doc.blocks[e.name]
        vals = {a.tag: e.attribs.get(a.tag, a.default) for a in b.attdefs()}
        for p in b.params:
            v = e.dyn_value(p); vals[p["name"].upper()] = ("Yes" if v else "No") if p["type"] == "flip" else (f"{v:g}" if isinstance(v, float) else str(v))
        rows.append([str(i), e.name] + [vals.get(t, "") for t in tags])
    p = yield c.pt(f"{len(ents)} block(s) found. Specify insertion point of the table")
    if p is None:
        return
    tb = E.Table(p, rows, E.Table.fit_widths(rows, [10, 24] + [18] * len(tags), 2.5), "ATTRIBUTE LIST", 2.5, 7.0, c.ucs.x, c.ucs.z)
    tb.layer = "TEXT"; c.doc.add_keep(tb)
    c.msg("Attribute table created. TABLEEXPORT writes it to Excel.")


# ------------------------------------------------------------------------------------------------ block editor
def cmd_bedit(c, name=None):
    if name and name not in c.doc.blocks:
        name = None
    sel = c.app.selected_ents()
    if name is None and len(sel) == 1 and sel[0].kind == "insert":
        name = sel[0].name
    if name is None:
        names = sorted(n for n in c.doc.blocks if not n.startswith("*"))
        if not names:
            c.msg("No blocks in this drawing"); return
        name = c.app.choose("Block Editor", "Block to edit", names)
    if name:
        c.app.after_command(lambda: c.app.bedit_open(name))      # the editor swaps documents: do it after this command ends
    return
    yield


def _in_editor(c):
    if not c.app.bedit:
        c.msg("This command works inside the Block Editor (BEDIT)"); return False
    return True


def cmd_bvstate(c):
    """Visibility states: one block, several looks (e.g. valve open / closed, door left / right)."""
    if not _in_editor(c):
        return
    be = c.app.bedit
    vis = [p for p in be["params"] if p["type"] == "visibility"]
    prm = vis[0] if vis else None
    cur = be.get("state")
    o = yield c.opt("BVSTATE  [New/Current/Rename/Delete/List]" + (f"   states: {', '.join(prm['states'])}   current: {cur}" if prm else "   (no states yet)"),
                    ["New", "Current", "Rename", "Delete", "List"], "New")
    if o == "New":
        n = yield c.text("Name of the new visibility state")
        if not n or not n.strip():
            return
        n = n.strip()
        if prm is None:
            prm = {"type": "visibility", "name": "Visibility", "states": []}; be["params"].append(prm)
        if n in prm["states"]:
            c.msg("That state already exists"); return
        first = not prm["states"]
        prm["states"].append(n)
        if not first:                       # objects limited to some states stay as they are; the new state starts with everything shown
            for e in c.doc.ents.values():
                xs = (e.xd or {}).get("vis")
                if xs is not None and n not in xs:
                    c.doc.modify(e); e.xd = dict(e.xd, vis=xs + [n])
        be["state"] = n; c.app.bedit_refresh()
        c.msg(f'State "{n}" is current. Select objects and use BVHIDE to hide them in this state (BVSHOW shows them again).')
    elif o in ("Current", "Rename", "Delete") and prm and prm["states"]:
        n = c.app.choose("Visibility state", o, prm["states"])
        if not n:
            return
        if o == "Current":
            be["state"] = n
        elif o == "Rename":
            m = yield c.text(f'New name for "{n}"')
            if m and m.strip():
                m = m.strip(); prm["states"][prm["states"].index(n)] = m
                for e in c.doc.ents.values():
                    xs = (e.xd or {}).get("vis")
                    if xs and n in xs:
                        c.doc.modify(e); e.xd = dict(e.xd, vis=[m if s == n else s for s in xs])
                if be.get("state") == n:
                    be["state"] = m
        else:
            prm["states"].remove(n)
            for e in c.doc.ents.values():
                xs = (e.xd or {}).get("vis")
                if xs and n in xs:
                    c.doc.modify(e); e.xd = dict(e.xd, vis=[s for s in xs if s != n])
            if not prm["states"]:
                be["params"].remove(prm)
            be["state"] = prm["states"][0] if prm["states"] else None
        c.app.bedit_refresh()
    elif o == "List":
        c.app.bedit_list()


def _vis(c, show):
    if not _in_editor(c):
        return
    be = c.app.bedit
    vis = [p for p in be["params"] if p["type"] == "visibility"]
    if not vis or not be.get("state"):
        c.msg("Create a visibility state first (BVSTATE > New)"); return
    states = vis[0]["states"]; cur = be["state"]
    if show:
        hidden = [e for e in c.doc.ents.values() if (e.xd or {}).get("vis") is not None and cur not in e.xd["vis"]]
        if not hidden:
            c.msg("Nothing is hidden in this state"); return
        names = c.app.choose_many("BVSHOW", f'Objects hidden in state "{cur}"', [f"{e.label} #{e.id}" for e in hidden])
        for e, lab in zip(hidden, [f"{e.label} #{e.id}" for e in hidden]):
            if names is None or lab in names:
                c.doc.modify(e); xs = e.xd["vis"] + [cur]
                e.xd = dict(e.xd); e.xd["vis"] = None if set(xs) >= set(states) else xs
                if e.xd["vis"] is None:
                    e.xd.pop("vis"); e.xd = e.xd or None
        c.app.bedit_refresh(); return
    ents = yield c.sel(f'BVHIDE  Select objects to hide in state "{cur}"')
    for e in ents or []:
        c.doc.modify(e); xs = (e.xd or {}).get("vis")
        xs = [s for s in (xs if xs is not None else states) if s != cur]
        e.xd = dict(e.xd or {}, vis=xs)
    c.app.after_command(c.app.bedit_refresh)
    if ents:
        c.msg(f'{len(ents)} object(s) hidden in state "{cur}"')


def cmd_bvhide(c):
    yield from _vis(c, False)


def cmd_bvshow(c):
    r = _vis(c, True)
    if r is not None:
        yield from r


def cmd_bparam(c):
    """Linear (stretch) parameter: a length the user can change on every block reference."""
    if not _in_editor(c):
        return
    be = c.app.bedit
    a = yield c.pt("BPARAM Linear  Specify start point of the dimension (fixed side)")
    if a is None:
        return
    b = yield c.pt("Specify end point (the side that moves)", base=a, preview=lambda q: [E.Line(a, q)])
    if b is None or norm(b - a) < 1e-9:
        return
    c.msg("Now give the stretch frame: everything inside it moves with the end point (like STRETCH with a crossing window).")
    f1 = yield c.pt("Specify first corner of the stretch frame")
    if f1 is None:
        return
    f2 = yield c.corner("Specify opposite corner of the stretch frame", f1)
    if f2 is None:
        return
    n = len([p for p in be["params"] if p["type"] == "linear"]) + 1
    name = yield c.text(f"Parameter name <Length{n}>", f"Length{n}")
    name = (name or f"Length{n}").strip()
    L = float(norm(b - a))
    lo = yield c.num(f"Minimum value <none>   (base length = {L:g})", 0.0)
    hi = yield c.num("Maximum value <none>", 0.0)
    be["params"].append({"type": "linear", "name": name, "p0": [float(v) for v in a], "p1": [float(v) for v in b], "base": L,
                         "frame": [float(min(f1[0], f2[0])), float(min(f1[1], f2[1])), float(max(f1[0], f2[0])), float(max(f1[1], f2[1]))],
                         "min": float(lo) if lo else None, "max": float(hi) if hi else None})
    c.app.after_command(c.app.bedit_refresh)
    c.msg(f'Linear parameter "{name}" = {L:g} added. After saving, change it per block in Properties or by double-clicking the block.')


def cmd_bflip(c):
    if not _in_editor(c):
        return
    be = c.app.bedit
    a = yield c.pt("BFLIP  Specify first point of the mirror axis")
    if a is None:
        return
    b = yield c.pt("Specify second point of the mirror axis", base=a, preview=lambda q: [E.Line(a, q)])
    if b is None or norm(b - a) < 1e-9:
        return
    n = len([p for p in be["params"] if p["type"] == "flip"]) + 1
    name = yield c.text(f"Parameter name <Flip{n}>", f"Flip{n}")
    be["params"].append({"type": "flip", "name": (name or f"Flip{n}").strip(), "p0": [float(v) for v in a], "p1": [float(v) for v in b]})
    c.app.after_command(c.app.bedit_refresh)
    c.msg("Flip parameter added")


def register(eng):
    R = eng.register
    R("ARRAY", cmd_array, ["AR"], "Associative array: rectangular / polar (edit on the Array ribbon tab) or along a path")
    R("ARRAYRECT", cmd_arrayrect, [], "Associative rectangular array"); R("ARRAYPOLAR", cmd_arraypolar, [], "Associative polar array")
    R("ATTDEF", cmd_attdef, ["ATT", "DDATTDEF"], "Define a block attribute (tag / prompt / default)")
    R("INSERT", cmd_insert, ["I", "DDINSERT"], "Insert block (asks the attribute values and dynamic options)")
    R("ATTEDIT", cmd_attedit, ["ATE", "EATTEDIT", "DDATTE"], "Edit the attributes / dynamic options of a block reference")
    R("ATTEXT", cmd_attext, ["DATAEXTRACTION", "EATTEXT"], "Attribute extraction to a table")
    R("BEDIT", cmd_bedit, ["BE", "BLOCKEDIT"], "Block Editor")
    R("BSAVE", T(lambda c: c.app.bedit_save()), [], "Block Editor: save the block"); R("BCLOSE", T(lambda c: c.app.bedit_close()), [], "Block Editor: close")
    R("BVSTATE", cmd_bvstate, [], "Block Editor: visibility states"); R("BVHIDE", cmd_bvhide, [], "Block Editor: hide objects in the current state")
    R("BVSHOW", cmd_bvshow, [], "Block Editor: show hidden objects in the current state")
    R("BPARAM", cmd_bparam, [], "Block Editor: linear (stretch) parameter"); R("BFLIP", cmd_bflip, [], "Block Editor: flip parameter")
    R("BPARAMLIST", T(lambda c: c.app.bedit_list()), [], "Block Editor: list / delete parameters")
