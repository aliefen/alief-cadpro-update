"""Commands of version 1.8: REFEDIT / REFCLOSE (Edit Block In-place)."""
import numpy as np

from ..core import entities as E
from .misc import T


def working_set(doc):
    r = getattr(doc, "refedit", None)
    if r is None:
        return None
    return {i for i in doc.ents if i in r["ids"] or i >= r["start"]}


def refedit_open(app, ins):
    """The objects of the block are put into the drawing at the place of the reference: edit them with the usual
    commands (new objects join the block), the rest of the drawing is faded and cannot be selected."""
    doc = app.doc
    b = doc.blocks.get(ins.name)
    if b is None or ins.id not in doc.ents:
        return False
    M = np.asarray(ins.Meff(), float)
    n0 = len(doc.undo_stack)
    doc.begin("refedit"); ids = set()
    keep = ins.to_dict()
    doc.remove(ins)
    for e in b.ents:
        k = e.copy(); k.xd = dict(e.xd) if e.xd else None; k.transform(M)
        doc.add_keep(k); ids.add(k.id)
    doc.end()
    del doc.undo_stack[n0:]; doc.redo_stack.clear()       # opening the edit is not an undo step of its own
    doc.refedit = {"name": ins.name, "ins": keep, "M": M, "ids": ids, "start": doc.next_id, "n0": len(doc.undo_stack)}
    doc.rev += 1
    app.clear_selection(silent=True)
    try:
        app.refedit_ui(True)
    except Exception:
        pass
    app.message(f"REFEDIT {ins.name}: edit the block in place - the rest of the drawing is faded.  "
                f"REFCLOSE (or right click) to save or discard the changes.")
    return True


def refedit_close(app, save=True):
    doc = app.doc; r = getattr(doc, "refedit", None)
    if r is None:
        return False
    if app.engine.busy():
        app.engine.cancel()
    work = [doc.ents[i] for i in sorted(working_set(doc))]
    del doc.undo_stack[r["n0"]:]; doc.redo_stack.clear()    # the steps made inside the edit refer to the temporary objects
    n0 = len(doc.undo_stack)
    b = doc.blocks.get(r["name"])
    if save and b is not None:
        Mi = np.linalg.inv(r["M"]); ents = []
        for e in work:
            k = e.copy(); k.xd = dict(e.xd) if e.xd else None; k.transform(Mi); ents.append(k)
        b.ents = ents
        for a in ("_geo", "_plain"):
            if hasattr(b, a):
                setattr(b, a, None)
    doc.begin("refclose")
    for e in work:
        doc.remove(e)
    ins = E.from_dict(r["ins"]); doc.add_keep(ins)
    doc.end()
    del doc.undo_stack[n0:]
    doc.refedit = None
    for e in doc.ents.values():                            # every reference of the block shows the new definition
        if isinstance(e, E.Insert) and e.name == r["name"]:
            e.touch()
    doc.rev += 1; doc.modified = True; doc.changed()
    try:
        app.refedit_ui(False)
    except Exception:
        pass
    app.clear_selection(silent=True)
    app.message(f"REFCLOSE: block {r['name']} " + ("saved - every reference is updated" if save else "unchanged (edits discarded)"))
    return True


def cmd_refedit(c):
    if getattr(c.doc, "refedit", None) is not None:
        c.msg("A block is already being edited in place - REFCLOSE first"); return
    sel = [e for e in c.app.selected_ents() if e.kind == "insert"]
    if len(sel) == 1:
        ins = sel[0]
    else:
        r = yield c.ent("REFEDIT  Select the block reference to edit in place", filt=lambda e: e.kind == "insert")
        if r is None:
            return
        ins = r[0]
    b = c.doc.blocks.get(ins.name)
    if b is None:
        c.msg("Not a block reference"); return
    if b.params or getattr(b, "actions", None):
        c.msg(f"{ins.name} is a dynamic block - open it with the Block Editor (BEDIT)"); return
    if getattr(c.app, "bedit", None):
        c.msg("Close the Block Editor first"); return
    c.app.after_command(lambda: refedit_open(c.app, ins))


def cmd_refclose(c):
    if getattr(c.doc, "refedit", None) is None:
        c.msg("No block is being edited in place (REFEDIT)"); return
    o = yield c.opt("REFCLOSE  Enter option [Save reference edits/Discard reference changes] <Save>",
                    ["Save reference edits", "Discard reference changes"], "Save reference edits")
    if o is None:
        return
    save = o.startswith("Save")
    c.app.after_command(lambda: refedit_close(c.app, save))


def cmd_refset(c):
    """Add objects to the block being edited in place / remove them from it."""
    r = getattr(c.doc, "refedit", None)
    if r is None:
        c.msg("No block is being edited in place (REFEDIT)"); return
    o = yield c.opt("REFSET  Transfer objects between the reference set and the drawing [Add/Remove] <Add>", ["Add", "Remove"], "Add")
    if o is None:
        return
    c.doc.refedit = None                                   # selection of the faded drawing for the transfer
    try:
        ents = yield c.sel("Select objects")
    finally:
        c.doc.refedit = r
    for e in ents or []:
        if o == "Add":
            r["ids"].add(e.id)
        else:
            r["ids"].discard(e.id)
            if e.id >= r["start"]:
                c.msg("Objects drawn during the edit belong to the block; erase them instead")
    c.doc.rev += 1


def register(eng):
    R = eng.register
    R("REFEDIT", cmd_refedit, ["REFE", "EDITBLOCKINPLACE"], "Edit Block In-place: edit a block reference directly in the drawing")
    R("REFCLOSE", cmd_refclose, [], "Save or discard the changes of Edit Block In-place")
    R("REFSET", cmd_refset, [], "Edit Block In-place: add / remove objects of the block")
    R("REFSAVE", T(lambda c: c.app.after_command(lambda: refedit_close(c.app, True))), [], "Edit Block In-place: save and close")
    R("REFDISCARD", T(lambda c: c.app.after_command(lambda: refedit_close(c.app, False))), [], "Edit Block In-place: discard and close")
