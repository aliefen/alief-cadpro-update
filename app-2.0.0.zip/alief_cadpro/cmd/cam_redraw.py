"""CAM (G-code, nesting) and redrawing tools (image underlay, calibrate, deskew, auto trace, PDF import, CSV/Excel points)."""
import math
import os
import numpy as np
from ..core import entities as E, cam as CAM
from ..core.geom import unit, norm, Plane, v3, m_scale, m_rotate, m_translate


# ================================================================================================ CAM
def cmd_camcut(c):
    ents = yield c.sel("CAM CUT  Select closed contours of the parts (outer + holes)", filt=lambda e: getattr(e, "closed", False))
    if not ents:
        return
    parts = CAM.build_parts(ents, c.ucs)
    if not parts:
        c.msg("No closed contours"); return
    c.app.dialog_cam(parts, c.ucs)


def cmd_nest(c):
    ents = yield c.sel("NEST  Select closed part contours to nest", filt=lambda e: getattr(e, "closed", False) or e.kind == "text")
    if not ents:
        return
    opt = c.app.dialog_nest()
    if not opt:
        return
    curves = [e for e in ents if e.kind != "text"]
    parts = CAM.build_parts(curves, c.ucs)
    qty = int(opt.get("qty", 1))
    allp = []
    for p in parts:
        allp += [p] * qty
    place, nsheet = CAM.nest_rect(allp, opt["W"], opt["H"], opt["gap"], opt["margin"], opt["rotate"])
    base = yield c.pt("Specify lower-left corner of the first sheet")
    if base is None:
        return
    pl = c.ucs
    b = pl.to_local(base)[:2]
    W, H = opt["W"], opt["H"]
    # map each part's source entities
    def ents_of(p):
        return [p["outer"]["ent"]] + [h["ent"] for h in p["holes"]]
    used = np.zeros(max(1, nsheet))
    for si, i, x, y, rot, mn, w, h in place:
        if si < 0:
            c.msg("A part is larger than the sheet"); continue
        ox = b[0] + si * (W + 200); oy = b[1]
        T = m_translate(pl.to_world(np.array([ox + x, oy + y, 0])) - pl.to_world(np.array([mn[0], mn[1], 0])))
        if rot:
            R = m_rotate(pl.to_world(np.array([mn[0], mn[1], 0])), pl.z, math.pi / 2)
            M = m_translate(pl.to_world(np.array([ox + x + h, oy + y, 0])) - pl.to_world(np.array([mn[0], mn[1], 0]))) @ R
        else:
            M = T
        for e in ents_of(allp[i]):
            n = e.copy(); n.transform(M); n.layer = "CAM"; c.doc.add_keep(n)
        used[si] += w * h
    for si in range(nsheet):
        ox = b[0] + si * (W + 200); oy = b[1]
        pts = pl.to_world(np.array([[ox, oy, 0], [ox + W, oy, 0], [ox + W, oy + H, 0], [ox, oy + H, 0]]))
        s = E.Polyline(pts, True, None, pl.z); s.layer = "CAM"; s.color = 1; c.doc.add_keep(s)
        t = E.Text(pl.to_world(np.array([ox, oy - 8 * E.Entity.anno_scale, 0])), f"SHEET {si + 1}: {W:g} x {H:g} - utilisation {used[si] / (W * H) * 100:.1f}% (bounding box)",
                   2.5, pl.x, pl.z); t.anno = 2.5; t.layer = "CAM"; c.doc.add_keep(t)
    c.msg(f"{len(allp)} part(s) nested on {nsheet} sheet(s)")


# ================================================================================================ redraw
def _read(path):
    with open(path, "rb") as f:
        return f.read()


def cmd_image(c, path=None):
    path = path or c.app.ask_open("Attach raster image", "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.gif);;All files (*)")
    if not path:
        return
    data = _read(path)
    from PySide6.QtGui import QImage
    img = QImage.fromData(data)
    if img.isNull():
        c.msg("Cannot read the image"); return
    if not path.lower().endswith((".png", ".jpg", ".jpeg")):
        from PySide6.QtCore import QBuffer, QByteArray, QIODevice
        ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly); img.save(buf, "PNG"); data = bytes(ba)
    w, h = img.width(), img.height()
    p = yield c.pt("Specify insertion point (lower-left corner) <0,0>", default=c.ucs.o.copy())
    s = yield c.num(f"Image width in drawing units <{w:g}>  (calibrate later with CALIBRATE)", float(w))
    s = float(s or w)
    e = E.ImageE(data, p, c.ucs.x * s, c.ucs.y * s * h / w, w, h, os.path.basename(path))
    e.layer = "IMAGE"; c.doc.ensure_layer("IMAGE", 8); c.doc.add_keep(e)
    c.view.zoom_extents([e])


def cmd_calibrate(c):
    s = yield c.ent("CALIBRATE  Select image / objects to scale (pick image)", filt=lambda e: True)
    if s is None:
        return
    target = [s[0]]
    if s[0].kind != "image":
        more = yield c.sel("Select all objects to scale together <Enter = picked only>")
        target = more or target
    a = yield c.pt("Pick first point of a known distance")
    b = yield c.pt("Pick second point", base=a)
    if a is None or b is None:
        return
    L = yield c.dist(f"Enter the real distance (measured {norm(b - a):.3f})")
    if not isinstance(L, float) or L <= 0:
        return
    f = L / max(norm(b - a), 1e-12)
    for e in target:
        c.doc.modify(e); e.transform(m_scale(a, f))
    c.msg(f"Scaled by {f:.6f}")


def cmd_deskew(c):
    s = yield c.ent("DESKEW  Select image / objects to straighten (pick image)")
    if s is None:
        return
    target = [s[0]]
    a = yield c.pt("Pick first point of a line that must be horizontal (or vertical)")
    b = yield c.pt("Pick second point", base=a)
    if a is None or b is None:
        return
    d = c.ucs.to_local(b) - c.ucs.to_local(a)
    ang = math.atan2(d[1], d[0])
    k = round(ang / (math.pi / 2))
    rot = k * math.pi / 2 - ang
    for e in target:
        c.doc.modify(e); e.transform(m_rotate(a, c.ucs.z, rot))
    c.msg(f"Rotated by {math.degrees(rot):.3f} deg")


def cmd_imagefade(c):
    s = yield c.ent("IMAGEFADE  Select image", filt=lambda e: e.kind == "image")
    if s is None:
        return
    v = yield c.num(f"Fade 0 (solid) .. 90 (very light) <{s[0].fade * 100:g}>", s[0].fade * 100)
    c.doc.modify(s[0]); s[0].fade = min(0.9, max(0.0, float(v) / 100)); s[0].touch()


def cmd_autotrace(c):
    s = yield c.ent("AUTO TRACE  Select raster image", filt=lambda e: e.kind == "image")
    if s is None:
        return
    img = s[0]
    opt = c.app.dialog_trace(img)
    if not opt:
        return
    region = None
    if opt.get("window"):
        a = yield c.pt("Specify first corner of the area to trace")
        b = yield c.corner("Specify opposite corner", a)
        if a is None or b is None:
            return
        region = (a, b)
    from ..core import raster
    g, (W0, H0) = raster.gray_from_bytes(img.data, opt.get("max_side", 3000))
    sx = W0 / g.shape[1]
    x0 = y0 = 0
    if region:
        pa = np.array(img.world_to_pixel(region[0])); pb = np.array(img.world_to_pixel(region[1]))
        lo = np.floor(np.minimum(pa, pb) / sx).astype(int); hi = np.ceil(np.maximum(pa, pb) / sx).astype(int)
        lo = np.clip(lo, 0, [g.shape[1], g.shape[0]]); hi = np.clip(hi, 0, [g.shape[1], g.shape[0]])
        g = g[lo[1]:hi[1], lo[0]:hi[0]]; x0, y0 = lo
    if g.size == 0:
        return
    lines, thr, sk = raster.vectorize(g, opt.get("thr"), opt.get("invert", False), opt.get("speck", 1), opt.get("simplify", 1.2),
                                      opt.get("straight", True), opt.get("ang_tol", 3.0), opt.get("gap", 3.0), opt.get("min_len", 8))
    lay = opt.get("layer", "TRACE"); c.doc.ensure_layer(lay, 4)
    n = 0
    for l in lines:
        P = np.array([img.pixel_to_world((x + x0) * sx, (y + y0) * sx) for x, y in l])
        if len(P) == 2:
            e = E.Line(P[0], P[1])
        else:
            closed = norm(P[0] - P[-1]) < 1e-9
            e = E.Polyline(P[:-1] if closed else P, closed, None, c.ucs.z)
        e.layer = lay; c.doc.add_keep(e); n += 1
    c.msg(f"Auto trace: {n} line(s) / polyline(s) created (threshold {thr})")


def cmd_pdfimport(c, path=None):
    path = path or c.app.ask_open("Import PDF", "PDF (*.pdf)")
    if not path:
        return
    opt = c.app.dialog_pdf(path)
    if not opt:
        return
    path = opt.get("path", path)
    p = c.ucs.o.copy()
    if opt.get("onscreen", True):
        p = yield c.pt("Specify insertion point <0,0>", default=c.ucs.o.copy())
        if p is None:
            p = c.ucs.o.copy()
    ents = run_pdf_import(c.app, path, opt, p)
    if ents is None:
        c.msg("PDF import cancelled"); return
    if isinstance(ents, Exception):
        c.msg(f"PDF import failed: {ents}"); return
    from ..core import pdfimport as PI
    from ..core.geom import m_rotate
    if opt.get("infer"):
        try:
            ents = PI.infer_dashes(ents)
        except Exception:
            import traceback; traceback.print_exc()
    if not opt.get("hatch", True):
        ents = [e for e in ents if e.kind != "hatch"]
    if not opt.get("lw", True):
        for e in ents:
            e.lw = -1
    mode = opt.get("layers", "pdf")
    if mode == "current":
        for e in ents:
            e.layer = c.doc.cur_layer
    elif mode == "object":
        names = {"text": "PDF_Text", "hatch": "PDF_Solid Fills", "image": "PDF_Images"}
        for e in ents:
            e.layer = names.get(e.kind, "PDF_Geometry")
    rot = float(opt.get("rotation", 0.0) or 0.0)
    if abs(rot) > 1e-12:
        M = m_rotate(np.asarray(p, float), c.ucs.z, math.radians(rot))
        for e in ents:
            e.transform(M)
    for lay in sorted({e.layer for e in ents}):
        c.doc.ensure_layer(lay, 7)
    if opt.get("as_block") and ents:
        import os, re
        base = re.sub(r"[^A-Za-z0-9_\-]+", "_", os.path.splitext(os.path.basename(path))[0])[:40] or "PDF"
        name = f"{base}_p{opt['page'] + 1}"; k = 1
        while name in c.doc.blocks:
            k += 1; name = f"{base}_p{opt['page'] + 1}_{k}"
        c.doc.add_block(E.Block(name, np.asarray(p, float), ents))
        ins = E.Insert(name, np.eye(4)); ins.layer = c.doc.cur_layer
        c.doc.add_keep(ins)
        c.msg(f"PDF page {opt['page'] + 1}: {len(ents):,} object(s) imported as block {name}  (EXPLODE to edit the single objects)")
        c.view.zoom_extents([ins])
        return
    for e in ents:
        c.doc.add_keep(e)
    c.msg(f"PDF page {opt['page'] + 1}: {len(ents):,} object(s) imported")
    c.view.zoom_extents(ents)


def run_pdf_import(app, path, opt, p):
    """Reads the PDF in a background thread with a progress window, so the program keeps responding (Cancel stops it)."""
    import threading, time
    from PySide6.QtWidgets import QProgressDialog, QApplication
    from PySide6.QtCore import Qt
    from ..core import pdfimport as PI
    state = {"f": 0.0, "msg": "Opening the PDF ...", "res": None, "cancel": False}
    def work():
        try:
            state["res"] = PI.import_pdf(path, opt["page"], opt["scale"], p, opt["vectors"], opt["texts"], opt["fills"], opt["images"],
                                         opt["raster"], opt.get("dpi", 200), join=opt.get("join", True), progress=lambda f, m: state.update(f=f, msg=m),
                                         cancel=lambda: state["cancel"])
        except KeyboardInterrupt:
            state["res"] = None
        except Exception as ex:                      # noqa - reported to the user
            state["res"] = ex
    th = threading.Thread(target=work, daemon=True); th.start()
    dlg = QProgressDialog("Importing PDF ...", "Cancel", 0, 1000, app); dlg.setWindowTitle("PDF import")
    dlg.setWindowModality(Qt.WindowModal); dlg.setMinimumDuration(400); dlg.setAutoClose(False); dlg.setAutoReset(False)
    while th.is_alive():
        dlg.setValue(int(state["f"] * 1000)); dlg.setLabelText(state["msg"])
        if dlg.wasCanceled():
            state["cancel"] = True
        QApplication.processEvents(); time.sleep(0.03)
    dlg.setValue(1000); dlg.close()
    return None if state["cancel"] else state["res"]


def cmd_csvimport(c, path=None):
    path = path or c.app.ask_open("Import points from CSV / Excel / TXT", "Tables (*.csv *.txt *.xlsx *.xls);;All files (*)")
    if not path:
        return
    rows = []
    if path.lower().endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        for r in wb.active.iter_rows(values_only=True):
            rows.append(r)
    else:
        import csv
        txt = open(path, encoding="utf-8", errors="ignore").read()
        delim = ";" if txt.count(";") > txt.count(",") else ("\t" if "\t" in txt else ",")
        rows = list(csv.reader(txt.splitlines(), delimiter=delim))
    pts = []
    for r in rows:
        nums = []
        for v in r:
            try:
                nums.append(float(str(v).replace(",", ".")) if not isinstance(v, (int, float)) else float(v))
            except (ValueError, TypeError):
                pass
        if len(nums) >= 2:
            pts.append(nums[:3] + [0.0] * (3 - len(nums[:3])))
    if not pts:
        c.msg("No numeric x,y(,z) rows found"); return
    mode = yield c.opt(f"{len(pts)} points read. Create [Points/Polyline/Spline] <Polyline>", ["Points", "Polyline", "Spline"], "Polyline")
    P = c.ucs.to_world(np.array(pts))
    if mode == "Points":
        for q in P:
            c.add(E.PointE(q))
    elif mode == "Spline":
        c.add(E.Spline.through(P))
    else:
        planar = np.ptp(np.array(pts)[:, 2]) < 1e-9
        c.add(E.Polyline(P, False, None, c.ucs.z, is3d=not planar))


def register(eng):
    R = eng.register
    R("CAMCUT", cmd_camcut, ["CAM", "GCODE"], "CNC cutting G-code (plasma / oxy / laser)")
    R("NEST", cmd_nest, [], "Rectangular nesting of parts on plates")
    R("IMAGEATTACH", cmd_image, ["IMAGE", "IAT"], "Attach raster image (JPG / PNG / BMP / TIF) as underlay")
    R("CALIBRATE", cmd_calibrate, ["CALIB", "IMAGESCALE"], "Scale image / objects by a known distance")
    R("DESKEW", cmd_deskew, [], "Straighten a skewed scan")
    R("IMAGEFADEOLD", cmd_imagefade, [], "Fade a raster image (command line)")
    R("AUTOTRACE", cmd_autotrace, ["TRACE", "VECTORIZE"], "Raster to vector (centre-line tracing)")
    R("PDFIMPORT", cmd_pdfimport, ["PDFI"], "Import PDF vectors / text / images")
    R("CSVIMPORT", cmd_csvimport, ["PTIMPORT"], "Import points from CSV / Excel (offset tables)")
