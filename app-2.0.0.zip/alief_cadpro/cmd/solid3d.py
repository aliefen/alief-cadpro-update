"""3D solid and surface commands."""
import math
import numpy as np
from ..core import entities as E, solids as S
from ..core.geom import unit, norm, Plane, v3, prims_tess


def _layer(c, b):
    return b


def _base_plane(c, p):
    pl = c.ucs.copy(); pl.o = v3(p); return pl


def _height_preview(c, base_pl, make):
    def pv(q):
        h = np.dot(q - base_pl.o, base_pl.z)
        try:
            return [make(h)] if abs(h) > 1e-9 else []
        except Exception:
            return []
    return pv


def _height_req(c, prompt, pl, make):
    h = yield c.dist(prompt, base=pl.o, preview=_height_preview(c, pl, make))
    return h


def _h_from(c, h, pl):
    return h


def _get_height(c, pl, make):
    q = yield c.pt("Specify height (point or value)", base=pl.o, preview=_height_preview(c, pl, make))
    if q is None:
        return None
    if isinstance(q, (int, float)):
        return float(q)
    return float(np.dot(q - pl.o, pl.z))


def cmd_box(c):
    a = yield c.pt("BOX  Specify first corner")
    if a is None:
        return
    pl = c.ucs
    def foot(q):
        A, B = pl.to_local(a), pl.to_local(q)
        return [E.Polyline(pl.to_world(np.array([A, [B[0], A[1], A[2]], [B[0], B[1], A[2]], [A[0], B[1], A[2]]])), True, None, pl.z)]
    b = yield c.corner("Specify other corner or @length,width", a, preview=foot)
    if b is None:
        return
    A, B = pl.to_local(a), pl.to_local(b)
    bp = _base_plane(c, pl.o)
    mk = lambda h: S.box(pl, A[0], A[1], B[0], B[1], A[2], A[2] + h)
    h = yield c.height("Specify height", a, preview=lambda q: [mk(float(np.dot(q - a, pl.z)))] if abs(np.dot(q - a, pl.z)) > 1e-9 else [])
    if h is None:
        return
    h = float(h) if isinstance(h, (int, float)) else float(np.dot(h - a, pl.z))
    c.add(mk(h))


def _round_solid(c, name, make, ask_top=False):
    p = yield c.pt(f"{name}  Specify center point of base")
    if p is None:
        return
    pl = _base_plane(c, p)
    r = yield c.dist("Specify base radius", base=p, preview=lambda q: [E.Circle(p, norm(q - p), pl.z)])
    if not isinstance(r, float) or r <= 0:
        return
    rt = None
    if ask_top:
        rt = yield c.dist("Specify top radius <0>", default=0.0)
    h = yield c.height("Specify height", p, preview=lambda q: [make(pl, r, float(np.dot(q - p, pl.z)), rt)] if abs(np.dot(q - p, pl.z)) > 1e-9 else [])
    if h is None:
        return
    h = float(h) if isinstance(h, (int, float)) else float(np.dot(h - p, pl.z))
    c.add(make(pl, r, h, rt))


def cmd_cylinder(c):
    yield from _round_solid(c, "CYLINDER", lambda pl, r, h, rt: S.cylinder(pl, r, h))


def cmd_cone(c):
    yield from _round_solid(c, "CONE", lambda pl, r, h, rt: S.cylinder(pl, r, h, rt or 0.0), True)


def cmd_sphere(c):
    p = yield c.pt("SPHERE  Specify center point")
    if p is None:
        return
    r = yield c.dist("Specify radius", base=p, preview=lambda q: [E.Circle(p, norm(q - p), c.view.cam.back())])
    if isinstance(r, float) and r > 0:
        c.add(S.sphere(p, r))


def cmd_torus(c):
    p = yield c.pt("TORUS  Specify center point")
    if p is None:
        return
    pl = _base_plane(c, p)
    R = yield c.dist("Specify torus radius", base=p, preview=lambda q: [E.Circle(p, norm(q - p), pl.z)])
    r = yield c.dist("Specify tube radius")
    if isinstance(R, float) and isinstance(r, float):
        c.add(S.torus(pl, R, r))


def cmd_wedge(c):
    a = yield c.pt("WEDGE  Specify first corner")
    b = yield c.corner("Specify other corner", a)
    if a is None or b is None:
        return
    pl = _base_plane(c, a); d = pl.to_local(b)
    h = yield c.dist("Specify height")
    if isinstance(h, float):
        c.add(S.wedge(pl, d[0], d[1], h))


def cmd_pyramid(c):
    n = yield c.num("PYRAMID  Number of sides <4>", 4)
    p = yield c.pt("Specify center point of base")
    if p is None:
        return
    pl = _base_plane(c, p)
    r = yield c.dist("Specify base radius (circumscribed)", base=p)
    h = yield c.dist("Specify height")
    if isinstance(r, float) and isinstance(h, float):
        c.add(S.pyramid(pl, r, h, int(n or 4), 0.0, math.pi / int(n or 4)))


def cmd_extrude(c):
    ents = yield c.sel("EXTRUDE  Select closed curves (solid) or open curves (surface)", filt=lambda e: e.is_curve or e.kind == "body")
    if not ents:
        return
    closed = [e for e in ents if getattr(e, "closed", False)]
    opened = [e for e in ents if e.is_curve and not getattr(e, "closed", False)]
    groups = S.regions_from_curves(closed, c.ucs) if closed else []
    nrm = groups[0][0].z if groups else (opened[0].plane().z if opened and opened[0].plane() is not None else c.ucs.z)
    o = groups[0][0].o if groups else (opened[0].prims()[0][1] if opened else np.zeros(3))
    def mk(h):
        out = []
        for pl, loops in groups:
            try:
                out.append(S.extrude_region(pl, loops, 0, h))
            except Exception:
                pass
        for e in opened:
            out.append(S.extrude_surface(prims_tess(e.prims()) if e.kind not in ("spline", "ellipse") else e.pts(), nrm * h))
        return out
    q = yield c.height("Specify height of extrusion or [Direction]", o, options=["Direction"],
                   preview=lambda q: mk(float(np.dot(q - o, nrm))) if abs(np.dot(q - o, nrm)) > 1e-9 else [])
    if q is None:
        return
    if q == "Direction":
        a = yield c.pt("Specify start point of direction"); b = yield c.pt("Specify end point of direction", base=a)
        d = b - a
        for pl, loops in groups:
            P = [pl.to_world(l) for l in loops]
            c.add(S.extrude_surface(P[0], d)) if False else None
        # oblique extrusion: sweep along straight path
        for pl, loops in groups:
            body = S.extrude_region(pl, loops, 0, float(np.dot(d, pl.z)))
            c.add(body)
        return
    h = float(q) if isinstance(q, (int, float)) else float(np.dot(q - o, nrm))
    for b in mk(h):
        c.add(b)
    keep = c.app.view.opt.get("delobj", True)
    if keep:
        for e in closed + opened:
            c.doc.remove(e)


def cmd_revolve(c):
    ents = yield c.sel("REVOLVE  Select profiles (closed = solid, open = surface)", filt=lambda e: e.is_curve)
    if not ents:
        return
    a = yield c.pt("Specify axis start point or [X/Y/Z]", options=["X", "Y", "Z"])
    if a in ("X", "Y", "Z"):
        d = {"X": c.ucs.x, "Y": c.ucs.y, "Z": c.ucs.z}[a]; a = c.ucs.o
    else:
        b = yield c.pt("Specify axis end point", base=a); d = b - a
    ang = yield c.num("Specify angle of revolution <360>", 360.0)
    ang = float(ang or 360.0)
    for e in ents:
        if getattr(e, "closed", False):
            for pl, loops in S.regions_from_curves([e]):
                try:
                    c.add(S.revolve_region(pl, loops, a, d, ang))
                except Exception as ex:
                    c.msg(f"Revolve failed: {ex}")
        else:
            P = S.curve_points(e)
            c.add(S.revolve_surface(P, a, d, ang))
        c.doc.remove(e)


def cmd_sweep(c):
    prof = yield c.sel("SWEEP  Select profile(s) to sweep", filt=lambda e: e.is_curve)
    if not prof:
        return
    s = yield c.ent("Select sweep path", filt=lambda e: e.is_curve)
    if s is None:
        return
    path = s[0]
    P = S.curve_points(path)
    for e in prof:
        if getattr(e, "closed", False):
            groups = S.regions_from_curves([e])
            for pl, loops in groups:
                # move the section to the path start, normal along the path tangent
                t0 = unit(P[1] - P[0]); cen = pl.to_world(np.mean(loops[0], axis=0))
                lp = [np.asarray(l) - np.mean(loops[0], axis=0) for l in loops]
                up = pl.y if abs(np.dot(pl.y, t0)) < 0.95 else pl.x
                ss = [np.stack([l[:, 0], l[:, 1]], axis=1) for l in lp]
                try:
                    c.add(S.sweep_solid(ss, P, pl.y if abs(np.dot(pl.y, t0)) < 0.99 else pl.x, path.closed))
                except Exception as ex:
                    c.msg(f"Sweep failed: {ex}")
        else:
            c.add(S.sweep_surface(S.curve_points(e), P))
        c.doc.remove(e)


def cmd_loft(c):
    ents = yield c.sel("LOFT  Select cross sections in lofting order", filt=lambda e: e.is_curve)
    if not ents or len(ents) < 2:
        c.msg("Select at least two cross sections"); return
    ents = sorted(ents, key=lambda e: e.id) if False else ents
    if all(getattr(e, "closed", False) for e in ents):
        loops = [S.curve_loop_world(e) for e in ents]
        try:
            c.add(S.loft_solid(loops))
        except Exception as ex:
            c.msg(f"Loft failed: {ex}"); return
    else:
        c.add(S.loft_surface([S.curve_points(e) for e in ents]))
    for e in ents:
        c.doc.remove(e)


def _bool(c, op):
    is_solid = lambda e: e.kind == "body" and e.role in ("solid", "plate", "profile", "mesh", "pipe", "fitting", "equipment")
    if op == "union":
        A = yield c.sel("UNION  Select solids", filt=is_solid); B = []
        if not A or len(A) < 2:
            return
    else:
        A = yield c.sel(("SUBTRACT  Select solids to subtract FROM" if op == "subtract" else "INTERSECT  Select solids"), filt=is_solid)
        if not A:
            return
        if op == "subtract":
            B = yield c.sel("Select solids to SUBTRACT", filt=is_solid)
            if not B:
                return
        else:
            B = A[1:]; A = A[:1]
    try:
        if op == "union":
            outs = [(A[0], S.boolean(A[:1], A[1:], "union"))]
        elif op == "subtract":
            outs = [(a, S.boolean([a], B, "subtract")) for a in A]
        else:
            outs = [(A[0], S.boolean(A[:1], B, "intersect"))]
    except S.SolidError as ex:
        c.msg(f"{op.title()} failed: {ex}"); return
    for src, m in outs:
        if m.is_empty():
            c.msg("Result is empty"); continue
        b = S.from_manifold(m, src.role, dict(src.meta))
        b.layer, b.color = src.layer, src.color
        c.doc.add_keep(b)
    for e in set(A) | set(B):
        c.doc.remove(e)


def cmd_union(c):
    yield from _bool(c, "union")


def cmd_subtract(c):
    yield from _bool(c, "subtract")


def cmd_intersect(c):
    yield from _bool(c, "intersect")


def cmd_slice(c):
    ents = yield c.sel("SLICE  Select solids to slice", filt=lambda e: e.kind == "body" and e.role != "surface")
    if not ents:
        return
    o = yield c.opt("Slicing plane [3points/XY/YZ/ZX] <3points>", ["3points", "XY", "YZ", "ZX"], "3points")
    if o == "3points":
        a = yield c.pt("Specify first point on plane"); b = yield c.pt("Specify second point", base=a); q = yield c.pt("Specify third point", base=b)
        if None in (a, b, q):
            return
        n = unit(np.cross(b - a, q - a)); p = a
    else:
        p = yield c.pt("Specify a point on the plane")
        n = {"XY": c.ucs.z, "YZ": c.ucs.x, "ZX": c.ucs.y}[o]
    keep = yield c.opt("Keep [Both/Positive/Negative] <Both>", ["Both", "Positive", "Negative"], "Both")
    for e in ents:
        try:
            parts = S.slice_body(e, p, n)
        except S.SolidError as ex:
            c.msg(str(ex)); continue
        c.doc.remove(e)
        for k, part in enumerate(parts):
            ctr = part.centroid()
            side = np.dot(ctr - p, n) > 0
            if keep == "Both" or (keep == "Positive" and side) or (keep == "Negative" and not side):
                part.layer, part.color = e.layer, e.color; c.doc.add_keep(part)


def cmd_thicken(c):
    ents = yield c.sel("THICKEN  Select surfaces", filt=lambda e: e.kind == "body" and e.role == "surface")
    if not ents:
        return
    t = yield c.dist("Specify thickness <10>", default=10.0)
    for e in ents:
        try:
            b = S.thicken(e.V, e.F, float(t)); b.layer = e.layer; c.doc.add_keep(b); c.doc.remove(e)
        except S.SolidError as ex:
            c.msg(f"Thicken failed: {ex}")


def cmd_planesurf(c):
    o = yield c.pt("PLANESURF  Specify first corner or [Object]", options=["Object"])
    if o == "Object":
        ents = yield c.sel("Select closed planar curves", filt=lambda e: getattr(e, "closed", False))
        for pl, loops in S.regions_from_curves(ents or [], c.ucs):
            c.add(S.planar_surface(pl, loops))
        return
    if o is None:
        return
    pl = c.ucs
    def mk(q):
        A, B = pl.to_local(o), pl.to_local(q)
        loop = np.array([[A[0], A[1]], [B[0], A[1]], [B[0], B[1]], [A[0], B[1]]])
        p2 = pl.copy(); p2.o = pl.to_world(np.array([0, 0, A[2]]))
        return S.planar_surface(p2, [loop])
    q = yield c.corner("Specify other corner", o, preview=lambda q: [mk(q)])
    if q is not None:
        c.add(mk(q))


def cmd_edgesurf(c):
    cur = []
    for k in range(4):
        s = yield c.ent(f"EDGESURF  Select edge {k + 1} of 4", filt=lambda e: e.is_curve and not e.closed)
        if s is None:
            return
        cur.append(S.curve_points(s[0]))
    try:
        c.add(S.coons_surface(*cur))
    except Exception as ex:
        c.msg(f"Edges must form a closed loop ({ex})")


def cmd_rulesurf(c):
    a = yield c.ent("RULESURF  Select first defining curve", filt=lambda e: e.is_curve)
    b = yield c.ent("Select second defining curve", filt=lambda e: e.is_curve)
    if a and b:
        c.add(S.ruled_surface(S.curve_points(a[0]), S.curve_points(b[0])))


def cmd_loftsurf(c):
    ents = yield c.sel("LOFTSURF  Select curves in order", filt=lambda e: e.is_curve)
    if ents and len(ents) >= 2:
        c.add(S.loft_surface([S.curve_points(e) for e in ents]))


def cmd_sweepsurf(c):
    a = yield c.ent("SWEEPSURF  Select profile curve", filt=lambda e: e.is_curve)
    b = yield c.ent("Select path curve", filt=lambda e: e.is_curve)
    if a and b:
        c.add(S.sweep_surface(S.curve_points(a[0]), S.curve_points(b[0])))


def cmd_revsurf(c):
    a = yield c.ent("REVSURF  Select curve to revolve", filt=lambda e: e.is_curve)
    if a is None:
        return
    p = yield c.pt("Specify axis start point"); q = yield c.pt("Specify axis end point", base=p)
    ang = yield c.num("Angle <360>", 360.0)
    if p is not None and q is not None:
        c.add(S.revolve_surface(S.curve_points(a[0]), p, q - p, float(ang or 360)))


def cmd_extsurf(c):
    a = yield c.ent("EXTRUDESURF  Select curve", filt=lambda e: e.is_curve)
    if a is None:
        return
    p = yield c.pt("Specify direction start"); q = yield c.pt("Specify direction end", base=p,
                                                           preview=lambda q: [S.extrude_surface(S.curve_points(a[0]), q - p)])
    if p is not None and q is not None:
        c.add(S.extrude_surface(S.curve_points(a[0]), q - p))


def register(eng):
    R = eng.register
    R("BOX", cmd_box, [], "Solid box"); R("CYLINDER", cmd_cylinder, ["CYL"], "Solid cylinder"); R("CONE", cmd_cone, [], "Solid cone / frustum")
    R("SPHERE", cmd_sphere, [], "Solid sphere"); R("TORUS", cmd_torus, ["TOR"], "Solid torus"); R("WEDGE", cmd_wedge, ["WE"], "Solid wedge")
    R("PYRAMID", cmd_pyramid, ["PYR"], "Solid pyramid")
    R("EXTRUDE", cmd_extrude, ["EXT"], "Extrude curves into solids / surfaces")
    R("REVOLVE", cmd_revolve, ["REV"], "Revolve curves about an axis")
    R("SWEEP", cmd_sweep, [], "Sweep a profile along a path")
    R("LOFT", cmd_loft, [], "Loft through cross sections")
    R("UNION", cmd_union, ["UNI"], "Boolean union"); R("SUBTRACT", cmd_subtract, ["SU"], "Boolean subtract"); R("INTERSECT", cmd_intersect, ["IN"], "Boolean intersect")
    R("SLICE", cmd_slice, ["SL"], "Slice solids with a plane"); R("THICKEN", cmd_thicken, [], "Thicken surfaces into solids")
    R("PLANESURF", cmd_planesurf, [], "Planar surface"); R("EDGESURF", cmd_edgesurf, [], "Surface from 4 edges (Coons)")
    R("RULESURF", cmd_rulesurf, [], "Ruled surface between 2 curves"); R("LOFTSURF", cmd_loftsurf, [], "Loft surface")
    R("SWEEPSURF", cmd_sweepsurf, [], "Sweep surface"); R("REVSURF", cmd_revsurf, [], "Revolved surface"); R("EXTRUDESURF", cmd_extsurf, [], "Extruded surface")
