"""Surface commands with the names, prompts and options of Rhinoceros 8 (Surface menu):
Plane, SrfPt, EdgeSrf, PlanarSrf, ExtrudeCrv, ExtrudeCrvAlongCrv, ExtrudeCrvToPoint, Loft, Sweep1, Sweep2, Revolve,
RailRevolve, NetworkSrf, Patch, OffsetSrf, Flip, DupBorder, Section, Contour."""
import math
import numpy as np
from ..core import entities as E, solids as S
from ..core.geom import unit, norm, Plane, v3

is_crv = lambda e: getattr(e, "is_curve", False)
is_open = lambda e: is_crv(e) and not getattr(e, "closed", False)
is_srf = lambda e: e.kind == "body" and e.role == "surface"
is_body = lambda e: e.kind == "body"


def _pts(e, n=None):
    return S.curve_points(e, n)


def _out(c, b, src=None):
    """Add the new surface on the current layer; delete the input curves only when DELOBJ asks for it (Rhino keeps them)."""
    r = c.add(b)
    return r


def _cyc(c, prompt, st, spec):
    """Rhino-style option line: spec = {OptionName: [values]}; clicking / typing an option cycles it. Enter accepts."""
    while True:
        txt = "  ".join(f"{k}={st[k]}" for k in spec)
        o = yield c.opt(f"{prompt} ( {txt} ) [" + "/".join(spec) + "] <Enter = accept>", list(spec))
        if o is None:
            return
        vals = spec[o]; st[o] = vals[(vals.index(st[o]) + 1) % len(vals)]


# ------------------------------------------------------------------------------------------------ Plane / SrfPt
def cmd_plane(c):
    o = yield c.pt("Plane  First corner of plane [3Point/Vertical/Center]", options=["3Point", "Vertical", "Center"])
    if o is None:
        return
    pl = c.ucs
    if o == "3Point":
        a = yield c.pt("Start of edge")
        b = yield c.pt("End of edge", base=a, preview=lambda q: [E.Line(a, q)])
        def mk3(q):
            x = unit(b - a); w = q - a; y = w - np.dot(w, x) * x
            return S.srf_pt([a, b, b + y, a + y])
        q = yield c.pt("Width. Press Enter to use length", base=b, preview=lambda q: [mk3(q)])
        if a is not None and b is not None and q is not None:
            _out(c, mk3(q))
        return
    if o == "Vertical":
        a = yield c.pt("Start of edge")
        b = yield c.pt("End of edge", base=a, preview=lambda q: [E.Line(a, q)])
        mk = lambda h: S.srf_pt([a, b, b + pl.z * h, a + pl.z * h])
        h = yield c.height("Height. Press Enter to use width", b, preview=lambda q: [mk(float(np.dot(q - b, pl.z)) or 1.0)])
        if h is None:
            h = norm(b - a)
        elif not isinstance(h, (int, float)):
            h = float(np.dot(h - b, pl.z))
        if abs(h) > 1e-9:
            _out(c, mk(float(h)))
        return
    center = o == "Center"
    if center:
        o = yield c.pt("Center of plane")
        if o is None:
            return
    def mk(q):
        A, B = pl.to_local(o), pl.to_local(q)
        if center:
            A = 2 * A - B
        z = pl.to_local(o)[2]
        return S.srf_pt([pl.to_world(np.array(v)) for v in ((A[0], A[1], z), (B[0], A[1], z), (B[0], B[1], z), (A[0], B[1], z))])
    q = yield c.corner("Other corner or length", o, preview=lambda q: [mk(q)])
    if q is not None:
        _out(c, mk(q))


def cmd_srfpt(c):
    pts = []
    names = ["First corner of surface", "Second corner of surface", "Third corner of surface", "Fourth corner of surface. Press Enter for 3 points"]
    for k in range(4):
        def pv(q, k=k):
            P = pts + [q]
            if len(P) == 2:
                return [E.Line(P[0], P[1])]
            return [S.srf_pt(P)] if len(P) >= 3 else []
        p = yield c.pt("SrfPt  " + names[k], base=pts[-1] if pts else None, preview=pv)
        if p is None:
            break
        pts.append(p)
    if len(pts) >= 3:
        _out(c, S.srf_pt(pts))


# ------------------------------------------------------------------------------------------------ edges / planar
def cmd_edgesrf(c):
    ents = yield c.sel("EdgeSrf  Select 2, 3, or 4 open curves", filt=is_open)
    if not ents:
        return
    if not 2 <= len(ents) <= 4:
        c.msg("EdgeSrf needs 2, 3 or 4 open curves"); return
    try:
        _out(c, S.edge_surface([_pts(e) for e in ents]))
    except Exception as ex:
        c.msg(f"EdgeSrf failed: {ex}")


def cmd_planarsrf(c):
    ents = yield c.sel("PlanarSrf  Select planar curves to build surface", filt=is_crv)
    if not ents:
        return
    closed = [e for e in ents if getattr(e, "closed", False)]
    opened = [e for e in ents if not getattr(e, "closed", False)]
    n = 0
    if opened:                                          # open curves that join into a closed planar loop
        try:
            loop = S.chain_loop([_pts(e) for e in opened])
            r = S.plane_of_points(loop)
            if r is not None and norm(loop[0] - loop[-1]) < 0.05 * (np.ptp(loop, axis=0).max() + 1e-9) and r[2] < 1e-4:
                pl = Plane.from_normal(r[0], r[1]); _out(c, S.planar_surface(pl, [pl.to_local(loop)[:, :2]])); n += 1
        except Exception:
            pass
    for pl, loops in S.regions_from_curves(closed, c.ucs) if closed else []:
        try:
            _out(c, S.planar_surface(pl, loops)); n += 1
        except Exception as ex:
            c.msg(f"PlanarSrf failed: {ex}")
    c.msg(f"{n} planar surface(s) created" if n else "The curves must be closed and planar")


# ------------------------------------------------------------------------------------------------ extrude
def cmd_extrudecrv(c):
    ents = yield c.sel("ExtrudeCrv  Select curves to extrude", filt=is_crv)
    if not ents:
        return
    st = {"dir": None, "both": False, "solid": False}
    pl0 = ents[0].plane() if hasattr(ents[0], "plane") else None
    nrm = pl0.z if pl0 is not None and getattr(ents[0], "closed", False) else c.ucs.z
    o = _pts(ents[0])[0]
    def mk(h):
        d = (st["dir"] if st["dir"] is not None else nrm) * h
        out = []
        for e in ents:
            P = _pts(e)
            if st["both"]:
                P = P - d
            dd = d * (2 if st["both"] else 1)
            if st["solid"] and getattr(e, "closed", False):
                try:
                    for pl, loops in S.regions_from_curves([e], c.ucs):
                        hh = float(np.dot(dd, pl.z)); z0 = -hh / 2 if st["both"] else 0.0
                        out.append(S.extrude_region(pl, loops, z0, z0 + hh)); continue
                    continue
                except Exception:
                    pass
            if getattr(e, "closed", False) and norm(P[0] - P[-1]) > 1e-9:
                P = np.vstack([P, P[:1]])
            out.append(S.extrude_surface(P, dd))
        return out
    while True:
        dv = st["dir"] if st["dir"] is not None else nrm
        q = yield c.height(f"Extrusion distance ( BothSides={'Yes' if st['both'] else 'No'}  Solid={'Yes' if st['solid'] else 'No'} ) "
                           "[Direction/BothSides/Solid]", o, options=["Direction", "BothSides", "Solid"],
                           preview=lambda q, dv=dv: mk(float(np.dot(q - o, dv))) if abs(np.dot(q - o, dv)) > 1e-9 else [])
        if q is None:
            return
        if q == "Direction":
            a = yield c.pt("Base point of direction"); b = yield c.pt("Second direction point", base=a, preview=lambda q: [E.Line(a, q)])
            if a is not None and b is not None and norm(b - a) > 1e-9:
                st["dir"] = unit(b - a)
            continue
        if q == "BothSides":
            st["both"] = not st["both"]; continue
        if q == "Solid":
            st["solid"] = not st["solid"]; continue
        h = float(q) if isinstance(q, (int, float)) else float(np.dot(q - o, dv))
        if abs(h) < 1e-9:
            return
        for b in mk(h):
            _out(c, b)
        return


def cmd_extrudecrvalongcrv(c):
    ents = yield c.sel("ExtrudeCrvAlongCrv  Select curves to extrude", filt=is_crv)
    if not ents:
        return
    s = yield c.ent("Select path curve near its start", filt=is_crv)
    if s is None:
        return
    Q = _pts(s[0])
    if s[1] is not None and norm(Q[-1] - s[1]) < norm(Q[0] - s[1]):
        Q = Q[::-1]
    for e in ents:
        P = _pts(e)
        if getattr(e, "closed", False) and norm(P[0] - P[-1]) > 1e-9:
            P = np.vstack([P, P[:1]])
        _out(c, S.extrude_along(P, Q))


def cmd_extrudecrvtopoint(c):
    ents = yield c.sel("ExtrudeCrvToPoint  Select curves to extrude", filt=is_crv)
    if not ents:
        return
    def mk(q):
        out = []
        for e in ents:
            P = _pts(e)
            if getattr(e, "closed", False) and norm(P[0] - P[-1]) > 1e-9:
                P = np.vstack([P, P[:1]])
            out.append(S.extrude_to_point(P, q))
        return out
    q = yield c.pt("Point to extrude to", base=_pts(ents[0])[0], preview=mk)
    if q is not None:
        for b in mk(q):
            _out(c, b)


# ------------------------------------------------------------------------------------------------ loft / sweeps / revolve
def cmd_loft(c):
    ents = yield c.sel("Loft  Select curves to loft", filt=is_crv)
    if not ents or len(ents) < 2:
        c.msg("Select at least two curves to loft"); return
    st = {"Style": "Normal", "Closed": "No", "Solid": "Yes" if all(getattr(e, "closed", False) for e in ents) else "No", "Order": "Auto"}
    spec = {"Style": ["Normal", "Straight"], "Closed": ["No", "Yes"], "Order": ["Auto", "AsSelected"]}
    if all(getattr(e, "closed", False) for e in ents):
        spec["Solid"] = ["Yes", "No"]
    yield from _cyc(c, "Loft options", st, spec)
    cur = [_pts(e) for e in ents]
    try:
        if st.get("Solid") == "Yes" and "Solid" in spec:
            loops = [S.curve_loop_world(e) for e in ents]
            if st["Order"] == "Auto":
                loops = [loops[i] for i in S.sort_sections(loops)]
            _out(c, S.loft_solid(loops))
        else:
            cur = [np.vstack([p, p[:1]]) if getattr(e, "closed", False) and norm(p[0] - p[-1]) > 1e-9 else p for p, e in zip(cur, ents)]
            _out(c, S.loft_surface_ex(cur, st["Style"], st["Closed"] == "Yes", sort=st["Order"] == "Auto"))
    except Exception as ex:
        c.msg(f"Loft failed: {ex}")


def cmd_sweep1(c):
    s = yield c.ent("Sweep1  Select rail", filt=is_crv)
    if s is None:
        return
    ents = yield c.sel("Select cross section curves", filt=lambda e: is_crv(e) and e is not s[0])
    if not ents:
        return
    rail = _pts(s[0])
    try:
        if len(ents) == 1:
            e = ents[0]; P = _pts(e)
            if norm(rail[-1] - P.mean(axis=0)) < norm(rail[0] - P.mean(axis=0)):
                rail = rail[::-1]
            if getattr(e, "closed", False) and norm(P[0] - P[-1]) > 1e-9:
                P = np.vstack([P, P[:1]])
            _out(c, S.sweep_surface(P, rail))
        else:
            # several sections: sweep each along the rail and blend between them along the rail
            n = 40; secs = []
            for e in ents:
                P = S.resample_open(_pts(e), n)
                i = int(np.argmin(np.linalg.norm(rail - P.mean(axis=0), axis=1)))
                secs.append((i, P))
            secs.sort(key=lambda t: t[0])
            for k in range(1, len(secs)):
                A, B = secs[k - 1][1], secs[k][1]
                if norm(A[0] - B[0]) + norm(A[-1] - B[-1]) > norm(A[0] - B[-1]) + norm(A[-1] - B[0]):
                    secs[k] = (secs[k][0], B[::-1])
            R = S.resample_open(rail, 64)
            G = _sweep1_multi(R, secs, n)
            _out(c, S.grid_surface(G))
    except Exception as ex:
        c.msg(f"Sweep1 failed: {ex}")


def _sweep1_multi(R, secs, n):
    """Sections placed along rail R (index, points): each is carried by the rail frames, then blended linearly."""
    r = S.plane_of_points(secs[0][1])
    t0 = unit(R[1] - R[0])
    up = r[1] if r is not None and abs(np.dot(r[1], t0)) < 0.9 else np.array([0, 0, 1.0])
    fr = S._frames(R, up)
    def frame(j):
        a = fr[max(j - 1, 0)]; b = fr[min(j, len(fr) - 1)]
        return unit(a[0] + b[0]), unit(a[1] + b[1]), unit(a[2] + b[2])
    carried = []
    for i, P in secs:
        i = int(np.argmin(np.linalg.norm(R - P.mean(axis=0), axis=1)))
        t, s, w = frame(i)
        loc = np.stack([(P - R[i]) @ s, (P - R[i]) @ w, (P - R[i]) @ t], axis=1)
        carried.append((i, loc))
    carried.sort(key=lambda q: q[0])
    G = []
    for j in range(len(R)):
        t, s, w = frame(j)
        if j <= carried[0][0]:
            loc = carried[0][1]
        elif j >= carried[-1][0]:
            loc = carried[-1][1]
        else:
            k = max(q for q in range(len(carried)) if carried[q][0] <= j); k = min(k, len(carried) - 2)
            i0, i1 = carried[k][0], carried[k + 1][0]; f = (j - i0) / max(1, i1 - i0)
            loc = (1 - f) * carried[k][1] + f * carried[k + 1][1]
        G.append(R[j] + loc[:, :1] * s + loc[:, 1:2] * w + loc[:, 2:3] * t)
    return np.array(G)


def cmd_sweep2(c):
    a = yield c.ent("Sweep2  Select first rail", filt=is_crv)
    if a is None:
        return
    b = yield c.ent("Select second rail", filt=lambda e: is_crv(e) and e is not a[0])
    if b is None:
        return
    ents = yield c.sel("Select cross section curves", filt=lambda e: is_crv(e) and e is not a[0] and e is not b[0])
    if not ents:
        return
    try:
        _out(c, S.sweep2(_pts(a[0]), _pts(b[0]), [_pts(e) for e in ents]))
    except Exception as ex:
        c.msg(f"Sweep2 failed: {ex}")


def cmd_revolve(c):
    ents = yield c.sel("Revolve  Select curves to revolve", filt=is_crv)
    if not ents:
        return
    a = yield c.pt("Start of revolve axis [X/Y/Z]", options=["X", "Y", "Z"])
    if a is None:
        return
    if isinstance(a, str):
        b = c.ucs.o + {"X": c.ucs.x, "Y": c.ucs.y, "Z": c.ucs.z}[a]; a = c.ucs.o
    else:
        b = yield c.pt("End of revolve axis", base=a, preview=lambda q: [E.Line(a, q)])
    if b is None or norm(b - a) < 1e-9:
        return
    a0 = yield c.num("Start angle <0> [FullCircle]", 0.0, options=["FullCircle"])
    if a0 == "FullCircle":
        a0, a1 = 0.0, 360.0
    else:
        a1 = yield c.num("Revolution angle <360>", 360.0)
    a0 = float(a0 or 0.0); a1 = float(a1 or 360.0)
    from ..core.geom import m_rotate, xform_pt
    for e in ents:
        try:
            if getattr(e, "closed", False) and abs(abs(a1) - 360) < 1e-6:
                done = False
                for pl, loops in S.regions_from_curves([e]):
                    _out(c, S.revolve_region(pl, loops, a, b - a, a1)); done = True
                if done:
                    continue
            P = _pts(e)
            if abs(a0) > 1e-9:
                P = xform_pt(m_rotate(a, b - a, math.radians(a0)), P)
            _out(c, S.revolve_surface(P, a, b - a, a1))
        except Exception as ex:
            c.msg(f"Revolve failed: {ex}")


def cmd_railrevolve(c):
    st = {"ScaleHeight": "No"}
    p = yield c.ent("RailRevolve  Select profile curve [ScaleHeight]", filt=is_crv, options=["ScaleHeight"])
    if p == "ScaleHeight":
        st["ScaleHeight"] = "Yes"; p = yield c.ent("Select profile curve (ScaleHeight=Yes)", filt=is_crv)
    if p is None:
        return
    r = yield c.ent("Select rail curve", filt=lambda e: is_crv(e) and e is not p[0])
    if r is None:
        return
    a = yield c.pt("Start of RailRevolve axis")
    b = yield c.pt("End of RailRevolve axis", base=a, preview=lambda q: [E.Line(a, q)])
    if a is None or b is None or norm(b - a) < 1e-9:
        return
    try:
        R = _pts(r[0])
        if getattr(r[0], "closed", False) and norm(R[0] - R[-1]) > 1e-9:
            R = np.vstack([R, R[:1]])
        _out(c, S.rail_revolve(_pts(p[0]), R, a, b - a, scale_height=st["ScaleHeight"] == "Yes"))
    except Exception as ex:
        c.msg(f"RailRevolve failed: {ex}")


# ------------------------------------------------------------------------------------------------ network / patch
def cmd_networksrf(c):
    ents = yield c.sel("NetworkSrf  Select curves in network", filt=is_open)
    if not ents:
        return
    try:
        _out(c, S.network_surface([_pts(e) for e in ents]))
    except Exception as ex:
        c.msg(f"NetworkSrf failed: {ex}")


def cmd_patch(c):
    ents = yield c.sel("Patch  Select curves and points to fit surface through", filt=lambda e: is_crv(e) or e.kind == "point")
    if not ents:
        return
    cur = [e for e in ents if is_crv(e)]; inner = [e.p for e in ents if e.kind == "point"]
    closed = [e for e in cur if getattr(e, "closed", False)]
    try:
        if closed:
            loop = _pts(closed[0]); extra = [x for x in cur if x is not closed[0]]
        else:
            loop = S.chain_loop([_pts(e) for e in cur]); extra = []
        for e in extra:                     # other curves inside the boundary pull the surface
            inner += list(S.resample_open(_pts(e), 12))
        _out(c, S.patch_surface(loop, inner=inner))
    except Exception as ex:
        c.msg(f"Patch failed: {ex}")


# ------------------------------------------------------------------------------------------------ offset / edit / curves from surfaces
def cmd_offsetsrf(c):
    ents = yield c.sel("OffsetSrf  Select surfaces or polysurfaces to offset", filt=is_srf)
    if not ents:
        return
    st = {"flip": False, "solid": False, "both": False}
    while True:
        d = yield c.dist(f"Offset distance <10> ( FlipAll={'Yes' if st['flip'] else 'No'}  Solid={'Yes' if st['solid'] else 'No'}  BothSides={'Yes' if st['both'] else 'No'} ) "
                         "[FlipAll/Solid/BothSides]", default=10.0, options=["FlipAll", "Solid", "BothSides"])
        if d == "FlipAll":
            st["flip"] = not st["flip"]; continue
        if d == "Solid":
            st["solid"] = not st["solid"]; continue
        if d == "BothSides":
            st["both"] = not st["both"]; continue
        break
    if d is None:
        return
    d = float(d) * (-1 if st["flip"] else 1)
    for e in ents:
        try:
            if st["solid"]:
                b = S.thicken(e.V, e.F, d, both=st["both"]); b.layer = e.layer; c.doc.add_keep(b)
            else:
                b = S.offset_surface(e, d); b.layer = e.layer; c.doc.add_keep(b)
                if st["both"]:
                    b = S.offset_surface(e, -d); b.layer = e.layer; c.doc.add_keep(b)
        except Exception as ex:
            c.msg(f"OffsetSrf failed: {ex}")


def cmd_flip(c):
    ents = yield c.sel("Flip  Select objects to flip normal direction", filt=is_srf)
    for e in ents or []:
        c.doc.modify(e); S.flip_surface(e); e.touch()
    if ents:
        c.msg(f"{len(ents)} surface normal(s) flipped")


def _poly(P, closed=False):
    return E.Polyline(np.asarray(P, float), closed, None, (0, 0, 1), True)


def cmd_dupborder(c):
    ents = yield c.sel("DupBorder  Select surfaces, polysurfaces, or meshes", filt=is_body)
    n = 0
    for e in ents or []:
        for L in S.boundary_loops(e.V, e.F):
            closed = norm(L[0] - L[-1]) < 1e-9
            c.add(_poly(L[:-1] if closed else L, closed)); n += 1
    if ents:
        c.msg(f"{n} border curve(s) created" if n else "The objects have no naked edges (closed solids)")


def cmd_section(c):
    ents = yield c.sel("Section  Select objects for sections", filt=is_body)
    if not ents:
        return
    n = 0
    while True:
        a = yield c.pt("Start of section <done>")
        if a is None:
            break
        b = yield c.pt("End of section", base=a, preview=lambda q: [E.Line(a, q)])
        if b is None or norm(b - a) < 1e-9:
            break
        nrm = np.cross(b - a, c.ucs.z)              # cutting plane through the picked line, perpendicular to the work plane
        for e in ents:
            for L in S.mesh_section(e.V, e.F, a, nrm):
                closed = norm(L[0] - L[-1]) < 1e-9 and len(L) > 3
                c.add(_poly(L[:-1] if closed else L, closed)); n += 1
    c.msg(f"{n} section curve(s) created")


def cmd_contour(c):
    ents = yield c.sel("Contour  Select objects for contours", filt=is_body)
    if not ents:
        return
    a = yield c.pt("Contour plane base point")
    if a is None:
        return
    b = yield c.pt("Direction perpendicular to contour planes [X/Y/Z]", base=a, options=["X", "Y", "Z"], preview=lambda q: [E.Line(a, q)])
    if b is None:
        return
    d = {"X": c.ucs.x, "Y": c.ucs.y, "Z": c.ucs.z}[b] if isinstance(b, str) else unit(b - a)
    step = yield c.dist("Distance between contours <500>", default=500.0)
    step = abs(float(step or 500.0))
    if step < 1e-9:
        return
    allv = np.vstack([e.V for e in ents]); s = (allv - a) @ d
    k0, k1 = math.ceil(s.min() / step - 1e-9), math.floor(s.max() / step + 1e-9)
    if k1 - k0 > 2000:
        c.msg("Too many contours - use a larger distance"); return
    n = 0
    for k in range(k0, k1 + 1):
        p = a + d * (k * step)
        for e in ents:
            for L in S.mesh_section(e.V, e.F, p, d):
                closed = norm(L[0] - L[-1]) < 1e-9 and len(L) > 3
                c.add(_poly(L[:-1] if closed else L, closed)); n += 1
    c.msg(f"{n} contour curve(s) created ({k1 - k0 + 1} planes at {step:g})")


def register(eng):
    R = eng.register
    R("PLANE", cmd_plane, [], "Rhino Plane: rectangular planar surface (3Point / Vertical / Center)")
    R("SRFPT", cmd_srfpt, [], "Rhino SrfPt: surface from 3 or 4 corner points")
    R("EDGESRF", cmd_edgesrf, ["EDGESURF"], "Rhino EdgeSrf: surface from 2, 3 or 4 edge curves")
    R("PLANARSRF", cmd_planarsrf, ["PLANESURF"], "Rhino PlanarSrf: surface from planar closed curves")
    R("EXTRUDECRV", cmd_extrudecrv, ["EXTRUDESURF"], "Rhino ExtrudeCrv: extrude curves straight (Direction / BothSides / Solid)")
    R("EXTRUDECRVALONGCRV", cmd_extrudecrvalongcrv, [], "Rhino ExtrudeCrvAlongCrv: extrude curves along a path curve")
    R("EXTRUDECRVTOPOINT", cmd_extrudecrvtopoint, [], "Rhino ExtrudeCrvToPoint: extrude curves to a point")
    R("LOFT", cmd_loft, ["LOFTSURF"], "Rhino Loft: surface through section curves (Style / Closed / Solid)")
    R("SWEEP1", cmd_sweep1, ["SWEEPSURF"], "Rhino Sweep1: cross sections along one rail")
    R("SWEEP2", cmd_sweep2, [], "Rhino Sweep2: cross sections along two rails")
    R("RAILREVOLVE", cmd_railrevolve, [], "Rhino RailRevolve: revolve a profile following a rail curve")
    R("REVOLVE", cmd_revolve, ["REV", "REVSURF"], "Rhino Revolve: revolve curves (start angle / revolution angle)")
    R("NETWORKSRF", cmd_networksrf, [], "Rhino NetworkSrf: surface from a network of crossing curves")
    R("PATCH", cmd_patch, [], "Rhino Patch: fit a surface through boundary curves and points")
    R("OFFSETSRF", cmd_offsetsrf, [], "Rhino OffsetSrf: offset a surface (FlipAll / Solid / BothSides)")
    R("FLIP", cmd_flip, ["DIR"], "Rhino Flip: reverse surface normals")
    R("DUPBORDER", cmd_dupborder, [], "Rhino DupBorder: curves from the border of surfaces")
    R("SECTION", cmd_section, [], "Rhino Section: section curves through surfaces / solids")
    R("CONTOUR", cmd_contour, [], "Rhino Contour: evenly spaced section curves (stations, waterlines, buttocks)")
