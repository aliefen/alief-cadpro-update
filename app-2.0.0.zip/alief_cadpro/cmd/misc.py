"""View, UCS, inquiry, blocks, layers, files, annotation scale and application commands."""
import math
import numpy as np
from ..core import entities as E
from ..core.geom import unit, norm, Plane, v3, fmt, fmt_pt, poly_area2, poly_centroid2, prims_tess

STD_SCALES = [1, 2, 2.5, 5, 10, 15, 20, 25, 30, 40, 50, 75, 100, 125, 150, 200, 250, 300, 400, 500, 1000, 2000, 5000]
PAPERS = {"A4": (297, 210), "A3": (420, 297), "A2": (594, 420), "A1": (841, 594), "A0": (1189, 841)}


def T(fn):
    fn.transparent = True
    return fn


def _view(name):
    @T
    def f(c):
        c.view.set_view(name)
    return f


@T
def cmd_zoom_ext(c):
    c.view.zoom_extents()


def cmd_zoom(c):
    o = yield c.opt("ZOOM  [Extents/Window/All/In/Out/Selected] <Extents>", ["Extents", "Window", "All", "In", "Out", "Selected"], "Extents")
    v = c.view
    if o in ("Extents", "All"):
        v.zoom_extents()
    elif o == "In":
        v.zoom_at(v.width() / 2, v.height() / 2, 0.5)
    elif o == "Out":
        v.zoom_at(v.width() / 2, v.height() / 2, 2.0)
    elif o == "Selected":
        ents = yield c.sel("Select objects to zoom to")
        if ents:
            v.zoom_extents(ents)
    elif o == "Window":
        a = yield c.pt("Specify first corner")
        b = yield c.corner("Specify opposite corner", a)
        if a is not None and b is not None:
            bb = (np.minimum(a, b), np.maximum(a, b))
            class _B:
                def bbox(self_):
                    return bb
            v.zoom_extents([_B()])


@T
def cmd_zoomwin(c):
    c.app.zoom_window_pending = True; c.view.zoom_window_pending = True
    c.msg("Drag a window to zoom")


def _vs(mode):
    @T
    def f(c):
        c.view.mode = mode; c.view.invalidate(); c.app.refresh_status()
    return f


@T
def cmd_persp(c):
    c.view.cam.persp = not c.view.cam.persp; c.view.invalidate(); c.msg("Perspective " + ("ON" if c.view.cam.persp else "OFF"))


def cmd_ucs(c):
    o = yield c.opt("UCS  [World/3point/Origin/View/Object/X/Y/Z/Previous] <World>", ["World", "3point", "Origin", "View", "Object", "X", "Y", "Z", "Previous"], "World")
    v = c.view
    prev = v.ucs.copy()
    if o == "World":
        v.ucs = Plane()
    elif o == "3point":
        a = yield c.pt("Specify new origin point <0,0,0>")
        b = yield c.pt("Specify point on positive portion of X-axis", base=a)
        q = yield c.pt("Specify point on positive-Y portion of the UCS XY plane", base=a)
        if a is None or b is None or q is None:
            return
        v.ucs = Plane(a, b - a, q - a)
    elif o == "Origin":
        a = yield c.pt("Specify new origin point")
        if a is None:
            return
        u = v.ucs.copy(); u.o = a; v.ucs = u
    elif o == "View":
        v.ucs = Plane(v.ucs.o, v.cam.right(), v.cam.up())
    elif o == "Object":
        s = yield c.ent("Select object to align UCS (plate, planar curve, face of a solid)")
        if s is None:
            return
        e, p = s
        pl = None
        if e.kind == "body" and "plane" in e.meta:
            pl = Plane.from_dict(e.meta["plane"])
        elif e.kind == "body":
            ro, rd = v.cam.ray(v.mouse.x(), v.mouse.y())
            fn = e.normals(); k = int(np.argmin(np.linalg.norm(e.V[e.F].mean(axis=1) - p, axis=1)))
            pl = Plane.from_normal(p, fn[k])
        else:
            pl = e.plane()
        if pl is None:
            c.msg("Object is not planar"); return
        pl.o = v3(p) if e.kind != "body" else pl.o
        v.ucs = pl
    elif o in ("X", "Y", "Z"):
        a = yield c.num(f"Specify rotation angle about {o} axis <90>", 90.0)
        from ..core.geom import m_rotate
        ax = {"X": v.ucs.x, "Y": v.ucs.y, "Z": v.ucs.z}[o]
        M = m_rotate(v.ucs.o, ax, math.radians(a or 90))
        v.ucs = v.ucs.transformed(M)
    elif o == "Previous":
        if c.app.ucs_prev is not None:
            v.ucs = c.app.ucs_prev
    c.app.ucs_prev = prev
    v.invalidate(); c.app.refresh_status()


@T
def cmd_ucsworld(c):
    c.app.ucs_prev = c.view.ucs.copy(); c.view.ucs = Plane(); c.view.invalidate()


@T
def cmd_ucsview(c):
    v = c.view; c.app.ucs_prev = v.ucs.copy(); v.ucs = Plane(v.cam.target, v.cam.right(), v.cam.up()); v.invalidate()


def _ucs_preset(name):
    @T
    def f(c):
        c.app.ucs_prev = c.view.ucs.copy()
        o = c.view.ucs.o
        c.view.ucs = {"UCSTOP": Plane(o, (1, 0, 0), (0, 1, 0)), "UCSFRONT": Plane(o, (1, 0, 0), (0, 0, 1)),
                      "UCSRIGHT": Plane(o, (0, 1, 0), (0, 0, 1))}[name]
        c.view.invalidate()
    return f


@T
def cmd_plan(c):
    c.view.plan_view(c.view.ucs)


def _toggle(attr, label):
    @T
    def f(c):
        setattr(c.view, attr, not getattr(c.view, attr)); c.view.invalidate(); c.app.refresh_status()
        c.msg(f"<{label} {'on' if getattr(c.view, attr) else 'off'}>")
    return f


@T
def cmd_undo(c):
    n = c.doc.undo(); c.app.clear_selection(silent=True); c.msg(f"UNDO {n or 'nothing'}")


@T
def cmd_redo(c):
    n = c.doc.redo(); c.msg(f"REDO {n or 'nothing'}")


# --------------------------------------------------------------------------------------------- inquiry
def cmd_dist(c):
    a = yield c.pt("DIST  Specify first point")
    b = yield c.pt("Specify second point", base=a, preview=lambda q: [E.Line(a, q)])
    if a is None or b is None:
        return
    d = b - a; q = c.ucs.to_local(b) - c.ucs.to_local(a)
    c.msg(f"Distance = {norm(d):.4f},  Angle in XY = {math.degrees(math.atan2(q[1], q[0])) % 360:.3f}°,  "
          f"Delta X = {q[0]:.4f}, Delta Y = {q[1]:.4f}, Delta Z = {q[2]:.4f}")


def cmd_id(c):
    p = yield c.pt("ID  Specify point")
    if p is not None:
        q = c.ucs.to_local(p)
        c.msg(f"X = {q[0]:.4f}   Y = {q[1]:.4f}   Z = {q[2]:.4f}")


def cmd_area(c):
    o = yield c.pt("AREA  Specify first corner point or [Object]", options=["Object"])
    pts = []
    if o == "Object":
        s = yield c.ent("Select closed object (or 3D solid / plate)")
        if s is None:
            return
        e = s[0]
        if e.kind == "body":
            c.msg(f"Surface area = {e.area():.4f}" + (f",  plate area (one side) = {e.meta['area']:.4f}" if "area" in e.meta else "")); return
        if not getattr(e, "closed", False):
            c.msg("Object is not closed"); return
        P = prims_tess(e.prims()) if e.kind not in ("ellipse", "spline") else e.pts()
        pl = e.plane() or c.ucs
        Q = pl.to_local(P)[:, :2]
    else:
        if o is None:
            return
        pts = [o]
        while True:
            q = yield c.pt("Specify next point <done>", base=pts[-1], preview=lambda q: [E.Polyline(np.array(pts + [q]), True, None, c.ucs.z)])
            if q is None:
                break
            pts.append(q)
        if len(pts) < 3:
            return
        pl = c.ucs; Q = pl.to_local(np.array(pts))[:, :2]
        P = np.array(pts)
    cen, A = poly_centroid2(Q)
    per = float(np.sum(np.linalg.norm(np.diff(np.vstack([Q, Q[:1]]), axis=0), axis=1)))
    cw = pl.to_world(np.append(cen, 0))
    c.msg(f"Area = {abs(A):.4f},  Perimeter = {per:.4f},  Centroid = ({fmt_pt(c.ucs.to_local(cw))})")
    lab = yield c.opt("Place area / centroid label at the centroid? [Yes/No] <No>", ["Yes", "No"], "No")
    if lab == "Yes":
        t = E.Text(cw, f"A = {abs(A):.2f}\nCG ({fmt(c.ucs.to_local(cw)[0], 2)}, {fmt(c.ucs.to_local(cw)[1], 2)})", 2.5, c.ucs.x, c.ucs.z, 1, 2)
        t.anno = 2.5; t.layer = "TEXT"; c.doc.add_keep(t)
        c.doc.add_keep(E.PointE(cw))


def cmd_list(c):
    ents = yield c.sel("LIST  Select objects")
    lines = []
    for e in ents or []:
        lines.append(f"--- {e.label}  (layer {e.layer}, handle {e.id})")
        for k, v in e.info():
            if isinstance(v, np.ndarray):
                v = fmt_pt(v)
            elif isinstance(v, float):
                v = fmt(v, 4)
            lines.append(f"    {k}: {v}")
    c.app.show_text("LIST", "\n".join(lines) or "Nothing selected")


def cmd_massprop(c):
    ents = yield c.sel("MASSPROP  Select solids", filt=lambda e: e.kind == "body")
    if not ents:
        return
    from ..core.ship import density
    units = c.doc.settings.get("units", "mm"); f3 = {"mm": 1e-9, "cm": 1e-6, "m": 1.0}.get(units, 1e-9)
    V = 0.0; M = 0.0; C = np.zeros(3)
    for e in ents:
        v = abs(e.volume()); d = density(e.meta.get("grade", "")) if e.meta.get("grade") else 7850
        V += v; m = v * f3 * d; M += m; C += e.centroid() * m
    C = C / M if M > 0 else C
    bb = c.doc.extents(ents)
    c.app.show_text("MASSPROP", f"Objects: {len(ents)}\nVolume: {V:.4f} {units}3\nMass: {M:.3f} kg (density per material grade, default steel 7850 kg/m3)\n"
                    f"Centre of gravity: {fmt_pt(c.ucs.to_local(C))}\nBounding box: {fmt_pt(bb[0])}  -  {fmt_pt(bb[1])}")


# --------------------------------------------------------------------------------------------- blocks
def cmd_block(c):
    name = yield c.text("BLOCK  Enter block name")
    if not name:
        return
    ents = yield c.sel("Select objects for the block")
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    blk = E.Block(name.strip(), b, [e.copy() for e in ents])
    c.doc.add_block(blk)
    for e in ents:
        c.doc.remove(e)
    ins = E.Insert(name.strip(), np.eye(4)); ins.M[:3, 3] = 0
    c.doc.add(ins)
    c.msg(f"Block {name} created")


def cmd_insert(c):
    names = sorted(c.doc.blocks)
    if not names:
        c.msg("No blocks in this drawing"); return
    name = c.app.choose("INSERT", "Block name", names)
    if not name:
        return
    sc = 1.0
    def mk(p, a=0.0):
        return E.Insert.make(name, p, sc, sc, sc, a, c.ucs.z)
    p = yield c.pt("Specify insertion point", preview=lambda q: [mk(q)])
    if p is None:
        return
    s = yield c.num("Scale factor <1>", 1.0)
    sc = float(s or 1.0)
    a = yield c.angle("Rotation angle <0>", base=p, default=0.0, preview=lambda q: [mk(p, math.atan2(*(c.ucs.to_local(q) - c.ucs.to_local(p))[1::-1]))])
    c.add(mk(p, math.radians(a or 0)))


# --------------------------------------------------------------------------------------------- annotation scale
def auto_scale(doc, paper="A3", margin=0.85):
    bb = doc.extents()
    if bb is None:
        return 1
    size = bb[1] - bb[0]
    w, h = sorted([size[0], size[1]], reverse=True)
    pw, ph = PAPERS.get(paper, PAPERS["A3"])
    need = max(w / (pw * margin), h / (ph * margin), 1e-9)
    for s in STD_SCALES:
        if s >= need:
            return s
    return STD_SCALES[-1]


def ensure_scale(c):
    """Automatic annotation scale: when the drawing is still at 1:1 but much larger than the paper, choose a standard scale."""
    if not c.doc.settings.get("auto_anno", True) or abs(E.Entity.anno_scale - 1.0) > 1e-9:
        return
    n = auto_scale(c.doc, c.doc.settings.get("paper", "A3"))
    if n > 1:
        set_anno_scale(c, n)
        c.msg(f"Drawing scale set automatically to 1:{n:g} for {c.doc.settings.get('paper', 'A3')} paper - text, dimensions and symbols follow it "
              f"(change it in the status bar or with ANNOSCALE)")


def set_anno_scale(c, s):
    c.doc.settings["anno_scale"] = float(s)
    E.Entity.anno_scale = float(s)
    for e in c.doc.ents.values():
        e.touch()
    for b in c.doc.blocks.values():
        for e in b.ents:
            e.touch()
    c.doc.changed(); c.app.refresh_status()


def cmd_annoscale(c):
    cur = E.Entity.anno_scale
    s = yield c.text(f"ANNOSCALE  Drawing scale 1:N, enter N or AUTO <{cur:g}>", default=str(cur))
    if s is None:
        return
    if str(s).strip().upper().startswith("A"):
        paper = c.doc.settings.get("paper", "A3")
        n = auto_scale(c.doc, paper)
        c.msg(f"Auto scale for {paper}: 1:{n:g}")
    else:
        try:
            n = float(str(s).split(":")[-1])
        except ValueError:
            return
    set_anno_scale(c, n)


def cmd_textfit(c):
    """Make texts / dimensions / leaders annotative with standard ISO 3098 paper heights."""
    ents = yield c.sel("TEXTFIT  Select texts / dimensions / symbols <Enter = whole drawing>")
    ents = ents or list(c.doc.ents.values())
    k = E.Entity.anno_scale
    std = [1.8, 2.5, 3.5, 5.0, 7.0, 10.0]
    n = 0
    for e in ents:
        if e.kind == "text":
            c.doc.modify(e)
            ph = e.h / k
            ph = min(std, key=lambda s: abs(math.log(max(ph, 1e-6) / s)))
            ph = max(2.5, ph) if ph < 2.5 and len(e.s) > 3 else ph
            e.anno = ph; e.touch(); n += 1
        elif e.kind == "dimension":
            c.doc.modify(e); e.style["anno"] = True
            for key in ("th", "asz"):
                e.style[key] = c.doc.settings.get("dim", {}).get(key, 2.5)
            e.style["exo"] = 1.25; e.style["exe"] = 1.25; e.style["gap"] = 0.8
            e.touch(); n += 1
        elif e.kind == "leader":
            c.doc.modify(e); e.anno = True; e.hm = 2.5; e.asz0 = 2.5; e.touch(); n += 1
        elif e.kind == "insert" and e.name.startswith("SYM_"):
            c.doc.modify(e); e.anno = True
            s = (abs(np.linalg.det(e.M[:3, :3])) ** (1 / 3)) or 1
            e.M[:3, :3] /= s; e.touch(); n += 1
    c.msg(f"{n} annotation object(s) set to annotative size at 1:{k:g}")


# --------------------------------------------------------------------------------------------- app / files (thin wrappers)
def _app(method):
    @T
    def f(c):
        getattr(c.app, method)()
    return f


@T
def cmd_selectall(c):
    c.app.set_selection([e.id for e in c.doc.visible_ents() if c.doc.selectable(e)])


@T
def cmd_regen(c):
    for e in c.doc.ents.values():
        e.touch()
    c.view.invalidate()


APP_DESC = {"NEW": "New drawing", "OPEN": "Open drawing (.acp, .dxf, .dwg)", "SAVE": "Save drawing", "SAVEAS": "Save drawing under a new name / format",
            "IMPORT": "Import DXF / DWG / STL / OBJ / PDF / image / CSV", "EXPORT": "Export DXF / DWG / STL / OBJ", "PLOT": "Plot to PDF with title block",
            "PNGOUT": "Save the view as a PNG image", "LAYER": "Layer manager", "PROPERTIES": "Properties panel", "OPTIONS": "Program options",
            "UPDATE": "Check / install updates", "ABOUT": "About ALIEF CAD PRO", "HELP": "List of all commands", "GUIDE": "Open the user guide (Panduan)",
            "SYMLIB": "Show the symbol library", "THEME": "Toggle dark / light theme", "QUIT": "Exit the program"}


def register(eng):
    R = eng.register
    for v in ("top", "bottom", "front", "back", "left", "right", "swiso", "seiso", "neiso", "nwiso"):
        R(v.upper(), _view(v), [], (v.upper() + " view") if not v.endswith("iso") else
          {"sw": "South-west", "se": "South-east", "ne": "North-east", "nw": "North-west"}[v[:2]] + " isometric view")
    R("ZOOMEXT", cmd_zoom_ext, ["ZE"], "Zoom extents"); R("ZOOM", cmd_zoom, ["Z"], "Zoom options"); R("ZOOMWIN", cmd_zoomwin, ["ZW"], "Zoom window")
    for m, al in (("wire", ["2DWIREFRAME", "VSWIRE"]), ("hidden", ["HIDE", "VSHIDDEN"]), ("shaded", ["VSSHADED"]), ("shadededges", ["VSEDGES"]), ("xray", ["VSXRAY"])):
        R(m.upper(), _vs(m), al, "Visual style " + {"wire": "2D wireframe", "hidden": "hidden line", "shaded": "shaded",
                                                     "shadededges": "shaded with edges", "xray": "X-ray"}[m])
    R("PERSPECTIVE", cmd_persp, ["PERSP"], "Toggle perspective")
    R("UCS", cmd_ucs, [], "User coordinate system / work plane"); R("UCSWORLD", cmd_ucsworld, ["UCSW"], "World UCS"); R("UCSVIEW", cmd_ucsview, [], "UCS aligned to view")
    for n in ("UCSTOP", "UCSFRONT", "UCSRIGHT"):
        R(n, _ucs_preset(n), [], "UCS on the " + n[3:].lower() + " plane (work plane)")
    R("PLAN", cmd_plan, [], "Plan view of the UCS")
    R("GRID", _toggle("show_grid", "Grid"), ["F7"], "Toggle grid"); R("ORTHO", _toggle("ortho", "Ortho"), ["F8"], "Toggle ortho")
    R("SNAP", _toggle("snap_on", "Snap"), ["F9"], "Toggle grid snap"); R("OSNAP", _toggle("osnap_on", "Osnap"), ["F3"], "Toggle object snap")
    R("DYNMODE", _toggle("dyn", "Dynamic input"), ["F12", "DYN"], "Toggle dynamic input"); R("LWDISPLAY", _toggle("lwt", "Lineweight"), ["LWT"], "Toggle lineweight display")
    R("UNDO", cmd_undo, ["U"], "Undo"); R("REDO", cmd_redo, [], "Redo")
    R("DIST", cmd_dist, ["DI"], "Measure distance"); R("ID", cmd_id, [], "Point coordinates"); R("AREA", cmd_area, ["AA"], "Area, perimeter and centroid")
    R("LIST", cmd_list, ["LI", "LS"], "List object data"); R("MASSPROP", cmd_massprop, [], "Volume, mass and centre of gravity")
    R("BLOCK", cmd_block, ["B"], "Create block"); R("INSERT", cmd_insert, ["I"], "Insert block")
    R("ANNOSCALE", cmd_annoscale, ["SCALEANNO", "CANNOSCALE"], "Drawing scale for annotative text / dimensions / symbols (or AUTO)")
    R("TEXTFIT", cmd_textfit, ["AUTOTEXT", "ANNOFIT"], "Normalise text heights to standard annotative sizes")
    for name, meth, al in (("NEW", "file_new", ["QNEW"]), ("OPEN", "file_open", []), ("SAVE", "file_save", ["QSAVE"]), ("SAVEAS", "file_saveas", []),
                           ("IMPORT", "file_import", ["IMP"]), ("EXPORT", "file_export", ["EXP"]), ("PLOT", "file_plot", ["PRINT"]),
                           ("PNGOUT", "file_png", []), ("LAYER", "show_layers", ["LA"]), ("PROPERTIES", "show_props", ["PR", "PROPS"]),
                           ("OPTIONS", "show_options", ["OP"]), ("UPDATE", "check_update_manual", []), ("ABOUT", "show_about", []),
                           ("HELP", "show_help", []), ("GUIDE", "show_guide", ["PANDUAN"]), ("SYMLIB", "show_symbol_library", ["TP", "TOOLPALETTES"]),
                           ("THEME", "toggle_theme", []), ("QUIT", "close", ["EXIT"])):
        R(name, _app(meth), al, APP_DESC.get(name, name.title()))
    R("SELECTALL", cmd_selectall, ["ALL"], "Select all"); R("REGEN", cmd_regen, ["RE"], "Regenerate display")
