"""Commands of version 1.9.1: the layer tools of the ribbon (Off, Isolate, Freeze, Lock, Make Current, Match ...)."""
from .misc import T


def _done(c, names=None, msg=None):
    doc = c.doc
    for e in doc.ents.values():
        if names is None or e.layer in names:
            e.touch()
    doc.rev += 1; doc.changed()
    app = c.app
    for fn in ("layers_ui_refresh",):
        if hasattr(app, fn):
            getattr(app, fn)()
    if msg:
        c.msg(msg)


def _pick_layers(c, prompt, apply, allow_current=True):
    """Pick objects one after the other; apply(layer) is called for the layer of each."""
    pre = [e for e in c.app.selected_ents()] if hasattr(c.app, "selected_ents") else []
    if pre:
        names = sorted({e.layer for e in pre})
        for n in names:
            apply(c.doc.layers[n])
        c.app.clear_selection(silent=True); _done(c, set(names), f"{prompt.split()[0]}: " + ", ".join(names)); return
    while True:
        r = yield c.ent(prompt + "  (Enter = finish)")
        if r is None or isinstance(r, str):
            return
        L = c.doc.layers.get(r[0].layer)
        if L is None:
            continue
        apply(L); _done(c, {L.name}, f'Layer "{L.name}"')


def cmd_layoff(c):
    def ap(L):
        L.on = False
    yield from _pick_layers(c, "LAYOFF  Select an object on the layer to be turned off", ap)


def cmd_layfrz(c):
    def ap(L):
        if L.name != c.doc.cur_layer:
            L.frozen = True
        else:
            c.msg("The current layer cannot be frozen")
    yield from _pick_layers(c, "LAYFRZ  Select an object on the layer to be frozen", ap)


def cmd_laylck(c):
    def ap(L):
        L.locked = True
    yield from _pick_layers(c, "LAYLCK  Select an object on the layer to be locked", ap)


def _all(c, attr, val, what):
    n = 0
    for L in c.doc.layers.values():
        if getattr(L, attr) != val:
            setattr(L, attr, val); n += 1
    _done(c, None, f"{n} layer(s) {what}")


def cmd_layiso(c):
    ents = c.app.selected_ents() if hasattr(c.app, "selected_ents") else []
    if not ents:
        ents = yield c.sel("LAYISO  Select objects on the layer(s) to be isolated")
    if not ents:
        return
    keep = {e.layer for e in ents}
    doc = c.doc
    if "_layiso" not in doc.settings:
        doc.settings["_layiso"] = {n: bool(L.on) for n, L in doc.layers.items()}
    for n, L in doc.layers.items():
        L.on = n in keep
    if doc.cur_layer not in keep:
        doc.cur_layer = sorted(keep)[0]
    c.app.clear_selection(silent=True)
    _done(c, None, "Isolated: " + ", ".join(sorted(keep)) + "   -  LAYUNISO restores the other layers")


def cmd_layuniso(c):
    st = c.doc.settings.pop("_layiso", None)
    if st is None:
        c.msg("No layers are isolated"); return
    for n, L in c.doc.layers.items():
        L.on = st.get(n, True)
    _done(c, None, "Layers restored")
    return
    yield


def cmd_laymcur(c):
    ents = c.app.selected_ents() if hasattr(c.app, "selected_ents") else []
    if ents:
        e = ents[0]
    else:
        r = yield c.ent("LAYMCUR  Select the object whose layer will be made current")
        if r is None or isinstance(r, str):
            return
        e = r[0]
    if e.layer in c.doc.layers:
        c.doc.cur_layer = e.layer
        _done(c, set(), f'"{e.layer}" is now the current layer')


def cmd_laymch(c):
    ents = c.app.selected_ents() if hasattr(c.app, "selected_ents") else []
    if not ents:
        ents = yield c.sel("LAYMCH  Select objects to be changed")
    if not ents:
        return
    r = yield c.ent("Select an object on the destination layer")
    if r is None or isinstance(r, str):
        return
    dst = r[0].layer
    for e in ents:
        if e.layer != dst:
            c.doc.modify(e); e.layer = dst; e.touch()
    c.app.clear_selection(silent=True)
    c.msg(f'{len(ents)} object(s) moved to layer "{dst}"')


def register(eng):
    R = eng.register
    R("LAYOFF", cmd_layoff, [], "Turn off the layer of a selected object")
    R("LAYON", T(lambda c: _all(c, "on", True, "turned on")), [], "Turn on all layers")
    R("LAYISO", cmd_layiso, [], "Isolate the layers of the selected objects (all other layers off)")
    R("LAYUNISO", cmd_layuniso, [], "Restore the layers hidden by LAYISO")
    R("LAYFRZ", cmd_layfrz, [], "Freeze the layer of a selected object")
    R("LAYTHW", T(lambda c: _all(c, "frozen", False, "thawed")), [], "Thaw all layers")
    R("LAYLCK", cmd_laylck, [], "Lock the layer of a selected object")
    R("LAYULK", T(lambda c: _all(c, "locked", False, "unlocked")), [], "Unlock all layers")
    R("LAYMCUR", cmd_laymcur, [], "Make the layer of a selected object current")
    R("LAYMCH", cmd_laymch, [], "Layer Match: move objects to the layer of another object")
