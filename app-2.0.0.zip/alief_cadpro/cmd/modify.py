"""Modify commands (2D + 3D)."""
import math
import numpy as np
from ..core import entities as E, editops as X
from ..core.geom import (unit, norm, m_translate, m_rotate, m_scale, m_mirror, Plane, v3, xform_pt, prims_closest, TAU)


def _copies(ents, M):
    out = []
    for e in ents:
        n = e.copy(); n.transform(M); out.append(n)
    return out


def _ghost(ents, M):
    """Preview of ents under M (one fast Ghost when the selection is big)."""
    return E.ghost(ents, M, _copies)


def _sel(c, prompt="Select objects"):
    ents = yield c.sel(prompt)
    return ents or []


def cmd_erase(c):
    ents = yield from _sel(c)
    for e in ents:
        c.doc.remove(e)
    c.msg(f"{len(ents)} object(s) erased")


def _move_like(c, copy=False):
    ents = yield from _sel(c)
    if not ents:
        return
    b = yield c.pt("Specify base point or [Displacement] <Displacement>", options=["Displacement"])
    if b is None or b == "Displacement":
        d = yield c.pt("Specify displacement <0,0,0>")
        if d is None:
            return
        base = np.zeros(3); b = base; tgt = [d]
    else:
        tgt = None
    made = []                                              # COPY: the copies of every placement, for Undo (U / Ctrl+Z)
    while True:
        if tgt:
            p = tgt.pop()
        else:
            p = yield c.pt("Specify second point" + (" or [Array/Undo/Exit] <Exit>" if copy else ""), base=b,
                           preview=lambda q: _ghost(ents, m_translate(q - b)), options=["Array", "Undo", "Exit"] if copy else None)
        if p is None or p == "Exit":
            return
        if p == "Undo":
            if made:
                for e in made.pop():
                    if e.id in c.doc.ents:
                        c.doc.remove(e)
                c.msg("Last copy undone")
            else:
                c.msg("Nothing to undo")
            continue
        if p == "Array":
            n = yield c.num("Enter number of items to array <3>", 3)
            q = yield c.pt("Specify second point (spacing)", base=b, preview=lambda q: [x for k in range(1, int(n or 3)) for x in _copies(ents, m_translate((q - b) * k))])
            if q is None:
                return
            for k in range(1, int(n or 3)):
                for e in _copies(ents, m_translate((q - b) * k)):
                    c.doc.add_keep(e)
            return
        M = m_translate(p - b)
        if copy:
            new = _copies(ents, M)
            for e in new:
                c.doc.add_keep(e)
            made.append(new)
        else:
            for e in ents:
                c.doc.modify(e); e.transform(M)
            return


def cmd_move(c):
    yield from _move_like(c, False)


def cmd_copy(c):
    yield from _move_like(c, True)


def cmd_rotate(c):
    ents = yield from _sel(c)
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    a = yield c.angle("Specify rotation angle or [Copy/Reference]", base=b, options=["Copy", "Reference"],
                      preview=lambda q: _ghost(ents, m_rotate(b, c.ucs.z, _ang(c, b, q))))
    copy = False
    if a == "Copy":
        copy = True
        a = yield c.angle("Specify rotation angle", base=b, preview=lambda q: _ghost(ents, m_rotate(b, c.ucs.z, _ang(c, b, q))))
    if a == "Reference":
        r1 = yield c.angle("Specify the reference angle <0>", base=b, default=0.0)
        r2 = yield c.angle("Specify the new angle", base=b)
        a = (r2 or 0) - (r1 or 0)
    if not isinstance(a, float):
        return
    M = m_rotate(b, c.ucs.z, math.radians(a))
    if copy:
        for e in _copies(ents, M):
            c.doc.add_keep(e)
    else:
        for e in ents:
            c.doc.modify(e); e.transform(M)


def _ang(c, b, q):
    d = c.ucs.to_local(q) - c.ucs.to_local(b)
    return math.atan2(d[1], d[0])


def cmd_scale(c):
    ents = yield from _sel(c)
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    def pv(q):
        f = norm(q - b) / max(c.view.cam.px() * 80, 1e-9)
        return _copies(ents, m_scale(b, max(f, 1e-6)))
    f = yield c.num("Specify scale factor or [Reference]", options=["Reference"])
    if f == "Reference":
        r1 = yield c.dist("Specify reference length <1>", default=1.0)
        r2 = yield c.dist("Specify new length")
        f = (r2 or 1) / (r1 or 1)
    if not isinstance(f, float) or f <= 0:
        return
    for e in ents:
        c.doc.modify(e); e.transform(m_scale(b, f))


def cmd_mirror(c):
    ents = yield from _sel(c)
    if not ents:
        return
    a = yield c.pt("Specify first point of mirror line")
    if a is None:
        return
    mk = lambda q: m_mirror(a, np.cross(c.ucs.z, unit(q - a))) if norm(q - a) > 1e-12 else np.eye(4)
    b = yield c.pt("Specify second point of mirror line", base=a, preview=lambda q: _ghost(ents, mk(q)))
    if b is None:
        return
    keep = yield c.opt("Erase source objects? [Yes/No] <No>", ["Yes", "No"], "No")
    for e in _copies(ents, mk(b)):
        c.doc.add_keep(e)
    if keep == "Yes":
        for e in ents:
            c.doc.remove(e)


def cmd_mirror3d(c):
    ents = yield from _sel(c)
    if not ents:
        return
    o = yield c.opt("Mirror plane [3points/XY/YZ/ZX] <3points>", ["3points", "XY", "YZ", "ZX"], "3points")
    if o == "3points":
        a = yield c.pt("First point on mirror plane"); b = yield c.pt("Second point", base=a); q = yield c.pt("Third point", base=b)
        n = unit(np.cross(b - a, q - a)); p = a
    else:
        p = yield c.pt("Point on mirror plane")
        n = {"XY": c.ucs.z, "YZ": c.ucs.x, "ZX": c.ucs.y}[o]
    if p is None or norm(n) < 1e-12:
        return
    for e in _copies(ents, m_mirror(p, n)):
        c.doc.add_keep(e)


def cmd_rotate3d(c):
    ents = yield from _sel(c)
    if not ents:
        return
    a = yield c.pt("Specify first point on axis or [X/Y/Z]", options=["X", "Y", "Z"])
    if a in ("X", "Y", "Z"):
        p = yield c.pt("Specify a point on the axis")
        d = {"X": c.ucs.x, "Y": c.ucs.y, "Z": c.ucs.z}[a]; a = p
    else:
        b = yield c.pt("Specify second point on axis", base=a); d = b - a
    ang = yield c.num("Specify rotation angle (deg)")
    if a is None or not isinstance(ang, float):
        return
    M = m_rotate(a, d, math.radians(ang))
    for e in ents:
        c.doc.modify(e); e.transform(M)


def cmd_offset(c):
    d = c.doc.settings.get("offset_d", 10.0)
    r = yield c.dist(f"OFFSET  Specify offset distance <{d:g}>", default=d)
    if not isinstance(r, float) or r <= 0:
        return
    c.doc.settings["offset_d"] = r
    while True:
        s = yield c.ent("Select object to offset <exit>", filt=X.is_editable_curve)
        if s is None:
            return
        e, pk = s
        q = yield c.pt("Specify point on side to offset", preview=lambda q: [X.offset(e, r, q, c.ucs.z)])
        if q is None:
            return
        o = X.offset(e, r, q, c.ucs.z)
        if o is not None:
            c.doc.add_keep(o)


def _trim_extend(c, extend=False):
    name = "EXTEND" if extend else "TRIM"
    edges = yield c.sel(f"{name}  Select boundary edges or <Enter = all objects>")
    if not edges:
        edges = list(c.doc.visible_ents())
    while True:
        s = yield c.ent(f"Select object to {name.lower()} <exit>", filt=X.is_editable_curve)
        if s is None:
            return
        e, pk = s
        if extend:
            n = X.extend(e, pk, edges)
            if n is None:
                c.msg("No boundary found in that direction"); continue
            c.doc.modify(e); c.doc.remove(e); n.id = 0; c.doc.add_keep(n)
            edges = [n if x is e else x for x in edges]
        else:
            res = X.trim(e, pk, edges)
            if res is None:
                c.msg("Object does not intersect a cutting edge"); continue
            c.doc.remove(e)
            new = [c.doc.add_keep(r) for r in res]
            edges = [x for x in edges if x is not e] + new


def cmd_trim(c):
    yield from _trim_extend(c, False)


def cmd_extend(c):
    yield from _trim_extend(c, True)


def cmd_fillet(c, chamfer=False):
    st = c.doc.settings
    r = st.get("fillet_r", 0.0); d1 = st.get("cham_d1", 5.0); d2 = st.get("cham_d2", 5.0)
    name = "CHAMFER" if chamfer else "FILLET"
    while True:
        s = yield c.ent(f"{name}  Select first line or [" + ("Distance" if chamfer else "Radius") + "/Polyline]  (" +
                        (f"D1={d1:g}, D2={d2:g}" if chamfer else f"R={r:g}") + ")",
                        filt=lambda e: e.kind in ("line", "polyline"), options=["Radius", "Distance", "Polyline"])
        if s == "Radius":
            v = yield c.dist(f"Specify fillet radius <{r:g}>", default=r)
            r = st["fillet_r"] = float(v); continue
        if s == "Distance":
            v1 = yield c.dist(f"Specify first chamfer distance <{d1:g}>", default=d1)
            v2 = yield c.dist(f"Specify second chamfer distance <{v1:g}>", default=v1)
            d1 = st["cham_d1"] = float(v1); d2 = st["cham_d2"] = float(v2); continue
        if s == "Polyline":
            p = yield c.ent("Select 2D polyline", filt=lambda e: e.kind == "polyline")
            if p is None:
                return
            n = X.fillet_polyline(p[0], r)
            c.doc.remove(p[0]); c.doc.add_keep(n); return
        if s is None:
            return
        e1, p1 = s
        if e1.kind != "line":
            c.msg("Select a line (use the Polyline option for polylines)"); continue
        s2 = yield c.ent("Select second line", filt=lambda e: e.kind == "line" and e is not e1)
        if s2 is None:
            return
        e2, p2 = s2
        res = X.chamfer_lines(e1, p1, e2, p2, d1, d2) if chamfer else X.fillet_lines(e1, p1, e2, p2, r)
        if res is None:
            c.msg("Lines are parallel or too short"); continue
        a, b, mid = res
        c.doc.remove(e1); c.doc.remove(e2)
        for n in (a, b, mid):
            if n is not None and (n.kind != "line" or norm(n.p1 - n.p0) > 1e-9):
                c.doc.add_keep(n)
        return


def cmd_chamfer(c):
    yield from cmd_fillet(c, True)


def cmd_explode(c):
    ents = yield from _sel(c)
    n = 0
    for e in ents:
        parts = e.explode()
        if not parts:
            continue
        c.doc.remove(e)
        for p in parts:
            if p.layer == "0" and e.layer != "0":
                p.layer = e.layer
            if p.color in (256, 0):
                p.color = e.color
            if e.kind != "insert":                         # pieces of a polyline / spline ... keep its linetype, scale and weight
                if p.ltype in ("ByLayer", None, "") and e.ltype not in ("ByLayer", None, ""):
                    p.ltype = e.ltype
                if float(getattr(p, "lts", 1.0) or 1.0) == 1.0:
                    p.lts = float(getattr(e, "lts", 1.0) or 1.0)
                if p.lw == -1:
                    p.lw = e.lw
            c.doc.add_keep(p); n += 1
    c.msg(f"{n} object(s) created")


def cmd_join(c):
    ents = yield from _sel(c, "Select lines, arcs or polylines to join")
    res, used = X.join(ents)
    for u in used:
        c.doc.remove(u)
    for r in res:
        c.doc.add_keep(r)
    c.msg(f"{len(used)} object(s) joined into {len(res)} polyline(s)")


def cmd_break(c):
    s = yield c.ent("BREAK  Select object", filt=X.is_editable_curve)
    if s is None:
        return
    e, p1 = s
    o = yield c.pt("Specify second break point or [First point / @ = break at point]", options=["First"])
    if o == "First":
        p1 = yield c.pt("Specify first break point"); o = yield c.pt("Specify second break point", base=p1)
    if o is None:
        return
    res = X.break_curve(e, p1, o)
    if res is None:
        return
    c.doc.remove(e)
    for r in res:
        c.doc.add_keep(r)


def cmd_stretch(c):
    c.msg("STRETCH: select objects with a crossing window (right to left)")
    ents = yield c.sel("Select objects to stretch by crossing-window")
    win = c.app.last_window
    if not ents or win is None:
        c.msg("Use a crossing window to select"); return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    def apply(q, dry=True):
        out = []
        d = q - b; M = m_translate(d)
        for e in ents:
            n = e.copy() if dry else e
            if not dry:
                c.doc.modify(e)
            if e.kind == "line":
                ins = c.view.window_contains_screen(win, np.array([e.p0, e.p1]))
                if ins[0]:
                    n.p0 = e.p0 + d
                if ins[1]:
                    n.p1 = e.p1 + d
            elif e.kind == "polyline":
                ins = c.view.window_contains_screen(win, e.pts)
                n.pts = e.pts + np.where(ins[:, None], d, 0)
            else:
                bb = e.bbox()
                if bb is not None and c.view.window_contains_screen(win, np.array(bb)).all():
                    n.transform(M)
            n.touch(); out.append(n)
        return out
    q = yield c.pt("Specify second point", base=b, preview=lambda q: apply(q))
    if q is not None:
        apply(q, dry=False)


def cmd_array(c):
    ents = yield from _sel(c)
    if not ents:
        return
    opt = c.app.dialog_array(ents)
    if not opt:
        return
    bb = c.doc.extents(ents)
    base = (bb[0] + bb[1]) / 2 if bb else np.zeros(3)
    pl = c.ucs
    if opt["type"] == "rect":
        for i in range(opt["rows"]):
            for j in range(opt["cols"]):
                for k in range(opt.get("levels", 1)):
                    if i == j == k == 0:
                        continue
                    d = pl.y * opt["dy"] * i + pl.x * opt["dx"] * j + pl.z * opt.get("dz", 0) * k
                    for e in _copies(ents, m_translate(d)):
                        c.doc.add_keep(e)
    elif opt["type"] == "polar":
        cen = yield c.pt("Specify center point of array")
        if cen is None:
            return
        n = opt["count"]; fill = math.radians(opt["fill"])
        step = fill / (n if abs(opt["fill"] - 360) < 1e-9 else max(1, n - 1))
        for k in range(1, n):
            M = m_rotate(cen, pl.z, step * k)
            if not opt.get("rotate", True):
                bp = xform_pt(M, base); M = m_translate(bp - base)
            for e in _copies(ents, M):
                c.doc.add_keep(e)
    else:
        s = yield c.ent("Select path curve", filt=X.is_editable_curve)
        if s is None:
            return
        path = s[0]; pr = path.prims(); L = sum(__import__("alief_cadpro.core.geom", fromlist=["prim_len"]).prim_len(p) for p in pr)
        from ..core.geom import prims_point, prim_tangent
        n = opt["count"]
        st = L / max(1, n - 1) if not path.closed else L / n
        p0 = prims_point(pr, 0)
        for k in range(1, n):
            q = prims_point(pr, min(L, st * k))
            for e in _copies(ents, m_translate(q - p0)):
                c.doc.add_keep(e)


MATCH_KEYS = [("color", "Color"), ("layer", "Layer"), ("ltype", "Linetype"), ("lts", "Linetype scale"), ("lw", "Lineweight"),
              ("text", "Text (font, height, width factor, formatting)"), ("dim", "Dimension (style)"), ("hatch", "Hatch (pattern, scale, angle)"),
              ("pline", "Polyline (width)"), ("leader", "Leader (arrowhead, size, landing)")]


def match_props(src, e, use=None):
    """Copy the properties of src to e (MATCHPROP). use = set of MATCH_KEYS names (None = all)."""
    use = set(k for k, _ in MATCH_KEYS) if use is None else set(use)
    if "color" in use:
        e.color = src.color
    if "layer" in use:
        e.layer = src.layer
    if "ltype" in use:
        e.ltype = src.ltype
    if "lts" in use:
        e.lts = float(getattr(src, "lts", 1.0) or 1.0)
    if "lw" in use:
        e.lw = src.lw
    if "text" in use and src.kind == "text" and e.kind == "text":
        from ..core import mtext as MT
        # the size the source text really shows: its height x the factor set inside the text (sizes changed in the editor)
        hs = src.h * (MT.dominant_hf(src.rich) if src.rich else 1.0)
        e.font = src.font; e.wf = src.wf; e.lsf = getattr(src, "lsf", 1.0)
        if e.rich:                                         # formatting codes inside the text would win over the matched values
            r2, _ = MT.fold_height(MT.strip_overrides(e.rich, e.font), 1.0)
            e.set_rich(r2)
        if src.anno:
            e.anno = hs / (E.Entity.anno_scale or 1.0)
        else:
            e.anno = 0.0; e.hm = hs
    if "dim" in use and src.kind == "dimension" and e.kind == "dimension":
        e.style = dict(src.style)
    if "hatch" in use and src.kind == "hatch" and e.kind == "hatch":
        e.pattern, e.scale, e.angle = src.pattern, src.scale, src.angle
        if getattr(src, "pdef", None) is not None:
            e.pdef = [list(f) for f in src.pdef]
    if "pline" in use and src.kind == "polyline" and e.kind == "polyline":
        e.width = float(getattr(src, "width", 0.0) or 0.0)
    if "leader" in use and src.kind == "leader" and e.kind == "leader":
        for k in ("arrow", "asz0", "land0", "hm", "anno"):
            if hasattr(src, k):
                setattr(e, k, getattr(src, k))
    e.touch()


def cmd_matchprop(c):
    use = c.doc.settings.get("matchprop", None)
    while True:
        s = yield c.ent("MATCHPROP  Select source object or [Settings]", options=["Settings"])
        if s is None:
            return
        if s == "Settings":
            r = c.app.dialog_matchprop(use) if hasattr(c.app, "dialog_matchprop") else None
            if r is not None:
                use = r; c.doc.settings["matchprop"] = list(r)
            continue
        break
    src = s[0]
    c.msg(f"Source: {src.label} - layer {src.layer}, linetype {src.ltype}, linetype scale {getattr(src, 'lts', 1.0):g}")
    while True:
        r = c.sel("Select destination object(s) or [Settings]")
        r.options = ["Settings"]
        ents = yield r
        if ents == "Settings":
            rr = c.app.dialog_matchprop(use) if hasattr(c.app, "dialog_matchprop") else None
            if rr is not None:
                use = rr; c.doc.settings["matchprop"] = list(rr)
            continue
        if not ents:
            return
        for e in ents:
            if e is src:
                continue
            c.doc.modify(e); match_props(src, e, use)
        c.msg(f"{len(ents)} object(s) matched")
        return


def cmd_align(c):
    ents = yield from _sel(c)
    if not ents:
        return
    s1 = yield c.pt("Specify first source point"); d1 = yield c.pt("Specify first destination point", base=s1)
    s2 = yield c.pt("Specify second source point"); d2 = yield c.pt("Specify second destination point", base=s2)
    if None in (s1, d1, s2, d2):
        return
    sc = yield c.opt("Scale objects based on alignment points? [Yes/No] <No>", ["Yes", "No"], "No")
    a = s2 - s1; b = d2 - d1
    pl = c.ucs
    la = pl.to_local(s1 + a) - pl.to_local(s1); lb = pl.to_local(d1 + b) - pl.to_local(d1)
    ang = math.atan2(lb[1], lb[0]) - math.atan2(la[1], la[0])
    M = m_rotate(d1, pl.z, ang) @ m_translate(d1 - s1)
    if sc == "Yes" and norm(a) > 1e-12:
        M = m_scale(d1, norm(b) / norm(a)) @ M
    for e in ents:
        c.doc.modify(e); e.transform(M)


def register(eng):
    R = eng.register
    R("ERASE", cmd_erase, ["E", "DEL"], "Erase objects")
    R("MOVE", cmd_move, ["M"], "Move objects")
    R("COPY", cmd_copy, ["CO", "CP"], "Copy objects")
    R("ROTATE", cmd_rotate, ["RO"], "Rotate about a base point")
    R("SCALE", cmd_scale, ["SC"], "Scale objects")
    R("MIRROR", cmd_mirror, ["MI"], "Mirror about a line")
    R("MIRROR3D", cmd_mirror3d, ["3M"], "Mirror about a plane")
    R("ROTATE3D", cmd_rotate3d, ["3R", "3DROTATE"], "Rotate about a 3D axis")
    R("OFFSET", cmd_offset, ["O"], "Offset curves")
    R("TRIM", cmd_trim, ["TR"], "Trim to cutting edges")
    R("EXTEND", cmd_extend, ["EX"], "Extend to boundary edges")
    R("FILLET", cmd_fillet, ["F"], "Round corners")
    R("CHAMFER", cmd_chamfer, ["CHA"], "Bevel corners")
    R("EXPLODE", cmd_explode, ["X"], "Break compound objects")
    R("JOIN", cmd_join, ["J"], "Join curves into polylines")
    R("BREAK", cmd_break, ["BR"], "Break a curve")
    R("STRETCH", cmd_stretch, ["S"], "Stretch with crossing window")
    R("ARRAY", cmd_array, ["AR"], "Rectangular / polar / path array")
    R("MATCHPROP", cmd_matchprop, ["MA"], "Copy properties")
    R("ALIGN", cmd_align, ["AL"], "Align by point pairs (move + rotate + scale)")
