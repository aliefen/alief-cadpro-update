"""Frame spacing ruler (Ship Structure): frame numbers from any start number (also negative), spacing given per segment."""
import numpy as np
from ..core import entities as E

DEFAULT = {"first": 0, "last": 20, "spacing": 600.0, "segments": [], "label_step": 1, "reverse": False,
           "tick": 2.5, "th": 3.5, "lines": False, "line_up": 2000.0, "line_down": 0.0, "notes": True, "note_text": "FRAME SPACE",
           "feet": True, "prefix": "", "note_pos": "below"}


def frame_positions(first, last, spacing, segments):
    """-> {frame number: distance from frame 0}.  segments = [(from frame, to frame, spacing), ...]; the default spacing fills the rest.
    Frame 0 is the origin when it lies inside first..last, otherwise the first frame is."""
    first, last = int(min(first, last)), int(max(first, last))
    def sp(i):                                   # spacing of the interval i -> i + 1
        for a, b, s in segments:
            a, b = int(min(a, b)), int(max(a, b))
            if a <= i < b and s > 0:
                return float(s)
        return float(spacing)
    org = 0 if first <= 0 <= last else first
    pos = {org: 0.0}
    x = 0.0
    for i in range(org, last):
        x += sp(i); pos[i + 1] = x
    x = 0.0
    for i in range(org - 1, first - 1, -1):
        x -= sp(i); pos[i] = x
    return pos, org, sp


def spacing_runs(first, last, sp):
    """Consecutive frames with the same spacing -> [(from, to, spacing)]."""
    runs = []
    for i in range(first, last):
        s = sp(i)
        if runs and abs(runs[-1][2] - s) < 1e-9:
            runs[-1][1] = i + 1
        else:
            runs.append([i, i + 1, s])
    return [tuple(r) for r in runs]


def note_for(s, text, feet, units="mm"):
    v = f"{s:.4f}".rstrip("0").rstrip(".")
    ft = s / 304.8
    if feet and abs(ft - round(ft * 4) / 4) < 1e-6 and ft >= 1:        # whole / quarter feet -> show both, as on class drawings
        f = f"{ft:.2f}".rstrip("0").rstrip(".")
        return f"{f}FT ({v}{units}) {text}".strip()
    return f"{v} {units} {text}".strip()


def build(opt, origin, xdir, ydir, n, units="mm"):
    """All entities of the ruler. origin = position of the origin frame on the base line."""
    k = E.Entity.anno_scale
    first, last = int(min(opt["first"], opt["last"])), int(max(opt["first"], opt["last"]))
    pos, org, sp = frame_positions(first, last, opt["spacing"], opt.get("segments") or [])
    sgn = -1.0 if opt.get("reverse") else 1.0
    X = lambda i: origin + xdir * (sgn * pos[i])
    tick = float(opt["tick"]) * k; th = float(opt["th"])
    out = []
    def L(a, b, layer="FRAME"):
        l = E.Line(a, b); l.layer = layer; out.append(l); return l
    def T(p, s, h, ha, va):
        t = E.Text(p, s, 2.5, xdir, n, ha, va); t.anno = h; t.layer = "FRAME_TEXT"; out.append(t); return t
    L(X(first), X(last))
    step = max(1, int(opt.get("label_step", 1)))
    for i in range(first, last + 1):
        lab = (i % step == 0) or i in (first, last)
        L(X(i), X(i) + ydir * (tick if lab else tick * 0.6))
        if lab:
            T(X(i) - ydir * (tick * 0.6), f"{opt.get('prefix', '')}{i}", th, 1, 3)
        if opt.get("lines") and (opt.get("line_up", 0) > 0 or opt.get("line_down", 0) > 0):
            y0 = tick * 2 + (th * k * 3.2 if opt.get("notes") and opt.get("note_pos") == "above" else 0.0)
            a = X(i) + ydir * y0; b = X(i) + ydir * (y0 + float(opt.get("line_up", 0)))
            if opt.get("line_up", 0) > 0:
                L(a, b, "FRAME_LINE")
            if opt.get("line_down", 0) > 0:
                y1 = tick * 0.6 + th * k * 2.2 + (th * 0.8 * k * 3.6 if opt.get("notes") and opt.get("note_pos", "below") != "above" else 0.0)
                L(X(i) - ydir * y1, X(i) - ydir * (y1 + float(opt["line_down"])), "FRAME_LINE")
    if opt.get("notes"):
        hn = th * 0.8
        for a, b, s in spacing_runs(first, last, sp):
            if opt.get("note_pos", "below") == "above":
                p0 = X(a) + ydir * (tick * 2 + hn * k * 0.9)
            else:                                   # below the frame numbers
                p0 = X(a) - ydir * (tick * 0.6 + th * k * 1.9 + hn * k * 2.4)
            txt = note_for(s, opt.get("note_text", "FRAME SPACE"), opt.get("feet", True), units)
            t = T(p0 + xdir * (sgn * hn * k * 0.6) + ydir * (hn * k * 0.5), txt, hn, 2 if sgn < 0 else 0, 0)
            try:
                bb = t.bbox(); w = float(np.linalg.norm(np.asarray(bb[1]) - np.asarray(bb[0])))
            except Exception:
                w = len(txt) * hn * k * 0.8
            ln = min(max(w + hn * k * 3, hn * k * 8), max(abs(pos[b] - pos[a]) * (b - a > 1 and 1.0 or 3.0), w + hn * k * 3))
            p1 = p0 + xdir * (sgn * ln)
            L(p0 - ydir * (hn * k * 0.9), p0 + ydir * (hn * k * 0.9)); L(p0, p1)
            ah = hn * k * 1.1
            tri = E.Polyline([p1, p1 - xdir * (sgn * ah) + ydir * (ah * 0.18), p1 - xdir * (sgn * ah) - ydir * (ah * 0.18)], True)
            tri.layer = "FRAME"; out.append(tri)
            try:
                h = E.Hatch([np.array([p1, p1 - xdir * (sgn * ah) + ydir * (ah * 0.18), p1 - xdir * (sgn * ah) - ydir * (ah * 0.18)])], n, "SOLID")
                h.layer = "FRAME"; out.append(h)
            except Exception:
                pass
    return out, pos, org


def cmd_framespacing(c):
    """Frame spacing ruler: numbers from any start (0 1 2 ... or -5 -4 ... 0 1 2 ...), spacing per segment."""
    from .misc import ensure_scale
    opt = dict(DEFAULT); opt.update(c.doc.settings.get("frame_spacing") or {})
    opt = c.app.dialog_frames(opt)
    if not opt:
        return
    c.doc.settings["frame_spacing"] = dict(opt)
    first, last = int(min(opt["first"], opt["last"])), int(max(opt["first"], opt["last"]))
    org = 0 if first <= 0 <= last else first
    x, y, n = c.ucs.x, c.ucs.y, c.ucs.z
    units = c.doc.settings.get("units", "mm")
    prev = lambda q: build(opt, q, x, y, n, units)[0]
    p = yield c.pt(f"FRAMESPACING  Specify position of frame {org} on the base line", preview=prev)
    if p is None:
        return
    ents, pos, org = build(opt, p, x, y, n, units)
    c.doc.ensure_layer("FRAME", 7); c.doc.ensure_layer("FRAME_TEXT", 7); c.doc.ensure_layer("FRAME_LINE", 8)
    for e in ents:
        c.doc.add_keep(e)
    k0 = E.Entity.anno_scale
    ensure_scale(c)                                # an empty drawing gets its scale from the ruler itself
    if abs(E.Entity.anno_scale - k0) > 1e-9:
        for e in ents:
            c.doc.remove(e)
        ents, pos, org = build(opt, p, x, y, n, units)
        for e in ents:
            c.doc.add_keep(e)
    c.msg(f"Frame ruler {first} .. {last} created: total length {pos[last] - pos[first]:g} {units}, frame {org} at the picked point.")


def register(eng):
    eng.register("FRAMESPACING", cmd_framespacing, ["FRS", "FRAMERULER", "FRAMESPACE"], "Frame spacing ruler with free numbering and spacing per segment")
