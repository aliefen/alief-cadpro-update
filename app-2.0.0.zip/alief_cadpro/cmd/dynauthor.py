"""Block Editor authoring: parameters, actions and parameter sets for dynamic blocks (AutoCAD-style BPARAMETER, BACTIONTOOL,
parameter sets). Everything is stored in the Block Editor session (c.app.bedit) and saved with BSAVE."""
import math
import numpy as np
from ..core import entities as E
from ..core import dynblock as DB
from ..core.geom import norm, unit
from .misc import T

PNAMES = {"point": "Position", "linear": "Distance", "polar": "Polar", "xy": "XY", "rotation": "Angle", "flip": "Flip",
          "visibility": "Visibility"}


def _ed(c):
    if not c.app.bedit:
        c.msg("Open the Block Editor first (BEDIT, or double-click a block)")
        return None
    return c.app.bedit


def _f(p):
    return [float(v) for v in p]


def _name(be, kind):
    used = {p["name"] for p in be["params"]}
    n = 1
    while f"{PNAMES[kind]}{n}" in used:
        n += 1
    return f"{PNAMES[kind]}{n}"


def _tag(c, ents):
    """Give every entity a block tag (e.xd['bk']) and return the tags."""
    tags = []
    top = max([int((e.xd or {}).get("bk", 0)) for e in c.doc.ents.values()] + [0])
    for e in ents:
        xd = dict(e.xd or {})
        if "bk" not in xd:
            top += 1; xd["bk"] = top; e.xd = xd
        tags.append(int(e.xd["bk"]))
    return tags


def _value_set(c, p, kind):
    """Optional value set: increment (+ min / max) or a list of allowed values."""
    if kind in ("flip", "visibility", "point"):
        return
    o = yield c.opt("Value set [None/Increment/List] <None>", ["None", "Increment", "List"], "None")
    if o == "Increment":
        inc = yield c.dist("Distance increment" if kind != "rotation" else "Angle increment (deg)")
        lo = yield c.text("Minimum value <none>", "")
        hi = yield c.text("Maximum value <none>", "")
        p["inc"] = float(inc) if inc else None
        for k, v in (("min", lo), ("max", hi)):
            try:
                p[k] = float(v) if str(v).strip() else None
            except ValueError:
                p[k] = None
    elif o == "List":
        s = yield c.text("Allowed values, separated by commas (e.g. 600,800,1000,1200)", "")
        try:
            lst = sorted({float(x) for x in str(s).replace(";", ",").split(",") if x.strip()})
        except ValueError:
            lst = []
        if lst:
            p["list"] = lst


def make_param(c, kind, name=None):
    """Asks the points of a parameter; returns the parameter dict (already added to the session) or None."""
    be = _ed(c)
    if be is None:
        return None
    kind = kind.lower()
    if kind == "point":
        a = yield c.pt("Point parameter  Specify parameter location")
        if a is None:
            return None
        p = {"type": "point", "p0": _f(a), "p1": _f(a)}
    elif kind in ("linear", "polar"):
        a = yield c.pt(f"{kind.capitalize()} parameter  Specify start point (base, fixed)")
        if a is None:
            return None
        b = yield c.pt("Specify end point (the grip that moves)", base=a, preview=lambda q: [E.Line(a, q)])
        if b is None or norm(b - a) < 1e-9:
            return None
        p = {"type": kind, "p0": _f(a), "p1": _f(b)}
        if kind == "linear":
            p["base"] = float(norm(b - a))
    elif kind == "xy":
        a = yield c.pt("XY parameter  Specify base point")
        if a is None:
            return None
        b = yield c.corner("Specify opposite corner (the grip that moves)", a)
        if b is None:
            return None
        p = {"type": "xy", "p0": _f(a), "p1": _f(b)}
    elif kind == "rotation":
        a = yield c.pt("Rotation parameter  Specify base point (centre of rotation)")
        if a is None:
            return None
        b = yield c.pt("Specify radius / base angle point (the grip)", base=a, preview=lambda q: [E.Line(a, q), E.Circle(a, max(norm(q - a), 1e-6))])
        if b is None or norm(b - a) < 1e-9:
            return None
        d = b - a
        p = {"type": "rotation", "p0": _f(a), "p1": _f(b), "base": math.degrees(math.atan2(d[1], d[0]))}
    elif kind == "flip":
        a = yield c.pt("Flip parameter  Specify first point of the reflection line")
        if a is None:
            return None
        b = yield c.pt("Specify second point of the reflection line", base=a, preview=lambda q: [E.Line(a, q)])
        if b is None or norm(b - a) < 1e-9:
            return None
        p = {"type": "flip", "p0": _f(a), "p1": _f(b)}
    elif kind == "visibility":
        if [q for q in be["params"] if q["type"] == "visibility"]:
            c.msg("This block already has a visibility parameter - use States to add states"); return None
        a = yield c.pt("Visibility parameter  Specify parameter location (the grip with the list of states)")
        if a is None:
            return None
        p = {"type": "visibility", "p0": _f(a), "p1": _f(a), "states": ["VisibilityState0"]}
        be["state"] = "VisibilityState0"
    else:
        c.msg("Unknown parameter type"); return None
    nm = name or _name(be, kind)
    p["name"] = nm if nm not in {q["name"] for q in be["params"]} else nm + "_2"
    be["params"].append(p)                                   # shown at once (like AutoCAD); label, name and value set are optional
    c.app.bedit_refresh(); c.view.update()
    if kind != "visibility":
        a0 = np.asarray(p["p0"], float); b0 = np.asarray(p["p1"], float)
        def prev(q):
            p["lp"] = _f(q); return []
        while True:
            r = yield c.pt(f'Parameter "{p["name"]}"  Specify label location or [Name/Value set] <Enter = keep>', options=["Name", "Value set"],
                           preview=prev if kind in ("linear", "polar", "xy", "rotation") else None)
            if r is None:
                p.pop("lp", None) if "lp_set" not in p else None
                break
            if isinstance(r, str) and r == "Name":
                s2 = yield c.text(f'Parameter name <{p["name"]}>', p["name"])
                s2 = (s2 or p["name"]).strip() or p["name"]
                if s2 != p["name"] and s2 in {q["name"] for q in be["params"]}:
                    s2 += "_2"
                p["name"] = s2; c.app.bedit_refresh(); continue
            if isinstance(r, str):
                yield from _value_set(c, p, kind); continue
            p["lp"] = _f(r); p["lp_set"] = True
            break
        p.pop("lp_set", None)
    c.app.after_command(c.app.bedit_refresh)
    c.msg(f'{kind.capitalize()} parameter "{p["name"]}" added' + ("" if kind in ("visibility",) else " - now add an action to it (Actions); the yellow ! shows a parameter without action"))
    return p


def _pick_param(c, act):
    be = c.app.bedit
    ok = [p for p in be["params"] if act in DB.ACTIONS_FOR.get(p["type"], ())]
    if not ok:
        c.msg(f"No parameter accepts a {act} action - add a parameter first"); return None
    if len(ok) == 1:
        return ok[0]
    names = [p["name"] + f"  [{p['type']}]" for p in ok]
    s = c.app.choose(f"{act.capitalize()} action", "Parameter to drive the action:", names)
    if not s:
        return None
    return ok[names.index(s)]


def _in_frame(ent, f):
    try:
        bb = ent.bbox()
    except Exception:
        return False
    if bb is None:
        return False
    return not (bb[1][0] < f[0] or bb[0][0] > f[2] or bb[1][1] < f[1] or bb[0][1] > f[3])


def make_action(c, act, prm=None):
    be = _ed(c)
    if be is None:
        return None
    act = act.lower()
    prm = prm or _pick_param(c, act)
    if prm is None:
        return None
    a = {"type": act, "param": prm["name"]}
    if act == "stretch":
        f1 = yield c.pt(f"Stretch action ({prm['name']})  Specify first corner of the stretch frame")
        if f1 is None:
            return None
        f2 = yield c.corner("Specify opposite corner of the stretch frame", f1)
        if f2 is None:
            return None
        fr = [float(min(f1[0], f2[0])), float(min(f1[1], f2[1])), float(max(f1[0], f2[0])), float(max(f1[1], f2[1]))]
        a["frame"] = fr
        c.app.set_selection([e.id for e in c.doc.ents.values() if _in_frame(e, fr)])
        ents = yield c.sel("Select objects to stretch (the objects crossing the frame are pre-selected - Enter to accept)")
        if not ents:
            ents = [e for e in c.doc.ents.values() if _in_frame(e, fr)]
    else:
        lbl = {"move": "move", "scale": "scale", "rotate": "rotate", "array": "array", "flip": "flip"}[act]
        ents = yield c.sel(f"{act.capitalize()} action ({prm['name']})  Select objects to {lbl}")
    if not ents:
        c.msg("No objects selected - action not created"); return None
    a["tags"] = _tag(c, ents)
    if act == "array":
        sx = yield c.dist("Enter the distance between columns (item spacing along the parameter)")
        if not sx:
            return None
        a["spacing"] = [float(sx), 0.0]
        if prm["type"] == "xy":
            sy = yield c.dist("Enter the distance between rows")
            a["spacing"][1] = float(sy or sx)
    if act in ("move", "stretch"):
        m = yield c.text("Distance multiplier <1>", "1")
        try:
            if abs(float(m) - 1.0) > 1e-12:
                a["mult"] = float(m)
        except (TypeError, ValueError):
            pass
    be.setdefault("actions", []).append(a)
    c.app.after_command(c.app.bedit_refresh)
    c.msg(f'{act.capitalize()} action on "{prm["name"]}" with {len(ents)} object(s)')
    return a


SETS = {   # parameter set: (parameter type, action or None)
    "LinearStretch": ("linear", "stretch"), "LinearMove": ("linear", "move"), "LinearArray": ("linear", "array"),
    "LinearScale": ("linear", "scale"), "PolarStretch": ("polar", "stretch"), "PolarMove": ("polar", "move"),
    "PolarArray": ("polar", "array"), "XYStretch": ("xy", "stretch"), "XYMove": ("xy", "move"), "XYArray": ("xy", "array"),
    "RotationSet": ("rotation", "rotate"), "FlipSet": ("flip", "flip"), "PointMove": ("point", "move"),
    "VisibilitySet": ("visibility", None),
}


def cmd_bparameter(c, kind=None):
    if _ed(c) is None:
        return
    if kind is None:
        kind = yield c.opt("BPARAMETER  Enter parameter type [Point/Linear/Polar/XY/Rotation/Flip/Visibility] <Linear>",
                           ["Point", "Linear", "Polar", "XY", "Rotation", "Flip", "Visibility"], "Linear")
        if kind is None:
            return
    yield from make_param(c, kind)


def cmd_baction(c, act=None):
    if _ed(c) is None:
        return
    if act is None:
        act = yield c.opt("BACTIONTOOL  Enter action type [Move/Stretch/Scale/Rotate/Array/Flip] <Stretch>",
                          ["Move", "Stretch", "Scale", "Rotate", "Array", "Flip"], "Stretch")
        if act is None:
            return
    yield from make_action(c, act)


def cmd_bparamset(c, which=None):
    if _ed(c) is None:
        return
    if which is None:
        which = yield c.opt("Parameter set [" + "/".join(SETS) + "] <LinearStretch>", list(SETS), "LinearStretch")
        if which is None:
            return
    kind, act = SETS[which]
    p = yield from make_param(c, kind)
    if p is None or act is None:
        if kind == "visibility" and p is not None:
            c.msg("Visibility set added: use States to add states, then hide objects per state")
        return
    yield from make_action(c, act, p)


def _wrap(fn, arg):
    def f(c):
        return fn(c, arg)
    f.__name__ = f"{fn.__name__}_{arg}"
    return f


def register(eng):
    R = eng.register
    R("BPARAMETER", cmd_bparameter, ["BPARAM"], "Block Editor: add a parameter (Point / Linear / Polar / XY / Rotation / Flip / Visibility)")
    R("BACTIONTOOL", cmd_baction, ["BACTION"], "Block Editor: add an action (Move / Stretch / Scale / Rotate / Array / Flip)")
    R("BPARAMSET", cmd_bparamset, ["BSET"], "Block Editor: parameter set = parameter + action in one go")
    for k in ("Point", "Linear", "Polar", "XY", "Rotation", "Flip", "Visibility"):
        R("BP" + k.upper(), _wrap(cmd_bparameter, k), [], f"Block Editor: {k} parameter")
    for k in ("Move", "Stretch", "Scale", "Rotate", "Array", "Flip"):
        R("BA" + k.upper(), _wrap(cmd_baction, k), [], f"Block Editor: {k} action")
    for k in SETS:
        R("BS" + k.upper(), _wrap(cmd_bparamset, k), [], f"Block Editor: parameter set {k}")
    R("BFLIP", _wrap(cmd_bparamset, "FlipSet"), [], "Block Editor: flip parameter + flip action")
