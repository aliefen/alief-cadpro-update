"""Ship structure commands: 3D Plate, 3D Profile, plate openings, brackets, frame connection details, material list, BOM."""
import math
import numpy as np
from ..core import entities as E, solids as S, ship as SH, details as D
from ..core.geom import unit, norm, Plane, v3, prims_tess, poly_area2, m_translate, xform_pt
from ..core.entities import Body


def _next_mark(c, prefix):
    cnt = c.doc.settings.setdefault("marks", {})
    cnt[prefix] = cnt.get(prefix, 0) + 1
    return f"{prefix}{cnt[prefix]:03d}"


def _plate_area(loops):
    from ..core.entities import area_evenodd
    return area_evenodd([np.asarray(l) for l in loops])


def cmd_plate3d(c):
    opt = c.app.dialog_plate()
    if not opt:
        return
    ents = yield c.sel("3D PLATE  Select closed boundary (+ inner openings) or surfaces",
                       filt=lambda e: getattr(e, "closed", False) or (e.kind == "body" and e.role == "surface"))
    if not ents:
        return
    t = opt["thk"]; side = opt["side"]
    made = 0
    curves = [e for e in ents if e.kind != "body"]
    for pl, loops in S.regions_from_curves(curves, c.ucs):
        z0, z1 = {"+": (0, t), "-": (-t, 0), "0": (-t / 2, t / 2)}[side]
        meta = {"thk": t, "grade": opt["grade"], "mark": opt["mark"] or _next_mark(c, opt.get("prefix", "P")), "side": side,
                "plane": pl.to_dict(), "loops": [np.asarray(l).tolist() for l in loops], "area": _plate_area(loops)}
        try:
            b = S.extrude_region(pl, loops, z0, z1, "plate", meta)
        except S.SolidError as ex:
            c.msg(f"Plate failed: {ex}"); continue
        b.layer = opt.get("layer", "PLATE"); b.color = opt.get("color", 256)
        c.doc.add_keep(b); made += 1
    for s in [e for e in ents if e.kind == "body"]:
        try:
            b = S.thicken(s.V, s.F, t if side != "-" else -t, both=(side == "0"))
        except S.SolidError as ex:
            c.msg(f"Plate from surface failed: {ex}"); continue
        b.role = "plate"; b.meta = {"thk": t, "grade": opt["grade"], "mark": opt["mark"] or _next_mark(c, opt.get("prefix", "P")),
                                    "side": side, "area": s.area()}
        b.layer = opt.get("layer", "PLATE"); c.doc.add_keep(b); made += 1
        if opt.get("delete_src", False):
            c.doc.remove(s)
    if opt.get("delete_src", False):
        for e in curves:
            c.doc.remove(e)
    c.msg(f"{made} plate(s) created, t = {t:g} mm, {opt['grade']}")


def cmd_platehole(c):
    s = yield c.ent("PLATE OPENING  Select plate", filt=lambda e: e.kind == "body" and e.role in ("plate", "solid"))
    if s is None:
        return
    plate = s[0]
    cur = yield c.sel("Select closed curves of the openings (manhole, lightening hole, cut-out)", filt=lambda e: getattr(e, "closed", False))
    if not cur:
        return
    thk = plate.meta.get("thk", 50.0)
    cutters = []
    for pl, loops in S.regions_from_curves(cur):
        big = max(thk * 4, 1000.0)
        cutters.append(S.extrude_region(pl, loops, -big, big))
    try:
        m = S.boolean([plate], cutters, "subtract")
        nb = S.from_manifold(m, plate.role, dict(plate.meta))
    except S.SolidError as ex:
        c.msg(f"Opening failed: {ex}"); return
    if "area" in nb.meta:
        nb.meta["area"] = max(0.0, nb.meta["area"] - sum(abs(_plate_area(l)) for _, l in S.regions_from_curves(cur)))
        if "loops" in nb.meta:
            pl0 = Plane.from_dict(nb.meta["plane"])
            for pl, loops in S.regions_from_curves(cur, pl0):
                nb.meta["loops"] += [pl0.to_local(pl.to_world(np.asarray(l)))[:, :2].tolist() for l in loops]
    nb.layer, nb.color = plate.layer, plate.color
    c.doc.remove(plate); c.doc.add_keep(nb)
    for e in cur:
        c.doc.remove(e)


def cmd_profile3d(c):
    opt = c.app.dialog_profile()
    if not opt:
        return
    ents = yield c.sel("3D PROFILE  Select path curves (moulded / attachment line)", filt=lambda e: e.is_curve)
    if not ents:
        return
    loops = SH.placed_loops(opt["ptype"], opt["dims"], opt["align"], opt["flip"], opt["rot"], opt.get("off_s", 0), opt.get("off_t", 0))
    up_mode = opt.get("web_dir", "UCS Z")
    for e in ents:
        P = S.curve_points(e)
        if len(P) < 2:
            continue
        pl = e.plane()
        if up_mode == "UCS Z":
            up = c.ucs.z
        elif up_mode == "UCS X":
            up = c.ucs.x
        elif up_mode == "UCS Y":
            up = c.ucs.y
        elif up_mode == "Curve plane normal" and pl is not None:
            up = pl.z
        else:
            up = c.ucs.z
        if opt.get("reverse_web"):
            up = -up
        L = float(np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1)))
        meta = {"ptype": opt["ptype"], "dims": opt["dims"], "size": SH.size_label(opt["ptype"], opt["dims"]), "grade": opt["grade"],
                "length": L, "mark": opt["mark"] or _next_mark(c, opt.get("prefix", "S")), "path": P.tolist(),
                "kgm": SH.kg_per_m(opt["ptype"], opt["dims"], opt["grade"])}
        try:
            b = S.sweep_solid(loops, P, up, getattr(e, "closed", False), "profile", meta)
        except S.SolidError as ex:
            c.msg(f"Profile failed on {e.label}: {ex}"); continue
        b.layer = opt.get("layer", "PROFILE"); c.doc.add_keep(b)
        if opt.get("delete_src", False):
            c.doc.remove(e)
    c.msg(f"Profile {SH.size_label(opt['ptype'], opt['dims'])} created")


def cmd_bracket3d(c):
    W = None; grade = "A (NS)"
    s = yield c.ent("BRACKET  Select connected profile (smaller member) or press Enter to type W", filt=lambda e: e.kind == "body" and e.role == "profile")
    if s is not None:
        m = s[0].meta
        W = D.section_modulus(m["ptype"], m["dims"], c.doc.settings.get("plate_t", 10.0))[0]; grade = m.get("grade", grade)
    else:
        W = yield c.num("Section modulus W of the smaller member (cm3) <100>", 100.0)
    br = D.bracket_size(float(W), grade)
    c.msg(f"W = {float(W):.1f} cm3 -> bracket t = {br['t']:g} mm, arm l = {br['l']:g} mm" + (f", flange b = {br['b']:g} mm" if br["need_flange"] else ""))
    o = yield c.pt("Specify bracket corner (heel) point")
    if o is None:
        return
    a = yield c.pt("Specify direction of first arm", base=o)
    b = yield c.pt("Specify direction of second arm", base=o)
    if a is None or b is None:
        return
    l1 = yield c.dist(f"First arm length <{br['l']:g}>", default=br["l"])
    l2 = yield c.dist(f"Second arm length <{l1:g}>", default=l1)
    u = unit(a - o); w = unit(b - o - np.dot(b - o, u) * u)
    pl = Plane(o, u, w)
    sn = min(25.0, max(15.0, br["t"] * 1.5))
    loop = np.array([[0, 0], [l1, 0], [l1, sn], [sn, l2], [0, l2]])
    t = br["t"]
    meta = {"thk": t, "grade": grade, "mark": _next_mark(c, "BKT"), "side": "0", "plane": pl.to_dict(), "loops": [loop.tolist()],
            "area": abs(poly_area2(loop)), "bracket": True}
    body = S.extrude_region(pl, [loop], -t / 2, t / 2, "plate", meta)
    body.layer = "PLATE"; c.doc.add_keep(body)
    if br["need_flange"]:
        fl = [np.array([[l1, sn], [sn, l2]])]
        d = unit(np.array([sn - l1, l2 - sn])); nrm = np.array([d[1], -d[0]])
        p0 = np.array([l1, sn]); p1 = np.array([sn, l2])
        bw = br["b"]
        quad = np.array([p0, p1, p1 + nrm * 0.1, p0 + nrm * 0.1])
        fpl = Plane(pl.to_world(np.append(p0, 0)), pl.to_world(np.append(p1, 0)) - pl.to_world(np.append(p0, 0)), pl.z)
        Lf = norm(p1 - p0)
        floop = np.array([[0, -bw / 2], [Lf, -bw / 2], [Lf, bw / 2], [0, bw / 2]])
        fb = S.extrude_region(fpl, [floop], 0, -t if np.dot(fpl.z, pl.to_world(np.append(p0 + nrm, 0)) - fpl.o) < 0 else t, "plate",
                              {"thk": t, "grade": grade, "mark": meta["mark"] + "-FL", "side": "+", "area": Lf * bw})
        fb.layer = "PLATE"; c.doc.add_keep(fb)


def cmd_detail(c):
    from .misc import ensure_scale; ensure_scale(c)
    opt = c.app.dialog_detail()
    if not opt:
        return
    p = yield c.pt("Specify insertion point of the detail")
    if p is None:
        return
    pl = c.ucs.copy(); pl.o = v3(p)
    ds = float(opt.get("ds", 10.0))
    ents, info = D.build_detail(opt["kind"], pl, opt["ptype"], opt["dims"], opt["grade"], opt["plate_t"], opt["web_t"],
                                opt.get("t_br"), opt.get("flanged"), opt.get("rule", "BKI / IACS"), ds)
    for L in ("DETAIL",):
        c.doc.ensure_layer(L, 7)
    name = f"DET_{opt['kind'].split()[0].upper()}_{len(c.doc.blocks) + 1}"
    for e in ents:
        e.color = e.color if e.color != 256 else 256
    blk = E.Block(name, p, ents)
    c.doc.add_block(blk)
    from ..core.geom import m_scale
    ins = E.Insert(name, m_scale(p, E.Entity.anno_scale / ds)); ins.layer = "DETAIL"
    c.doc.add_keep(ins)
    c.msg(f"Detail inserted. W = {info['W']:.1f} cm3, bracket t = {info['t']:g} mm, l = {info['l']:g} mm")


# ------------------------------------------------------------------------------------------------ material list / BOM
def collect_bom(doc, ents=None):
    ents = list(doc.ents.values()) if ents is None else ents
    units = doc.settings.get("units", "mm")
    f3 = {"mm": 1e-9, "cm": 1e-6, "m": 1.0, "in": 1.6387e-5, "ft": 0.0283168}.get(units, 1e-9)
    f1 = {"mm": 1e-3, "cm": 1e-2, "m": 1.0, "in": 0.0254, "ft": 0.3048}.get(units, 1e-3)
    groups = {}
    def add(key, item, desc, mat, qty, amount, unit_, kg, marks):
        g = groups.setdefault(key, {"item": item, "desc": desc, "mat": mat, "qty": 0, "amount": 0.0, "unit": unit_, "kg": 0.0, "marks": []})
        g["qty"] += qty; g["amount"] += amount; g["kg"] += kg
        if marks:
            g["marks"].append(marks)
    for e in ents:
        if isinstance(e, Body):
            m = e.meta
            vol = abs(e.volume()) * f3
            if e.role == "plate":
                dens = SH.density(m.get("grade", ""))
                add(("P", m.get("thk"), m.get("grade")), "Plate", f"PL {m.get('thk', 0):g} mm", m.get("grade", ""), 1,
                    m.get("area", 0) * f1 * f1, "m2", vol * dens, m.get("mark", ""))
            elif e.role == "profile":
                dens = SH.density(m.get("grade", ""))
                add(("S", m.get("size"), m.get("grade")), "Profile", m.get("size", ""), m.get("grade", ""), 1, m.get("length", 0) * f1, "m",
                    vol * dens, m.get("mark", ""))
            elif e.role == "pipe":
                add(("PI", m.get("size"), m.get("pipe_std")), "Pipe", f"Pipe {m.get('size', '')}", m.get("pipe_std", ""), 1,
                    m.get("length", 0) * f1, "m", vol * 7850, "")
            elif e.role == "fitting":
                add(("F", m.get("ftype"), m.get("size"), m.get("std", "")), "Fitting", f"{m.get('ftype', '')} {m.get('size', '')}",
                    m.get("std", m.get("pipe_std", "")), 1, 0, "pcs", vol * 7850, "")
            elif e.role == "equipment":
                add(("EQ", m.get("ftype"), m.get("size")), "Equipment", f"{m.get('ftype', '')} {m.get('size', '')}", "", 1,
                    m.get("length", 0) * f1 if "length" in m else 0, "m" if "length" in m else "pcs", vol * 7850 if "Tray" in m.get("ftype", "") else 0, "")
            elif e.role in ("solid", "mesh"):
                add(("SOL", e.layer), "Solid", f"3D solid (layer {e.layer})", "", 1, vol, "m3", vol * 7850, "")
        elif isinstance(e, E.Insert) and e.name.startswith("SYM_"):
            nm = e.name[4:].replace("_", " ").title()
            add(("SYM", e.name), "Symbol", nm, "", 1, 0, "pcs", 0, "")
    rows = []
    for k in sorted(groups, key=lambda k: (["P", "S", "PI", "F", "EQ", "SOL", "SYM"].index(k[0]), str(k[1:]))):
        g = groups[k]; rows.append(g)
    return rows


def bom_table_rows(rows):
    out = [["NO", "ITEM", "DESCRIPTION / SIZE", "MATERIAL", "QTY", "LENGTH / AREA", "WEIGHT (kg)"]]
    tot = 0.0
    for i, g in enumerate(rows):
        amt = "" if g["unit"] == "pcs" else f"{g['amount']:.2f} {g['unit']}"
        out.append([str(i + 1), g["item"], g["desc"], g["mat"], str(g["qty"]), amt, f"{g['kg']:.1f}" if g["kg"] else "-"])
        tot += g["kg"]
    out.append(["", "", "TOTAL", "", "", "", f"{tot:.1f}"])
    return out


def cmd_bom(c):
    from .misc import ensure_scale; ensure_scale(c)
    ents = yield c.sel("BOM  Select objects for the bill of materials <Enter = whole drawing>")
    rows = collect_bom(c.doc, ents if ents else None)
    if not rows:
        c.msg("No plates, profiles, pipes, fittings, equipment or symbols found"); return
    data = bom_table_rows(rows)
    p = yield c.pt("Specify insertion point (top-left corner) of the BOM table")
    if p is None:
        return
    widths = E.Table.fit_widths(data, [10, 20, 50, 26, 12, 26, 24], 2.5, [None, 40, 110, 60, 20, 40, 34])
    t = E.Table(p, data, widths, "BILL OF MATERIALS", 2.5, 7.0, c.ucs.x, c.ucs.z)
    t.aligns = [1, 0, 0, 0, 1, 2, 2]; t.layer = "TEXT"
    c.doc.add_keep(t)


def cmd_matlist(c):
    rows = collect_bom(c.doc)
    c.app.dialog_matlist(rows)


def cmd_colorthk(c):
    v = c.view; v.color_by_thk = not v.color_by_thk; v.invalidate()
    c.msg("Colour by plate thickness: " + ("ON" if v.color_by_thk else "OFF"))


cmd_colorthk.transparent = True


def cmd_flatten(c):
    ents = yield c.sel("FLATTEN  Select planar 3D plates", filt=lambda e: e.kind == "body" and e.role == "plate" and "loops" in e.meta)
    if not ents:
        return
    p = yield c.pt("Specify base point for the flat plates (layout on current UCS)")
    if p is None:
        return
    x = 0.0; gap = 50.0
    for e in ents:
        loops = [np.asarray(l, float) for l in e.meta["loops"]]
        allp = np.vstack(loops); mn = allp.min(axis=0); mx = allp.max(axis=0)
        for l in loops:
            q = l - mn + [x, 0]
            pts = c.ucs.to_world(np.hstack([q, np.zeros((len(q), 1))])) + (v3(p) - c.ucs.o)
            pl = E.Polyline(pts, True, None, c.ucs.z); pl.layer = "CAM"; c.doc.add_keep(pl)
        tx = E.Text(c.ucs.to_world(np.array([x + (mx - mn)[0] / 2, (mx - mn)[1] / 2, 0])) + (v3(p) - c.ucs.o),
                    f"{e.meta.get('mark', '')} PL{e.meta.get('thk', 0):g} {e.meta.get('grade', '')}", 2.5, c.ucs.x, c.ucs.z, 1, 2)
        tx.anno = 2.5; tx.layer = "CAM"; c.doc.add_keep(tx)
        x += (mx - mn)[0] + gap


def register(eng):
    R = eng.register
    R("PLATE3D", cmd_plate3d, ["PLT", "PLATE"], "3D plate from closed curves or surfaces (thickness + IACS grade)")
    R("PLATEHOLE", cmd_platehole, ["PHO", "OPENING"], "Cut openings (manhole, lightening hole) in plates")
    R("PROFILE3D", cmd_profile3d, ["PRF", "PROFILE", "STIFFENER"], "3D profile (FB, L, HP, T, H, C, pipe, RB, SHS) along a path")
    R("BRACKET3D", cmd_bracket3d, ["BKT", "BRACKET"], "3D bracket sized by the rule formula")
    R("DETAIL", cmd_detail, ["DET", "FRAMECONN"], "Standard frame connection details (brackets, slots, collars, scallops, snipes)")
    R("BOM", cmd_bom, [], "Bill of materials table in the drawing")
    R("MATLIST", cmd_matlist, ["MTO"], "Material list / take-off with Excel export")
    R("COLORTHK", cmd_colorthk, [], "Toggle colour by plate thickness")
    R("FLATTEN", cmd_flatten, ["FLT"], "Flat plate outlines for cutting / nesting")
