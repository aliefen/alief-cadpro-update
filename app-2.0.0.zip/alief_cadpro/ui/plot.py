"""Plot - Model: printer / PDF / PNG, paper size, plot area (Display, Extents, Window, Selection), offset, scale,
plot style (monochrome / grayscale / colours), lineweights, orientation, preview and the company title block."""
import math
import os
import datetime
import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, QSizeF, QMarginsF, QLineF, QTimer
from PySide6.QtGui import (QPdfWriter, QPainter, QPen, QColor, QPageSize, QPageLayout, QFont, QPolygonF, QBrush, QImage, QPixmap, QPainterPath,
                           QTransform)
from PySide6.QtWidgets import (QFormLayout, QComboBox, QCheckBox, QLineEdit, QFileDialog, QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
                               QGroupBox, QLabel, QPushButton, QSpinBox, QDoubleSpinBox, QRadioButton, QDialogButtonBox, QInputDialog,
                               QMessageBox, QScrollArea)
from .viewport import resolve_rgb
from ..core import entities as E
from ..core.document import LINETYPES, dash_segments

PAPER_MM = {"ISO A4 (210 x 297 mm)": (210.0, 297.0), "ISO A3 (297 x 420 mm)": (297.0, 420.0), "ISO A2 (420 x 594 mm)": (420.0, 594.0),
            "ISO A1 (594 x 841 mm)": (594.0, 841.0), "ISO A0 (841 x 1189 mm)": (841.0, 1189.0), "ISO B4 (250 x 353 mm)": (250.0, 353.0),
            "ISO B3 (353 x 500 mm)": (353.0, 500.0), "ISO B2 (500 x 707 mm)": (500.0, 707.0), "ISO B1 (707 x 1000 mm)": (707.0, 1000.0),
            "ANSI A Letter (8.5 x 11 in)": (215.9, 279.4), "ANSI B Tabloid (11 x 17 in)": (279.4, 431.8), "ANSI C (17 x 22 in)": (431.8, 558.8),
            "ANSI D (22 x 34 in)": (558.8, 863.6), "ARCH D (24 x 36 in)": (609.6, 914.4), "A1 long (594 x 1189 mm)": (594.0, 1189.0),
            "A0 long (841 x 1682 mm)": (841.0, 1682.0)}
PAPERS = {"A4": QPageSize.A4, "A3": QPageSize.A3, "A2": QPageSize.A2, "A1": QPageSize.A1, "A0": QPageSize.A0}      # old short names
SHORT = {"A4": "ISO A4 (210 x 297 mm)", "A3": "ISO A3 (297 x 420 mm)", "A2": "ISO A2 (420 x 594 mm)", "A1": "ISO A1 (594 x 841 mm)",
         "A0": "ISO A0 (841 x 1189 mm)"}
SCALES = ["1:1", "1:2", "1:5", "1:10", "1:20", "1:25", "1:50", "1:75", "1:100", "1:125", "1:150", "1:200", "1:250", "1:500", "1:1000", "2:1", "5:1", "10:1"]
# monochrome.ctb / grayscale.ctb work like the plot style tables of AutoCAD: they map the index colours (1-255) to
# black / gray, while objects with a TRUE COLOUR keep their colour (symbols of a safety / fire plan stay coloured).
STYLES = ["None (object colours)", "monochrome.ctb", "grayscale.ctb", "acad.ctb (screen colours)", "all black (true colours too)"]
PDF_DEVICE = "ALIEF PDF (vector PDF file)"; PNG_DEVICE = "PNG image file"
DEFAULTS = {"device": PDF_DEVICE, "paper": "ISO A3 (297 x 420 mm)", "landscape": True, "upside": False, "area": "Extents", "window": None,
            "fit": True, "scale": 1.0, "scale_txt": "1:1", "center": True, "offx": 0.0, "offy": 0.0, "style": "monochrome.ctb", "lw": True,
            "tblock": True, "stamp": False, "copies": 1, "title": "", "dno": "AEU-DWG-001", "to_file": True}


def system_printers():
    try:
        from PySide6.QtPrintSupport import QPrinterInfo
        return [p.printerName() for p in QPrinterInfo.availablePrinters()]
    except Exception:
        return []


def page_mm(o):
    w, h = PAPER_MM.get(o["paper"], PAPER_MM["ISO A3 (297 x 420 mm)"])
    if o.get("paper") == "Custom" and o.get("custom"):
        w, h = o["custom"]
    w, h = min(w, h), max(w, h)
    return (h, w) if o.get("landscape", True) else (w, h)


# ============================================================================================================ rendering
def render(app, p, pw, ph, dpmm, o):
    """Draws the plot on painter p: the page is pw x ph mm, dpmm device units per mm. Returns the scale text."""
    doc = app.doc; view = app.view
    mono = o.get("style", "").startswith("monochrome"); gray = o.get("style", "").startswith("grayscale")
    allblack = o.get("style", "").startswith("all black")
    lws = bool(o.get("lw", True)); tblock = bool(o.get("tblock", True))
    p.save()
    if o.get("upside"):
        p.translate(pw * dpmm, ph * dpmm); p.rotate(180)
    m = 10.0 if tblock else 5.0; tb_h = 22.0 if tblock else 0.0
    fx0, fy0, fx1, fy1 = m + (10 if tblock else 0), m, pw - m, ph - m - tb_h      # drawing frame (mm)
    R = view.cam.R
    ents = doc.visible_ents()
    area = o.get("area", "Extents")
    if area == "Selection":
        ents = app.selected_ents() or ents
    ents = [e for e in ents if doc.layer_of(e).plot]
    center = view.cam.target
    if area == "Display":
        hh = view.cam.h; ww = hh * view.cam.W / max(1, view.cam.H)
        x0, x1, y0, y1 = -ww / 2, ww / 2, -hh / 2, hh / 2
    elif area == "Window" and o.get("window") is not None:
        q = (np.asarray(o["window"], float) - center) @ R
        x0, x1 = sorted((q[0, 0], q[1, 0])); y0, y1 = sorted((q[0, 1], q[1, 1]))
    else:
        pts = []
        for e in ents:
            if e.kind == "line" and ((e.xd and e.xd.get("inf")) or abs(e.p1 - e.p0).max() > 4.0e6):
                continue
            bb = e.bbox()
            if bb is not None:
                pts += [np.array([bb[i][0], bb[j][1], bb[k][2]]) for i in (0, 1) for j in (0, 1) for k in (0, 1)]
        P = np.array(pts) if pts else np.zeros((1, 3))
        center = (P.min(axis=0) + P.max(axis=0)) / 2
        q = (P - center) @ R
        x0, x1, y0, y1 = q[:, 0].min(), q[:, 0].max(), q[:, 1].min(), q[:, 1].max()
    inner = 5.0 if tblock else 0.0
    fw, fh = fx1 - fx0 - 2 * inner, fy1 - fy0 - 2 * inner
    if o.get("fit", True):
        k = min(fw / max(x1 - x0, 1e-9), fh / max(y1 - y0, 1e-9))
    else:
        k = 1.0 / max(float(o.get("scale", 1.0)), 1e-12)                  # paper mm per drawing unit
    if o.get("center", True) or o.get("fit", True):
        cxm = (fx0 + fx1) / 2; cym = (fy0 + fy1) / 2
        xm = (x0 + x1) / 2; ym = (y0 + y1) / 2
    else:
        cxm = fx0 + inner + float(o.get("offx", 0.0)); cym = fy1 - inner - float(o.get("offy", 0.0)); xm = x0; ym = y0
    def T(P):
        q = (np.asarray(P, float) - center) @ R
        return np.stack([(cxm + (q[..., 0] - xm) * k) * dpmm, (cym - (q[..., 1] - ym) * k) * dpmm], axis=-1)
    def qcol(c):
        true = isinstance(c, str) and c.startswith("#")
        if allblack or (mono and not true):
            return QColor(0, 0, 0)
        r, g, b = resolve_rgb(c, True)
        if gray and not true:
            v = int((0.299 * r + 0.587 * g + 0.114 * b) * 255); return QColor(v, v, v)
        return QColor(int(r * 255), int(g * 255), int(b * 255))
    lts_g = float(doc.settings.get("ltscale", 1.0) or 1.0)
    layers = doc.layers
    def pen_for(col, lw):
        pen = QPen(col, max(0.13, (lw if lw and lw > 0 else 18) / 100.0) * dpmm); pen.setCapStyle(Qt.RoundCap); pen.setJoinStyle(Qt.RoundJoin)
        return pen
    def draw_segments(S, pen):
        if not len(S):
            return
        A = T(S[:, 0]); B = T(S[:, 1])
        p.setPen(pen); p.setBrush(Qt.NoBrush)
        p.drawLines([QLineF(float(a[0]), float(a[1]), float(b[0]), float(b[1])) for a, b in zip(A, B)])
    def draw_tris(tri, col):
        if not len(tri):
            return
        S = T(tri.reshape(-1, 3)).reshape(-1, 3, 2)
        path = QPainterPath()
        for t in S:
            path.moveTo(float(t[0][0]), float(t[0][1])); path.lineTo(float(t[1][0]), float(t[1][1])); path.lineTo(float(t[2][0]), float(t[2][1])); path.closeSubpath()
        p.setPen(Qt.NoPen); p.setBrush(col); p.drawPath(path)
    def draw(e, parent=None):
        if e.kind == "image":
            img = QImage.fromData(e.data)
            if img.isNull():
                return
            if getattr(e, "brightness", 0) or getattr(e, "contrast", 0):
                from .viewport import adjust_rgba
                im = img.convertToFormat(QImage.Format_RGBA8888)
                buf = np.frombuffer(im.constBits(), np.uint8, im.sizeInBytes()).reshape(im.height(), im.bytesPerLine())[:, :im.width() * 4].reshape(im.height(), im.width(), 4)
                out = np.ascontiguousarray(adjust_rgba(buf, e.brightness, e.contrast))
                img = QImage(out.data, im.width(), im.height(), im.width() * 4, QImage.Format_RGBA8888).copy()
            c = T(e.corners())
            p.save()
            src = QPolygonF([QPointF(0, img.height()), QPointF(img.width(), img.height()), QPointF(img.width(), 0), QPointF(0, 0)])
            dst = QPolygonF([QPointF(*c[i]) for i in range(4)])
            tr = QTransform()
            if QTransform.quadToQuad(src, dst, tr):
                p.setTransform(tr, True); p.setOpacity(1 - e.fade); p.drawImage(0, 0, img)
            p.restore()
            return
        if e.kind == "insert" and e.heavy():
            S, Sg, Tr, Tg, pal = e.heavy_geo()
            S, Sg = e.heavy_disp()                         # with the linetypes of the objects in the block
            pcol = doc.color_of(e) if parent is None else e.color
            for gi, (cc, lay) in enumerate(pal):
                c0 = pcol if cc == 0 else ((layers[lay].color if (lay != "0" and lay in layers) else pcol) if cc in (256, None) else cc)
                col = qcol(c0)
                draw_tris(Tr[Tg == gi], col); draw_segments(S[Sg == gi], pen_for(col, 18))
            return
        if e.kind in ("insert", "detailview", "array"):
            for ch in e.children():
                draw(ch, e)
            return
        c0 = doc.color_of(e) if parent is None else (e.color if e.color not in (256, None) else (doc.layer_of(e).color if e.layer != "0" else doc.color_of(parent)))
        col = qcol(c0)
        lw = doc.lw_of(e) if lws else 25
        pen = pen_for(col, lw)
        if e.kind != "body":
            groups = e.tris_groups() if hasattr(e, "tris_groups") else None
            if groups is None:
                t = e.tris()
                groups = [(t[0], t[1], None)] if t is not None and len(t[1]) else []
            for V, F, gc in groups:
                if len(F):
                    draw_tris(np.asarray(V, float)[np.asarray(F)], col if gc is None else qcol(gc))
        pat = LINETYPES.get(doc.ltype_of(e))
        scale = lts_g * float(getattr(e, "lts", 1.0) or 1.0)
        for wl in (e.wire() if e.kind != "body" else [np.vstack([s[0], s[1]]) for s in e.edges()]):
            if len(wl) < 2:
                continue
            ds = dash_segments(wl, pat, scale) if pat is not None else None
            if ds is not None:
                draw_segments(ds, pen)
            else:
                S = T(wl); p.setPen(pen); p.setBrush(Qt.NoBrush)
                p.drawPolyline(QPolygonF([QPointF(float(s[0]), float(s[1])) for s in S]))
    p.save(); p.setClipRect(QRectF(fx0 * dpmm, fy0 * dpmm, (fx1 - fx0) * dpmm, (fy1 - fy0) * dpmm))
    order = sorted(ents, key=lambda e: ((0 if e.kind == "image" else 1), (e.xd.get("order", 0.0) if e.xd else 0.0)))
    for e in order:
        try:
            draw(e)
        except Exception:
            import traceback; traceback.print_exc()
    p.restore()
    N = 1.0 / k if k > 0 else 0.0
    stxt = (f"1:{N:.4g}" if N >= 1 else f"{k:.4g}:1")
    if o.get("fit", True):
        stxt += " (fit)"
    def txt(x, y, s, size, bold=False):
        f = QFont("Arial"); f.setPixelSize(max(1, int(size * dpmm))); f.setBold(bold); p.setFont(f); p.setPen(QColor(0, 0, 0))
        p.drawText(QPointF(x * dpmm, y * dpmm), s)
    if tblock:
        pen = QPen(QColor(0, 0, 0), 0.5 * dpmm); p.setPen(pen); p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(fx0 * dpmm, m * dpmm, (fx1 - fx0) * dpmm, (ph - 2 * m) * dpmm))
        ty = (ph - m - tb_h) * dpmm
        p.setPen(QPen(QColor(0, 0, 0), 0.35 * dpmm)); p.drawLine(QPointF(fx0 * dpmm, ty), QPointF(fx1 * dpmm, ty))
        wtb = fx1 - fx0
        cols = [fx0, fx0 + min(80, wtb * 0.3), fx1 - min(150, wtb * 0.52), fx1 - min(95, wtb * 0.33), fx1 - min(45, wtb * 0.16), fx1]
        for x in cols[1:-1]:
            p.drawLine(QPointF(x * dpmm, ty), QPointF(x * dpmm, (ph - m) * dpmm))
        try:
            from .brand import draw_mark
            draw_mark(p, (fx0 + 2) * dpmm, ty + 2 * dpmm, 18 * dpmm, 18 * dpmm)
        except Exception:
            pass
        yb = ph - m - tb_h
        txt(fx0 + 22, yb + 8, app.view.opt.get("plot_company") or "PT. ALIEF ENERGY UTAMA", 3.2 if wtb > 250 else 2.4, True)
        txt(fx0 + 22, yb + 13, "Naval Architect & Marine Engineer Consultant", 2.2 if wtb > 250 else 1.6)
        txt(fx0 + 22, yb + 18, "Batam - Indonesia", 2.2 if wtb > 250 else 1.6)
        title = o.get("title", "") or ""
        txt(cols[1] + 3, yb + 6, "TITLE", 2.0); txt(cols[1] + 3, yb + 15, title.upper()[:60], 4.0 if wtb > 250 else 2.8, True)
        txt(cols[2] + 3, yb + 6, "DRAWING NO.", 2.0); txt(cols[2] + 3, yb + 15, o.get("dno", ""), 3.0 if wtb > 250 else 2.2, True)
        txt(cols[3] + 3, yb + 6, "SCALE", 2.0); txt(cols[3] + 3, yb + 15, stxt, 3.0 if wtb > 250 else 2.2, True)
        txt(cols[4] + 3, yb + 6, "DATE / SHEET", 2.0)
        txt(cols[4] + 3, yb + 15, datetime.date.today().strftime("%d-%m-%Y") + ("  " + o.get("paper", "").split(" (")[0].replace("ISO ", "")), 2.6 if wtb > 250 else 1.9, True)
    if o.get("stamp"):
        nm = os.path.basename(doc.path) if doc.path else "Drawing"
        txt(m + 1, ph - 2.0, f"{nm}   {datetime.datetime.now().strftime('%d-%m-%Y %H:%M')}   scale {stxt}   ALIEF CAD PRO", 1.8)
    p.restore()
    return stxt


def preview_image(app, o, px=1400):
    pw, ph = page_mm(o); dpmm = px / max(pw, ph)
    img = QImage(max(1, int(pw * dpmm)), max(1, int(ph * dpmm)), QImage.Format_RGB32); img.fill(QColor(255, 255, 255))
    p = QPainter(img); p.setRenderHint(QPainter.Antialiasing)
    try:
        render(app, p, pw, ph, dpmm, o)
    finally:
        p.end()
    return img


def plot_to_pdf(app, fn, o):
    pw, ph = page_mm(o)
    w = QPdfWriter(fn); w.setResolution(600)
    w.setPageSize(QPageSize(QSizeF(min(pw, ph), max(pw, ph)), QPageSize.Millimeter))
    w.setPageOrientation(QPageLayout.Landscape if pw > ph else QPageLayout.Portrait)
    w.setPageMargins(QMarginsF(0, 0, 0, 0), QPageLayout.Millimeter)
    w.setTitle(o.get("title", "")); w.setCreator("ALIEF CAD PRO")
    p = QPainter(w); p.setRenderHint(QPainter.Antialiasing)
    try:
        return render(app, p, pw, ph, 600 / 25.4, o)
    finally:
        p.end()


def plot_to_png(app, fn, o, dpi=200):
    pw, ph = page_mm(o); dpmm = dpi / 25.4
    while pw * dpmm * ph * dpmm > 120e6:
        dpmm *= 0.8
    img = QImage(int(pw * dpmm), int(ph * dpmm), QImage.Format_RGB32); img.fill(QColor(255, 255, 255))
    p = QPainter(img); p.setRenderHint(QPainter.Antialiasing)
    try:
        s = render(app, p, pw, ph, dpmm, o)
    finally:
        p.end()
    img.setDotsPerMeterX(int(dpmm * 1000)); img.setDotsPerMeterY(int(dpmm * 1000)); img.save(fn)
    return s


def plot_to_printer(app, name, o, to_file=None):
    from PySide6.QtPrintSupport import QPrinter, QPrinterInfo
    info = next((q for q in QPrinterInfo.availablePrinters() if q.printerName() == name), None)
    pr = QPrinter(info, QPrinter.HighResolution) if info is not None else QPrinter(QPrinter.HighResolution)
    pw, ph = page_mm(o)
    pr.setPageSize(QPageSize(QSizeF(min(pw, ph), max(pw, ph)), QPageSize.Millimeter))
    pr.setPageOrientation(QPageLayout.Landscape if pw > ph else QPageLayout.Portrait)
    pr.setFullPage(True); pr.setCopyCount(max(1, int(o.get("copies", 1))))
    pr.setDocName(o.get("title") or "ALIEF CAD PRO drawing")
    if to_file:
        pr.setOutputFileName(to_file)
    p = QPainter()
    if not p.begin(pr):
        raise RuntimeError(f"The printer '{name}' could not be started")
    try:
        p.setRenderHint(QPainter.Antialiasing)
        return render(app, p, pw, ph, pr.resolution() / 25.4, o)
    finally:
        p.end()


def plot_pdf(app, fn, paper="A3", landscape=True, area=0, true_scale=False, mono=True, lws=True, tblock=True, title="", dno=""):
    """Compatibility wrapper of the older plot function."""
    o = dict(DEFAULTS, paper=SHORT.get(paper, paper), landscape=landscape, area=["Extents", "Display", "Selection"][area] if isinstance(area, int) else area,
             fit=not true_scale, scale=E.Entity.anno_scale, style="monochrome.ctb" if mono else STYLES[0], lw=lws, tblock=tblock, title=title, dno=dno)
    plot_to_pdf(app, fn, o)
    return fn


# ============================================================================================================ dialog
class PlotDialog(QDialog):
    """Plot - Model."""
    PICK_WINDOW = 3

    def __init__(self, parent, app, state=None):
        super().__init__(parent); self.setWindowTitle("Plot - Model"); self.app = app
        doc = app.doc
        o = dict(DEFAULTS); o.update(doc.settings.get("plot") or {}); o.update(state or {})
        if not o.get("title"):
            o["title"] = (doc.path and os.path.splitext(os.path.basename(doc.path))[0]) or "DRAWING"
        self.o = o; self.window = o.get("window")
        root = QHBoxLayout(self); left = QVBoxLayout(); right = QVBoxLayout(); root.addLayout(left, 3); root.addLayout(right, 2)
        # ---- page setup
        g = QGroupBox("Page Setup"); h = QHBoxLayout(g); left.addWidget(g)
        self.setup = QComboBox(); self.setup.addItem("<None>"); self.setup.addItems(sorted((doc.settings.get("page_setups") or {}).keys()))
        self.setup.activated.connect(self._load_setup)
        b = QPushButton("Add..."); b.clicked.connect(self._add_setup)
        h.addWidget(QLabel("Name:")); h.addWidget(self.setup, 1); h.addWidget(b)
        # ---- printer
        g = QGroupBox("Printer/Plotter"); f = QGridLayout(g); left.addWidget(g)
        self.dev = QComboBox(); self.dev.addItems([PDF_DEVICE, PNG_DEVICE] + system_printers())
        self.dev.setCurrentText(o["device"] if self.dev.findText(o["device"]) >= 0 else PDF_DEVICE)
        self.dev.currentTextChanged.connect(self._dev_changed)
        self.props = QPushButton("Properties..."); self.props.clicked.connect(self._printer_props)
        f.addWidget(QLabel("Name:"), 0, 0); f.addWidget(self.dev, 0, 1); f.addWidget(self.props, 0, 2)
        self.devinfo = QLabel(); self.devinfo.setStyleSheet("color:#9AA6B6"); f.addWidget(self.devinfo, 1, 1, 1, 2)
        self.tofile = QCheckBox("Plot to File"); self.tofile.setChecked(bool(o.get("to_file", True))); f.addWidget(self.tofile, 2, 0, 1, 2)
        f.setColumnStretch(1, 1)
        row = QHBoxLayout(); left.addLayout(row)
        g = QGroupBox("Paper size"); gv = QVBoxLayout(g); row.addWidget(g, 2)
        self.paper = QComboBox(); self.paper.addItems(list(PAPER_MM)); self.paper.setCurrentText(SHORT.get(o["paper"], o["paper"])); gv.addWidget(self.paper)
        g = QGroupBox("Number of copies"); gv = QVBoxLayout(g); row.addWidget(g, 1)
        self.copies = QSpinBox(); self.copies.setRange(1, 99); self.copies.setValue(int(o.get("copies", 1))); gv.addWidget(self.copies)
        row = QHBoxLayout(); left.addLayout(row)
        col1 = QVBoxLayout(); row.addLayout(col1, 1)
        g = QGroupBox("Plot area"); gv = QGridLayout(g); col1.addWidget(g)
        self.area = QComboBox(); self.area.addItems(["Display", "Extents", "Window", "Selection"]); self.area.setCurrentText(o["area"])
        self.winbtn = QPushButton("Window<"); self.winbtn.clicked.connect(self._pick_window)
        self.winbtn.setToolTip("Pick two corners in the drawing")
        gv.addWidget(QLabel("What to plot:"), 0, 0, 1, 2); gv.addWidget(self.area, 1, 0); gv.addWidget(self.winbtn, 1, 1)
        self.wininfo = QLabel(); self.wininfo.setStyleSheet("color:#9AA6B6"); gv.addWidget(self.wininfo, 2, 0, 1, 2)
        g = QGroupBox("Plot offset (origin set to printable area)"); gv = QGridLayout(g); col1.addWidget(g)
        self.offx = QDoubleSpinBox(); self.offx.setRange(-5000, 5000); self.offx.setDecimals(2); self.offx.setValue(float(o.get("offx", 0)))
        self.offy = QDoubleSpinBox(); self.offy.setRange(-5000, 5000); self.offy.setDecimals(2); self.offy.setValue(float(o.get("offy", 0)))
        self.center = QCheckBox("Center the plot"); self.center.setChecked(bool(o.get("center", True)))
        gv.addWidget(QLabel("X:"), 0, 0); gv.addWidget(self.offx, 0, 1); gv.addWidget(QLabel("Millimeters"), 0, 2); gv.addWidget(self.center, 0, 3)
        gv.addWidget(QLabel("Y:"), 1, 0); gv.addWidget(self.offy, 1, 1); gv.addWidget(QLabel("Millimeters"), 1, 2)
        g = QGroupBox("Plot scale"); gv = QGridLayout(g); row.addWidget(g, 1)
        self.fit = QCheckBox("Fit to paper"); self.fit.setChecked(bool(o.get("fit", True)))
        self.scale = QComboBox(); self.scale.addItems(["User define"] + SCALES)
        self.units = QDoubleSpinBox(); self.units.setRange(1e-6, 1e9); self.units.setDecimals(4); self.units.setValue(float(o.get("scale", 1.0)))
        i = self.scale.findText(o.get("scale_txt", "1:1")); self.scale.setCurrentIndex(i if i >= 0 else 0)
        gv.addWidget(self.fit, 0, 0, 1, 3); gv.addWidget(QLabel("Scale:"), 1, 0); gv.addWidget(self.scale, 1, 1, 1, 2)
        gv.addWidget(QLabel("1"), 2, 0, Qt.AlignRight); gv.addWidget(QLabel("Millimeters  ="), 2, 1); gv.addWidget(self.units, 3, 0, 1, 2); gv.addWidget(QLabel("units"), 3, 2)
        self.scaleinfo = QLabel(); self.scaleinfo.setStyleSheet("color:#9AA6B6"); gv.addWidget(self.scaleinfo, 4, 0, 1, 3)
        g = QGroupBox("Title block"); f2 = QFormLayout(g); left.addWidget(g)
        self.tb = QCheckBox("Border + title block (" + (app.view.opt.get("plot_company") or "PT. ALIEF ENERGY UTAMA") + ")"); self.tb.setChecked(bool(o.get("tblock", True))); f2.addRow(self.tb)
        self.title = QLineEdit(o.get("title", "")); f2.addRow("Drawing title", self.title)
        self.dno = QLineEdit(o.get("dno", "")); f2.addRow("Drawing no.", self.dno)
        # ---- right column
        g = QGroupBox("Preview"); gv = QVBoxLayout(g); right.addWidget(g, 1)
        self.prev = QLabel(); self.prev.setMinimumSize(300, 230); self.prev.setAlignment(Qt.AlignCenter); self.prev.setStyleSheet("background:#3a3f48;")
        gv.addWidget(self.prev, 1)
        g = QGroupBox("Plot style table (pen assignments)"); gv = QVBoxLayout(g); right.addWidget(g)
        self.style = QComboBox(); self.style.addItems(STYLES); self.style.setCurrentText(o["style"] if o["style"] in STYLES else STYLES[1]); gv.addWidget(self.style)
        self.style.setToolTip("monochrome.ctb / grayscale.ctb: index colours (1-255) plot black / gray,\nobjects with a TRUE COLOUR keep their colour (like AutoCAD).\n"
                              "all black: everything black, true colours too.")
        _sl = QLabel("True-colour objects stay coloured with\nmonochrome.ctb / grayscale.ctb"); _sl.setStyleSheet("color:#9AA6B6"); gv.addWidget(_sl)
        g = QGroupBox("Plot options"); gv = QVBoxLayout(g); right.addWidget(g)
        self.lw = QCheckBox("Plot object lineweights"); self.lw.setChecked(bool(o.get("lw", True))); gv.addWidget(self.lw)
        self.stamp = QCheckBox("Plot stamp on (file, date, scale)"); self.stamp.setChecked(bool(o.get("stamp", False))); gv.addWidget(self.stamp)
        self.save = QCheckBox("Save changes to layout"); self.save.setChecked(True); gv.addWidget(self.save)
        g = QGroupBox("Drawing orientation"); gv = QVBoxLayout(g); right.addWidget(g)
        self.portrait = QRadioButton("Portrait"); self.landscape = QRadioButton("Landscape")
        (self.landscape if o.get("landscape", True) else self.portrait).setChecked(True)
        self.upside = QCheckBox("Plot upside-down"); self.upside.setChecked(bool(o.get("upside", False)))
        for wdg in (self.portrait, self.landscape, self.upside):
            gv.addWidget(wdg)
        bb = QHBoxLayout(); right.addLayout(bb)
        b = QPushButton("Preview..."); b.clicked.connect(self._big_preview); bb.addWidget(b)
        b = QPushButton("Apply to Layout"); b.clicked.connect(self._apply); bb.addWidget(b)
        bb2 = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); bb2.button(QDialogButtonBox.Ok).setObjectName("primary")
        bb2.accepted.connect(self.accept); bb2.rejected.connect(self.reject); right.addWidget(bb2)
        self.timer = QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(250); self.timer.timeout.connect(self._preview)
        for wdg in (self.paper, self.area, self.scale, self.style, self.dev):
            wdg.currentIndexChanged.connect(self._changed)
        for wdg in (self.fit, self.center, self.tb, self.lw, self.stamp, self.upside, self.portrait, self.landscape):
            wdg.toggled.connect(self._changed)
        for wdg in (self.offx, self.offy, self.units):
            wdg.valueChanged.connect(self._changed)
        self.scale.currentTextChanged.connect(self._scale_picked)
        self.title.editingFinished.connect(self._changed); self.dno.editingFinished.connect(self._changed)
        self._dev_changed(); self._changed()

    # ---------------------------------------------------------------- state
    def options(self):
        o = dict(self.o)
        o.update(device=self.dev.currentText(), paper=self.paper.currentText(), landscape=self.landscape.isChecked(), upside=self.upside.isChecked(),
                 area=self.area.currentText(), window=self.window, fit=self.fit.isChecked(), scale=float(self.units.value()),
                 scale_txt=self.scale.currentText(), center=self.center.isChecked(), offx=self.offx.value(), offy=self.offy.value(),
                 style=self.style.currentText(), lw=self.lw.isChecked(), tblock=self.tb.isChecked(), stamp=self.stamp.isChecked(),
                 copies=self.copies.value(), title=self.title.text(), dno=self.dno.text(), to_file=self.tofile.isChecked())
        return o

    def _scale_picked(self, t):
        if ":" in t:
            try:
                a, b = t.split(":"); self.units.blockSignals(True); self.units.setValue(float(b) / float(a)); self.units.blockSignals(False)
            except ValueError:
                pass

    def _changed(self, *a):
        fit = self.fit.isChecked()
        for wdg in (self.scale, self.units):
            wdg.setEnabled(not fit)
        self.center.setEnabled(not fit); self.offx.setEnabled(not fit and not self.center.isChecked()); self.offy.setEnabled(not fit and not self.center.isChecked())
        self.winbtn.setEnabled(True)
        if self.area.currentText() == "Window" and self.window is None:
            self.wininfo.setText("No window yet: click Window< and pick two corners")
        elif self.area.currentText() == "Window":
            w = np.asarray(self.window, float); self.wininfo.setText(f"Window {abs(w[1][0] - w[0][0]):.6g} x {abs(w[1][1] - w[0][1]):.6g}")
        else:
            self.wininfo.setText("")
        self.timer.start()

    def _dev_changed(self, *a):
        d = self.dev.currentText(); sys_ = d not in (PDF_DEVICE, PNG_DEVICE)
        self.props.setEnabled(sys_); self.tofile.setEnabled(sys_)
        if not sys_:
            self.tofile.setChecked(True)
        self.copies.setEnabled(sys_)
        self.devinfo.setText("Vector PDF, 600 dpi: lines stay sharp at any zoom" if d == PDF_DEVICE else
                             ("PNG picture, 200 dpi" if d == PNG_DEVICE else "Windows system printer / plotter"))
        if self.dev.count() <= 2:
            self.devinfo.setText(self.devinfo.text() + "\n(no system printer found - plot to PDF and print the PDF)")

    def _printer_props(self):
        try:
            from PySide6.QtPrintSupport import QPrinter, QPrinterInfo, QPrintDialog
            info = next((q for q in QPrinterInfo.availablePrinters() if q.printerName() == self.dev.currentText()), None)
            if info is not None:
                QPrintDialog(QPrinter(info), self).exec()
        except Exception as ex:
            QMessageBox.information(self, "Printer", str(ex))

    def _preview(self):
        try:
            img = preview_image(self.app, self.options(), 700)
            self.prev.setPixmap(QPixmap.fromImage(img).scaled(self.prev.width() - 8, self.prev.height() - 8, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            pw, ph = page_mm(self.options()); self.scaleinfo.setText(f"Paper {pw:g} x {ph:g} mm")
        except Exception as ex:
            self.prev.setText(str(ex))

    def _big_preview(self):
        img = preview_image(self.app, self.options(), 2600)
        d = QDialog(self); d.setWindowTitle("Plot preview"); v = QVBoxLayout(d)
        sa = QScrollArea(); lab = QLabel(); lab.setPixmap(QPixmap.fromImage(img).scaledToWidth(1500, Qt.SmoothTransformation)); sa.setWidget(lab); v.addWidget(sa)
        b = QDialogButtonBox(QDialogButtonBox.Close); b.rejected.connect(d.reject); v.addWidget(b)
        d.resize(1100, 760); d.exec()

    def _pick_window(self):
        self.area.setCurrentText("Window"); self.done(self.PICK_WINDOW)

    def _apply(self):
        o = self.options(); self.app.doc.settings["plot"] = {k: (np.asarray(v).tolist() if isinstance(v, np.ndarray) else v) for k, v in o.items()}
        self.app.doc.modified = True

    def _add_setup(self):
        name, ok = QInputDialog.getText(self, "Add Page Setup", "Name of the page setup:")
        if ok and name.strip():
            ps = dict(self.app.doc.settings.get("page_setups") or {})
            ps[name.strip()] = {k: (np.asarray(v).tolist() if isinstance(v, np.ndarray) else v) for k, v in self.options().items()}
            self.app.doc.settings["page_setups"] = ps; self.app.doc.modified = True
            if self.setup.findText(name.strip()) < 0:
                self.setup.addItem(name.strip())
            self.setup.setCurrentText(name.strip())

    def _load_setup(self, *a):
        ps = (self.app.doc.settings.get("page_setups") or {}).get(self.setup.currentText())
        if ps:
            st = dict(ps); st["title"] = self.title.text()
            self.o = dict(DEFAULTS, **st); self.done(4)                # reopened by the caller with this state

    # ---------------------------------------------------------------- output
    def run(self):
        o = self.options()
        if self.save.isChecked():
            self._apply()
        if o["area"] == "Window" and o.get("window") is None:
            QMessageBox.information(self, "Plot", "Pick the plot window first (Window<)."); return None
        dev = o["device"]; base = (o.get("title") or "drawing").upper()
        if dev == PDF_DEVICE:
            fn, _ = QFileDialog.getSaveFileName(self, "Plot to PDF", base + ".pdf", "PDF (*.pdf)")
            if not fn:
                return None
            plot_to_pdf(self.app, fn, o); return fn
        if dev == PNG_DEVICE:
            fn, _ = QFileDialog.getSaveFileName(self, "Plot to PNG", base + ".png", "PNG (*.png)")
            if not fn:
                return None
            plot_to_png(self.app, fn, o); return fn
        fn = None
        if o.get("to_file"):
            fn, _ = QFileDialog.getSaveFileName(self, "Plot to file", base + ".pdf", "PDF (*.pdf)")
            if not fn:
                return None
        plot_to_printer(self.app, dev, o, fn)
        return fn or f"printer {dev}"
