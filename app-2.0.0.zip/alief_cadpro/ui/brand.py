"""ALIEF CAD PRO product badge (Alief software family scheme: company mark + product-coloured ring + emblem +
product name band). CAD PRO: electric cyan -> violet ring, deep navy disc with a drafting grid, isometric
wire-cube emblem with a CAD crosshair. If resources/Logo_Alief.(png|jpg) exists it is used as the company mark."""
import math
import os
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (QImage, QPainter, QColor, QPen, QBrush, QPainterPath, QFont, QLinearGradient, QRadialGradient,
                           QConicalGradient, QPixmap, QIcon)

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(HERE, "resources")


def company_logo():
    for n in ("Logo_Alief.png", "Logo_Alief.jpg", "Logo_Alief.jpeg"):
        fn = os.path.join(RES, n)
        if os.path.exists(fn):
            img = QImage(fn)
            if not img.isNull():
                return img
    return None


def draw_mark(p, x, y, w, h):
    """Company mark: real logo if available, otherwise the stylised blue / green 'A' with the swoosh."""
    img = company_logo()
    if img is not None:
        im = img.scaled(int(w), int(h), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        p.drawImage(QPointF(x + (w - im.width()) / 2, y + (h - im.height()) / 2), im)
        return
    path = QPainterPath()
    path.moveTo(x + w * 0.50, y + h * 0.02); path.lineTo(x + w * 0.96, y + h * 0.96); path.lineTo(x + w * 0.74, y + h * 0.96)
    path.lineTo(x + w * 0.50, y + h * 0.43); path.lineTo(x + w * 0.27, y + h * 0.96); path.lineTo(x + w * 0.04, y + h * 0.96)
    path.closeSubpath()
    g = QLinearGradient(x, y, x + w, y + h); g.setColorAt(0, QColor("#4C7BFF")); g.setColorAt(1, QColor("#1F48C8"))
    p.setPen(Qt.NoPen); p.fillPath(path, g)
    sw = QPainterPath()
    sw.moveTo(x - w * 0.02, y + h * 0.74)
    sw.cubicTo(x + w * 0.35, y + h * 0.50, x + w * 0.72, y + h * 0.54, x + w * 1.04, y + h * 0.64)
    sw.cubicTo(x + w * 0.70, y + h * 0.62, x + w * 0.38, y + h * 0.64, x + w * 0.05, y + h * 0.84)
    sw.closeSubpath()
    g2 = QLinearGradient(x, y + h * 0.6, x + w, y + h * 0.6); g2.setColorAt(0, QColor("#2BC24F")); g2.setColorAt(1, QColor("#8CE63C"))
    p.fillPath(sw, g2)


def draw_badge(p, S, band=True):
    """Draw the badge into a square of size S at (0,0)."""
    p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
    c = S / 2
    # shadow
    sh = QRadialGradient(c, c + S * 0.03, S * 0.5); sh.setColorAt(0.85, QColor(0, 0, 0, 90)); sh.setColorAt(1, QColor(0, 0, 0, 0))
    p.setPen(Qt.NoPen); p.setBrush(QBrush(sh)); p.drawEllipse(QPointF(c, c + S * 0.02), S * 0.5, S * 0.5)
    # ring
    ring = QConicalGradient(c, c, 120)
    for t, col in ((0, "#22D3FF"), (0.25, "#3B82F6"), (0.5, "#7B5CFF"), (0.75, "#C04CFF"), (1, "#22D3FF")):
        ring.setColorAt(t, QColor(col))
    p.setBrush(QBrush(ring)); p.drawEllipse(QPointF(c, c), S * 0.48, S * 0.48)
    # disc
    disc = QRadialGradient(c * 0.85, c * 0.75, S * 0.55); disc.setColorAt(0, QColor("#1B3A66")); disc.setColorAt(1, QColor("#070F24"))
    p.setBrush(QBrush(disc)); p.drawEllipse(QPointF(c, c), S * 0.42, S * 0.42)
    # drafting grid inside disc
    clip = QPainterPath(); clip.addEllipse(QPointF(c, c), S * 0.42, S * 0.42)
    p.save(); p.setClipPath(clip)
    pen = QPen(QColor(46, 197, 255, 38), max(1.0, S / 400)); p.setPen(pen)
    step = S / 16
    k = 0.0
    while k < S:
        p.drawLine(QPointF(k, 0), QPointF(k, S)); p.drawLine(QPointF(0, k), QPointF(S, k)); k += step
    p.restore()
    # company mark
    draw_mark(p, c - S * 0.25, S * 0.15, S * 0.36, S * 0.36)
    # emblem: isometric wire cube + crosshair (lower right)
    ex, ey, es = c + S * 0.14, c + S * 0.07, S * 0.13
    a = es * 0.87; b = es * 0.5
    top = [(ex, ey - es), (ex + a, ey - b), (ex, ey), (ex - a, ey - b)]
    left = [(ex - a, ey - b), (ex, ey), (ex, ey + es), (ex - a, ey + b)]
    right = [(ex, ey), (ex + a, ey - b), (ex + a, ey + b), (ex, ey + es)]
    for poly, col in ((top, QColor(46, 197, 255, 150)), (left, QColor(59, 130, 246, 120)), (right, QColor(123, 92, 255, 140))):
        pp = QPainterPath(); pp.moveTo(*poly[0])
        for q in poly[1:]:
            pp.lineTo(*q)
        pp.closeSubpath()
        p.fillPath(pp, col)
        p.setPen(QPen(QColor("#E6F7FF"), max(1.2, S / 140))); p.setBrush(Qt.NoBrush); p.drawPath(pp)
    # crosshair
    cx, cy = ex - a * 1.55, ey - es * 0.05
    p.setPen(QPen(QColor("#FFB020"), max(1.2, S / 120)))
    r = S * 0.05
    p.drawLine(QPointF(cx - r * 1.8, cy), QPointF(cx + r * 1.8, cy)); p.drawLine(QPointF(cx, cy - r * 1.8), QPointF(cx, cy + r * 1.8))
    p.setBrush(Qt.NoBrush); p.drawRect(QRectF(cx - r * 0.55, cy - r * 0.55, r * 1.1, r * 1.1))
    if band:
        bw, bh = S * 0.66, S * 0.15
        bx, by = c - bw / 2, S * 0.70
        g = QLinearGradient(bx, 0, bx + bw, 0); g.setColorAt(0, QColor("#0EA5E9")); g.setColorAt(1, QColor("#7C3AED"))
        p.setPen(QPen(QColor("#E6F7FF"), max(1, S / 200))); p.setBrush(QBrush(g)); p.drawRoundedRect(QRectF(bx, by, bw, bh), bh * 0.35, bh * 0.35)
        f = QFont("Segoe UI"); f.setBold(True); f.setPixelSize(int(bh * 0.62)); f.setLetterSpacing(QFont.PercentageSpacing, 104)
        p.setFont(f); p.setPen(QColor("white"))
        p.drawText(QRectF(bx, by, bw, bh), Qt.AlignCenter, "CAD PRO")


def badge_image(S=256, band=True):
    img = QImage(S, S, QImage.Format_ARGB32_Premultiplied); img.fill(Qt.transparent)
    p = QPainter(img); draw_badge(p, S, band); p.end()
    return img


def app_icon():
    ic = QIcon()
    for s in (16, 24, 32, 48, 64, 128, 256):
        ic.addPixmap(QPixmap.fromImage(badge_image(s, band=s >= 32)))
    return ic


def splash_pixmap(version):
    W, H = 640, 360
    img = QImage(W, H, QImage.Format_ARGB32_Premultiplied); img.fill(Qt.transparent)
    p = QPainter(img); p.setRenderHint(QPainter.Antialiasing)
    g = QLinearGradient(0, 0, W, H); g.setColorAt(0, QColor("#0B1630")); g.setColorAt(1, QColor("#1A1F3B"))
    path = QPainterPath(); path.addRoundedRect(QRectF(0, 0, W, H), 14, 14); p.fillPath(path, g)
    p.setPen(QPen(QColor(46, 197, 255, 30), 1))
    for x in range(0, W, 24):
        p.drawLine(x, 0, x, H)
    for y in range(0, H, 24):
        p.drawLine(0, y, W, y)
    p.drawImage(QPointF(36, 60), badge_image(240))
    f = QFont("Segoe UI"); f.setPixelSize(40); f.setBold(True); p.setFont(f); p.setPen(QColor("white"))
    p.drawText(QPointF(300, 150), "ALIEF CAD PRO")
    f.setPixelSize(15); f.setBold(False); p.setFont(f); p.setPen(QColor("#9FDFFF"))
    p.drawText(QPointF(302, 182), "2D  •  Surface  •  3D Solid  •  Plate & Profile")
    p.drawText(QPointF(302, 202), "Piping & Electrical  •  CAM  •  Redraw")
    p.setPen(QColor("#C9D4E5")); f.setPixelSize(13); p.setFont(f)
    p.drawText(QPointF(302, 238), f"Version {version}")
    p.drawText(QPointF(302, 300), "PT. ALIEF ENERGY UTAMA")
    p.setPen(QColor("#7F8DA6")); f.setPixelSize(11); p.setFont(f)
    p.drawText(QPointF(302, 318), "Naval Architect & Marine Engineer Consultant - Batam")
    gb = QLinearGradient(0, H - 6, W, H); gb.setColorAt(0, QColor("#22D3FF")); gb.setColorAt(1, QColor("#7B5CFF"))
    p.fillRect(QRectF(0, H - 5, W, 5), gb)
    p.end()
    return QPixmap.fromImage(img)


def write_ico(path, sizes=(16, 24, 32, 48, 64, 128, 256)):
    """Multi-size Windows .ico with PNG entries."""
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice
    blobs = []
    for s in sizes:
        ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly)
        badge_image(s, band=s >= 32).save(buf, "PNG"); blobs.append((s, bytes(ba)))
    import struct
    head = struct.pack("<HHH", 0, 1, len(blobs))
    off = 6 + 16 * len(blobs)
    dirs = b""; data = b""
    for s, b in blobs:
        dirs += struct.pack("<BBBBHHII", s if s < 256 else 0, s if s < 256 else 0, 0, 0, 1, 32, len(b), off + len(data))
        data += b
    with open(path, "wb") as f:
        f.write(head + dirs + data)
