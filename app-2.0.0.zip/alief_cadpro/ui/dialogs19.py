"""Dialogs of version 1.9: Select Color (Index Color / True Color)."""
from PySide6.QtCore import Qt, QRectF, Signal, QSize
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QColorDialog, QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTabWidget,
                               QVBoxLayout, QWidget)

from ..core.aci import ACI

ACI_NAMES = {1: "red", 2: "yellow", 3: "green", 4: "cyan", 5: "blue", 6: "magenta", 7: "white", 8: "gray", 9: "light gray"}


def aci_qcolor(i):
    c = ACI[int(i) % 256]
    return QColor((c >> 16) & 255, (c >> 8) & 255, c & 255)


class AciGrid(QWidget):
    """The 255 index colours laid out like the Index Color tab of AutoCAD / GstarCAD."""
    picked = Signal(int)
    hovered = Signal(int)

    CELL = 17

    def __init__(self, parent=None):
        super().__init__(parent); self.cur = None; self.setMouseTracking(True)
        c = self.CELL
        self.cells = []                                    # (rect, index)
        # big block: 24 hues x 10 shades; upper half the even indices (light -> dark going up), lower half the odd ones
        for col in range(24):
            base = 10 + col * 10
            for k, sh in enumerate((8, 6, 4, 2, 0)):
                self.cells.append((QRectF(col * c, k * c, c - 1, c - 1), base + sh))
            for k, sh in enumerate((1, 3, 5, 7, 9)):
                self.cells.append((QRectF(col * c, (5 + k) * c + 6, c - 1, c - 1), base + sh))
        y = 10 * c + 18
        for k, i in enumerate(range(1, 10)):
            self.cells.append((QRectF(k * (c + 4), y, c + 2, c + 2), i))
        for k, i in enumerate(range(250, 256)):
            self.cells.append((QRectF((13 + k) * (c + 4), y, c + 2, c + 2), i))
        self.setFixedSize(24 * c + 2, y + c + 8)

    def paintEvent(self, ev):
        p = QPainter(self)
        for r, i in self.cells:
            p.fillRect(r, aci_qcolor(i))
            if i == self.cur:
                p.setPen(QPen(QColor(255, 255, 255), 2)); p.setBrush(Qt.NoBrush); p.drawRect(r.adjusted(-1, -1, 1, 1))
                p.setPen(QPen(QColor(0, 0, 0), 1)); p.drawRect(r.adjusted(1, 1, -1, -1))
        p.end()

    def _at(self, pos):
        for r, i in self.cells:
            if r.contains(pos):
                return i
        return None

    def mouseMoveEvent(self, ev):
        i = self._at(ev.position())
        if i is not None:
            self.hovered.emit(i)

    def mousePressEvent(self, ev):
        i = self._at(ev.position())
        if i is not None:
            self.cur = i; self.update(); self.picked.emit(i)

    def mouseDoubleClickEvent(self, ev):
        i = self._at(ev.position())
        if i is not None:
            self.cur = i; self.picked.emit(i)
            w = self.window()
            if isinstance(w, QDialog):
                w.accept()


class SelectColorDialog(QDialog):
    """Select Color with the tabs Index Color (ACI 1-255, ByLayer, ByBlock) and True Color (any RGB colour).
    value: int (index colour, 256 = ByLayer, 0 = ByBlock) or '#rrggbb' (true colour)."""

    def __init__(self, parent=None, current=7, allow_by=True, title="Select Color"):
        super().__init__(parent); self.setWindowTitle(title)
        self.value = current if current is not None else 7
        v = QVBoxLayout(self)
        self.tabs = QTabWidget(); v.addWidget(self.tabs)
        # ---- Index Color
        t1 = QWidget(); l1 = QVBoxLayout(t1)
        self.grid = AciGrid(); l1.addWidget(self.grid, 0, Qt.AlignHCenter)
        self.hint = QLabel(" "); l1.addWidget(self.hint)
        row = QHBoxLayout()
        if allow_by:
            for txt, val in (("ByLayer", 256), ("ByBlock", 0)):
                b = QPushButton(txt); b.clicked.connect(lambda _=False, val=val: self._set_index(val)); row.addWidget(b)
        row.addStretch(1); row.addWidget(QLabel("Color:"))
        self.edit = QLineEdit(); self.edit.setMaximumWidth(150)
        self.edit.setToolTip("Index 1-255, a colour name (red, yellow ...), ByLayer / ByBlock, or R,G,B for a true colour")
        self.edit.editingFinished.connect(self._typed); row.addWidget(self.edit)
        self.sw = QLabel(); self.sw.setFixedSize(46, 26); row.addWidget(self.sw)
        l1.addLayout(row)
        self.tabs.addTab(t1, "Index Color")
        # ---- True Color
        t2 = QWidget(); l2 = QVBoxLayout(t2)
        self.cd = QColorDialog(self); self.cd.setOptions(QColorDialog.NoButtons | QColorDialog.DontUseNativeDialog)
        self.cd.setWindowFlags(Qt.Widget); l2.addWidget(self.cd)
        self.rgb_lbl = QLabel(""); l2.addWidget(self.rgb_lbl)
        self.cd.currentColorChanged.connect(self._true_changed)
        self.tabs.addTab(t2, "True Color")
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        v.addWidget(bb)
        self.grid.picked.connect(self._set_index)
        self.grid.hovered.connect(lambda i: self.hint.setText(f"Index color: {i}     Red, Green, Blue: {aci_qcolor(i).red()}, {aci_qcolor(i).green()}, {aci_qcolor(i).blue()}"))
        if isinstance(self.value, str) and self.value.startswith("#"):
            self.cd.setCurrentColor(QColor(self.value)); self.tabs.setCurrentIndex(1); self._show(self.value)
        else:
            self._set_index(int(self.value)); self.cd.setCurrentColor(aci_qcolor(int(self.value) if int(self.value) not in (0, 256) else 7))
            self.value = int(current if current is not None else 7)
        self._true_touched = isinstance(self.value, str)

    def _show(self, val):
        if isinstance(val, str):
            c = QColor(val); self.edit.setText(f"{c.red()},{c.green()},{c.blue()}")
        else:
            c = aci_qcolor(val if val not in (0, 256) else 7)
            self.edit.setText("ByLayer" if val == 256 else "ByBlock" if val == 0 else ACI_NAMES.get(val, str(val)))
        self.sw.setStyleSheet(f"background:{c.name()}; border:1px solid #808890")

    def _set_index(self, i):
        self.value = int(i); self.grid.cur = int(i); self.grid.update(); self._show(self.value); self._true_touched = False

    def _typed(self):
        t = self.edit.text().strip().lower()
        if not t:
            return
        inv = {v: k for k, v in ACI_NAMES.items()}
        if t in ("bylayer", "byblock"):
            self._set_index(256 if t == "bylayer" else 0)
        elif t in inv:
            self._set_index(inv[t])
        elif t.isdigit() and 1 <= int(t) <= 255:
            self._set_index(int(t))
        else:
            try:
                r, g, b = [max(0, min(255, int(float(x)))) for x in t.replace(";", ",").split(",")]
            except Exception:
                self._show(self.value); return
            self.value = QColor(r, g, b).name(); self.cd.setCurrentColor(QColor(r, g, b)); self._show(self.value); self._true_touched = True

    def _true_changed(self, c):
        self.rgb_lbl.setText(f"True Color stored as RGB:   Red {c.red()}   Green {c.green()}   Blue {c.blue()}")
        if self.tabs.currentIndex() == 1:
            self.value = c.name(); self._true_touched = True; self._show(self.value)

    def accept(self):
        if self.tabs.currentIndex() == 1:
            self.value = self.cd.currentColor().name()
        elif self.edit.hasFocus():
            self._typed()
        super().accept()


def select_color(parent, current=7, allow_by=True, title="Select Color"):
    """Returns an index colour (int), a true colour ('#rrggbb') or None when cancelled."""
    d = SelectColorDialog(parent, current, allow_by, title)
    return d.value if d.exec() else None
