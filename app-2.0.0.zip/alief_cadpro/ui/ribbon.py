"""Modern ribbon: application button, quick access toolbar, tabs, panels with large / small / split buttons."""
from PySide6.QtCore import Qt, QSize, Signal
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QToolButton, QStackedWidget, QFrame, QLabel, QMenu,
                               QGridLayout, QSizePolicy, QButtonGroup, QLineEdit, QCompleter)
from PySide6.QtGui import QAction
from .icons import icon


def _wrap(text):
    if len(text) <= 9 or " " not in text:
        return text
    words = text.split(" "); best = None
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        m = max(len(a), len(b))
        if best is None or m < best[0]:
            best = (m, a + "\n" + b)
    return best[1]


class RibbonPanel(QFrame):
    """A ribbon panel.  The columns of small buttons adapt to the room there is: full text, icon only (with tooltip)
    or moved to the drop-down of the panel title - a label is never cut to "R...e"."""
    ICON_W = 26

    def __init__(self, title, ribbon, weight=1.0):
        super().__init__(); self.setObjectName("rpanel"); self.ribbon = ribbon; self.weight = weight; self.title = title
        v = QVBoxLayout(self); v.setContentsMargins(4, 3, 4, 1); v.setSpacing(0)
        self.body = QHBoxLayout(); self.body.setSpacing(1); self.body.setContentsMargins(0, 0, 0, 0)
        v.addLayout(self.body, 1)
        tr = QHBoxLayout(); tr.setContentsMargins(0, 0, 0, 0); tr.setSpacing(0)
        t = QLabel(title); t.setObjectName("rpanelTitle"); t.setAlignment(Qt.AlignCenter); tr.addWidget(t, 1)
        self.more = QToolButton(); self.more.setObjectName("rmore"); self.more.setText("\u25BE"); self.more.setAutoRaise(True)
        self.more.setFixedSize(16, 13); self.more.setPopupMode(QToolButton.InstantPopup); self.more.setToolTip(f"More {title} commands")
        self.more_menu = QMenu(self.more); self.more.setMenu(self.more_menu); self.more.setVisible(False)
        tr.addWidget(self.more)
        v.addLayout(tr)
        self._title_w = t.fontMetrics().horizontalAdvance(title) + 26
        self._col = None; self._col_n = 0
        self.cols = []            # [{"w": widget, "btns": [...], "mode": "text"}]
        self.fixed = []           # big buttons and custom widgets

    def _btn(self, cmd, text, ic, tip, big):
        b = QToolButton(); b.setObjectName("rbig" if big else "rsmall")
        b.setIcon(icon(ic or cmd.lower())); b.setAutoRaise(True)
        if big:
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon); b.setIconSize(QSize(30, 30)); b.setText(_wrap(text))
            fm = b.fontMetrics(); tw = max(fm.horizontalAdvance(x) for x in _wrap(text).split("\n"))
            b.setMinimumWidth(max(46, tw + 14)); b.setFixedHeight(72); b.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        else:
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon); b.setIconSize(QSize(16, 16)); b.setText(text); b.setFixedHeight(23)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            b._tw = b.fontMetrics().horizontalAdvance(text) + 16 + 13      # icon + padding: the whole label always fits
            b.setMinimumWidth(b._tw)
        b._label = text.replace("\n", " ")
        cmdname = cmd.split()[0] if cmd else ""
        b.setToolTip(f"<b>{text.replace(chr(10), ' ')}</b><br>{tip or ''}<br><span style='color:#7FB8D8'>Command: {cmdname.upper()}</span>")
        if cmd:
            b.clicked.connect(lambda _=False, c=cmd: self.ribbon.command.emit(c))
        self.ribbon.buttons[cmdname.upper()] = b
        return b

    def big(self, cmd, text, ic=None, tip=""):
        self._col = None
        b = self._btn(cmd, text, ic, tip, True); self.body.addWidget(b); self.fixed.append(b)
        return b

    def _new_col(self):
        w = QWidget(); lay = QVBoxLayout(w); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(1)
        self.body.addWidget(w); self._col = lay; self._col_n = 0
        self.cols.append({"w": w, "btns": [], "mode": "text"})

    def small(self, cmd, text, ic=None, tip=""):
        if self._col is None or self._col_n >= 3:
            self._new_col()
        b = self._btn(cmd, text, ic, tip, False); self._col.addWidget(b); self._col_n += 1
        self.cols[-1]["btns"].append(b)
        return b

    def end_column(self):
        if self._col is not None:
            self._col.addStretch(1)
        self._col = None

    def split(self, text, ic, items, tip="", big=True):
        """Split button: first item is the default action, arrow shows all."""
        self._col = None if big else self._col
        b = self._btn(items[0][2], text, ic, tip, big)
        m = QMenu(b)
        try:
            b.clicked.disconnect()
        except Exception:
            pass
        b._cur = items[0][2]
        b.clicked.connect(lambda _=False, b=b: self.ribbon.command.emit(b._cur))
        def choose(it, b=b):
            # the button keeps the last used item (like AutoCAD): its icon and command, e.g. Linear -> Aligned
            t, i2, c = it[:3]
            b._cur = c; b.setIcon(icon(i2))
            b.setToolTip(f"<b>{t}</b><br><span style='color:#7FB8D8'>Command: {c.split()[0].upper()}</span>")
            self.ribbon.command.emit(c)
        for it in items:
            t, i2, c = it[:3]
            a = m.addAction(icon(i2), t); a.triggered.connect(lambda _=False, it=it: choose(it))
            if len(it) > 3:
                a.setToolTip(it[3])
        b.setMenu(m); b.setPopupMode(QToolButton.MenuButtonPopup)
        if big:
            b.setMinimumWidth(b.minimumWidth() + 12)
            self.body.addWidget(b); self.fixed.append(b)
        else:
            if self._col is None or self._col_n >= 3:
                self._new_col()
            b._tw += 14; b.setMinimumWidth(b._tw); b._split = True
            self._col.addWidget(b); self._col_n += 1; self.cols[-1]["btns"].append(b)
        return b

    def widget(self, w):
        self._col = None; self.body.addWidget(w); self.fixed.append(w)

    # ---------------------------------------------------------------- adaptive width
    def col_width(self, c, mode=None):
        mode = mode or c["mode"]
        if mode == "hidden":
            return 0
        if mode == "icon":
            return max(self.ICON_W + (12 if getattr(b, "_split", False) else 0) for b in c["btns"])
        return max(b._tw for b in c["btns"])

    def natural(self):
        n = 0; k = 0
        for w in self.fixed:
            n += max(w.minimumWidth(), w.sizeHint().width() if not isinstance(w, QToolButton) else w.minimumWidth()); k += 1
        for c in self.cols:
            if c["mode"] != "hidden":
                n += self.col_width(c); k += 1
        return max(n + max(0, k - 1) + 10, self._title_w)

    def set_mode(self, c, mode):
        c["mode"] = mode
        c["w"].setVisible(mode != "hidden")
        for b in c["btns"]:
            if mode == "icon":
                b.setToolButtonStyle(Qt.ToolButtonIconOnly); w = self.ICON_W + (12 if getattr(b, "_split", False) else 0)
                b.setMinimumWidth(w); b.setMaximumWidth(w)
            else:
                b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon); b.setMinimumWidth(b._tw); b.setMaximumWidth(16777215)
        self._menu_refresh()

    def _menu_refresh(self):
        hid = [b for c in self.cols if c["mode"] == "hidden" for b in c["btns"]]
        self.more.setVisible(bool(hid)); self.more_menu.clear()
        for b in hid:
            a = self.more_menu.addAction(b.icon(), b._label); a.triggered.connect(lambda _=False, b=b: b.click())


class RibbonTab(QWidget):
    def __init__(self, ribbon):
        super().__init__(); self.ribbon = ribbon
        self.h = QHBoxLayout(self); self.h.setContentsMargins(4, 2, 4, 2); self.h.setSpacing(2)
        self.h.addStretch(1)
        self.panels = []; self._fit_w = None
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)

    def add_panel(self, title, weight=1.0):
        p = RibbonPanel(title, self.ribbon, weight)
        self.h.insertWidget(self.h.count() - 1, p); self.panels.append(p)
        return p

    def need(self):
        return sum(p.natural() for p in self.panels) + 2 * max(0, len(self.panels) - 1) + 10

    def fit(self, avail=None, force=False):
        """Give every column as much as fits: text first; when the window is narrow the least important columns show
        their icon only, and only when even that is too wide they move to the drop-down of the panel title."""
        avail = self.width() if avail is None else avail
        if avail <= 50 or (avail == self._fit_w and not force):
            return
        self._fit_w = avail
        state = {id(c): "text" for p in self.panels for c in p.cols}
        def need():
            n = 0
            for p in self.panels:
                w = 0; k = 0
                for f in p.fixed:
                    w += max(f.minimumWidth(), f.sizeHint().width() if not isinstance(f, QToolButton) else f.minimumWidth()); k += 1
                for c in p.cols:
                    if state[id(c)] != "hidden":
                        w += p.col_width(c, state[id(c)]); k += 1
                n += max(w + max(0, k - 1) + 10, p._title_w)
            return n + 2 * max(0, len(self.panels) - 1) + 10
        for frm, to in (("text", "icon"), ("icon", "hidden")):
            while need() > avail:
                best = None
                for p in self.panels:
                    cs = [c for c in p.cols if state[id(c)] == frm]
                    keep = 0 if frm == "text" else 1                # one column of every panel stays on the ribbon
                    if len(cs) > keep or (frm == "icon" and len([c for c in p.cols if state[id(c)] != "hidden"]) > 1 and cs):
                        score = (p.weight * len(cs), self.panels.index(p))
                        if best is None or score > best[0]:
                            best = (score, cs[-1])
                if best is None:
                    break
                state[id(best[1])] = to
        for p in self.panels:
            for c in p.cols:
                if c["mode"] != state[id(c)]:
                    p.set_mode(c, state[id(c)])

    def resizeEvent(self, ev):
        super().resizeEvent(ev); self.fit()

    def showEvent(self, ev):
        super().showEvent(ev); self.fit(force=True)


class Ribbon(QWidget):
    command = Signal(str)

    def __init__(self, app_icon, commands_for_search=()):
        super().__init__(); self.setObjectName("ribbon")
        self.buttons = {}
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        top = QWidget(); top.setObjectName("ribbonTop"); th = QHBoxLayout(top); th.setContentsMargins(6, 3, 6, 0); th.setSpacing(2)
        self.app_btn = QToolButton(); self.app_btn.setObjectName("appbtn"); self.app_btn.setIcon(app_icon)
        self.app_btn.setIconSize(QSize(34, 34)); self.app_btn.setPopupMode(QToolButton.InstantPopup); self.app_btn.setToolTip("Application menu")
        self.app_menu = QMenu(self.app_btn); self.app_btn.setMenu(self.app_menu)
        th.addWidget(self.app_btn)
        self.qat = QHBoxLayout(); self.qat.setSpacing(0); th.addLayout(self.qat)
        th.addSpacing(10)
        self.tabbar = QHBoxLayout(); self.tabbar.setSpacing(0); th.addLayout(self.tabbar)
        th.addStretch(1)
        self.search = QLineEdit(); self.search.setPlaceholderText("\U0001F50D  Command ..."); self.search.setMinimumWidth(110); self.search.setMaximumWidth(200)
        self.search.setClearButtonEnabled(True)
        if commands_for_search:
            comp = QCompleter(sorted(commands_for_search)); comp.setCaseSensitivity(Qt.CaseInsensitive); comp.setFilterMode(Qt.MatchContains)
            self.search.setCompleter(comp)
        self.search.returnPressed.connect(self._search)
        th.addWidget(self.search)
        v.addWidget(top)
        self.stack = QStackedWidget(); self.stack.setObjectName("ribbonBody"); self.stack.setFixedHeight(100)
        self.stack.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)      # the ribbon never forces the window wider
        v.addWidget(self.stack)
        self.group = QButtonGroup(self); self.group.setExclusive(True)
        self.tabs = []

    def _search(self):
        t = self.search.text().strip()
        if t:
            self.command.emit(t.split()[0] if " " not in t or t.upper().split()[0] in self.buttons else t)
            self.search.clear()

    def add_qat(self, cmd, ic, tip):
        b = QToolButton(); b.setObjectName("qat"); b.setIcon(icon(ic)); b.setIconSize(QSize(18, 18)); b.setToolTip(tip); b.setAutoRaise(True)
        b.clicked.connect(lambda _=False, c=cmd: self.command.emit(c)); self.qat.addWidget(b)
        return b

    def add_tab(self, title):
        page = RibbonTab(self)
        idx = self.stack.addWidget(page)
        b = QToolButton(); b.setObjectName("rtab"); b.setText(title.replace("&", "&&")); b.setCheckable(True)
        b.clicked.connect(lambda _=False, i=idx: self._select(i))
        b.mouseDoubleClickEvent = lambda e: self.toggle_collapse()
        f = b.font(); f.setBold(True)
        from PySide6.QtGui import QFontMetrics
        b.setMinimumWidth(QFontMetrics(f).horizontalAdvance(title) + 20)      # never elide a tab title
        self.group.addButton(b); self.tabbar.addWidget(b); self.tabs.append(b)
        if idx == 0:
            b.setChecked(True)
        return page

    def _select(self, i):
        self.stack.setCurrentIndex(i)
        if not self.stack.isVisible():
            self.stack.setVisible(True)

    def select_tab(self, title):
        for i, b in enumerate(self.tabs):
            if b.text().replace("&&", "&") == title:
                b.setChecked(True); self._select(i)

    def set_tab_visible(self, title, vis, select=True):
        """Contextual tabs (Array, Block Editor): shown only while they apply."""
        for i, b in enumerate(self.tabs):
            if b.text().replace("&&", "&") == title:
                was = b.isVisible()
                b.setVisible(vis)
                b.setStyleSheet("QToolButton { color: #06202E; background: #2EC5FF; border-radius: 4px; font-weight: 700; }" if vis else "")
                if vis and select and not was:
                    self._prev_tab = self.stack.currentIndex(); b.setChecked(True); self._select(i)
                elif not vis and self.stack.currentIndex() == i:
                    j = getattr(self, "_prev_tab", 0)
                    j = j if j != i and self.tabs[j].isVisible() else 0
                    self.tabs[j].setChecked(True); self._select(j)

    def toggle_collapse(self):
        self.stack.setVisible(not self.stack.isVisible())
