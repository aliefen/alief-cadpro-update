"""Dialogs of version 1.8: Hatch Pattern Palette (ANSI / ISO / Other Predefined / Custom)."""
import json
import math

import numpy as np
from PySide6.QtCore import Qt, QSize, QPointF, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFileDialog, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
                               QPushButton, QTabWidget, QVBoxLayout, QWidget)

from ..core import hatchpat as HP

_SW = {}


def _char_size(fams):
    """A typical repeat length of a pattern (for the preview scale)."""
    v = []
    for a, x0, y0, dx, dy, d in fams:
        if abs(dy) > 1e-9:
            v.append(abs(dy))
        if d:
            v.append(sum(abs(x) for x in d) / 2.5)
    if not v:
        return 3.175
    return float(np.median(v))


def swatch(name, size=56, pdef=None, light=True):
    """Preview picture of a pattern (black lines on white, like the palettes of AutoCAD / GstarCAD)."""
    key = (name, size, light, bool(pdef))
    if key in _SW and not pdef:
        return _SW[key]
    pm = QPixmap(size, size); pm.fill(QColor("#FFFFFF") if light else QColor("#141A22"))
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    ink = QColor("#000000") if light else QColor("#E6EBF2")
    if name == "SOLID":
        p.fillRect(3, 3, size - 6, size - 6, ink)
    else:
        fams = HP.families(name, pdef)
        sc = (size / 7.0) / max(1e-9, _char_size(fams))
        loop = [np.array([[2, 2], [size - 2, 2], [size - 2, size - 2], [2, size - 2.0]])]
        p.setPen(QPen(ink, 1.0))
        for a, b in HP.segments(loop, fams, sc, 0.0, max_segs=6000):
            if abs(a[0] - b[0]) + abs(a[1] - b[1]) < 0.6:
                p.drawPoint(QPointF(a[0], size - a[1]))
            else:
                p.drawLine(QPointF(a[0], size - a[1]), QPointF(b[0], size - b[1]))
    p.setPen(QPen(QColor("#9AA6B6"), 1)); p.setBrush(Qt.NoBrush); p.drawRect(0, 0, size - 1, size - 1)
    p.end()
    ic = QIcon(pm)
    if not pdef:
        _SW[key] = ic
    return ic


def load_user_patterns(settings):
    try:
        d = json.loads(settings.value("hatch/user_pat", "{}") or "{}")
        for k, (desc, fams) in d.items():
            HP.USER[k] = (desc, [tuple(f[:5]) + (tuple(f[5]),) for f in fams])
    except Exception:
        pass


def save_user_patterns(settings):
    d = {k: [desc, [list(f[:5]) + [list(f[5])] for f in fams]] for k, (desc, fams) in HP.USER.items()}
    settings.setValue("hatch/user_pat", json.dumps(d))


class HatchPalette(QWidget):
    """Tabs ANSI / ISO / Other Predefined / Custom with a picture of every pattern; the description of the pattern under
    the selection is shown below. picked(name) on a click, activated(name) on a double click."""
    picked = Signal(str)
    activated = Signal(str)

    def __init__(self, parent=None, current="ANSI31", settings=None):
        super().__init__(parent); self.settings = settings; self.current = current
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0)
        self.tabs = QTabWidget(); v.addWidget(self.tabs, 1)
        self.lists = {}
        for cat, d in HP.CATEGORIES:
            self._add_tab(cat, list(d))
        self._add_tab("Custom", list(HP.USER))
        cw = self.tabs.widget(self.tabs.count() - 1)
        row = QHBoxLayout(); b = QPushButton("Load .pat file ..."); b.setToolTip("Add the patterns of a .pat file (for example acadiso.pat of AutoCAD,\n"
                                                                                "zwcadiso.pat of ZWCAD or your own) to the Custom tab")
        b.clicked.connect(self._load_pat); row.addWidget(b)
        rm = QPushButton("Remove"); rm.setToolTip("Remove the selected custom pattern from the list"); rm.clicked.connect(self._remove); row.addWidget(rm)
        row.addStretch(1); cw.layout().addLayout(row)
        self.desc = QLabel(""); self.desc.setStyleSheet("padding:4px"); v.addWidget(self.desc)
        self.select(current)

    def _add_tab(self, cat, names):
        w = QWidget(); lv = QVBoxLayout(w); lv.setContentsMargins(4, 4, 4, 4)
        lst = QListWidget(); lst.setViewMode(QListWidget.IconMode); lst.setIconSize(QSize(56, 56)); lst.setGridSize(QSize(92, 84))
        lst.setResizeMode(QListWidget.Adjust); lst.setMovement(QListWidget.Static); lst.setWordWrap(True); lst.setMinimumSize(420, 300)
        for n in names:
            it = QListWidgetItem(swatch(n), n); it.setToolTip(f"{n}  -  {HP.description(n)}"); lst.addItem(it)
        lst.currentItemChanged.connect(lambda it, _p=None: self._cur(it))
        lst.itemDoubleClicked.connect(lambda it: self.activated.emit(it.text()))
        lv.addWidget(lst, 1); self.tabs.addTab(w, cat); self.lists[cat] = lst

    def _cur(self, it):
        if it is None:
            return
        self.current = it.text(); self.desc.setText(f"<b>{it.text()}</b>   {HP.description(it.text())}")
        self.picked.emit(it.text())

    def select(self, name):
        for i, (cat, lst) in enumerate(self.lists.items()):
            for k in range(lst.count()):
                if lst.item(k).text() == name:
                    self.tabs.setCurrentIndex(i); lst.setCurrentRow(k); return
        lst = self.lists["ANSI"]; lst.setCurrentRow(0)

    def _load_pat(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Load hatch patterns", "", "Hatch patterns (*.pat);;All files (*)")
        if not fn:
            return
        try:
            raw = open(fn, "rb").read()
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                text = raw.decode("latin-1")
            pats = HP.parse_pat(text)
        except Exception as ex:
            self.desc.setText(f"Cannot read {fn}: {ex}"); return
        lst = self.lists["Custom"]; have = {lst.item(k).text() for k in range(lst.count())}
        for k, v in pats.items():
            if k == "SOLID":
                continue
            HP.USER[k] = v
            if k not in have:
                it = QListWidgetItem(swatch(k, pdef=v[1]), k); it.setToolTip(f"{k}  -  {v[0]}"); lst.addItem(it)
        if self.settings is not None:
            save_user_patterns(self.settings)
        self.tabs.setCurrentIndex(self.tabs.count() - 1)
        self.desc.setText(f"{len(pats)} pattern(s) loaded from {fn.split('/')[-1]}")

    def _remove(self):
        lst = self.lists["Custom"]; it = lst.currentItem()
        if it is None:
            return
        HP.USER.pop(it.text(), None); lst.takeItem(lst.row(it))
        if self.settings is not None:
            save_user_patterns(self.settings)

    def result(self):
        n = self.current or "ANSI31"
        pdef = HP.USER[n][1] if (n in HP.USER and n not in HP.LIBRARY) else None
        return n, pdef


class HatchPaletteDialog(QDialog):
    def __init__(self, parent, current="ANSI31", settings=None):
        super().__init__(parent); self.setWindowTitle("Hatch Pattern Palette"); self.resize(470, 520)
        v = QVBoxLayout(self); self.pal = HatchPalette(self, current, settings); v.addWidget(self.pal, 1)
        self.pal.activated.connect(lambda _n: self.accept())
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def result_pattern(self):
        return self.pal.result()
