"""Palettes (Properties, Layers, Symbol library, Model browser, Command window): dock on any side, float, tab together and
AUTO-HIDE like AutoCAD - an auto-hidden palette collapses to a tab on the window edge and slides out when the cursor
moves over the tab, then hides again when the cursor leaves."""
import time
from PySide6.QtCore import Qt, QTimer, QSize, QRect, QPoint, QPointF, Signal
from PySide6.QtGui import QPainter, QColor, QPen, QCursor, QFont, QFontMetrics, QIcon, QPixmap, QPolygonF
from PySide6.QtWidgets import (QDockWidget, QWidget, QHBoxLayout, QLabel, QToolButton, QToolBar, QApplication, QLineEdit,
                               QAbstractSpinBox, QSizePolicy)


def _glyph(kind, col="#C9D4E5"):
    pm = QPixmap(32, 32); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing); p.setPen(QPen(QColor(col), 2.6)); p.setBrush(Qt.NoBrush)
    if kind == "close":
        p.drawLine(9, 9, 23, 23); p.drawLine(23, 9, 9, 23)
    elif kind == "float":
        p.drawRect(7, 11, 14, 14); p.drawLine(11, 7, 25, 7); p.drawLine(25, 7, 25, 21)
    elif kind == "pin":            # upright push-pin = palette stays open
        p.drawLine(11, 8, 21, 8); p.drawLine(13, 8, 13, 18); p.drawLine(19, 8, 19, 18); p.drawLine(8, 18, 24, 18); p.drawLine(16, 18, 16, 27)
    else:                           # lying push-pin = auto-hide is on
        p.drawLine(24, 11, 24, 21); p.drawLine(24, 13, 14, 13); p.drawLine(24, 19, 14, 19); p.drawLine(14, 8, 14, 24); p.drawLine(14, 16, 5, 16)
    p.end()
    return QIcon(pm)


class TitleBar(QWidget):
    def __init__(self, dock):
        super().__init__(dock); self.dock = dock; self.setObjectName("palette_title")
        h = QHBoxLayout(self); h.setContentsMargins(8, 2, 4, 2); h.setSpacing(2)
        self.label = QLabel(dock.windowTitle()); self.label.setObjectName("palette_title_label"); h.addWidget(self.label, 1)
        def btn(kind, tip, fn):
            b = QToolButton(); b.setObjectName("palette_btn"); b.setAutoRaise(True); b.setIcon(_glyph(kind)); b.setIconSize(QSize(14, 14))
            b.setToolTip(tip); b.clicked.connect(fn); b.setFocusPolicy(Qt.NoFocus); h.addWidget(b); return b
        self.b_pin = btn("pin", "Auto-hide: collapse this palette to a tab on the window edge", lambda: dock.manager.toggle_autohide(dock))
        self.b_float = btn("float", "Float / dock (you can also drag the title bar or double-click it)", lambda: dock.manager.toggle_float(dock))
        self.b_close = btn("close", "Close (reopen from View > Palettes)", lambda: dock.manager.close(dock))
        if not dock.can_autohide:
            self.b_pin.hide()

    def refresh(self):
        self.b_pin.setIcon(_glyph("unpin" if self.dock.autohide else "pin"))
        self.b_pin.setToolTip("Auto-hide is ON - click to keep the palette open (dock it)" if self.dock.autohide
                              else "Auto-hide: collapse this palette to a tab on the window edge")

    def sizeHint(self):
        return QSize(120, 24)

    def minimumSizeHint(self):
        return QSize(60, 24)


class Palette(QDockWidget):
    def __init__(self, title, widget, main, manager, can_autohide=True):
        super().__init__(title, main); self.setObjectName(title); self.setWidget(widget)
        self.manager = manager; self.can_autohide = can_autohide; self.autohide = False; self.home_area = Qt.RightDockWidgetArea
        self.fly_w = 320
        self.bar = TitleBar(self); self.setTitleBarWidget(self.bar)
        self.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable | QDockWidget.DockWidgetClosable)
        self.topLevelChanged.connect(self._floated)

    def _floated(self, floating):
        # a free-floating palette gets the native window frame (so it can be resized); docked / fly-out palettes use the slim bar
        if self.autohide:
            return
        if floating:
            self.setTitleBarWidget(None)
        elif self.titleBarWidget() is not self.bar:
            self.bar = TitleBar(self); self.setTitleBarWidget(self.bar)


class SideTab(QWidget):
    """Vertical tab of an auto-hidden palette."""
    def __init__(self, dock, manager, left):
        super().__init__(); self.dock = dock; self.manager = manager; self.left = left; self.hot = False
        self.setMouseTracking(True); self.setCursor(Qt.PointingHandCursor); self.setToolTip(f"{dock.windowTitle()} (auto-hide) - move the cursor here")
        f = QFont("Segoe UI"); f.setPixelSize(12); f.setBold(True); self.f = f
        self.tw = QFontMetrics(f).horizontalAdvance(dock.windowTitle())

    def sizeHint(self):
        return QSize(24, self.tw + 26)

    def minimumSizeHint(self):
        return self.sizeHint()

    def enterEvent(self, ev):
        self.hot = True; self.update(); self.manager.flyout(self.dock)

    def leaveEvent(self, ev):
        self.hot = False; self.update()

    def mousePressEvent(self, ev):
        self.manager.flyout(self.dock)

    def paintEvent(self, ev):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        light = self.manager.main.view.light
        bg = QColor("#2EC5FF" if self.hot else ("#DCE6F2" if light else "#263142"))
        p.setPen(Qt.NoPen); p.setBrush(bg); p.drawRoundedRect(self.rect().adjusted(2, 3, -2, -3), 4, 4)
        p.setPen(QColor("#06202E" if self.hot else ("#1E2733" if light else "#D5DEEA"))); p.setFont(self.f)
        p.translate(self.width() / 2, self.height() / 2); p.rotate(90 if not self.left else -90)
        p.drawText(QRect(-self.height() // 2, -self.width() // 2, self.height(), self.width()), Qt.AlignCenter, self.dock.windowTitle())


class PaletteManager:
    def __init__(self, main):
        self.main = main; self.docks = []; self.tabs = {}; self.fly = None; self._away = None
        self.bars = {}
        for area, name in ((Qt.LeftToolBarArea, "autohide_left"), (Qt.RightToolBarArea, "autohide_right")):
            tb = QToolBar(name, main); tb.setObjectName(name); tb.setMovable(False); tb.setFloatable(False); tb.setOrientation(Qt.Vertical)
            tb.toggleViewAction().setVisible(False); tb.setContextMenuPolicy(Qt.PreventContextMenu)
            main.addToolBar(area, tb); tb.hide(); self.bars[area] = tb
        self.timer = QTimer(main); self.timer.setInterval(120); self.timer.timeout.connect(self._poll)

    def add(self, title, widget, area, can_autohide=True):
        d = Palette(title, widget, self.main, self, can_autohide); d.home_area = area
        self.main.addDockWidget(area, d); self.docks.append(d)
        d.dockLocationChanged.connect(lambda a, d=d: self._moved(d, a))
        return d

    def _moved(self, d, area):
        if not d.autohide and area in (Qt.LeftDockWidgetArea, Qt.RightDockWidgetArea, Qt.TopDockWidgetArea, Qt.BottomDockWidgetArea):
            d.home_area = area

    def _bar_for(self, d):
        return self.bars[Qt.LeftToolBarArea if d.home_area == Qt.LeftDockWidgetArea else Qt.RightToolBarArea]

    # ------------------------------------------------------------------ auto-hide
    def toggle_autohide(self, d):
        if d.autohide:
            self.pin(d)
        else:
            self.set_autohide(d)

    def set_autohide(self, d):
        if d.autohide or not d.can_autohide:
            return
        if not d.isFloating():
            a = self.main.dockWidgetArea(d)
            if a in (Qt.LeftDockWidgetArea, Qt.RightDockWidgetArea):
                d.home_area = a
            elif a in (Qt.TopDockWidgetArea, Qt.BottomDockWidgetArea):
                d.home_area = Qt.RightDockWidgetArea
            if d.isVisible() and not d.visibleRegion().isEmpty() and d.width() > 160:
                d.fly_w = d.width()
        d.autohide = True
        if d.titleBarWidget() is not d.bar:
            d.bar = TitleBar(d); d.setTitleBarWidget(d.bar)
        d.bar.refresh(); d.hide()
        bar = self._bar_for(d); left = bar is self.bars[Qt.LeftToolBarArea]
        tab = SideTab(d, self, left); self.tabs[d] = (tab, bar.addWidget(tab)); bar.show()

    def pin(self, d):
        """Leave auto-hide: dock the palette again on its side."""
        if not d.autohide:
            return
        self._drop_tab(d)
        if self.fly is d:
            self.fly = None; self.timer.stop()
        if d.isFloating() and d.width() > 120:
            d.fly_w = d.width()
        d.autohide = False; d.hide(); d.setFloating(False)
        self.main.addDockWidget(d.home_area, d); d.show(); d.bar.refresh()
        self.main.resizeDocks([d], [d.fly_w], Qt.Horizontal)

    def _drop_tab(self, d):
        t = self.tabs.pop(d, None)
        if t:
            bar = self._bar_for(d)
            for b in self.bars.values():
                b.removeAction(t[1])
            t[0].deleteLater()
        for b in self.bars.values():
            b.setVisible(any(self._bar_for(x) is b for x in self.tabs))

    def flyout(self, d):
        if not d.autohide:
            d.show(); d.raise_(); return
        if self.fly is not None and self.fly is not d:
            self.fly.hide()
        self.fly = d; self._away = None
        view = self.main.view; bar = self._bar_for(d)
        top = view.mapToGlobal(QPoint(0, 0)); h = max(240, view.height())
        w = max(220, min(d.fly_w, int(self.main.width() * 0.6)))
        if bar is self.bars[Qt.LeftToolBarArea]:
            x = bar.mapToGlobal(QPoint(bar.width(), 0)).x()
        else:
            x = bar.mapToGlobal(QPoint(0, 0)).x() - w
        if not d.isFloating():
            d.setFloating(True)
        d.setGeometry(x, top.y(), w, h); d.show(); d.raise_()
        self.timer.start()

    def _poll(self):
        d = self.fly
        if d is None or not d.isVisible():
            self.fly = None; self.timer.stop(); return
        if QApplication.activePopupWidget() is not None or QApplication.activeModalWidget() is not None:
            self._away = None; return
        if QApplication.mouseButtons() != Qt.NoButton:
            self._away = None; return
        pos = QCursor.pos()
        inside = d.frameGeometry().adjusted(-8, -8, 8, 8).contains(pos)
        tab = self.tabs.get(d)
        if tab is not None:
            t = tab[0]; inside = inside or QRect(t.mapToGlobal(QPoint(0, 0)), t.size()).contains(pos)
        fw = QApplication.focusWidget()
        editing = isinstance(fw, (QLineEdit, QAbstractSpinBox)) and d.isAncestorOf(fw) and fw.hasFocus() and inside
        if inside or editing:
            self._away = None; return
        if self._away is None:
            self._away = time.time(); return
        if time.time() - self._away > 0.35:
            if d.width() > 120:
                d.fly_w = d.width()
            d.hide(); self.fly = None; self.timer.stop()
            self.main.view.setFocus()

    # ------------------------------------------------------------------ float / close / show
    def toggle_float(self, d):
        if d.autohide:                      # fly-out -> a normal floating palette
            self._drop_tab(d); self.fly = None; self.timer.stop(); d.autohide = False
            g = d.geometry(); d.setTitleBarWidget(None); d.setGeometry(g.adjusted(40, 40, 40, 40)); d.show(); return
        d.setFloating(not d.isFloating())

    def close(self, d):
        if d.autohide:
            self.pin(d)
        d.hide()

    def reveal(self, d):
        """Show a palette (used by PROPERTIES, LAYER, SYMLIB ...): fly it out when it is auto-hidden."""
        if d.autohide:
            self.flyout(d)
        else:
            d.show(); d.raise_()

    def toggle(self, d):
        if d.autohide:
            self.flyout(d)
        elif d.isVisible():
            d.hide()
        else:
            d.show(); d.raise_()

    # ------------------------------------------------------------------ persistence
    def state(self):
        return [d.objectName() + "|" + ("L" if d.home_area == Qt.LeftDockWidgetArea else "R") + "|" + str(int(d.fly_w)) for d in self.docks if d.autohide]

    def restore(self, items):
        by = {d.objectName(): d for d in self.docks}
        for it in items or []:
            try:
                name, side, w = str(it).split("|")
                d = by.get(name)
                if d is not None:
                    d.home_area = Qt.LeftDockWidgetArea if side == "L" else Qt.RightDockWidgetArea; d.fly_w = int(w)
                    self.set_autohide(d)
            except Exception:
                pass

    def unhide_all(self):
        for d in list(self.docks):
            if d.autohide:
                self.pin(d)
