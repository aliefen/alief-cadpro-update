"""Ribbon widgets of the Home tab: the Layers tools with the layer list, and the Properties boxes (colour, lineweight,
linetype) - laid out like AutoCAD / GstarCAD."""
from PySide6.QtCore import Qt, QSize, QEvent, QObject, QRectF, QPointF
from PySide6.QtWidgets import QWidget, QGridLayout, QVBoxLayout, QToolButton, QComboBox
from PySide6.QtGui import QPixmap, QPainter, QIcon, QColor, QPen

from . import icons as IC
from .icons import icon

STATE_W = 74
_state_cache = {}


def layer_state_icon(L, light=False):
    """Bulb (on / off), sun or snowflake (thawed / frozen), padlock, colour box - one picture for the layer list."""
    from .panels import color_icon
    key = (L.on, L.frozen, L.locked, str(L.color), IC._light)
    if key in _state_cache:
        return _state_cache[key]
    pm = QPixmap(STATE_W * 2, 32); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing); p.scale(2, 2)
    q = IC.P(p)
    IC._bulb(q, 8, 6.5, L.on, 0.85); IC._sun(q, 27, 8, not L.frozen, 0.85); IC._lock(q, 45, 7, L.locked, 0.85)
    p.drawPixmap(56, 1, color_icon(L.color, 14).pixmap(14, 14))
    p.end()
    pm.setDevicePixelRatio(2.0)
    _state_cache[key] = QIcon(pm)
    return _state_cache[key]


class _PopupFilter(QObject):
    """Clicks on the bulb / sun / padlock of a layer in the open list toggle that state without closing the list."""
    def __init__(self, tools):
        super().__init__(tools); self.tools = tools

    def eventFilter(self, obj, ev):
        if ev.type() in (QEvent.MouseButtonPress, QEvent.MouseButtonRelease):
            view = self.tools.combo.view(); pos = ev.position().toPoint()
            idx = view.indexAt(pos)
            if idx.isValid():
                x = pos.x() - view.visualRect(idx).left() - 3
                k = 0 if x < 18 else 1 if x < 37 else 2 if x < 55 else None
                if k is not None and x >= 0:
                    if ev.type() == QEvent.MouseButtonRelease:
                        self.tools.toggle(self.tools.combo.itemText(idx.row()), ("on", "frozen", "locked")[k])
                    return True
        return False


class LayerTools(QWidget):
    TOOLS = (("LAYOFF", "layoff", "Off: turn off the layer of a selected object"),
             ("LAYISO", "layiso", "Isolate: only the layers of the selected objects stay visible"),
             ("LAYFRZ", "layfrz", "Freeze the layer of a selected object"),
             ("LAYLCK", "laylck", "Lock the layer of a selected object"),
             ("LAYMCUR", "laymcur", "Make Current: the layer of a selected object becomes the current layer"),
             ("LAYON", "layon", "Turn all layers on"),
             ("LAYUNISO", "layuniso", "Unisolate: restore the layers hidden by Isolate"),
             ("LAYTHW", "laythw", "Thaw all layers"),
             ("LAYULK", "layulk", "Unlock all layers"),
             ("LAYMCH", "laymch", "Layer Match: move the selected objects to the layer of another object"))

    def __init__(self, app, ribbon):
        super().__init__(); self.app = app
        g = QGridLayout(self); g.setContentsMargins(2, 1, 2, 1); g.setHorizontalSpacing(1); g.setVerticalSpacing(1)
        for i, (cmd, ic, tip) in enumerate(self.TOOLS):
            b = QToolButton(); b.setObjectName("rsmall"); b.setAutoRaise(True); b.setIcon(icon(ic)); b.setIconSize(QSize(20, 20))
            b.setFixedSize(28, 23)
            b.setToolTip(f"<b>{tip.split(':')[0] if ':' in tip else tip}</b><br>{tip}<br><span style='color:#7FB8D8'>Command: {cmd}</span>")
            b.clicked.connect(lambda _=False, c=cmd: ribbon.command.emit(c))
            ribbon.buttons[cmd] = b
            g.addWidget(b, i // 5, i % 5)
        self.combo = QComboBox(); self.combo.setIconSize(QSize(STATE_W, 16)); self.combo.setMinimumWidth(150); self.combo.setFixedHeight(23)
        self.combo.setToolTip("Current layer.  With objects selected: their layer - choosing another one moves them there.\n"
                              "In the list, click the bulb / sun / padlock to turn a layer on-off, freeze-thaw or lock-unlock it.")
        self.combo.view().setMinimumWidth(260)
        self._flt = _PopupFilter(self); self.combo.view().viewport().installEventFilter(self._flt)
        self.combo.textActivated.connect(self._chosen)
        g.addWidget(self.combo, 2, 0, 1, 5)
        self._ents = []

    def refresh(self, ents=None, rebuild=True):
        if ents is not None:
            self._ents = list(ents)
        doc = self.app.doc; c = self.combo
        c.blockSignals(True)
        if rebuild or c.count() != len(doc.layers):
            c.clear()
            for n, L in doc.layers.items():
                c.addItem(layer_state_icon(L), n)
        lays = {e.layer for e in self._ents[:5000]}
        if len(lays) == 1:
            c.setCurrentText(next(iter(lays)))
        elif len(lays) > 1:
            c.setCurrentIndex(-1)
        else:
            c.setCurrentText(doc.cur_layer)
        c.blockSignals(False)

    def toggle(self, name, attr):
        doc = self.app.doc; L = doc.layers.get(name)
        if L is None:
            return
        if attr == "frozen" and not L.frozen and name == doc.cur_layer:
            self.app.message("The current layer cannot be frozen"); return
        setattr(L, attr, not getattr(L, attr))
        for e in doc.ents.values():
            if e.layer == name:
                e.touch()
        doc.rev += 1; doc.changed()
        row = self.combo.findText(name)
        if row >= 0:
            self.combo.setItemIcon(row, layer_state_icon(L))
        self.app.layers.refresh(); self.app.view.invalidate(); self.app.view.update()

    def _chosen(self, name):
        doc = self.app.doc
        if name not in doc.layers:
            return
        ents = [e for e in self.app.selected_ents()]
        if ents:                                           # objects selected: they move to the chosen layer
            doc.begin("layer")
            for e in ents:
                if e.layer != name:
                    doc.modify(e); e.layer = name; e.touch()
            doc.end(); self.app.message(f'{len(ents)} object(s) moved to layer "{name}"')
        else:
            doc.cur_layer = name; self.app.layers.refresh(); self.app.refresh_status()
        self.app.view.setFocus()


class PropBoxes(QWidget):
    """Colour, lineweight and linetype: of the selected objects, or - nothing selected - of the objects drawn next."""
    COLORS = [256, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 30, 40, 140, 170, 210, 250]
    LWS = [-1, 0, 13, 18, 25, 35, 50, 70, 100, 140, 200]

    def __init__(self, app):
        super().__init__(); self.app = app; self._ents = []; self._busy = False
        v = QVBoxLayout(self); v.setContentsMargins(2, 1, 2, 1); v.setSpacing(1)
        from .panels import color_icon, color_name
        self.col = QComboBox(); self.lw = QComboBox(); self.lt = QComboBox()
        for w, tip in ((self.col, "Object colour"), (self.lw, "Lineweight"), (self.lt, "Linetype")):
            w.setFixedHeight(23); w.setMinimumWidth(140); w.setToolTip(tip + ": of the selected objects, or of the objects drawn next"); v.addWidget(w)
        for o in self.COLORS:
            self.col.addItem(color_icon(o), color_name(o), o)
        self.col.addItem("Select Color ...", "pick")
        for x in self.LWS:
            self.lw.addItem(self._lw_icon(x), "ByLayer" if x < 0 else f"{x / 100:.2f} mm", x)
        self.lw.setIconSize(QSize(40, 14))
        from ..core.document import LINETYPES, LT_DESC
        from .dialogs16 import linetype_icon
        self.lt.setIconSize(QSize(48, 14))
        for nm in ["ByLayer"] + list(LINETYPES):
            self.lt.addItem(linetype_icon(LINETYPES.get(nm), 48, 14), nm)
            self.lt.setItemData(self.lt.count() - 1, f"{nm}  -  {LT_DESC.get(nm, '')}", Qt.ToolTipRole)
        self.lt.view().setMinimumWidth(220)
        self.col.activated.connect(self._set_col); self.lw.activated.connect(lambda i: self._apply("lw", self.lw.itemData(i)))
        self.lt.textActivated.connect(lambda t: self._apply("ltype", t))

    @staticmethod
    def _lw_icon(x):
        pm = QPixmap(92, 28); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        w = 2.0 if x < 0 else max(1.0, x / 100.0 * 7.0)
        p.setPen(QPen(QColor("#C9D4E2"), w)); p.drawLine(QPointF(4, 14), QPointF(88, 14)); p.end()
        pm.setDevicePixelRatio(2.0)
        return QIcon(pm)

    def refresh(self, ents=None):
        if ents is not None:
            self._ents = list(ents)
        from .panels import color_icon, color_name
        doc = self.app.doc; ents = self._ents
        def common(attr, cur):
            if not ents:
                return cur
            vals = {repr(getattr(e, attr, None)) for e in ents[:2000]}
            return getattr(ents[0], attr) if len(vals) == 1 else None
        for w in (self.col, self.lw, self.lt):
            w.blockSignals(True)
        while self.col.count() > len(self.COLORS) + 1:
            self.col.removeItem(0)
        c0 = common("color", doc.cur_color)
        if c0 is None:
            self.col.setCurrentIndex(-1)
        elif c0 in self.COLORS:
            self.col.setCurrentIndex(self.COLORS.index(c0))
        else:
            self.col.insertItem(0, color_icon(c0), color_name(c0), c0); self.col.setCurrentIndex(0)
        w0 = common("lw", doc.cur_lw)
        self.lw.setCurrentIndex(self.LWS.index(w0) if w0 in self.LWS else -1)
        t0 = common("ltype", doc.cur_ltype)
        i = self.lt.findText(t0) if t0 else -1
        self.lt.setCurrentIndex(i)
        for w in (self.col, self.lw, self.lt):
            w.blockSignals(False)

    def _set_col(self, i):
        d = self.col.itemData(i)
        if d == "pick":
            from .dialogs19 import select_color
            cur = self._ents[0].color if self._ents else self.app.doc.cur_color
            d = select_color(self.app, cur)
            if d is None:
                self.refresh(); return
        self._apply("color", d)

    def _apply(self, attr, val):
        ents = [e for e in self.app.selected_ents()]
        self.app.props._set_all(ents, attr, val)
        self.refresh(ents); self.app.view.setFocus()
