"""Dialogs added in 1.5: Drafting Settings (snap & grid, polar tracking, object snap, selection), Dimension Style Manager,
dynamic block parameter / action manager, Block Authoring Palettes, Select Similar settings."""
import math
import copy
from PySide6.QtCore import Qt, QPointF, QRectF, QSize
from PySide6.QtGui import QPainter, QPen, QColor, QFont, QPolygonF, QBrush
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QLabel, QComboBox, QDoubleSpinBox, QSpinBox,
                               QCheckBox, QLineEdit, QPushButton, QDialogButtonBox, QWidget, QTabWidget, QListWidget, QListWidgetItem,
                               QGroupBox, QInputDialog, QMessageBox, QToolButton, QRadioButton, QButtonGroup, QSizePolicy)
from .icons import icon


def _dspin(v, lo, hi, dec=3, step=1.0, suffix=""):
    s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec); s.setSingleStep(step); s.setValue(float(v))
    if suffix:
        s.setSuffix(" " + suffix)
    return s


def _ispin(v, lo, hi):
    s = QSpinBox(); s.setRange(lo, hi); s.setValue(int(v)); return s


class _Dlg(QDialog):
    def __init__(self, parent, title, w=520):
        super().__init__(parent); self.setWindowTitle(title); self.setMinimumWidth(w)
        self.v = QVBoxLayout(self)

    def buttons(self, ok="OK"):
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText(ok); bb.button(QDialogButtonBox.Ok).setObjectName("primary")
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); self.v.addWidget(bb)
        return bb


# ===================================================================================================== DRAFTING SETTINGS
class DraftingSettingsDialog(_Dlg):
    """AutoCAD DSETTINGS: Snap and Grid / Polar Tracking / Object Snap / Selection."""
    TABS = ("Snap and Grid", "Polar Tracking", "Object Snap", "Selection")

    def __init__(self, app, tab=None):
        super().__init__(app, "Drafting Settings", 560)
        self.app = app; v = app.view; o = dict(v.opt)
        self.tabs = QTabWidget(); self.v.addWidget(self.tabs)
        # ---- snap and grid
        w = QWidget(); g = QGridLayout(w)
        sb = QGroupBox("Snap"); f = QFormLayout(sb)
        self.snap_on = QCheckBox("Snap On (F9)"); self.snap_on.setChecked(v.snap_on); f.addRow(self.snap_on)
        self.sx = _dspin(o.get("snap_step", 10.0), 1e-6, 1e9, 4, 1.0); self.sy = _dspin(o.get("snap_y", 0) or o.get("snap_step", 10.0), 1e-6, 1e9, 4, 1.0)
        self.seq = QCheckBox("Equal X and Y spacing"); self.seq.setChecked(not o.get("snap_y") or abs(float(o.get("snap_y") or 0) - float(o.get("snap_step", 10))) < 1e-12)
        f.addRow("Snap X spacing", self.sx); f.addRow("Snap Y spacing", self.sy); f.addRow(self.seq)
        self.seq.toggled.connect(lambda on: (self.sy.setEnabled(not on), on and self.sy.setValue(self.sx.value())))
        self.sx.valueChanged.connect(lambda val: self.seq.isChecked() and self.sy.setValue(val)); self.sy.setEnabled(not self.seq.isChecked())
        st = QGroupBox("Snap type"); fs = QVBoxLayout(st)
        self.st_grid = QRadioButton("Grid snap (rectangular)"); self.st_polar = QRadioButton("PolarSnap (distance along polar tracking paths)")
        (self.st_polar if o.get("snap_type") == "Polar" else self.st_grid).setChecked(True)
        fs.addWidget(self.st_grid); fs.addWidget(self.st_polar)
        self.pdist = _dspin(o.get("polar_dist", 0.0), 0, 1e9, 4, 1.0); hp = QHBoxLayout(); hp.addWidget(QLabel("Polar distance (0 = snap X)")); hp.addWidget(self.pdist)
        fs.addLayout(hp)
        gb = QGroupBox("Grid"); fg = QFormLayout(gb)
        self.grid_on = QCheckBox("Grid On (F7)"); self.grid_on.setChecked(v.show_grid); fg.addRow(self.grid_on)
        self.gx = _dspin(o.get("grid_x", 0.0), 0, 1e9, 4, 1.0); self.gy = _dspin(o.get("grid_y", 0.0), 0, 1e9, 4, 1.0)
        fg.addRow("Grid X spacing (0 = automatic)", self.gx); fg.addRow("Grid Y spacing (0 = same as X)", self.gy)
        self.gmaj = _ispin(o.get("grid_major", 5), 1, 100); fg.addRow("Major line every", self.gmaj)
        self.gad = QCheckBox("Adaptive grid (coarser when zoomed out)"); self.gad.setChecked(bool(o.get("grid_adaptive", True))); fg.addRow(self.gad)
        g.addWidget(sb, 0, 0); g.addWidget(gb, 0, 1); g.addWidget(st, 1, 0, 1, 2)
        self.tabs.addTab(w, "Snap and Grid")
        # ---- polar tracking
        w = QWidget(); f = QFormLayout(w)
        self.polar_on = QCheckBox("Polar Tracking On (F10)"); self.polar_on.setChecked(v.polar_on); f.addRow(self.polar_on)
        self.pinc = QComboBox(); self.pinc.setEditable(True); self.pinc.addItems(["90", "45", "30", "22.5", "18", "15", "10", "5"])
        self.pinc.setCurrentText(f"{float(o.get('polar_inc', 90)):g}"); f.addRow("Increment angle (deg)", self.pinc)
        self.pextra = QLineEdit(", ".join(f"{float(a):g}" for a in (o.get("polar_extra") or []))); self.pextra.setPlaceholderText("e.g. 12, 75")
        f.addRow("Additional angles", self.pextra)
        self.ppx = _ispin(o.get("polar_px", 10), 2, 40); f.addRow("Acquire distance (pixels)", self.ppx)
        f.addRow(QLabel("While a command asks for the next point, the cursor locks onto the polar angles near it and shows\n"
                        "a dashed tracking path with the distance and angle. Type a number to go exactly that far."))
        self.tabs.addTab(w, "Polar Tracking")
        # ---- object snap
        from .viewport import SNAP_KINDS, SNAP_LABEL
        w = QWidget(); vb = QVBoxLayout(w)
        self.os_on = QCheckBox("Object Snap On (F3)"); self.os_on.setChecked(v.osnap_on); vb.addWidget(self.os_on)
        gg = QGridLayout(); self.os = {}
        for i, k in enumerate(SNAP_KINDS):
            cb = QCheckBox(SNAP_LABEL[k]); cb.setChecked(k in v.snap_modes); self.os[k] = cb
            if hasattr(app, "_snap_icon"):
                cb.setIcon(app._snap_icon(k))
            gg.addWidget(cb, i % 6, i // 6)
        vb.addLayout(gg)
        hb = QHBoxLayout(); b1 = QPushButton("Select All"); b2 = QPushButton("Clear All"); hb.addWidget(b1); hb.addWidget(b2); hb.addStretch(1); vb.addLayout(hb)
        b1.clicked.connect(lambda: [c.setChecked(True) for c in self.os.values()]); b2.clicked.connect(lambda: [c.setChecked(False) for c in self.os.values()])
        f = QFormLayout(); vb.addLayout(f)
        self.ap = _ispin(o.get("aperture", 12), 3, 40); f.addRow("Aperture (pixels)", self.ap)
        self.mk = _ispin(o.get("marker_size", 6), 3, 20); f.addRow("Marker size", self.mk)
        vb.addWidget(QLabel("The snap point of the object under the cursor wins over points of nearby objects.\n"
                            "Nearest keeps a pick exactly on the object when no other snap point is close."))
        vb.addStretch(1)
        self.tabs.addTab(w, "Object Snap")
        # ---- selection
        w = QWidget(); f = QFormLayout(w)
        self.pb = _ispin(o.get("pickbox", 5), 2, 20); f.addRow("Pickbox size (pixels)", self.pb)
        self.sc = QCheckBox("Selection cycling (Ctrl+W): a list appears when several objects lie on top of each other")
        self.sc.setChecked(v.sel_cycling); f.addRow(self.sc)
        self.gm = QCheckBox("Multi-function grip menu (hover over a polyline grip: Add Vertex, Convert to Arc ...)")
        self.gm.setChecked(bool(o.get("grip_menu", True))); f.addRow(self.gm)
        self.tabs.addTab(w, "Selection")
        if tab in self.TABS:
            self.tabs.setCurrentIndex(self.TABS.index(tab))
        self.buttons("OK")

    def apply(self):
        app = self.app; v = app.view; o = v.opt
        o["snap_step"] = self.sx.value(); o["snap_y"] = 0.0 if self.seq.isChecked() else self.sy.value()
        o["snap_type"] = "Polar" if self.st_polar.isChecked() else "Grid"; o["polar_dist"] = self.pdist.value()
        o["grid_x"] = self.gx.value(); o["grid_y"] = self.gy.value(); o["grid_major"] = self.gmaj.value(); o["grid_adaptive"] = self.gad.isChecked()
        try:
            o["polar_inc"] = float(self.pinc.currentText())
        except ValueError:
            pass
        ex = []
        for t in self.pextra.text().replace(";", ",").split(","):
            try:
                ex.append(float(t))
            except ValueError:
                pass
        o["polar_extra"] = ex; o["polar_px"] = self.ppx.value()
        o["aperture"] = self.ap.value(); o["marker_size"] = self.mk.value(); o["pickbox"] = self.pb.value(); o["grip_menu"] = self.gm.isChecked()
        from .viewport import SNAP_KINDS
        modes = [k for k in SNAP_KINDS if self.os[k].isChecked()]
        o["snap_modes"] = modes
        for vw in app.views:
            vw.opt = o if vw is v else dict(o)
            vw.snap_modes = set(modes); vw.aperture = self.ap.value(); vw.polar_inc = o["polar_inc"]
        for attr, cb in (("snap_on", self.snap_on), ("show_grid", self.grid_on), ("polar_on", self.polar_on), ("osnap_on", self.os_on),
                         ("sel_cycling", self.sc)):
            app._set_view_flag(attr, cb.isChecked())
        app._sync_options()


# ===================================================================================================== DIMENSION STYLES
ARROWS = [("closed", "Closed filled"), ("open", "Open"), ("tick", "Architectural tick"), ("oblique", "Oblique"), ("dot", "Dot"),
          ("none", "None")]
STYLE_KEYS = ("th", "asz", "exo", "exe", "gap", "dec", "lfac", "arrow", "dsep", "prefix", "suffix", "dimz", "anno",
              "unit", "rnd", "zlead", "zft", "zin", "aunit", "adec", "azlead", "aztrail", "dli", "se1", "se2", "tad", "talign",
              "alt", "alt_unit", "alt_f", "alt_dec", "alt_prefix", "alt_suffix", "tol", "tol_dec", "tol_up", "tol_lo")


class DimPreview(QWidget):
    """Small drawing of a linear, a radius and an angular dimension with the given style."""
    def __init__(self, style):
        super().__init__(); self.style = style; self.setMinimumSize(250, 190)

    def sizeHint(self):
        return QSize(260, 200)

    def paintEvent(self, ev):
        st = self.style; p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#1C222B"))
        k = 6.0                                         # paper mm -> pixels
        th = float(st.get("th", 2.5)) * k; asz = float(st.get("asz", 2.5)) * k; exo = float(st.get("exo", 1.25)) * k
        exe = float(st.get("exe", 1.25)) * k; gap = float(st.get("gap", 0.8)) * k
        geo = QColor("#DDE3EA"); dim = QColor("#5EC8FF")
        # a part: rectangle with a hole
        x0, y0, x1, y1 = 40, 120, 210, 165
        p.setPen(QPen(geo, 1.6)); p.drawRect(QRectF(x0, y0, x1 - x0, y1 - y0)); p.drawEllipse(QPointF(170, 142), 12, 12)
        yd = y0 - 34
        p.setPen(QPen(dim, 1.1))
        p.drawLine(QPointF(x0, y0 - exo), QPointF(x0, yd - exe)); p.drawLine(QPointF(x1, y0 - exo), QPointF(x1, yd - exe))
        p.drawLine(QPointF(x0, yd), QPointF(x1, yd))
        self._arrow(p, QPointF(x0, yd), 1, asz, dim); self._arrow(p, QPointF(x1, yd), -1, asz, dim)
        txt = self._num(170.0)
        f = QFont("Segoe UI"); f.setPixelSize(max(6, int(th))); p.setFont(f)
        r = QRectF(x0, yd - gap - th * 1.25, x1 - x0, th * 1.25)
        p.setPen(QColor("#F5F7FA")); p.drawText(r, Qt.AlignHCenter | Qt.AlignBottom, txt)
        p.setPen(QPen(dim, 1.1)); p.drawLine(QPointF(170, 142), QPointF(205, 108))
        self._arrow_dir(p, QPointF(170 + 12 * 0.707, 142 - 12 * 0.707), (0.707, -0.707), asz, dim, inward=True)
        f.setPixelSize(max(6, int(th * 0.9))); p.setFont(f); p.setPen(QColor("#F5F7FA"))
        rt = "R" + self._num(12.0); tw = p.fontMetrics().horizontalAdvance(rt)
        tx = min(207.0, self.width() - tw - 4.0)
        if tx < 207.0:                                   # not enough room: put the text above the leader end
            p.drawText(QPointF(tx, 108 - 4), rt)
        else:
            p.drawText(QPointF(tx, 108), rt)
        p.end()

    def _num(self, v):
        from ..core.entities import Dimension
        d = Dimension("linear", [(0, 0, 0), (v, 0, 0), (0, 10, 0)], style=dict(self.style, anno=False))
        return d.text()

    def _arrow(self, p, tip, sgn, asz, col):
        self._arrow_dir(p, tip, (-sgn, 0), asz, col)

    def _arrow_dir(self, p, tip, d, asz, col, inward=False):
        typ = self.style.get("arrow", "closed"); dx, dy = d
        if inward:
            dx, dy = -dx, -dy
        # direction from the tip back along the dimension line
        ux, uy = -dx, -dy
        bx, by = tip.x() + ux * asz, tip.y() + uy * asz
        sx, sy = -uy * asz / 6, ux * asz / 6
        if typ == "closed":
            p.setPen(Qt.NoPen); p.setBrush(col)
            p.drawPolygon(QPolygonF([tip, QPointF(bx + sx, by + sy), QPointF(bx - sx, by - sy)]))
        elif typ == "open":
            p.setPen(QPen(col, 1.1)); p.drawLine(tip, QPointF(bx + sx * 1.6, by + sy * 1.6)); p.drawLine(tip, QPointF(bx - sx * 1.6, by - sy * 1.6))
        elif typ in ("tick", "oblique"):
            h = asz / 2; c = 0.7071
            ax, ay = (ux * c - uy * c) * h, (uy * c + ux * c) * h
            p.setPen(QPen(col, 2.2 if typ == "tick" else 1.1)); p.drawLine(QPointF(tip.x() - ax, tip.y() - ay), QPointF(tip.x() + ax, tip.y() + ay))
        elif typ == "dot":
            p.setPen(Qt.NoPen); p.setBrush(col); p.drawEllipse(tip, asz / 4, asz / 4)
        p.setBrush(Qt.NoBrush)


class DimStyleEdit(_Dlg):
    """Modify Dimension Style: Lines / Symbols and Arrows / Text / Fit / Primary Units / Alternate Units / Tolerances."""
    def __init__(self, parent, name, style):
        from PySide6.QtWidgets import QGroupBox, QGridLayout
        from ..core.entities import DIM_UNITS, DIM_ANGLES
        super().__init__(parent, f"Modify Dimension Style: {name}", 760)
        self.st = dict(style); st = self.st
        dec0 = int(st.get("dec", 0) or 0); adec0 = int(st.get("adec", dec0) or 0); alt0 = int(st.get("alt_dec", 2) or 0)
        tol0 = int(st.get("tol_dec", dec0) or 0)
        h = QHBoxLayout(); self.v.addLayout(h)
        tabs = QTabWidget(); h.addWidget(tabs, 1)
        self.prev = DimPreview(self.st); h.addWidget(self.prev, 0, Qt.AlignTop)
        self.w = {}
        def reg(key, widget):
            self.w[key] = widget
            for sig in ("valueChanged", "currentIndexChanged", "textChanged", "toggled"):
                if hasattr(widget, sig):
                    getattr(widget, sig).connect(self._live); break
            return widget
        def combo(key, items, cur):
            c = QComboBox()
            for it in items:
                c.addItem(it[1], it[0]) if isinstance(it, tuple) else c.addItem(it, it)
            i = c.findData(cur); c.setCurrentIndex(i if i >= 0 else 0)
            return reg(key, c)
        def check(key, text, default=False):
            c = QCheckBox(text); c.setChecked(bool(st.get(key, default))); return reg(key, c)
        def page(title, groups):
            w = QWidget(); v = QVBoxLayout(w)
            for gtitle, rows in groups:
                g = QGroupBox(gtitle); f = QFormLayout(g)
                for label, widget in rows:
                    f.addRow(label, widget) if label else f.addRow(widget)
                v.addWidget(g)
            v.addStretch(1); tabs.addTab(w, title)
        page("Lines", [("Dimension lines", [("Baseline spacing (paper mm)", reg("dli", _dspin(st.get("dli", 3.75), 0, 100, 2, 0.25)))]),
                       ("Extension lines", [("Offset from origin (paper mm)", reg("exo", _dspin(st.get("exo", 1.25), 0, 50, 2, 0.25))),
                                            ("Extend beyond dimension lines", reg("exe", _dspin(st.get("exe", 1.25), 0, 50, 2, 0.25))),
                                            ("", check("se1", "Suppress extension line 1")), ("", check("se2", "Suppress extension line 2"))])])
        page("Symbols and Arrows", [("Arrowheads", [("First / second", combo("arrow", ARROWS, st.get("arrow", "closed"))),
                                                   ("Arrow size (paper mm)", reg("asz", _dspin(st.get("asz", 2.5), 0, 50, 2, 0.25)))])])
        page("Text", [("Text appearance", [("Text height (paper mm)", reg("th", _dspin(st.get("th", 2.5), 0.1, 50, 2, 0.25)))]),
                      ("Text placement", [("Vertical", combo("tad", [("Above", "Above"), ("Centered", "Centered")], st.get("tad", "Above"))),
                                          ("Offset from dimension line", reg("gap", _dspin(st.get("gap", 0.8), 0, 20, 2, 0.1)))]),
                      ("Text alignment", [("", combo("talign", [("Aligned", "Aligned with dimension line"), ("Horizontal", "Horizontal")],
                                                     st.get("talign", "Aligned")))])])
        page("Fit", [("Scale for dimension features", [("", check("anno", "Annotative (sizes follow the drawing scale 1:N)", True))])])
        # ---- primary units (like AutoCAD / GstarCAD)
        self.prec = QComboBox(); reg("dec", self.prec)
        self.unit = combo("unit", DIM_UNITS, st.get("unit", "Decimal")); self.unit.currentIndexChanged.connect(self._fill_prec)
        self.zft = check("zft", "0 feet"); self.zin = check("zin", "0 inches")
        zs = QWidget(); zg = QGridLayout(zs); zg.setContentsMargins(0, 0, 0, 0)
        zg.addWidget(check("zlead", "Leading"), 0, 0); zg.addWidget(check("dimz", "Trailing"), 0, 1); zg.addWidget(self.zft, 1, 0); zg.addWidget(self.zin, 1, 1)
        self.aprec = QComboBox(); reg("adec", self.aprec)
        self.aunit = combo("aunit", DIM_ANGLES, st.get("aunit", "Decimal Degrees")); self.aunit.currentIndexChanged.connect(self._fill_aprec)
        az = QWidget(); ag = QHBoxLayout(az); ag.setContentsMargins(0, 0, 0, 0); ag.addWidget(check("azlead", "Leading")); ag.addWidget(check("aztrail", "Trailing"))
        page("Primary Units", [("Linear dimensions", [("Unit format", self.unit), ("Precision", self.prec),
                                                      ("Decimal separator", combo("dsep", [(".", "'.' (Period)"), (",", "',' (Comma)")], st.get("dsep", "."))),
                                                      ("Round off", reg("rnd", _dspin(st.get("rnd", 0.0), 0, 1e6, 4, 0.5))),
                                                      ("Prefix", reg("prefix", QLineEdit(st.get("prefix", "")))),
                                                      ("Suffix", reg("suffix", QLineEdit(st.get("suffix", ""))))]),
                               ("Measurement scale", [("Scale factor", reg("lfac", _dspin(st.get("lfac", 1.0), 1e-9, 1e9, 6, 0.1)))]),
                               ("Zero suppression", [("", zs)]),
                               ("Angular dimensions", [("Units format", self.aunit), ("Precision", self.aprec), ("Zero suppression", az)])])
        self.altprec = QComboBox(); reg("alt_dec", self.altprec)
        self.altunit = combo("alt_unit", DIM_UNITS, st.get("alt_unit", "Decimal")); self.altunit.currentIndexChanged.connect(self._fill_altprec)
        page("Alternate Units", [("Alternate units", [("", check("alt", "Display alternate units  (shown as 100 [3.94])")),
                                                      ("Unit format", self.altunit), ("Precision", self.altprec),
                                                      ("Multiplier for alt units", reg("alt_f", _dspin(st.get("alt_f", 0.03937007874), 1e-9, 1e9, 8, 0.01))),
                                                      ("Prefix", reg("alt_prefix", QLineEdit(st.get("alt_prefix", "")))),
                                                      ("Suffix", reg("alt_suffix", QLineEdit(st.get("alt_suffix", ""))))])])
        self.tolprec = QComboBox(); reg("tol_dec", self.tolprec)
        for i in range(9):
            self.tolprec.addItem("0" if i == 0 else "0." + "0" * i, i)
        self.tolprec.setCurrentIndex(min(8, max(0, tol0)))
        page("Tolerances", [("Tolerance format", [("Method", combo("tol", ["None", "Symmetrical", "Deviation", "Limits", "Basic"], st.get("tol", "None"))),
                                                  ("Precision", self.tolprec),
                                                  ("Upper value", reg("tol_up", _dspin(st.get("tol_up", 0.0), 0, 1e6, 4, 0.05))),
                                                  ("Lower value", reg("tol_lo", _dspin(st.get("tol_lo", 0.0), 0, 1e6, 4, 0.05)))])])
        self._fill_prec(keep=dec0); self._fill_aprec(keep=adec0)
        self._fill_altprec(keep=alt0)
        tabs.setCurrentIndex(4 if getattr(parent, "_dim_tab_units", False) else 0)
        self.buttons("OK")

    @staticmethod
    def _prec_items(unit):
        if unit in ("Architectural", "Fractional"):
            arch = unit == "Architectural"
            return [((("0'-0\"" if arch else "0") if i == 0 else (("0'-0 " if arch else "0 ") + f"1/{2 ** i}" + ('"' if arch else ""))), i) for i in range(9)]
        if unit == "Engineering":
            return [("0'-0" + ("" if i == 0 else "." + "0" * i) + '"', i) for i in range(9)]
        if unit == "Scientific":
            return [("0" + ("" if i == 0 else "." + "0" * i) + "E+01", i) for i in range(9)]
        return [("0" if i == 0 else "0." + "0" * i, i) for i in range(9)]

    def _fill(self, box, items, keep):
        box.blockSignals(True); cur = box.currentData() if keep is None else keep
        box.clear()
        for t, d in items:
            box.addItem(t, d)
        i = box.findData(cur); box.setCurrentIndex(i if i >= 0 else 0); box.blockSignals(False)

    def _fill_prec(self, *a, keep=None):
        u = self.unit.currentData(); self._fill(self.prec, self._prec_items(u), keep)
        self.zft.setEnabled(u in ("Engineering", "Architectural")); self.zin.setEnabled(u in ("Engineering", "Architectural"))
        self._live()

    def _fill_altprec(self, *a, keep=None):
        self._fill(self.altprec, self._prec_items(self.altunit.currentData()), keep); self._live()

    def _fill_aprec(self, *a, keep=None):
        u = self.aunit.currentData()
        if u == "Degrees Minutes Seconds":
            items = [("0d", 0), ("0d00'", 2), ("0d00'00\"", 4), ("0d00'00.0\"", 5), ("0d00'00.00\"", 6), ("0d00'00.000\"", 7), ("0d00'00.0000\"", 8)]
        else:
            sfx = {"Gradians": "g", "Radians": "r"}.get(u, "")
            items = [(("0" if i == 0 else "0." + "0" * i) + sfx, i) for i in range(9)]
        self._fill(self.aprec, items, keep); self._live()

    def _read(self):
        for k, w in self.w.items():
            if isinstance(w, QDoubleSpinBox):
                self.st[k] = w.value()
            elif isinstance(w, QSpinBox):
                self.st[k] = w.value()
            elif isinstance(w, QCheckBox):
                self.st[k] = w.isChecked()
            elif isinstance(w, QComboBox):
                if w.count() == 0:
                    continue                                 # precision list not filled yet
                self.st[k] = w.currentData() if w.currentData() is not None else w.currentText()
            elif isinstance(w, QLineEdit):
                self.st[k] = w.text()
        return self.st

    def _live(self, *a):
        if not hasattr(self, "prev"):
            return
        self._read(); self.prev.style = self.st; self.prev.update()

    def style(self):
        return self._read()


class DimStyleManager(_Dlg):
    """DIMSTYLE: named dimension styles; Set Current / New / Modify / Rename / Delete. Modifying a style updates its dimensions."""
    def __init__(self, app):
        super().__init__(app, "Dimension Style Manager", 640)
        self.app = app; doc = app.doc
        self.styles = copy.deepcopy(styles_of(doc)); self.cur = doc.settings.get("dimstyle", "Standard")
        h = QHBoxLayout(); self.v.addLayout(h)
        lv = QVBoxLayout(); h.addLayout(lv)
        lv.addWidget(QLabel("Styles:")); self.lst = QListWidget(); self.lst.setMinimumWidth(170); lv.addWidget(self.lst, 1)
        self.curlbl = QLabel(); lv.addWidget(self.curlbl)
        self.prev = DimPreview({}); h.addWidget(self.prev, 1)
        bv = QVBoxLayout(); h.addLayout(bv)
        for txt, fn in (("Set Current", self._setcur), ("New ...", self._new), ("Modify ...", self._mod), ("Rename ...", self._ren),
                        ("Delete", self._del)):
            b = QPushButton(txt); b.clicked.connect(fn); bv.addWidget(b)
        bv.addStretch(1)
        self.lst.currentTextChanged.connect(self._show); self._fill()
        self.v.addWidget(QLabel("Modify updates every dimension that uses the style. New dimensions use the current style."))
        self.buttons("Close")

    def _fill(self, sel=None):
        self.lst.clear()
        for n in sorted(self.styles):
            it = QListWidgetItem(("▶ " if n == self.cur else "   ") + n); it.setData(Qt.UserRole, n); self.lst.addItem(it)
        self.curlbl.setText(f"Current: {self.cur}")
        names = [self.lst.item(i).data(Qt.UserRole) for i in range(self.lst.count())]
        self.lst.setCurrentRow(names.index(sel or self.cur) if (sel or self.cur) in names else 0)

    def _name(self):
        it = self.lst.currentItem()
        return it.data(Qt.UserRole) if it else None

    def _show(self, *_):
        n = self._name()
        if n:
            self.prev.style = self.styles[n]; self.prev.update()

    def _setcur(self):
        n = self._name()
        if n:
            self.cur = n; self._fill(n)

    def _new(self):
        base = self._name() or self.cur
        n, ok = QInputDialog.getText(self, "New dimension style", f"New style name (starts as a copy of {base}):", text=f"Copy of {base}")
        n = (n or "").strip()
        if ok and n and n not in self.styles:
            self.styles[n] = dict(self.styles[base]); d = DimStyleEdit(self, n, self.styles[n])
            if d.exec():
                self.styles[n] = d.style()
            self._fill(n)

    def _mod(self):
        n = self._name()
        if n:
            d = DimStyleEdit(self, n, self.styles[n])
            if d.exec():
                self.styles[n] = d.style(); self._show()

    def _ren(self):
        n = self._name()
        if not n or n == "Standard":
            return
        m, ok = QInputDialog.getText(self, "Rename dimension style", "New name:", text=n)
        m = (m or "").strip()
        if ok and m and m not in self.styles:
            self.styles[m] = self.styles.pop(n)
            if self.cur == n:
                self.cur = m
            self.renamed = getattr(self, "renamed", {}); self.renamed[n] = m
            self._fill(m)

    def _del(self):
        n = self._name()
        if not n or n == "Standard" or n == self.cur:
            QMessageBox.information(self, "Dimension styles", "The Standard style and the current style cannot be deleted."); return
        used = [e for e in self.app.doc.ents.values() if e.kind == "dimension" and e.style.get("name", "Standard") == n]
        if used and QMessageBox.question(self, "Dimension styles", f"{len(used)} dimension(s) use {n}. Delete it and move them to Standard?") != QMessageBox.Yes:
            return
        self.styles.pop(n); self.deleted = getattr(self, "deleted", set()) | {n}; self._fill()

    def apply(self):
        """Write the styles into the drawing and update the dimensions that use them (undoable)."""
        doc = self.app.doc
        ren = getattr(self, "renamed", {}); dele = getattr(self, "deleted", set())
        doc.begin("dimstyle")
        n = 0
        for e in list(doc.ents.values()):
            if e.kind != "dimension":
                continue
            sn = e.style.get("name", "Standard")
            sn2 = ren.get(sn, sn)
            if sn2 in dele:
                sn2 = "Standard"
            st = self.styles.get(sn2)
            if st is None:
                continue
            new = dict(e.style); new.update({k: st[k] for k in STYLE_KEYS if k in st}); new["name"] = sn2
            if new != e.style:
                doc.modify(e); e.style = new; e.touch(); n += 1
        doc.end()
        doc.settings["dimstyles"] = self.styles; doc.settings["dimstyle"] = self.cur
        doc.settings["dim"] = dict(self.styles[self.cur]); doc.modified = True
        doc.changed()
        return n


def styles_of(doc):
    """Named dimension styles of the drawing (the old single 'dim' block becomes 'Standard')."""
    from ..core.entities import DIMSTYLE_DEFAULT
    st = doc.settings.get("dimstyles")
    if not st:
        base = dict(DIMSTYLE_DEFAULT); base.update({"arrow": "closed", "dsep": ".", "prefix": "", "suffix": "", "dimz": False, "anno": True})
        base.update({k: v for k, v in (doc.settings.get("dim") or {}).items() if k in STYLE_KEYS})
        for k in ("rot", "sweep", "axis"):
            base.pop(k, None)
        st = {"Standard": base}
        doc.settings["dimstyles"] = st; doc.settings.setdefault("dimstyle", "Standard")
    return st


# ===================================================================================================== DYNAMIC BLOCK MANAGER
class BlockParamsDialog(_Dlg):
    """Parameters and actions of the block being edited: value sets, delete."""
    def __init__(self, app, be):
        super().__init__(app, f"Parameters & actions - {be['name']}", 620)
        self.app = app; self.be = be; self.changed = False
        self.lst = QListWidget(); self.lst.setMinimumHeight(260); self.v.addWidget(self.lst)
        h = QHBoxLayout(); self.v.addLayout(h)
        for txt, fn in (("Value set ...", self._vset), ("Rename ...", self._ren), ("Delete", self._del)):
            b = QPushButton(txt); b.clicked.connect(fn); h.addWidget(b)
        h.addStretch(1)
        self.v.addWidget(QLabel("Parameters give the grips and the values you can change on each block reference;\n"
                                "actions say which objects move / stretch / scale / rotate / array / flip with them."))
        self._fill(); self.buttons("Close")

    def _fill(self):
        from ..core import dynblock as DB
        self.lst.clear(); self.rows = []
        for p in self.be["params"]:
            it = QListWidgetItem("◆ " + DB.describe(p)); self.lst.addItem(it); self.rows.append(("param", p))
            for a in self.be.get("actions", []):
                if a.get("param") == p["name"]:
                    extra = f"  frame" if a.get("frame") else ""
                    if a.get("spacing"):
                        extra += f"  spacing {a['spacing'][0]:g}" + (f" x {a['spacing'][1]:g}" if a['spacing'][1] else "")
                    if a.get("mult"):
                        extra += f"  x{a['mult']:g}"
                    it = QListWidgetItem(f"      ▸ {a['type'].capitalize()} action  ({len(a.get('tags', []))} object(s)){extra}")
                    self.lst.addItem(it); self.rows.append(("action", a))
        for a in self.be.get("actions", []):
            if a.get("param") not in {p["name"] for p in self.be["params"]}:
                it = QListWidgetItem(f"   (orphan) {a['type']} action"); self.lst.addItem(it); self.rows.append(("action", a))

    def _cur(self):
        r = self.lst.currentRow()
        return self.rows[r] if 0 <= r < len(self.rows) else (None, None)

    def _vset(self):
        k, p = self._cur()
        if k != "param" or p["type"] in ("flip", "visibility", "point"):
            return
        s, ok = QInputDialog.getText(self, "Value set", "Increment, min, max  (e.g. 100, 600, 2400)\nor list: L 600, 800, 1000\n"
                                     "(empty = free value)", text="")
        if not ok:
            return
        for x in ("inc", "min", "max", "list"):
            p.pop(x, None)
        s = s.strip()
        try:
            if s.upper().startswith("L"):
                p["list"] = sorted(float(t) for t in s[1:].replace(";", ",").split(",") if t.strip())
            elif s:
                v = [t.strip() for t in s.split(",")]
                if v[0]:
                    p["inc"] = float(v[0])
                if len(v) > 1 and v[1]:
                    p["min"] = float(v[1])
                if len(v) > 2 and v[2]:
                    p["max"] = float(v[2])
        except ValueError:
            QMessageBox.warning(self, "Value set", "Could not read the numbers"); return
        self.changed = True; self._fill()

    def _ren(self):
        k, p = self._cur()
        if k != "param":
            return
        n, ok = QInputDialog.getText(self, "Rename parameter", "New name:", text=p["name"])
        n = (n or "").strip()
        if ok and n and n not in {q["name"] for q in self.be["params"]}:
            for a in self.be.get("actions", []):
                if a.get("param") == p["name"]:
                    a["param"] = n
            p["name"] = n; self.changed = True; self._fill()

    def _del(self):
        k, x = self._cur()
        if k == "param":
            if QMessageBox.question(self, "Delete", f'Delete parameter "{x["name"]}" and its actions?') != QMessageBox.Yes:
                return
            self.be["params"].remove(x)
            self.be["actions"] = [a for a in self.be.get("actions", []) if a.get("param") != x["name"]]
        elif k == "action":
            self.be["actions"].remove(x)
        else:
            return
        self.changed = True; self._fill()


class AuthoringPalette(QWidget):
    """Block Authoring Palettes: Parameters / Actions / Parameter Sets (buttons run the Block Editor commands)."""
    def __init__(self, app):
        super().__init__(); self.app = app
        v = QVBoxLayout(self); v.setContentsMargins(2, 2, 2, 2)
        tabs = QTabWidget(); tabs.setTabPosition(QTabWidget.West); v.addWidget(tabs)
        def page(items):
            w = QWidget(); l = QVBoxLayout(w); l.setSpacing(2)
            for cmd, label, ic, tip in items:
                b = QToolButton(); b.setText(label); b.setIcon(icon(ic)); b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
                b.setIconSize(QSize(22, 22)); b.setAutoRaise(True); b.setToolTip(tip); b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.clicked.connect(lambda _=False, c=cmd: app.run_command(c)); l.addWidget(b)
            l.addStretch(1); return w
        tabs.addTab(page([("BPPOINT", "Point", "point", "A position that can be moved (with a Move / Stretch action)"),
                          ("BPLINEAR", "Linear", "dimlin", "A distance between two points - Move / Stretch / Scale / Array"),
                          ("BPPOLAR", "Polar", "dimang", "Distance and angle - Move / Stretch / Scale / Array"),
                          ("BPXY", "XY", "rect", "Horizontal and vertical distance - Move / Stretch / Scale / Array"),
                          ("BPROTATION", "Rotation", "rotate", "An angle - Rotate action"),
                          ("BPFLIP", "Flip", "mirror", "Reflection line - Flip action"),
                          ("BPVISIBILITY", "Visibility", "layers", "Visibility states (then States / Hide)")]), "Parameters")
        tabs.addTab(page([("BAMOVE", "Move", "move", "Objects move with the parameter grip"),
                          ("BASTRETCH", "Stretch", "stretch", "Points inside a frame follow the grip (like STRETCH)"),
                          ("BASCALE", "Scale", "scale", "Objects scale with the distance"),
                          ("BAROTATE", "Rotate", "rotate", "Objects rotate with the rotation parameter"),
                          ("BAARRAY", "Array", "array", "Objects repeat along the distance"),
                          ("BAFLIP", "Flip", "mirror", "Objects mirror about the flip line")]), "Actions")
        tabs.addTab(page([("BSLINEARSTRETCH", "Linear Stretch", "stretch", "Linear parameter + stretch action"),
                          ("BSLINEARMOVE", "Linear Move", "move", "Linear parameter + move action"),
                          ("BSLINEARARRAY", "Linear Array", "array", "Linear parameter + array action"),
                          ("BSLINEARSCALE", "Linear Scale", "scale", "Linear parameter + scale action"),
                          ("BSPOLARSTRETCH", "Polar Stretch", "dimang", "Polar parameter + stretch action"),
                          ("BSPOLARMOVE", "Polar Move", "move", "Polar parameter + move action"),
                          ("BSXYSTRETCH", "XY Stretch", "rect", "XY parameter + stretch action"),
                          ("BSXYARRAY", "XY Array", "array", "XY parameter + array action"),
                          ("BSROTATIONSET", "Rotation Set", "rotate", "Rotation parameter + rotate action"),
                          ("BSFLIPSET", "Flip Set", "mirror", "Flip parameter + flip action"),
                          ("BSPOINTMOVE", "Point Move", "point", "Point parameter + move action"),
                          ("BSVISIBILITYSET", "Visibility Set", "layers", "Visibility parameter")]), "Parameter Sets")
        b = QPushButton("Parameters && actions ..."); b.clicked.connect(lambda: app.run_command("BPARAMLIST")); v.addWidget(b)


# ===================================================================================================== SELECT SIMILAR
SIMILAR = [("color", "Color"), ("layer", "Layer"), ("ltype", "Linetype"), ("lw", "Lineweight"),
           ("name", "Name (block name, text font, hatch pattern, plate thickness ...)"), ("style", "Style (dimension style)")]


class SimilarSettingsDialog(_Dlg):
    def __init__(self, app, cur):
        super().__init__(app, "Select Similar Settings", 420)
        self.v.addWidget(QLabel("Objects of the same type are selected when these properties match too:"))
        self.cb = {}
        for k, lbl in SIMILAR:
            c = QCheckBox(lbl); c.setChecked(k in cur); self.v.addWidget(c); self.cb[k] = c
        self.buttons("OK")

    def value(self):
        return [k for k, c in self.cb.items() if c.isChecked()]
