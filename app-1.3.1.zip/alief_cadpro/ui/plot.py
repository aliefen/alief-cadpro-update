"""Plot to PDF (vector) / PNG with paper sizes, scale (fit or 1:N), monochrome and a company title block."""
import math
import datetime
import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, QSizeF, QMarginsF
from PySide6.QtGui import QPdfWriter, QPainter, QPen, QColor, QPageSize, QPageLayout, QFont, QPolygonF, QBrush, QImage
from PySide6.QtWidgets import QFormLayout, QComboBox, QCheckBox, QLineEdit, QFileDialog
from .dialogs import Dlg
from .viewport import resolve_rgb
from ..core import entities as E

PAPERS = {"A4": QPageSize.A4, "A3": QPageSize.A3, "A2": QPageSize.A2, "A1": QPageSize.A1, "A0": QPageSize.A0}


class PlotDialog(Dlg):
    def __init__(self, parent, app):
        super().__init__(parent, "Plot / Print to PDF", 460); self.app = app
        f = QFormLayout(); self.v.addLayout(f)
        self.paper = QComboBox(); self.paper.addItems(list(PAPERS)); o = app.view.opt; self.paper.setCurrentText(o.get("plot_paper", "A3")); f.addRow("Paper", self.paper)
        self.orient = QComboBox(); self.orient.addItems(["Landscape", "Portrait"]); self.orient.setCurrentText(o.get("plot_orient", "Landscape")); f.addRow("Orientation", self.orient)
        self.area = QComboBox(); self.area.addItems(["Extents", "Current display", "Selection"]); f.addRow("Plot area", self.area)
        self.scale = QComboBox(); self.scale.addItems(["Fit to paper", f"Drawing scale 1:{E.Entity.anno_scale:g}"]); self.scale.setCurrentIndex(0 if o.get("plot_scale", "Fit to paper").startswith("Fit") else 1); f.addRow("Scale", self.scale)
        self.mono = QCheckBox("Monochrome (black lines)"); self.mono.setChecked(bool(o.get("plot_mono", True))); f.addRow(self.mono)
        self.lw = QCheckBox("Plot lineweights"); self.lw.setChecked(bool(o.get("plot_lw", True))); f.addRow(self.lw)
        self.tb = QCheckBox("Border + title block (" + (o.get("plot_company") or "company") + ")"); self.tb.setChecked(bool(o.get("plot_title", True))); f.addRow(self.tb)
        self.title = QLineEdit(app.doc.path and __import__("os").path.splitext(__import__("os").path.basename(app.doc.path))[0] or "DRAWING"); f.addRow("Drawing title", self.title)
        self.dno = QLineEdit(o.get("plot_dno", "AEU-DWG-001")); f.addRow("Drawing no.", self.dno)
        self.buttons("Plot ...")

    def run(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Plot to PDF", (self.title.text() or "drawing").upper() + ".pdf", "PDF (*.pdf)")
        if not fn:
            return None
        plot_pdf(self.app, fn, self.paper.currentText(), self.orient.currentIndex() == 0, self.area.currentIndex(),
                 self.scale.currentIndex() == 1, self.mono.isChecked(), self.lw.isChecked(), self.tb.isChecked(), self.title.text(), self.dno.text())
        return fn


def plot_pdf(app, fn, paper="A3", landscape=True, area=0, true_scale=False, mono=True, lws=True, tblock=True, title="", dno=""):
    doc = app.doc; view = app.view
    w = QPdfWriter(fn); w.setResolution(600)
    w.setPageSize(QPageSize(PAPERS[paper])); w.setPageOrientation(QPageLayout.Landscape if landscape else QPageLayout.Portrait)
    w.setPageMargins(QMarginsF(0, 0, 0, 0), QPageLayout.Millimeter)
    w.setTitle(title); w.setCreator("ALIEF CAD PRO")
    p = QPainter(w); p.setRenderHint(QPainter.Antialiasing)
    dpmm = 600 / 25.4
    pr = w.pageLayout().fullRectPoints(); pw_mm = pr.width() / 72 * 25.4; ph_mm = pr.height() / 72 * 25.4
    m = 10.0; tb_h = 22.0 if tblock else 0.0
    fx0, fy0, fx1, fy1 = m + 10, m, pw_mm - m, ph_mm - m - tb_h          # drawing frame (mm), ISO left binding margin
    R = view.cam.R
    ents = doc.visible_ents()
    if area == 2:
        ents = app.selected_ents() or ents
    ents = [e for e in ents if doc.layer_of(e).plot]
    if area == 1:
        c = view.cam.target; hh = view.cam.h; ww = hh * view.cam.W / max(1, view.cam.H)
        x0, x1, y0, y1 = -ww / 2, ww / 2, -hh / 2, hh / 2
        center = c
    else:
        pts = []
        for e in ents:
            bb = e.bbox()
            if bb is not None:
                pts += [np.array([bb[i][0], bb[j][1], bb[k][2]]) for i in (0, 1) for j in (0, 1) for k in (0, 1)]
        P = np.array(pts) if pts else np.zeros((1, 3))
        center = (P.min(axis=0) + P.max(axis=0)) / 2
        q = (P - center) @ R
        x0, x1, y0, y1 = q[:, 0].min(), q[:, 0].max(), q[:, 1].min(), q[:, 1].max()
    fw, fh = fx1 - fx0 - 10, fy1 - fy0 - 10
    if true_scale:
        k = 1.0 / E.Entity.anno_scale
    else:
        k = min(fw / max(x1 - x0, 1e-9), fh / max(y1 - y0, 1e-9))
    cxm = (fx0 + fx1) / 2; cym = (fy0 + fy1) / 2
    xm = (x0 + x1) / 2; ym = (y0 + y1) / 2
    def T(P):
        q = (np.asarray(P, float) - center) @ R
        return np.stack([(cxm + (q[..., 0] - xm) * k) * dpmm, (cym - (q[..., 1] - ym) * k) * dpmm], axis=-1)
    def col(e):
        if mono:
            return QColor(0, 0, 0)
        r, g, b = resolve_rgb(doc.color_of(e), True)
        return QColor(int(r * 255), int(g * 255), int(b * 255))
    p.save(); p.setClipRect(QRectF(fx0 * dpmm, fy0 * dpmm, (fx1 - fx0) * dpmm, (fy1 - fy0) * dpmm))
    for e in ents:
        if e.kind == "image":
            from PySide6.QtGui import QImage as QI
            img = QI.fromData(e.data)
            c = T(e.corners())
            p.save()
            from PySide6.QtGui import QTransform
            src = QPolygonF([QPointF(0, img.height()), QPointF(img.width(), img.height()), QPointF(img.width(), 0), QPointF(0, 0)])
            dst = QPolygonF([QPointF(*c[i]) for i in range(4)])
            tr = QTransform()
            if QTransform.quadToQuad(src, dst, tr):
                p.setTransform(tr, True); p.setOpacity(1 - e.fade); p.drawImage(0, 0, img)
            p.restore()
            continue
        lw = doc.lw_of(e) if lws else 25
        pen = QPen(col(e), max(0.13, (lw if lw > 0 else 18) / 100.0) * dpmm); pen.setCapStyle(Qt.RoundCap); pen.setJoinStyle(Qt.RoundJoin)
        lt = doc.ltype_of(e)
        if lt in ("Dashed", "Hidden"):
            pen.setDashPattern([6, 3])
        elif lt in ("Center", "Phantom", "DashDot"):
            pen.setDashPattern([12, 3, 2, 3])
        p.setPen(pen); p.setBrush(Qt.NoBrush)
        t = e.tris()
        if t is not None and e.kind != "body":
            V, F = t; S = T(V)
            p.setPen(Qt.NoPen); p.setBrush(col(e))
            for f in F:
                p.drawPolygon(QPolygonF([QPointF(*S[i]) for i in f]))
            p.setPen(pen); p.setBrush(Qt.NoBrush)
        for wl in e.wire():
            S = T(wl)
            p.drawPolyline(QPolygonF([QPointF(*s) for s in S]))
    p.restore()
    if tblock:
        pen = QPen(QColor(0, 0, 0), 0.5 * dpmm); p.setPen(pen); p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(fx0 * dpmm, m * dpmm, (fx1 - fx0) * dpmm, (ph_mm - 2 * m) * dpmm))
        ty = (ph_mm - m - tb_h) * dpmm
        p.setPen(QPen(QColor(0, 0, 0), 0.35 * dpmm)); p.drawLine(QPointF(fx0 * dpmm, ty), QPointF(fx1 * dpmm, ty))
        cols = [fx0, fx0 + 80, fx1 - 150, fx1 - 95, fx1 - 45, fx1]
        for x in cols[1:-1]:
            p.drawLine(QPointF(x * dpmm, ty), QPointF(x * dpmm, (ph_mm - m) * dpmm))
        try:
            from .brand import draw_mark
            draw_mark(p, (fx0 + 2) * dpmm, ty + 2 * dpmm, 18 * dpmm, 18 * dpmm)
        except Exception:
            pass
        def txt(x, y, s, size, bold=False):
            f = QFont("Arial"); f.setPixelSize(int(size * dpmm)); f.setBold(bold); p.setFont(f); p.setPen(QColor(0, 0, 0))
            p.drawText(QPointF(x * dpmm, y * dpmm), s)
        yb = ph_mm - m - tb_h
        txt(fx0 + 22, yb + 8, app.view.opt.get("plot_company") or "PT. ALIEF ENERGY UTAMA", 3.2, True)
        txt(fx0 + 22, yb + 13, "Naval Architect & Marine Engineer Consultant", 2.2)
        txt(fx0 + 22, yb + 18, "Batam - Indonesia", 2.2)
        txt(cols[1] + 3, yb + 6, "TITLE", 2.0); txt(cols[1] + 3, yb + 15, (title or "").upper()[:60], 4.0, True)
        txt(cols[2] + 3, yb + 6, "DRAWING NO.", 2.0); txt(cols[2] + 3, yb + 15, dno, 3.0, True)
        txt(cols[3] + 3, yb + 6, "SCALE", 2.0); txt(cols[3] + 3, yb + 15, f"1:{E.Entity.anno_scale:g}" if true_scale else "NTS (fit)", 3.0, True)
        txt(cols[4] + 3, yb + 6, "DATE / SHEET", 2.0); txt(cols[4] + 3, yb + 15, datetime.date.today().strftime("%d-%m-%Y") + f"  {paper}", 2.6, True)
    p.end()
    return fn
