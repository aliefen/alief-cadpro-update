"""Dockable panels: Properties, Layers, Symbol library, Model browser; and the command line."""
import math
import numpy as np
from PySide6.QtCore import Qt, Signal, QSize, QRectF, QPointF, QTimer
from PySide6.QtGui import QColor, QIcon, QPixmap, QPainter, QPen, QBrush, QFont
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, QHeaderView, QComboBox,
                               QLineEdit, QPlainTextEdit, QLabel, QToolButton, QListWidget, QListWidgetItem, QTabWidget,
                               QColorDialog, QAbstractItemView, QTreeWidget, QTreeWidgetItem, QPushButton, QCompleter, QMenu,
                               QSizePolicy, QApplication)
from ..core.aci import aci_rgb
from ..core.geom import fmt, fmt_pt
from ..core import entities as E
from .icons import icon


def color_icon(c, size=14):
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm)
    if isinstance(c, str) and c.startswith("#"):
        col = QColor(c)
    else:
        r, g, b = aci_rgb(int(c) if c not in (None, 256, 0) else 7)
        col = QColor(int(r * 255), int(g * 255), int(b * 255))
    p.setPen(QPen(QColor(90, 100, 115))); p.setBrush(col); p.drawRect(0, 0, size - 1, size - 1); p.end()
    return QIcon(pm)


def color_name(c):
    if c == 256 or c is None:
        return "ByLayer"
    if c == 0:
        return "ByBlock"
    if isinstance(c, str):
        return c
    return {1: "Red", 2: "Yellow", 3: "Green", 4: "Cyan", 5: "Blue", 6: "Magenta", 7: "White", 8: "Gray", 9: "Light gray"}.get(int(c), f"Color {c}")


# =========================================================================================== command line
class CommandLine(QWidget):
    """AutoCAD-style command window: resizable history, prompt with clickable [options], input line with command
    suggestions, recent-command list. It lives in a dock, so it can be dragged to the top / bottom, floated and resized."""
    submitted = Signal(str)
    escape = Signal()

    def __init__(self, commands=()):
        super().__init__()
        v = QVBoxLayout(self); v.setContentsMargins(6, 2, 6, 4); v.setSpacing(2)
        self.hist = QPlainTextEdit(); self.hist.setObjectName("cmdhist"); self.hist.setReadOnly(True)
        self.hist.setMaximumBlockCount(5000); self.hist.setMinimumHeight(18)
        self.hist.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        v.addWidget(self.hist, 1)
        h = QHBoxLayout(); h.setSpacing(4)
        self.recent = QToolButton(); self.recent.setObjectName("status"); self.recent.setText("\u25B8_"); self.recent.setToolTip("Recent commands")
        self.recent.setPopupMode(QToolButton.InstantPopup); self.recent_menu = QMenu(self.recent); self.recent.setMenu(self.recent_menu)
        self.recent_menu.aboutToShow.connect(self._fill_recent); self.recent.setFocusPolicy(Qt.NoFocus)
        h.addWidget(self.recent)
        self.prompt = QLabel("Command:"); self.prompt.setObjectName("cmdprompt"); h.addWidget(self.prompt)
        self.optbox = QWidget(); self.optlay = QHBoxLayout(self.optbox); self.optlay.setContentsMargins(0, 0, 0, 0); self.optlay.setSpacing(2)
        h.addWidget(self.optbox)
        self.tail = QLabel(""); self.tail.setObjectName("cmdprompt"); h.addWidget(self.tail)
        self.edit = QLineEdit(); self.edit.setObjectName("cmdline"); self.edit.setPlaceholderText("Type a command (LINE, PLATE3D, PIPE3D ...) or coordinates")
        self.edit.returnPressed.connect(self._enter)
        self.edit.installEventFilter(self)
        h.addWidget(self.edit, 1)
        v.addLayout(h)
        self.history = []; self.hidx = 0; self.cmd_history = []; self.space_enter = True; self.string_mode = False
        self.set_completer(commands)
        self.set_font_size(10)

    # ------------------------------------------------------------------ appearance
    def set_font_size(self, pt):
        f = QFont("Consolas"); f.setStyleHint(QFont.Monospace); f.setPointSize(int(pt))
        self.hist.setFont(f); self.edit.setFont(f)
        g = QFont("Segoe UI"); g.setPointSize(int(pt)); g.setBold(True); self.prompt.setFont(g); self.tail.setFont(g)
        self._pt = int(pt)

    def line_height(self):
        return self.hist.fontMetrics().lineSpacing()

    def height_for_lines(self, n):
        return int(n) * self.line_height() + self.edit.sizeHint().height() + 26

    def set_completer(self, cmds):
        comp = QCompleter(sorted(set(cmds))); comp.setCaseSensitivity(Qt.CaseInsensitive); comp.setCompletionMode(QCompleter.PopupCompletion)
        comp.setFilterMode(Qt.MatchStartsWith); comp.setMaxVisibleItems(12); self.edit.setCompleter(comp); self._comp = comp

    # ------------------------------------------------------------------ input
    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if ev.type() == QEvent.KeyPress:
            k = ev.key()
            if k == Qt.Key_Escape:
                self.edit.clear(); self.escape.emit(); return True
            if k == Qt.Key_Space and self.space_enter and not self.string_mode:
                self._enter(); return True
            if k == Qt.Key_Up and self.history and not self._comp.popup().isVisible():
                self.hidx = max(0, self.hidx - 1); self.edit.setText(self.history[self.hidx]); return True
            if k == Qt.Key_Down and self.history and not self._comp.popup().isVisible():
                self.hidx = min(len(self.history), self.hidx + 1)
                self.edit.setText(self.history[self.hidx] if self.hidx < len(self.history) else ""); return True
        return False

    def _enter(self):
        if self._comp.popup().isVisible():
            self._comp.popup().hide()
        t = self.edit.text(); self.edit.clear()
        if t.strip():
            self.history.append(t); self.hidx = len(self.history)
        self.submitted.emit(t)

    def note_command(self, name):
        if name in self.cmd_history:
            self.cmd_history.remove(name)
        self.cmd_history.insert(0, name); del self.cmd_history[20:]

    def _fill_recent(self):
        self.recent_menu.clear()
        if not self.cmd_history:
            a = self.recent_menu.addAction("(no recent commands)"); a.setEnabled(False)
        for n in self.cmd_history:
            self.recent_menu.addAction(n, lambda n=n: self.submitted.emit(n))
        self.recent_menu.addSeparator()
        self.recent_menu.addAction("Copy history", lambda: QApplication.clipboard().setText(self.hist.toPlainText()))
        self.recent_menu.addAction("Clear history", self.hist.clear)

    def log(self, s):
        self.hist.appendPlainText(s)
        self.hist.verticalScrollBar().setValue(self.hist.verticalScrollBar().maximum())

    # ------------------------------------------------------------------ prompt with clickable options
    def set_prompt(self, s, options=()):
        s = s or "Command"
        while self.optlay.count():
            w = self.optlay.takeAt(0).widget()
            if w is not None:
                w.deleteLater()
        head, tail = s, ""
        i, j = s.find("["), s.rfind("]")
        opts = list(options or [])
        if opts and 0 <= i < j:
            head, tail = s[:i].rstrip(), s[j + 1:].strip()
            for o in opts:
                b = QToolButton(); b.setObjectName("cmdopt"); b.setText(o); b.setCursor(Qt.PointingHandCursor); b.setFocusPolicy(Qt.NoFocus)
                key = "".join(ch for ch in o if ch.isupper() or ch.isdigit())
                b.setToolTip(f"Click, or type {key or o} and press Enter")
                f = QFont("Segoe UI"); f.setPointSize(self._pt); b.setFont(f)
                b.clicked.connect(lambda _=False, o=o: self.submitted.emit(o)); self.optlay.addWidget(b)
        if len(head) > 110:
            self.prompt.setToolTip(head); head = head[:107] + "..."
        else:
            self.prompt.setToolTip("")
        self.prompt.setText(head + (":" if not opts and not head.endswith(":") else ""))
        self.tail.setText((tail + ":") if opts else ""); self.tail.setVisible(bool(opts))
        self.optbox.setVisible(bool(opts))


# =========================================================================================== properties
class PropertiesPanel(QWidget):
    changed = Signal()

    def __init__(self, app):
        super().__init__(); self.app = app
        v = QVBoxLayout(self); v.setContentsMargins(4, 4, 4, 4)
        self.head = QLabel("No selection"); self.head.setStyleSheet("font-weight:600; padding:4px;")
        v.addWidget(self.head)
        self.table = QTableWidget(0, 2); self.table.horizontalHeader().setVisible(False); self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents); self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True); self.table.itemChanged.connect(self._edited)
        v.addWidget(self.table)
        self._busy = False; self._setters = {}

    def refresh(self, ents):
        self._busy = True
        self.table.setRowCount(0); self._setters = {}
        doc = self.app.doc
        if not ents:
            self.head.setText("No selection"); self._general(None); self._busy = False; return
        kinds = {e.label for e in ents}
        self.head.setText(f"{len(ents)} selected: " + (", ".join(sorted(kinds))[:60]))
        self._general(ents)
        if len(ents) == 1:
            e = ents[0]
            self._section("Geometry / data")
            props = e.props()
            pnames = {p[0] for p in props}
            for name, val, setter in props:
                self._row(name, val, setter)
            for name, val in e.info():
                if name in pnames:
                    continue
                self._row(name, val, None)
        self._busy = False

    def _section(self, t):
        r = self.table.rowCount(); self.table.insertRow(r)
        it = QTableWidgetItem(t); it.setFlags(Qt.ItemIsEnabled); f = it.font(); f.setBold(True); it.setFont(f)
        it.setForeground(QColor("#2EC5FF")); self.table.setItem(r, 0, it); self.table.setSpan(r, 0, 1, 2)

    def _row(self, name, val, setter):
        r = self.table.rowCount(); self.table.insertRow(r)
        a = QTableWidgetItem(name); a.setFlags(Qt.ItemIsEnabled); self.table.setItem(r, 0, a)
        if isinstance(val, np.ndarray):
            txt = fmt_pt(val)
        elif isinstance(val, float):
            txt = fmt(val, 4)
        else:
            txt = str(val)
        b = QTableWidgetItem(txt)
        if setter is None:
            b.setFlags(Qt.ItemIsEnabled); b.setForeground(QColor("#9AA6B6"))
        self.table.setItem(r, 1, b)
        if setter is not None:
            self._setters[r] = (setter, val)

    def _general(self, ents):
        doc = self.app.doc
        self._section("General")
        r = self.table.rowCount(); self.table.insertRow(r); self.table.setItem(r, 0, QTableWidgetItem("Layer"))
        cb = QComboBox(); cb.addItems(list(doc.layers))
        cur = ents[0].layer if ents and len({e.layer for e in ents}) == 1 else (doc.cur_layer if not ents else "")
        if cur:
            cb.setCurrentText(cur)
        else:
            cb.insertItem(0, "*varies*"); cb.setCurrentIndex(0)
        cb.currentTextChanged.connect(lambda t: self._set_all(ents, "layer", t))
        self.table.setCellWidget(r, 1, cb)
        r = self.table.rowCount(); self.table.insertRow(r); self.table.setItem(r, 0, QTableWidgetItem("Color"))
        cc = QComboBox()
        opts = [256, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 30, 40, 140, 170, 210, 250]
        for o in opts:
            cc.addItem(color_icon(o), color_name(o), o)
        cc.addItem("Select colour ...", "pick")
        c0 = ents[0].color if ents else doc.cur_color
        if c0 in opts:
            cc.setCurrentIndex(opts.index(c0))
        else:
            cc.insertItem(0, color_icon(c0), color_name(c0), c0); cc.setCurrentIndex(0)
        def setc(i):
            d = cc.itemData(i)
            if d == "pick":
                col = QColorDialog.getColor(QColor("white"), self)
                if not col.isValid():
                    return
                d = col.name()
            self._set_all(ents, "color", d)
        cc.currentIndexChanged.connect(setc)
        self.table.setCellWidget(r, 1, cc)
        r = self.table.rowCount(); self.table.insertRow(r); self.table.setItem(r, 0, QTableWidgetItem("Linetype"))
        lt = QComboBox(); lt.addItems(["ByLayer", "Continuous", "Dashed", "Hidden", "Center", "Phantom", "Dot", "DashDot"])
        lt.setCurrentText(ents[0].ltype if ents else doc.cur_ltype)
        lt.currentTextChanged.connect(lambda t: self._set_all(ents, "ltype", t))
        self.table.setCellWidget(r, 1, lt)
        r = self.table.rowCount(); self.table.insertRow(r); self.table.setItem(r, 0, QTableWidgetItem("Lineweight"))
        lw = QComboBox(); vals = [-1, 0, 13, 18, 25, 35, 50, 70, 100, 140, 200]
        for x in vals:
            lw.addItem("ByLayer" if x < 0 else f"{x / 100:.2f} mm", x)
        w0 = ents[0].lw if ents else doc.cur_lw
        if w0 in vals:
            lw.setCurrentIndex(vals.index(w0))
        lw.currentIndexChanged.connect(lambda i: self._set_all(ents, "lw", lw.itemData(i)))
        self.table.setCellWidget(r, 1, lw)

    def _set_all(self, ents, attr, val):
        if self._busy or val == "*varies*":
            return
        doc = self.app.doc
        if not ents:
            setattr(doc, {"layer": "cur_layer", "color": "cur_color", "ltype": "cur_ltype", "lw": "cur_lw"}[attr], val)
            self.app.refresh_status(); return
        doc.begin("properties")
        for e in ents:
            doc.modify(e); setattr(e, attr, val); e.touch()
        doc.end(); self.changed.emit()

    def _edited(self, item):
        if self._busy or item.column() != 1:
            return
        r = item.row()
        if r not in self._setters:
            return
        setter, old = self._setters[r]
        txt = item.text()
        try:
            val = float(eval(txt, {"__builtins__": {}}, {"pi": math.pi})) if isinstance(old, (int, float)) and not isinstance(old, bool) else txt
        except Exception:
            val = txt
        doc = self.app.doc
        sel = self.app.selected_ents()
        if not sel:
            return
        doc.begin("properties"); doc.modify(sel[0])
        try:
            setter(val)
        except Exception as ex:
            self.app.message(f"Invalid value: {ex}")
        sel[0].touch(); doc.end(); self.changed.emit()


# =========================================================================================== layers
class LayersPanel(QWidget):
    changed = Signal()

    def __init__(self, app):
        super().__init__(); self.app = app
        v = QVBoxLayout(self); v.setContentsMargins(4, 4, 4, 4)
        bar = QHBoxLayout()
        for txt, fn, tip in (("+", self._new, "New layer"), ("✓", self._current, "Set current"), ("−", self._delete, "Delete layer (empty)")):
            b = QToolButton(); b.setText(txt); b.setToolTip(tip); b.clicked.connect(fn); bar.addWidget(b)
        bar.addStretch(1)
        self.cur = QLabel(); bar.addWidget(self.cur)
        v.addLayout(bar)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["", "Name", "On", "Lock", "Color", "Linetype"])
        self.table.verticalHeader().setVisible(False); self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        hh = self.table.horizontalHeader(); hh.setSectionResizeMode(1, QHeaderView.Stretch); hh.setMinimumSectionSize(22)
        for i, wdt in ((0, 22), (2, 34), (3, 38), (4, 40), (5, 78)):
            hh.setSectionResizeMode(i, QHeaderView.Fixed); self.table.setColumnWidth(i, wdt)
        self.table.cellClicked.connect(self._clicked); self.table.cellDoubleClicked.connect(self._dbl)
        self.table.itemChanged.connect(self._renamed)
        v.addWidget(self.table)
        self._busy = False

    def refresh(self):
        self._busy = True
        doc = self.app.doc
        self.table.setRowCount(0)
        for name, L in doc.layers.items():
            r = self.table.rowCount(); self.table.insertRow(r)
            a = QTableWidgetItem("▶" if name == doc.cur_layer else ""); a.setFlags(Qt.ItemIsEnabled); a.setForeground(QColor("#2EC5FF"))
            self.table.setItem(r, 0, a)
            n = QTableWidgetItem(name)
            if name in ("0",):
                n.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 1, n)
            for col, val in ((2, "\U0001F4A1" if L.on else "○"), (3, "\U0001F512" if L.locked else "\U0001F513")):
                it = QTableWidgetItem(val); it.setFlags(Qt.ItemIsEnabled); it.setTextAlignment(Qt.AlignCenter); self.table.setItem(r, col, it)
            ci = QTableWidgetItem(""); ci.setIcon(color_icon(L.color)); ci.setToolTip(color_name(L.color)); ci.setFlags(Qt.ItemIsEnabled); self.table.setItem(r, 4, ci)
            lt = QTableWidgetItem(L.ltype); lt.setFlags(Qt.ItemIsEnabled); self.table.setItem(r, 5, lt)
        self.cur.setText(f"Current: {doc.cur_layer}")
        self._busy = False

    def _name(self, r):
        it = self.table.item(r, 1)
        return it.text() if it else None

    def _clicked(self, r, c):
        doc = self.app.doc; n = self._name(r); L = doc.layers.get(n)
        if L is None:
            return
        if c == 2:
            L.on = not L.on
        elif c == 3:
            L.locked = not L.locked
        elif c == 4:
            col = QColorDialog.getColor(QColor("white"), self, f"Colour of layer {n}")
            if col.isValid():
                from ..core.aci import ACI
                rgb = col.rgb() & 0xFFFFFF
                L.color = ACI.index(rgb) if rgb in ACI[1:] else col.name()
        elif c == 5:
            order = ["Continuous", "Dashed", "Hidden", "Center", "Phantom", "Dot", "DashDot"]
            L.ltype = order[(order.index(L.ltype) + 1) % len(order)] if L.ltype in order else "Continuous"
        else:
            return
        for e in doc.ents.values():
            if e.layer == n:
                e.touch()
        doc.changed(); self.refresh(); self.changed.emit()

    def _dbl(self, r, c):
        if c == 0:
            self.app.doc.cur_layer = self._name(r); self.refresh(); self.app.refresh_status()

    def _renamed(self, item):
        if self._busy or item.column() != 1:
            return
        doc = self.app.doc
        old = list(doc.layers)[item.row()]; new = item.text().strip()
        if not new or new in doc.layers:
            self.refresh(); return
        L = doc.layers.pop(old); L.name = new; doc.layers[new] = L
        for e in doc.ents.values():
            if e.layer == old:
                e.layer = new
        if doc.cur_layer == old:
            doc.cur_layer = new
        doc.changed(); self.refresh()

    def _new(self):
        doc = self.app.doc; i = 1
        while f"Layer{i}" in doc.layers:
            i += 1
        doc.ensure_layer(f"Layer{i}", 7); self.refresh()

    def _current(self):
        r = self.table.currentRow()
        if r >= 0:
            self.app.doc.cur_layer = self._name(r); self.refresh(); self.app.refresh_status()

    def _delete(self):
        r = self.table.currentRow(); doc = self.app.doc
        if r < 0:
            return
        n = self._name(r)
        if n in ("0", doc.cur_layer) or any(e.layer == n for e in doc.ents.values()):
            self.app.message(f"Layer {n} cannot be deleted (current, layer 0 or not empty)"); return
        doc.layers.pop(n, None); self.refresh()


# =========================================================================================== symbol library
def symbol_pixmap(name, size=56, light=False):
    from ..core import symbols as SY
    cat, desc, fn = SY.S[name]
    ents = fn()
    pts = []
    for e in ents:
        for w in e.wire():
            pts.append(w[:, :2])
        t = e.tris()
        if t is not None:
            pts.append(t[0][:, :2])
    P = np.vstack(pts) if pts else np.zeros((1, 2))
    mn = P.min(axis=0); mx = P.max(axis=0); sz = max(mx - mn) or 1
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    k = (size - 12) / sz; c = (mn + mx) / 2
    T = lambda q: QPointF(size / 2 + (q[0] - c[0]) * k, size / 2 - (q[1] - c[1]) * k)
    col = QColor("#1E2733") if light else QColor("#E6EBF2")
    p.setPen(QPen(col, 1.4))
    for e in ents:
        t = e.tris()
        if t is not None:
            V, F = t
            p.setPen(Qt.NoPen); p.setBrush(col)
            from PySide6.QtGui import QPolygonF
            for f in F:
                p.drawPolygon(QPolygonF([T(V[i]) for i in f]))
            p.setPen(QPen(col, 1.4)); p.setBrush(Qt.NoBrush)
        for w in e.wire():
            for i in range(len(w) - 1):
                p.drawLine(T(w[i]), T(w[i + 1]))
    p.end()
    return pm


class SymbolPanel(QWidget):
    def __init__(self, app):
        super().__init__(); self.app = app
        from ..core import symbols as SY
        v = QVBoxLayout(self); v.setContentsMargins(4, 4, 4, 4)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search symbol ..."); self.search.textChanged.connect(self._filter)
        v.addWidget(self.search)
        self.tabs = QTabWidget(); v.addWidget(self.tabs, 1)
        self.lists = []
        for cat, names in SY.categories().items():
            lw = QListWidget(); lw.setViewMode(QListWidget.IconMode); lw.setIconSize(QSize(52, 52)); lw.setGridSize(QSize(84, 86))
            lw.setResizeMode(QListWidget.Adjust); lw.setMovement(QListWidget.Static); lw.setWordWrap(True); lw.setSpacing(2)
            for n in names:
                it = QListWidgetItem(QIcon(symbol_pixmap(n)), n); it.setToolTip(f"<b>{n}</b><br>{SY.S[n][1]}"); it.setData(Qt.UserRole, n)
                lw.addItem(it)
            lw.itemClicked.connect(lambda it: self.app.run_command("SYMBOL", it.data(Qt.UserRole)))
            self.tabs.addTab(lw, cat.replace(" 2D", ""))
            self.lists.append(lw)
        # 3D tab: piping fittings + electrical equipment
        from ..core import fittings3d as F
        lw = QListWidget(); lw.setViewMode(QListWidget.IconMode); lw.setIconSize(QSize(40, 40)); lw.setGridSize(QSize(92, 74)); lw.setResizeMode(QListWidget.Adjust)
        lw.setWordWrap(True)
        for t in F.FITTING_TYPES:
            ic = "fitting" if "valve" in t or "strainer" in t else ("flange" if "lange" in t else ("pipe3d" if t.startswith("Pipe") or t.startswith("Elbow") else "pipe3d"))
            it = QListWidgetItem(icon(ic), t); it.setData(Qt.UserRole, ("FIT", t)); lw.addItem(it)
        for t in F.ELEC_TYPES:
            it = QListWidgetItem(icon("panel" if "Panel" in t else "equip"), t); it.setData(Qt.UserRole, ("EQ", t)); lw.addItem(it)
        for t, cmd, ic in (("3D Pipe route", "PIPE3D", "pipe3d"), ("Cable tray", "CABLETRAY", "tray"), ("Conduit", "CONDUIT", "conduit")):
            it = QListWidgetItem(icon(ic), t); it.setData(Qt.UserRole, ("CMD", cmd)); lw.addItem(it)
        lw.itemClicked.connect(self._click3d)
        self.tabs.addTab(lw, "3D Fittings && Equipment")
        self.lists.append(lw)
        hint = QLabel("Click a symbol, then click on a line: the symbol appears at once, turned to the line (in-line symbols open the line). Click empty space for a free symbol. Options: Angle / Perpendicular / Break. Enter = finish.")
        hint.setWordWrap(True); hint.setStyleSheet("color:#9AA6B6; font-size:8pt;")
        v.addWidget(hint)

    def _click3d(self, it):
        k, t = it.data(Qt.UserRole)
        if k == "FIT":
            self.app.run_command("FITTING", self.app.dialog_fitting(preset=t))
        elif k == "EQ":
            self.app.pending_equipment = t; self.app.run_command("EQUIPMENT")
        else:
            self.app.run_command(t)

    def _filter(self, s):
        s = s.lower()
        for lw in self.lists:
            for i in range(lw.count()):
                it = lw.item(i); it.setHidden(bool(s) and s not in it.text().lower())


# =========================================================================================== model browser
class BrowserPanel(QWidget):
    def __init__(self, app):
        super().__init__(); self.app = app
        v = QVBoxLayout(self); v.setContentsMargins(4, 4, 4, 4)
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Object", "Size / data", "Mark"]); self.tree.setColumnWidth(0, 150)
        self.tree.itemClicked.connect(self._click)
        v.addWidget(self.tree)
        b = QPushButton("Material list / BOM ..."); b.clicked.connect(lambda: app.run_command("MATLIST")); v.addWidget(b)
        self._pending = False

    def refresh(self):
        doc = self.app.doc
        self.tree.clear()
        groups = {}
        for e in doc.ents.values():
            key = e.label
            groups.setdefault(key, []).append(e)
        for key in sorted(groups):
            ents = groups[key]
            top = QTreeWidgetItem([f"{key} ({len(ents)})", "", ""]); self.tree.addTopLevelItem(top)
            for e in ents[:400]:
                m = getattr(e, "meta", {}) if isinstance(e, E.Body) else {}
                data = m.get("size") or (f"t = {m['thk']:g} mm {m.get('grade', '')}" if "thk" in m else "") or e.layer
                it = QTreeWidgetItem([f"#{e.id}", str(data), m.get("mark", "")]); it.setData(0, Qt.UserRole, e.id)
                top.addChild(it)

    def _click(self, it, col):
        eid = it.data(0, Qt.UserRole)
        if eid:
            self.app.set_selection([eid])
