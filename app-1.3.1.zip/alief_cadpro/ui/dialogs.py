"""Dialogs with live illustrations."""
import math
import os
import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, QTimer, QSize
from PySide6.QtGui import QPainter, QPen, QColor, QBrush, QFont, QPolygonF, QPixmap, QImage, QPainterPath
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QLabel, QComboBox, QDoubleSpinBox,
                               QSpinBox, QCheckBox, QLineEdit, QPushButton, QDialogButtonBox, QWidget, QTabWidget, QPlainTextEdit,
                               QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog, QSlider, QGroupBox, QProgressBar,
                               QListWidget, QListWidgetItem, QMessageBox, QTextBrowser, QSizePolicy, QRadioButton)
from ..core import ship as SH, details as D, fittings3d as F, cam as CAM
from ..core.geom import fmt

INK = QColor("#E6EBF2"); ACC = QColor("#2EC5FF"); ORG = QColor("#FFB020"); GRN = QColor("#36D399"); DIMC = QColor("#9FDFFF")


def spin(v, lo=-1e9, hi=1e9, dec=2, step=1.0, suffix=""):
    s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec); s.setValue(v); s.setSingleStep(step)
    if suffix:
        s.setSuffix(" " + suffix)
    s.setMinimumWidth(90)
    return s


def ispin(v, lo=1, hi=100000):
    s = QSpinBox(); s.setRange(lo, hi); s.setValue(v); return s


class Dlg(QDialog):
    def __init__(self, parent, title, w=560):
        super().__init__(parent); self.setWindowTitle(title); self.setMinimumWidth(w)
        self.v = QVBoxLayout(self)

    def buttons(self, ok="OK"):
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText(ok); bb.button(QDialogButtonBox.Ok).setObjectName("primary")
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); self.v.addWidget(bb)
        return bb


class Canvas(QWidget):
    """Illustration widget: draw(p, w, h) callback."""
    def __init__(self, draw, w=300, h=240):
        super().__init__(); self.draw = draw; self.setMinimumSize(w, h)

    def paintEvent(self, ev):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#141A22"))
        p.setPen(QPen(QColor(46, 197, 255, 25), 1))
        for x in range(0, self.width(), 16):
            p.drawLine(x, 0, x, self.height())
        for y in range(0, self.height(), 16):
            p.drawLine(0, y, self.width(), y)
        try:
            self.draw(p, self.width(), self.height())
        except Exception as ex:
            p.setPen(QColor("red")); p.drawText(10, 20, str(ex))
        p.end()


def dim_h(p, x0, x1, y, txt, col=DIMC):
    p.setPen(QPen(col, 1)); p.drawLine(QPointF(x0, y), QPointF(x1, y))
    for x, s in ((x0, 1), (x1, -1)):
        p.drawLine(QPointF(x, y), QPointF(x + 6 * s, y - 3)); p.drawLine(QPointF(x, y), QPointF(x + 6 * s, y + 3))
    f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f); p.drawText(QRectF(min(x0, x1), y - 16, abs(x1 - x0), 14), Qt.AlignCenter, txt)


def dim_v(p, x, y0, y1, txt, col=DIMC):
    p.setPen(QPen(col, 1)); p.drawLine(QPointF(x, y0), QPointF(x, y1))
    for y, s in ((y0, 1), (y1, -1)):
        p.drawLine(QPointF(x, y), QPointF(x - 3, y + 6 * s)); p.drawLine(QPointF(x, y), QPointF(x + 3, y + 6 * s))
    f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f)
    p.save(); p.translate(x - 4, (y0 + y1) / 2); p.rotate(-90); p.drawText(QRectF(-60, -14, 120, 14), Qt.AlignCenter, txt); p.restore()


# =============================================================================================== PLATE
class PlateDialog(Dlg):
    def __init__(self, parent, last=None):
        super().__init__(parent, "3D Plate", 640); last = last or {}
        h = QHBoxLayout(); self.v.addLayout(h)
        form = QFormLayout(); h.addLayout(form, 1)
        self.thk = spin(last.get("thk", 10), 0.1, 500, 1, 0.5, "mm"); form.addRow("Thickness", self.thk)
        self.grade = QComboBox(); self.grade.addItems(list(SH.MATERIALS)); self.grade.setCurrentText(last.get("grade", SH.DEFAULT_GRADE)); form.addRow("Material grade", self.grade)
        self.gi = QLabel(); self.gi.setStyleSheet("color:#9AA6B6"); form.addRow("", self.gi)
        self.side = QComboBox(); self.side.addItems(["+ normal side (moulded line on curve)", "centred on curve", "- opposite side"])
        self.side.setCurrentIndex({"+": 0, "0": 1, "-": 2}.get(last.get("side", "+"), 0)); form.addRow("Thickness direction", self.side)
        self.prefix = QLineEdit(last.get("prefix", "P")); form.addRow("Mark prefix (auto number)", self.prefix)
        self.mark = QLineEdit(""); self.mark.setPlaceholderText("auto"); form.addRow("Mark (fixed)", self.mark)
        self.layer = QComboBox(); self.layer.setEditable(True); self.layer.addItems(["PLATE", "SHELL", "DECK", "BULKHEAD", "FLOOR", "GIRDER"]); self.layer.setCurrentText(last.get("layer", "PLATE"))
        form.addRow("Layer", self.layer)
        self.dele = QCheckBox("Delete source curves / surfaces"); self.dele.setChecked(last.get("delete_src", False)); form.addRow(self.dele)
        self.canvas = Canvas(self._draw, 260, 250); h.addWidget(self.canvas)
        note = QLabel("Select the outer boundary together with inner closed curves: inner curves become openings (even-odd). "
                      "A surface can be selected too (curved shell plate).")
        note.setWordWrap(True); note.setStyleSheet("color:#9AA6B6"); self.v.addWidget(note)
        for w in (self.thk, ):
            w.valueChanged.connect(self.canvas.update)
        self.side.currentIndexChanged.connect(self.canvas.update); self.grade.currentTextChanged.connect(self._ginfo); self._ginfo()
        self.buttons("Select boundary")

    def _ginfo(self):
        g = SH.MATERIALS[self.grade.currentText()]
        self.gi.setText(f"ReH {g[1]} MPa, Rm {g[2]} MPa, density {g[0]} kg/m³ ({g[3]})")

    def _draw(self, p, w, h):
        t = max(6, min(40, self.thk.value() * 1.5))
        cx, cy = w / 2, h / 2 + 10
        top = [QPointF(30, cy - 40), QPointF(w - 70, cy - 70), QPointF(w - 30, cy - 30), QPointF(70, cy)]
        side = self.side.currentIndex()
        off = {0: -t, 1: -t / 2, 2: 0}[side]
        def sh(pts, d):
            return [QPointF(q.x(), q.y() + d) for q in pts]
        up = sh(top, off); lo = sh(top, off + t)
        p.setPen(QPen(INK, 1.4)); p.setBrush(QColor(46, 111, 208, 200)); p.drawPolygon(QPolygonF(up))
        p.setBrush(QColor(29, 74, 140, 220)); p.drawPolygon(QPolygonF([up[3], up[2], lo[2], lo[3]])); p.drawPolygon(QPolygonF([up[0], up[3], lo[3], lo[0]]))
        p.setPen(QPen(ORG, 2, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawPolygon(QPolygonF(top))
        p.setPen(ORG); f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f); p.drawText(QPointF(30, cy + 50), "--- selected curve (moulded line)")
        p.setPen(QPen(ACC, 2)); p.drawLine(QPointF(w - 30, cy - 30), QPointF(w - 30, cy - 30 - 40)); p.drawText(QPointF(w - 60, cy - 78), "normal")
        dim_v(p, 52, top[3].y() + off - 20, top[3].y() + off + t - 20, f"t = {self.thk.value():g}")

    def result(self):
        return {"thk": self.thk.value(), "grade": self.grade.currentText(), "side": ["+", "0", "-"][self.side.currentIndex()],
                "prefix": self.prefix.text().strip() or "P", "mark": self.mark.text().strip(), "layer": self.layer.currentText(),
                "delete_src": self.dele.isChecked()}


# =============================================================================================== PROFILE
def draw_section(p, w, h, ptype, dims, align=0, flip=False, rot=0.0, show_dims=True, path_pt=True):
    loops = SH.placed_loops(ptype, dims, align, flip, rot)
    P = np.vstack(loops)
    mn = P.min(axis=0); mx = P.max(axis=0)
    mn = np.minimum(mn, [0, 0]); mx = np.maximum(mx, [0, 0])
    sz = max(mx - mn) or 1
    k = min((w - 90) / (mx[0] - mn[0] + 1e-9), (h - 70) / (mx[1] - mn[1] + 1e-9), 4.0)
    cx = w / 2 - (mn[0] + mx[0]) / 2 * k; cy = h / 2 + (mn[1] + mx[1]) / 2 * k + 6
    T = lambda q: QPointF(cx + q[0] * k, cy - q[1] * k)
    # plate line
    p.setPen(QPen(QColor(120, 135, 155), 1)); p.setBrush(QColor(60, 72, 90))
    p.drawRect(QRectF(T((mn[0] - 25 / max(k, 1e-9) * 0 - 20 / k, 0)).x() - 10, cy, (mx[0] - mn[0]) * k + 60, 8))
    path = QPainterPath()
    for l in loops:
        path.addPolygon(QPolygonF([T(q) for q in l])); path.closeSubpath()
    path.setFillRule(Qt.OddEvenFill)
    p.setPen(QPen(INK, 1.6)); p.setBrush(QColor(255, 176, 32, 150)); p.drawPath(path)
    if path_pt:
        p.setPen(Qt.NoPen); p.setBrush(QColor("#FF4D4F")); p.drawEllipse(T((0, 0)), 4, 4)
        p.setPen(QPen(ACC, 2)); a = T((0, 0)); p.drawLine(a, QPointF(a.x(), a.y() - 34)); p.drawLine(QPointF(a.x(), a.y() - 34), QPointF(a.x() - 4, a.y() - 26))
        p.drawLine(QPointF(a.x(), a.y() - 34), QPointF(a.x() + 4, a.y() - 26))
        f = QFont("Segoe UI"); f.setPixelSize(10); p.setFont(f); p.setPen(ACC); p.drawText(QPointF(a.x() + 6, a.y() - 30), "web dir")
        p.setPen(QColor("#FF8A8C")); p.drawText(QPointF(a.x() + 6, a.y() + 20), "path")
    if show_dims and not rot:
        hgt = max(l[:, 1].max() for l in loops) - min(l[:, 1].min() for l in loops)
        x0 = min(l[:, 0].min() for l in loops); x1 = max(l[:, 0].max() for l in loops); y1 = max(l[:, 1].max() for l in loops); y0 = min(l[:, 1].min() for l in loops)
        dim_v(p, T((x1, 0)).x() + 22, T((0, y1)).y(), T((0, y0)).y(), f"h {dims.get('h', dims.get('D', 0)):g}")
        dim_h(p, T((x0, 0)).x(), T((x1, 0)).x(), T((0, y1)).y() - 10, f"{(x1 - x0):g}")


class ProfileDialog(Dlg):
    def __init__(self, parent, last=None):
        super().__init__(parent, "3D Profile (stiffener / beam / pillar)", 760); last = last or {}
        h = QHBoxLayout(); self.v.addLayout(h)
        left = QFormLayout(); h.addLayout(left, 1)
        self.ptype = QComboBox()
        for k, (nm, pars) in SH.PROFILE_TYPES.items():
            self.ptype.addItem(f"{k} - {nm}", k)
        self.size = QComboBox(); self.size.setMaxVisibleItems(24)
        left.addRow("Profile type", self.ptype); left.addRow("Catalogue size", self.size)
        self.pbox = QGroupBox("Dimensions (mm) - edit for manual size"); self.pgrid = QFormLayout(self.pbox); left.addRow(self.pbox)
        self.params = {}
        self.grade = QComboBox(); self.grade.addItems(list(SH.MATERIALS)); self.grade.setCurrentText(last.get("grade", SH.DEFAULT_GRADE)); left.addRow("Material grade", self.grade)
        self.align = QComboBox(); self.align.addItems(SH.ALIGNMENTS); left.addRow("Alignment on path", self.align)
        self.webdir = QComboBox(); self.webdir.addItems(["UCS Z", "UCS X", "UCS Y", "Curve plane normal"]); left.addRow("Web direction", self.webdir)
        row = QHBoxLayout(); self.flip = QCheckBox("Flip flange side"); self.rev = QCheckBox("Reverse web"); row.addWidget(self.flip); row.addWidget(self.rev)
        left.addRow(row)
        self.rot = spin(0, -360, 360, 1, 5, "deg"); left.addRow("Rotate section", self.rot)
        self.prefix = QLineEdit(last.get("prefix", "S")); left.addRow("Mark prefix", self.prefix)
        self.layer = QComboBox(); self.layer.setEditable(True); self.layer.addItems(["PROFILE", "LONGITUDINAL", "FRAME", "BEAM", "PILLAR"]); left.addRow("Layer", self.layer)
        self.dele = QCheckBox("Delete path curves"); left.addRow(self.dele)
        right = QVBoxLayout(); h.addLayout(right)
        self.canvas = Canvas(self._draw, 320, 300); right.addWidget(self.canvas)
        self.info = QLabel(); self.info.setStyleSheet("color:#9FDFFF"); self.info.setWordWrap(True); right.addWidget(self.info)
        self.ptype.currentIndexChanged.connect(self._type); self.size.currentIndexChanged.connect(self._size)
        for w in (self.align, self.webdir):
            w.currentIndexChanged.connect(self._upd)
        self.flip.toggled.connect(self._upd); self.rot.valueChanged.connect(self._upd); self.grade.currentTextChanged.connect(self._upd)
        i = self.ptype.findData(last.get("ptype", "BP")); self.ptype.setCurrentIndex(max(0, i)); self._type()
        if last.get("size") and self.size.findText(last["size"]) >= 0:
            self.size.setCurrentText(last["size"])
        self.buttons("Select path")

    def _type(self):
        k = self.ptype.currentData()
        self.size.blockSignals(True); self.size.clear(); self.size.addItems(list(SH.CATALOGUE[k]) + ["Manual (type dimensions)"]); self.size.blockSignals(False)
        while self.pgrid.rowCount():
            self.pgrid.removeRow(0)
        self.params = {}
        for par in SH.PROFILE_TYPES[k][1]:
            s = spin(0, 0, 5000, 1, 1); s.valueChanged.connect(self._upd); self.params[par] = s; self.pgrid.addRow(SH.PARAM_TEXT.get(par, par), s)
        self._size()

    def _size(self):
        k = self.ptype.currentData(); nm = self.size.currentText()
        d = SH.CATALOGUE[k].get(nm)
        if d:
            for par, s in self.params.items():
                s.blockSignals(True); s.setValue(float(d.get(par, s.value()))); s.blockSignals(False)
        self._upd()

    def dims(self):
        return {k: s.value() for k, s in self.params.items()}

    def _upd(self):
        k = self.ptype.currentData(); d = self.dims()
        try:
            kg = SH.kg_per_m(k, d, self.grade.currentText())
            W, I, A = D.section_modulus(k, d, 10.0)
            self.info.setText(f"{SH.size_label(k, d)} : A = {A - 60:.2f} cm² (profile), {kg:.2f} kg/m;  W = {W:.1f} cm³, I = {I:.0f} cm⁴ incl. 600 x 10 plating")
        except Exception as ex:
            self.info.setText(str(ex))
        self.canvas.update()

    def _draw(self, p, w, h):
        draw_section(p, w, h, self.ptype.currentData(), self.dims(), self.align.currentIndex(), self.flip.isChecked(), self.rot.value())

    def result(self):
        k = self.ptype.currentData()
        return {"ptype": k, "dims": self.dims(), "size": self.size.currentText(), "grade": self.grade.currentText(), "align": self.align.currentIndex(),
                "flip": self.flip.isChecked(), "rot": self.rot.value(), "web_dir": self.webdir.currentText(), "reverse_web": self.rev.isChecked(),
                "prefix": self.prefix.text().strip() or "S", "mark": "", "layer": self.layer.currentText(), "delete_src": self.dele.isChecked()}


# =============================================================================================== DETAIL
class DetailDialog(Dlg):
    RULES = ["BKI 2026 Pt.1 Vol.II", "IACS UR / Rec. 47", "DNV Pt.3 Ch.3", "ABS Part 3", "RINA Pt.B", "LR / KR / NK (equivalent)"]

    def __init__(self, parent, last=None):
        super().__init__(parent, "Frame Connection Details (international standard)", 900); last = last or {}
        h = QHBoxLayout(); self.v.addLayout(h)
        left = QFormLayout(); h.addLayout(left)
        self.kind = QComboBox(); self.kind.addItems(D.DETAIL_TYPES); left.addRow("Detail", self.kind)
        self.rule = QComboBox(); self.rule.addItems(self.RULES); left.addRow("Rule basis", self.rule)
        self.ptype = QComboBox()
        for k in ("BP", "L", "FB", "T", "C", "H"):
            self.ptype.addItem(f"{k} - {SH.PROFILE_TYPES[k][0]}", k)
        self.size = QComboBox(); self.size.setMaxVisibleItems(24)
        left.addRow("Member profile", self.ptype); left.addRow("Size", self.size)
        self.grade = QComboBox(); self.grade.addItems(list(SH.MATERIALS)); left.addRow("Material", self.grade)
        self.plate_t = spin(10, 4, 60, 1, 0.5, "mm"); left.addRow("Attached plating t", self.plate_t)
        self.web_t = spin(10, 4, 60, 1, 0.5, "mm"); left.addRow("Web frame / floor t", self.web_t)
        self.tbr = spin(0, 0, 60, 1, 0.5, "mm"); self.tbr.setSpecialValueText("auto"); left.addRow("Bracket t (0 = auto)", self.tbr)
        self.flg = QComboBox(); self.flg.addItems(["auto (per free edge)", "flanged", "not flanged"]); left.addRow("Bracket flange", self.flg)
        self.ds = QComboBox(); self.ds.setEditable(True); self.ds.addItems(["1:5", "1:10", "1:20", "1:25"]); self.ds.setCurrentText("1:10")
        left.addRow("Detail scale", self.ds)
        self.res = QLabel(); self.res.setWordWrap(True); self.res.setStyleSheet("color:#9FDFFF; padding:6px; border:1px solid #3A4352; border-radius:6px;")
        left.addRow(self.res)
        self.canvas = Canvas(self._draw, 470, 420); h.addWidget(self.canvas, 1)
        self.ptype.currentIndexChanged.connect(self._type); self.size.currentIndexChanged.connect(self._upd)
        for w in (self.kind, self.flg, self.grade, self.rule):
            (w.currentIndexChanged if hasattr(w, "currentIndexChanged") else w.valueChanged).connect(self._upd)
        for w in (self.plate_t, self.web_t, self.tbr):
            w.valueChanged.connect(self._upd)
        self._type()
        self.buttons("Insert detail")

    def _type(self):
        k = self.ptype.currentData()
        self.size.blockSignals(True); self.size.clear(); self.size.addItems(list(SH.CATALOGUE[k])); self.size.setCurrentIndex(min(10, self.size.count() - 1)); self.size.blockSignals(False)
        self._upd()

    def opt(self):
        k = self.ptype.currentData()
        fl = {0: None, 1: True, 2: False}[self.flg.currentIndex()]
        return {"kind": self.kind.currentText(), "ptype": k, "dims": SH.CATALOGUE[k][self.size.currentText()], "grade": self.grade.currentText(),
                "plate_t": self.plate_t.value(), "web_t": self.web_t.value(), "t_br": self.tbr.value() or None, "flanged": fl, "rule": self.rule.currentText(),
                "ds": self._ds()}

    def _ds(self):
        try:
            return float(self.ds.currentText().split(":")[-1])
        except ValueError:
            return 10.0

    def _upd(self):
        o = self.opt()
        W, I, A = D.section_modulus(o["ptype"], o["dims"], o["plate_t"])
        br = D.bracket_size(W, o["grade"], o["t_br"], bool(o["flanged"]) if o["flanged"] is not None else False)
        if o["flanged"] is None and br["need_flange"]:
            br = D.bracket_size(W, o["grade"], o["t_br"], True)
        self.res.setText(f"<b>W = {W:.1f} cm³</b> (incl. 600 mm plating)  I = {I:.0f} cm⁴<br>"
                         f"Bracket: t<sub>req</sub> = {br['t_req']:.2f} → <b>t = {br['t']:g} mm</b>, arm <b>l = {br['l']:g} mm</b>"
                         + (f", flange <b>{br['b']:g} mm</b>" if (o["flanged"] or (o["flanged"] is None and br["need_flange"])) else "")
                         + f"<br>k = {br['k']:.2f}  ({o['rule']})")
        self.canvas.update()

    def _draw(self, p, w, h):
        from ..core.geom import Plane
        from ..core import entities as E
        o = self.opt()
        ents, info = D.build_detail(o["kind"], Plane(), o["ptype"], o["dims"], o["grade"], o["plate_t"], o["web_t"], o["t_br"], o["flanged"], o["rule"], o["ds"])
        pts = [w_[:, :2] for e in ents for w_ in e.wire()]
        for e in ents:
            t = e.tris()
            if t is not None and len(t[0]):
                pts.append(t[0][:, :2])
        if not pts:
            return
        P = np.vstack(pts); mn = P.min(axis=0); mx = P.max(axis=0)
        k = min((w - 30) / (mx[0] - mn[0] + 1e-9), (h - 30) / (mx[1] - mn[1] + 1e-9))
        T = lambda q: QPointF(15 + (q[0] - mn[0]) * k, h - 15 - (q[1] - mn[1]) * k)
        from .viewport import resolve_rgb
        for e in ents:
            r, g, b = resolve_rgb(e.color if e.color != 256 else {"DETAIL": 7, "DIMENSION": 3, "TEXT": 2}.get(e.layer, 7), False)
            col = QColor(int(r * 255), int(g * 255), int(b * 255))
            t = e.tris()
            if t is not None and e.kind != "hatch":
                V, F_ = t; p.setPen(Qt.NoPen); p.setBrush(col)
                for f in F_[:4000]:
                    p.drawPolygon(QPolygonF([T(V[i]) for i in f]))
            if e.kind == "hatch" and e.pattern == "SOLID":
                continue
            p.setPen(QPen(col, 1.1)); p.setBrush(Qt.NoBrush)
            for wl in e.wire():
                p.drawPolyline(QPolygonF([T(q) for q in wl]))

    def result(self):
        return self.opt()


# =============================================================================================== ARRAY
class ArrayDialog(Dlg):
    def __init__(self, parent):
        super().__init__(parent, "Array", 640)
        self.tabs = QTabWidget(); self.v.addWidget(self.tabs)
        r = QWidget(); f = QFormLayout(r)
        self.rows = ispin(3); self.cols = ispin(4); self.lev = ispin(1); self.dx = spin(100); self.dy = spin(100); self.dz = spin(0)
        for a, b in (("Rows", self.rows), ("Columns", self.cols), ("Levels (Z)", self.lev), ("Column spacing (X)", self.dx), ("Row spacing (Y)", self.dy), ("Level spacing (Z)", self.dz)):
            f.addRow(a, b); (b.valueChanged).connect(lambda *_: self.cv.update())
        self.tabs.addTab(r, "Rectangular")
        pw = QWidget(); f2 = QFormLayout(pw)
        self.cnt = ispin(6); self.fill = spin(360, -360, 360, 1); self.rot = QCheckBox("Rotate items"); self.rot.setChecked(True)
        f2.addRow("Total items", self.cnt); f2.addRow("Angle to fill (deg)", self.fill); f2.addRow(self.rot)
        for b in (self.cnt, self.fill):
            b.valueChanged.connect(lambda *_: self.cv.update())
        self.tabs.addTab(pw, "Polar")
        aw = QWidget(); f3 = QFormLayout(aw); self.pcnt = ispin(5); f3.addRow("Items along path", self.pcnt); self.tabs.addTab(aw, "Path")
        self.tabs.currentChanged.connect(lambda *_: self.cv.update())
        self.cv = Canvas(self._draw, 560, 200); self.v.addWidget(self.cv)
        self.buttons("Create")

    def _draw(self, p, w, h):
        t = self.tabs.currentIndex()
        p.setPen(QPen(INK, 1.4))
        if t == 0:
            R, C = min(self.rows.value(), 12), min(self.cols.value(), 20)
            s = min((w - 40) / max(C, 1), (h - 40) / max(R, 1))
            for i in range(R):
                for j in range(C):
                    p.setBrush(QColor(255, 176, 32, 180) if i == j == 0 else QColor(46, 197, 255, 90))
                    p.drawRect(QRectF(20 + j * s, h - 20 - (i + 1) * s + s * 0.2, s * 0.6, s * 0.6))
            dim_h(p, 20, 20 + s, h - 6, f"{self.dx.value():g}")
        elif t == 1:
            n = self.cnt.value(); a = math.radians(self.fill.value()); cx, cy, r = w / 2, h / 2, min(w, h) / 2 - 24
            p.setPen(QPen(QColor(120, 130, 150), 1, Qt.DashLine)); p.drawEllipse(QPointF(cx, cy), r, r)
            for k in range(n):
                ang = a * k / (n if abs(self.fill.value()) >= 360 else max(1, n - 1))
                x, y = cx + r * math.cos(ang), cy - r * math.sin(ang)
                p.setPen(QPen(INK, 1.2)); p.setBrush(QColor(255, 176, 32, 200) if k == 0 else QColor(46, 197, 255, 110))
                p.drawEllipse(QPointF(x, y), 9, 9)
            p.setBrush(QColor("#FF4D4F")); p.drawEllipse(QPointF(cx, cy), 3, 3)
        else:
            path = QPainterPath(); path.moveTo(20, h - 30); path.cubicTo(w * 0.3, 10, w * 0.6, h, w - 20, 30)
            p.setPen(QPen(ORG, 1.6)); p.drawPath(path)
            n = self.pcnt.value()
            for k in range(n):
                q = path.pointAtPercent(k / max(1, n - 1)); p.setPen(QPen(INK, 1)); p.setBrush(QColor(46, 197, 255, 140)); p.drawRect(QRectF(q.x() - 7, q.y() - 7, 14, 14))

    def result(self):
        t = self.tabs.currentIndex()
        if t == 0:
            return {"type": "rect", "rows": self.rows.value(), "cols": self.cols.value(), "levels": self.lev.value(), "dx": self.dx.value(), "dy": self.dy.value(), "dz": self.dz.value()}
        if t == 1:
            return {"type": "polar", "count": self.cnt.value(), "fill": self.fill.value(), "rotate": self.rot.isChecked()}
        return {"type": "path", "count": self.pcnt.value()}


# =============================================================================================== HATCH / MTEXT
class HatchDialog(Dlg):
    def __init__(self, parent, last=None):
        super().__init__(parent, "Hatch", 520); last = last or {}
        from ..core.entities import HATCH_PATTERNS
        self.list = QListWidget(); self.list.setViewMode(QListWidget.IconMode); self.list.setIconSize(QSize(56, 56)); self.list.setGridSize(QSize(80, 82))
        for name in HATCH_PATTERNS:
            self.list.addItem(QListWidgetItem(self._swatch(name), name))
        self.list.setCurrentRow(list(HATCH_PATTERNS).index(last.get("pattern", "ANSI31")) if last.get("pattern", "ANSI31") in HATCH_PATTERNS else 0)
        self.v.addWidget(self.list)
        f = QFormLayout(); self.scale = spin(last.get("scale", 1.0), 0.001, 10000, 3, 0.25); self.angle = spin(last.get("angle", 0), -360, 360, 1, 15, "deg")
        f.addRow("Scale (paper, x drawing scale)", self.scale); f.addRow("Angle", self.angle); self.v.addLayout(f)
        self.buttons("Select boundaries")

    def _swatch(self, name):
        from ..core.entities import HATCH_PATTERNS, hatch_lines
        pm = QPixmap(56, 56); pm.fill(QColor("#141A22")); p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        if name == "SOLID":
            p.fillRect(4, 4, 48, 48, QColor("#9AA6B6"))
        else:
            loop = [np.array([[4, 4], [52, 4], [52, 52], [4, 52.0]])]
            p.setPen(QPen(QColor("#E6EBF2"), 1))
            for ang, sp, dash in HATCH_PATTERNS[name]:
                if dash in ("off", "off2"):
                    continue
                for a, b in hatch_lines(loop, math.radians(ang), sp * 2):
                    p.drawLine(QPointF(*a), QPointF(*b))
        p.end()
        from PySide6.QtGui import QIcon
        return QIcon(pm)

    def result(self):
        return {"pattern": self.list.currentItem().text() if self.list.currentItem() else "ANSI31", "scale": self.scale.value(), "angle": self.angle.value()}


class MTextDialog(Dlg):
    def __init__(self, parent, h=2.5):
        super().__init__(parent, "Multi-line text", 520)
        self.ed = QPlainTextEdit(); self.ed.setMinimumHeight(160); self.v.addWidget(self.ed)
        f = QFormLayout(); self.h = QComboBox(); self.h.setEditable(True); self.h.addItems(["1.8", "2.5", "3.5", "5", "7", "10"]); self.h.setCurrentText(f"{h:g}")
        f.addRow("Paper height (mm, ISO 3098) - annotative", self.h); self.v.addLayout(f)
        self.buttons("Place")

    def result(self):
        try:
            hh = float(self.h.currentText())
        except ValueError:
            hh = 2.5
        return {"text": self.ed.toPlainText().strip(), "height": hh}


# =============================================================================================== FITTINGS / PIPE / TRAY / EQUIPMENT
def _dn_combo(default=100):
    c = QComboBox()
    for dn in F.PIPES:
        c.addItem(F.size_text(dn), dn)
    c.setCurrentIndex(list(F.PIPES).index(default) if default in F.PIPES else 0)
    return c


class FittingDialog(Dlg):
    def __init__(self, parent, preset=None, last=None):
        super().__init__(parent, "3D Pipe fitting / flange / valve", 700); last = last or {}
        h = QHBoxLayout(); self.v.addLayout(h)
        f = QFormLayout(); h.addLayout(f, 1)
        self.ft = QComboBox(); self.ft.addItems(F.FITTING_TYPES); self.ft.setCurrentText(preset or last.get("ftype", "Elbow 90 LR")); f.addRow("Item", self.ft)
        self.dn = _dn_combo(last.get("dn", 100)); f.addRow("Size", self.dn)
        self.dn2 = _dn_combo(80); f.addRow("Small end (reducer)", self.dn2)
        self.std = QComboBox(); self.std.addItems(list(F.FLANGES)); self.std.setCurrentText(last.get("std", "ASME B16.5 Class 150")); f.addRow("Flange standard", self.std)
        self.pstd = QComboBox(); self.pstd.addItems(F.PIPE_STANDARDS); self.pstd.setCurrentText(last.get("pipe_std", F.PIPE_STANDARDS[0])); f.addRow("Pipe standard", self.pstd)
        self.length = spin(1000, 1, 1e6, 1, 100, "mm"); f.addRow("Length (straight pipe)", self.length)
        self.data = QLabel(); self.data.setStyleSheet("color:#9FDFFF"); self.data.setWordWrap(True); f.addRow(self.data)
        self.cv = Canvas(self._draw, 280, 260); h.addWidget(self.cv)
        for w in (self.ft, self.dn, self.dn2, self.std, self.pstd):
            w.currentIndexChanged.connect(self._upd)
        self._upd()
        self.buttons("Place")

    def _upd(self):
        dn = self.dn.currentData(); OD, wt = F.pipe_dims(dn, self.pstd.currentText())
        A, B, C, H, E_ = F.B169[dn]; fl = F.FLANGES[self.std.currentText()][dn]; ftf = F.B1610[dn]
        self.data.setText(f"OD {OD:g} x {wt:g} mm  |  90° LR A = {A}, 45° B = {B}, Tee C = {C}, Reducer H = {H}, Cap E = {E_}<br>"
                          f"Flange D {fl[0]:g}, t {fl[1]:g}, PCD {fl[2]:g}, {fl[3]} x Ø{fl[4]:g}  |  Valve F-F: gate {ftf[0]}, globe {ftf[1]}, wafer {ftf[2] or '-'}")
        self.dn2.setEnabled(self.ft.currentText().startswith("Reducer")); self.length.setEnabled(self.ft.currentText().startswith("Pipe"))
        self.cv.update()

    def _draw(self, p, w, h):
        t = self.ft.currentText(); cx, cy = w / 2, h / 2
        p.setPen(QPen(INK, 1.6)); p.setBrush(QColor(122, 139, 160, 200))
        r = 26
        if t.startswith("Elbow"):
            path = QPainterPath(); path.moveTo(30, cy - r); path.lineTo(cx - 20, cy - r); path.arcTo(QRectF(cx - 20 - 0, cy - r - 0, 0, 0), 0, 0)
            path = QPainterPath(); R = 90
            path.moveTo(30, cy + 40 - r); path.arcTo(QRectF(30 - R + 0, cy + 40 - r - R * 0, 2 * R, 2 * R), 90, -90 if "45" not in t else -45)
            p.setBrush(Qt.NoBrush); p.setPen(QPen(QColor(122, 139, 160), 2 * r)); p.drawPath(path); p.setPen(QPen(INK, 1)); p.drawPath(path)
        elif t == "Tee equal":
            p.drawRect(QRectF(30, cy - r, w - 60, 2 * r)); p.drawRect(QRectF(cx - r, 30, 2 * r, cy - 30 - r + 1))
        elif t.startswith("Reducer"):
            ecc = "ecc" in t
            p.drawPolygon(QPolygonF([QPointF(40, cy - 40), QPointF(w - 40, cy - (18 if not ecc else 40 - 44)), QPointF(w - 40, cy + (18 if not ecc else 40)), QPointF(40, cy + 40)]))
        elif "lange" in t:
            p.drawRect(QRectF(cx - 12, 30, 24, h - 60))
            if "neck" in t:
                p.drawPolygon(QPolygonF([QPointF(cx + 12, cy - 50), QPointF(cx + 70, cy - r), QPointF(cx + 70, cy + r), QPointF(cx + 12, cy + 50)]))
        elif "valve" in t or "strainer" in t:
            p.drawRect(QRectF(40, 60, 14, h - 120)); p.drawRect(QRectF(w - 54, 60, 14, h - 120)); p.drawRect(QRectF(54, cy - r, w - 108, 2 * r))
            p.drawEllipse(QPointF(cx, cy), 44, 40)
            if "Ball" not in t and "Butterfly" not in t and "strainer" not in t:
                p.drawRect(QRectF(cx - 10, 26, 20, cy - 66)); p.setBrush(Qt.NoBrush); p.setPen(QPen(ORG, 4)); p.drawEllipse(QPointF(cx, 26), 40, 8)
        elif t == "Cap":
            p.drawPie(QRectF(cx - 60, cy - 50, 120, 100), 90 * 16, -180 * 16); p.drawRect(QRectF(cx - 90, cy - 50, 90, 100))
        else:
            p.drawRect(QRectF(30, cy - r, w - 60, 2 * r))
        p.setPen(QPen(QColor("#FF4D4F"), 0)); p.setBrush(QColor("#FF4D4F")); p.drawEllipse(QPointF(30, cy), 4, 4)
        f = QFont("Segoe UI"); f.setPixelSize(10); p.setFont(f); p.setPen(QColor("#FF8A8C")); p.drawText(QPointF(12, cy + 20), "port 1")

    def result(self):
        return {"ftype": self.ft.currentText(), "dn": self.dn.currentData(), "dn2": self.dn2.currentData(), "std": self.std.currentText(),
                "pipe_std": self.pstd.currentText(), "length": self.length.value()}


class PipeDialog(Dlg):
    def __init__(self, parent, last=None):
        super().__init__(parent, "3D Pipe route", 460); last = last or {}
        f = QFormLayout(); self.v.addLayout(f)
        self.dn = _dn_combo(last.get("dn", 100)); f.addRow("Size", self.dn)
        self.pstd = QComboBox(); self.pstd.addItems(F.PIPE_STANDARDS); self.pstd.setCurrentText(last.get("pipe_std", F.PIPE_STANDARDS[0])); f.addRow("Pipe standard", self.pstd)
        self.bend = QComboBox(); self.bend.addItems(["Long radius 1.5D (B16.9 LR)", "Short radius 1.0D", "3D bend", "5D bend"]); f.addRow("Bends", self.bend)
        self.fl = QComboBox(); self.fl.addItems(["none", "start", "end", "both"]); f.addRow("Flanges at ends", self.fl)
        self.std = QComboBox(); self.std.addItems(list(F.FLANGES)); f.addRow("Flange standard", self.std)
        self.buttons("Draw route")

    def result(self):
        dn = self.dn.currentData(); A = F.B169[dn][0]
        R = {0: A, 1: A / 1.5, 2: A * 2, 3: A / 1.5 * 5}[self.bend.currentIndex()]
        return {"dn": dn, "pipe_std": self.pstd.currentText(), "R": R, "flanges": self.fl.currentText() if self.fl.currentIndex() else None, "std": self.std.currentText()}


class TrayDialog(Dlg):
    def __init__(self, parent):
        super().__init__(parent, "Cable tray", 380)
        f = QFormLayout(); self.v.addLayout(f)
        self.sz = QComboBox(); self.sz.addItems([f"{w} x {h}" for w, h in F.TRAY_SIZES] + ["custom"]); self.sz.setCurrentIndex(3); f.addRow("Size W x H (mm)", self.sz)
        self.W = spin(300, 50, 2000, 0, 50); self.H = spin(50, 20, 300, 0, 10); f.addRow("Custom width", self.W); f.addRow("Custom height", self.H)
        self.buttons("Draw route")

    def result(self):
        if self.sz.currentText() == "custom":
            return {"W": self.W.value(), "H": self.H.value()}
        w, h = F.TRAY_SIZES[self.sz.currentIndex()]
        return {"W": w, "H": h}


class EquipmentDialog(Dlg):
    DEF = {"Junction box": {"W": 150, "D": 100, "H": 150}, "Light fitting (LED tube)": {"L": 1270, "W": 120, "H": 90},
           "Panel / switchboard": {"W": 800, "D": 500, "H": 2000}, "Motor": {"L": 450, "D": 280}, "Socket outlet box": {"W": 90, "D": 60, "H": 120},
           "Push button station": {"W": 80, "D": 70, "H": 160}}

    def __init__(self, parent, preset=None):
        super().__init__(parent, "3D Electrical equipment", 400)
        f = QFormLayout(); self.v.addLayout(f)
        self.kind = QComboBox(); self.kind.addItems(F.ELEC_TYPES)
        if preset:
            self.kind.setCurrentText(preset)
        f.addRow("Equipment", self.kind)
        self.box = QWidget(); self.bf = QFormLayout(self.box); f.addRow(self.box)
        self.kind.currentTextChanged.connect(self._k); self.fields = {}; self._k()
        self.buttons("Place")

    def _k(self):
        while self.bf.rowCount():
            self.bf.removeRow(0)
        self.fields = {}
        for k, v in self.DEF[self.kind.currentText()].items():
            s = spin(v, 1, 1e5, 0, 10, "mm"); self.fields[k] = s; self.bf.addRow(k, s)

    def result(self):
        return {"kind": self.kind.currentText(), "dims": {k: s.value() for k, s in self.fields.items()}}


# =============================================================================================== CAM
class CamDialog(Dlg):
    def __init__(self, parent, parts, ucs):
        super().__init__(parent, "CNC cutting - G-code", 980)
        self.parts = parts; self.paths = []; self.sim = 0.0
        h = QHBoxLayout(); self.v.addLayout(h)
        f = QFormLayout(); h.addLayout(f)
        self.mach = QComboBox(); self.mach.addItems(list(CAM.MACHINES)); f.addRow("Machine", self.mach)
        m = CAM.MACHINES[self.mach.currentText()]
        self.kerf = spin(m["kerf"], 0, 20, 2, 0.1, "mm"); self.feed = spin(m["feed"], 1, 50000, 0, 50, "mm/min"); self.pierce = spin(m["pierce"], 0, 60, 2, 0.1, "s")
        self.lead = spin(m["lead"], 0, 100, 1, 1, "mm")
        self.comp = QComboBox(); self.comp.addItems(["CAM offset (G01, exact kerf)", "Controller G41/G42 (keeps G02/G03 arcs)", "None"])
        for a, b in (("Kerf width", self.kerf), ("Feed rate", self.feed), ("Pierce delay", self.pierce), ("Lead-in length", self.lead), ("Kerf compensation", self.comp)):
            f.addRow(a, b)
        self.dec = ispin(3, 0, 6); f.addRow("Decimals", self.dec)
        self.stats = QLabel(); self.stats.setWordWrap(True); self.stats.setStyleSheet("color:#9FDFFF"); f.addRow(self.stats)
        bplay = QPushButton("▶  Simulate"); bplay.clicked.connect(self._play); f.addRow(bplay)
        right = QVBoxLayout(); h.addLayout(right, 1)
        self.cv = Canvas(self._draw, 560, 440); right.addWidget(self.cv)
        self.code = QPlainTextEdit(); self.code.setReadOnly(True); self.code.setMaximumHeight(140); self.code.setStyleSheet("font-family:Consolas,monospace; font-size:9pt;")
        right.addWidget(self.code)
        self.mach.currentTextChanged.connect(self._mach)
        for w in (self.kerf, self.feed, self.pierce, self.lead, self.dec):
            w.valueChanged.connect(self._calc)
        self.comp.currentIndexChanged.connect(self._calc)
        bb = QHBoxLayout(); self.v.addLayout(bb); bb.addStretch(1)
        save = QPushButton("Save G-code ..."); save.setObjectName("primary"); save.clicked.connect(self._save); bb.addWidget(save)
        close = QPushButton("Close"); close.clicked.connect(self.reject); bb.addWidget(close)
        self.timer = QTimer(self); self.timer.timeout.connect(self._step)
        self._calc()

    def _mach(self, name):
        m = CAM.MACHINES[name]
        for w, k in ((self.kerf, "kerf"), (self.feed, "feed"), (self.pierce, "pierce"), (self.lead, "lead")):
            w.blockSignals(True); w.setValue(m[k]); w.blockSignals(False)
        self._calc()

    def _calc(self):
        comp = ["cam", "g41", "none"][self.comp.currentIndex()]
        self.paths = CAM.toolpaths(self.parts, self.kerf.value() if comp == "cam" else 0.0, self.lead.value(), comp if comp != "none" else "g41")
        m = dict(CAM.MACHINES[self.mach.currentText()]); m.update(feed=self.feed.value(), pierce=self.pierce.value())
        self.gc = CAM.gcode(self.paths, m, comp=comp, kerf=self.kerf.value() if comp == "g41" else 0.0, dec=self.dec.value())
        cut, rap = CAM.cut_length(self.paths)
        tmin = cut / max(1, self.feed.value()) + len(self.paths) * self.pierce.value() / 60
        self.stats.setText(f"{len(self.parts)} part(s), {len(self.paths)} contour(s) (holes first)<br>Cut length {cut / 1000:.2f} m, rapid {rap / 1000:.2f} m<br>"
                           f"Pierces {len(self.paths)}, estimated time {tmin:.1f} min")
        self.code.setPlainText(self.gc[:20000]); self.cv.update()

    def _play(self):
        self.sim = 0.0; self.timer.start(30)

    def _step(self):
        self.sim += 0.01
        if self.sim >= 1:
            self.sim = 1; self.timer.stop()
        self.cv.update()

    def _draw(self, p, w, h):
        if not self.paths:
            return
        P = np.vstack([c["pts"] for c in self.paths] + [np.array([c["lead"] for c in self.paths])])
        mn = P.min(axis=0); mx = P.max(axis=0)
        k = min((w - 40) / (mx[0] - mn[0] + 1e-9), (h - 40) / (mx[1] - mn[1] + 1e-9))
        T = lambda q: QPointF(20 + (q[0] - mn[0]) * k, h - 20 - (q[1] - mn[1]) * k)
        n = len(self.paths); lim = self.sim * n if self.timer.isActive() or self.sim > 0 else n
        pos = mn * 0
        for i, c in enumerate(self.paths):
            done = i < lim
            pen = QPen(QColor(110, 120, 140), 1, Qt.DashLine); p.setPen(pen); p.drawLine(T(pos), T(c["lead"]))
            col = (GRN if c["kind"] == "hole" else ACC) if done else QColor(90, 100, 115)
            p.setPen(QPen(ORG, 1.5)); p.drawLine(T(c["lead"]), T(c["start"]))
            p.setPen(QPen(col, 1.6)); pts = list(c["pts"]) + [c["pts"][0]]
            p.drawPolyline(QPolygonF([T(q) for q in pts]))
            p.setPen(Qt.NoPen); p.setBrush(QColor("#FF4D4F")); p.drawEllipse(T(c["lead"]), 2.5, 2.5)
            f = QFont("Segoe UI"); f.setPixelSize(9); p.setFont(f); p.setPen(QColor("#C9D4E5")); p.drawText(T(c["lead"]) + QPointF(4, -4), str(i + 1))
            pos = c["start"]

    def _save(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Save G-code", "cutting.nc", "G-code (*.nc *.tap *.gcode *.txt)")
        if fn:
            open(fn, "w").write(self.gc); QMessageBox.information(self, "G-code", f"Saved {fn}")


class NestDialog(Dlg):
    def __init__(self, parent):
        super().__init__(parent, "Nesting on plates", 380)
        f = QFormLayout(); self.v.addLayout(f)
        self.W = spin(6000, 100, 50000, 0, 100, "mm"); self.H = spin(1800, 100, 20000, 0, 100, "mm"); self.gap = spin(10, 0, 500, 1, 1, "mm")
        self.margin = spin(10, 0, 500, 1, 1, "mm"); self.rot = QCheckBox("Allow 90° rotation"); self.rot.setChecked(True); self.qty = ispin(1, 1, 999)
        for a, b in (("Sheet length", self.W), ("Sheet width", self.H), ("Gap between parts", self.gap), ("Sheet margin", self.margin), ("Quantity of each part", self.qty)):
            f.addRow(a, b)
        f.addRow(self.rot)
        self.buttons("Nest")

    def result(self):
        return {"W": self.W.value(), "H": self.H.value(), "gap": self.gap.value(), "margin": self.margin.value(), "rotate": self.rot.isChecked(), "qty": self.qty.value()}


# =============================================================================================== TRACE / PDF
class TraceDialog(Dlg):
    def __init__(self, parent, img):
        super().__init__(parent, "Auto trace (raster to vector, centre-line)", 900)
        from ..core import raster
        self.raster = raster
        self.g, _ = raster.gray_from_bytes(img.data, 900)
        self.auto_thr = raster.otsu(self.g)
        h = QHBoxLayout(); self.v.addLayout(h)
        f = QFormLayout(); h.addLayout(f)
        self.thr = QSlider(Qt.Horizontal); self.thr.setRange(1, 254); self.thr.setValue(self.auto_thr); self.thrl = QLabel()
        f.addRow("Threshold", self.thr); f.addRow("", self.thrl)
        b = QPushButton("Auto (Otsu)"); b.clicked.connect(lambda: self.thr.setValue(self.auto_thr)); f.addRow(b)
        self.inv = QCheckBox("Light lines on dark background"); f.addRow(self.inv)
        self.speck = QComboBox(); self.speck.addItems(["off", "light", "strong"]); self.speck.setCurrentIndex(1); f.addRow("Despeckle", self.speck)
        self.simp = spin(1.2, 0.2, 20, 1, 0.2, "px"); f.addRow("Simplify tolerance", self.simp)
        self.straight = QCheckBox("Straighten near horizontal / vertical"); self.straight.setChecked(True); f.addRow(self.straight)
        self.ang = spin(3, 0.5, 15, 1, 0.5, "deg"); f.addRow("Straighten tolerance", self.ang)
        self.gap = spin(3, 0, 50, 1, 1, "px"); f.addRow("Join gaps up to", self.gap)
        self.minl = spin(8, 1, 500, 0, 1, "px"); f.addRow("Ignore lines shorter than", self.minl)
        self.win = QCheckBox("Trace a window only (pick after OK)"); f.addRow(self.win)
        self.layer = QLineEdit("TRACE"); f.addRow("Layer", self.layer)
        bprev = QPushButton("Preview centre-lines"); bprev.clicked.connect(self._preview); f.addRow(bprev)
        self.cv = Canvas(self._draw, 560, 460); h.addWidget(self.cv, 1)
        self.thr.valueChanged.connect(self._thr); self.inv.toggled.connect(self._thr); self._lines = None; self._thr()
        self.buttons("Trace")

    def _thr(self):
        self.thrl.setText(f"{self.thr.value()}  (auto {self.auto_thr})"); self._lines = None; self.cv.update()

    def _preview(self):
        g = self.g
        lines, thr, sk = self.raster.vectorize(g, self.thr.value(), self.inv.isChecked(), self.speck.currentIndex(), self.simp.value(),
                                               self.straight.isChecked(), self.ang.value(), self.gap.value(), self.minl.value())
        self._lines = lines; self.cv.update()

    def _draw(self, p, w, h):
        g = self.g; H, W = g.shape
        k = min(w / W, h / H)
        m = (g > self.thr.value()) if self.inv.isChecked() else (g < self.thr.value())
        rgb = np.where(m[..., None], np.array([46, 197, 255], np.uint8), np.array([20, 26, 34], np.uint8)).astype(np.uint8)
        img = QImage(rgb.data, W, H, W * 3, QImage.Format_RGB888).copy()
        if self._lines is not None:
            rgb2 = (rgb * 0.35).astype(np.uint8); img = QImage(rgb2.data, W, H, W * 3, QImage.Format_RGB888).copy()
        p.drawImage(QRectF(0, 0, W * k, H * k), img)
        if self._lines is not None:
            p.setPen(QPen(ORG, 1.3))
            for l in self._lines:
                p.drawPolyline(QPolygonF([QPointF(x * k, y * k) for x, y in l]))
            f = QFont("Segoe UI"); f.setPixelSize(12); p.setFont(f); p.setPen(QColor("white")); p.drawText(QPointF(8, h - 8), f"{len(self._lines)} polylines")

    def result(self):
        return {"thr": self.thr.value(), "invert": self.inv.isChecked(), "speck": self.speck.currentIndex(), "simplify": self.simp.value(),
                "straight": self.straight.isChecked(), "ang_tol": self.ang.value(), "gap": self.gap.value(), "min_len": self.minl.value(),
                "window": self.win.isChecked(), "layer": self.layer.text().strip() or "TRACE"}


class PdfDialog(Dlg):
    def __init__(self, parent, path):
        super().__init__(parent, "Import PDF", 760)
        from ..core import pdfimport as PI
        self.PI = PI; self.path = path
        n = PI.page_count(path)
        h = QHBoxLayout(); self.v.addLayout(h)
        f = QFormLayout(); h.addLayout(f)
        self.page = ispin(1, 1, n); f.addRow(f"Page (1 - {n})", self.page)
        self.scale = QComboBox(); self.scale.setEditable(True)
        self.scale.addItems(["1:1", "1:2", "1:5", "1:10", "1:20", "1:25", "1:50", "1:100", "1:200", "1:500"]); self.scale.setCurrentText("1:1")
        f.addRow("Drawing scale on the PDF", self.scale)
        self.vec = QCheckBox("Vector geometry (lines, curves)"); self.vec.setChecked(True)
        self.txt = QCheckBox("Text"); self.txt.setChecked(True)
        self.fill = QCheckBox("Solid fills (as hatch)")
        self.img = QCheckBox("Embedded raster images"); self.img.setChecked(True)
        self.ras = QCheckBox("Whole page as raster image (scanned PDF -> use AUTOTRACE)")
        for w in (self.vec, self.txt, self.fill, self.img, self.ras):
            f.addRow(w)
        self.dpi = ispin(200, 72, 600); f.addRow("Raster resolution (dpi)", self.dpi)
        self.info = QLabel(); self.info.setStyleSheet("color:#9AA6B6"); f.addRow(self.info)
        self.thumb = QLabel(); self.thumb.setMinimumSize(320, 420); self.thumb.setAlignment(Qt.AlignCenter); self.thumb.setStyleSheet("background:#141A22; border:1px solid #3A4352;")
        h.addWidget(self.thumb)
        self.page.valueChanged.connect(self._thumb); self._thumb()
        self.buttons("Import")

    def _thumb(self):
        try:
            png, (w, h) = self.PI.page_thumb(self.path, self.page.value() - 1, 320)
            pm = QPixmap(); pm.loadFromData(png); self.thumb.setPixmap(pm.scaled(320, 420, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            self.info.setText(f"Paper size {w:.0f} x {h:.0f} mm")
        except Exception as ex:
            self.info.setText(str(ex))

    def result(self):
        try:
            sc = float(self.scale.currentText().split(":")[-1])
        except ValueError:
            sc = 1.0
        return {"page": self.page.value() - 1, "scale": sc, "vectors": self.vec.isChecked(), "texts": self.txt.isChecked(), "fills": self.fill.isChecked(),
                "images": self.img.isChecked(), "raster": self.ras.isChecked(), "dpi": self.dpi.value()}


# =============================================================================================== MATERIAL LIST
class MatListDialog(Dlg):
    def __init__(self, parent, rows, project=""):
        super().__init__(parent, "Material list / Bill of materials", 980)
        self.rows = rows
        from ..cmd.ship import bom_table_rows
        data = bom_table_rows(rows)
        self.tab = QTableWidget(len(data) - 1, len(data[0])); self.tab.setHorizontalHeaderLabels(data[0])
        for i, r in enumerate(data[1:]):
            for j, c in enumerate(r):
                it = QTableWidgetItem(c); it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if j >= 4:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.tab.setItem(i, j, it)
        self.tab.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch); self.tab.setAlternatingRowColors(True)
        self.v.addWidget(self.tab)
        marks = QLabel("Marks: " + "; ".join(f"{g['desc']}: {', '.join(g['marks'][:30])}" for g in rows if g["marks"])[:2000])
        marks.setWordWrap(True); marks.setStyleSheet("color:#9AA6B6"); self.v.addWidget(marks)
        h = QHBoxLayout(); self.v.addLayout(h); h.addStretch(1)
        bx = QPushButton("Export Excel ..."); bx.setObjectName("primary"); bx.clicked.connect(self._xlsx); h.addWidget(bx)
        bc = QPushButton("Export CSV ..."); bc.clicked.connect(self._csv); h.addWidget(bc)
        bb = QPushButton("Close"); bb.clicked.connect(self.reject); h.addWidget(bb)
        self.data = data

    def _csv(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Export CSV", "material_list.csv", "CSV (*.csv)")
        if fn:
            import csv
            with open(fn, "w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerows(self.data)

    def _xlsx(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Export Excel", "Material_List_ALIEF_CADPRO.xlsx", "Excel (*.xlsx)")
        if not fn:
            return
        export_bom_xlsx(fn, self.data, self.rows)
        QMessageBox.information(self, "Material list", f"Saved {fn}")


def export_bom_xlsx(fn, data, rows):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Material List"
    thin = Side(style="thin", color="7F9F7F"); B = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["A1"] = "MATERIAL LIST / BILL OF MATERIALS"; ws["A1"].font = Font(name="Cambria", size=14, bold=True, color="1F4E3D")
    ws["A2"] = "PT. ALIEF ENERGY UTAMA - generated by ALIEF CAD PRO"; ws["A2"].font = Font(name="Cambria", size=9, italic=True)
    hdr = PatternFill("solid", fgColor="C6E0B4"); body = PatternFill("solid", fgColor="EAF4E4")
    for j, h in enumerate(data[0]):
        c = ws.cell(4, j + 1, h); c.font = Font(name="Cambria", size=10, bold=True); c.fill = hdr; c.border = B; c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for i, r in enumerate(data[1:]):
        for j, v in enumerate(r):
            try:
                val = float(v.split()[0]) if j in (4, 6) and v not in ("", "-") else v
            except ValueError:
                val = v
            c = ws.cell(5 + i, j + 1, val); c.font = Font(name="Cambria", size=10, bold=(i == len(data) - 2)); c.border = B
            if i % 2 == 0:
                c.fill = body
    for j, w in enumerate([6, 12, 34, 22, 8, 16, 14]):
        ws.column_dimensions["ABCDEFG"[j]].width = w
    ws.page_setup.orientation = "portrait"; ws.page_setup.paperSize = ws.PAPERSIZE_A4; ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True; ws.page_setup.fitToHeight = 0
    ws.page_margins.top = 0.75 / 2.54; ws.page_margins.left = 0.95 / 2.54; ws.page_margins.right = 0.55 / 2.54; ws.page_margins.bottom = 0.55 / 2.54
    ws2 = wb.create_sheet("Marks")
    ws2.append(["Description", "Material", "Marks"])
    for g in rows:
        ws2.append([g["desc"], g["mat"], ", ".join(g["marks"])])
    for c in ws2[1]:
        c.font = Font(name="Cambria", bold=True); c.fill = hdr
    wb.save(fn)


# =============================================================================================== OPTIONS / UPDATE / ABOUT / TEXT
class OptionsDialog(Dlg):
    def __init__(self, parent, app):
        super().__init__(parent, "Options", 560); self.app = app
        s = app.doc.settings; v = app.view
        tabs = QTabWidget(); self.v.addWidget(tabs)
        g = QWidget(); f = QFormLayout(g); tabs.addTab(g, "Drawing")
        self.units = QComboBox(); self.units.addItems(["mm", "cm", "m", "in", "ft"]); self.units.setCurrentText(s.get("units", "mm")); f.addRow("Drawing units", self.units)
        self.txt = spin(s.get("text_paper", 2.5), 0.5, 50, 1, 0.5, "mm"); f.addRow("Default text height (paper)", self.txt)
        dim = s.get("dim", {})
        self.dth = spin(dim.get("th", 2.5), 0.5, 50, 1, 0.5, "mm"); self.dasz = spin(dim.get("asz", 2.5), 0.5, 50, 1, 0.5, "mm"); self.ddec = ispin(dim.get("dec", 0), 0, 6)
        f.addRow("Dimension text (paper)", self.dth); f.addRow("Arrow size (paper)", self.dasz); f.addRow("Dimension decimals", self.ddec)
        self.sym = spin(s.get("sym_scale", 1.0), 0.01, 100, 2, 0.25); f.addRow("Symbol size factor", self.sym)
        self.paper = QComboBox(); self.paper.addItems(["A4", "A3", "A2", "A1", "A0"]); self.paper.setCurrentText(s.get("paper", "A3")); f.addRow("Paper for AUTO scale", self.paper)
        d = QWidget(); f2 = QFormLayout(d); tabs.addTab(d, "Display & snap")
        self.theme = QComboBox(); self.theme.addItems(["Dark", "Light"]); self.theme.setCurrentIndex(1 if v.light else 0); f2.addRow("Theme", self.theme)
        self.ap = ispin(v.aperture, 4, 40); f2.addRow("OSNAP aperture (px)", self.ap)
        from .viewport import SNAP_KINDS, SNAP_LABEL
        self.snaps = {}
        grid = QGridLayout(); w = QWidget(); w.setLayout(grid)
        for i, k in enumerate(SNAP_KINDS):
            cb = QCheckBox(SNAP_LABEL[k]); cb.setChecked(k in v.snap_modes); grid.addWidget(cb, i // 3, i % 3); self.snaps[k] = cb
        f2.addRow("Object snap modes", w)
        u = QWidget(); f3 = QFormLayout(u); tabs.addTab(u, "Update")
        self.auto = QCheckBox("Check and install updates automatically at start-up"); self.auto.setChecked(app.settings.value("auto_update", True, bool)); f3.addRow(self.auto)
        self.buttons("Apply")

    def apply(self):
        app = self.app; s = app.doc.settings; v = app.view
        s["units"] = self.units.currentText(); s["text_paper"] = self.txt.value(); s["sym_scale"] = self.sym.value(); s["paper"] = self.paper.currentText()
        s["dim"] = dict(s.get("dim", {}), th=self.dth.value(), asz=self.dasz.value(), dec=self.ddec.value())
        v.aperture = self.ap.value(); v.snap_modes = {k for k, cb in self.snaps.items() if cb.isChecked()}
        app.settings.setValue("auto_update", self.auto.isChecked())
        if (self.theme.currentIndex() == 1) != v.light:
            app.toggle_theme()
        v.invalidate()


class UpdateDialog(Dlg):
    def __init__(self, parent, app):
        super().__init__(parent, "ALIEF CAD PRO - Update", 520); self.app = app
        self.lbl = QLabel("Checking ..."); self.lbl.setWordWrap(True); self.v.addWidget(self.lbl)
        self.notes = QTextBrowser(); self.notes.setMaximumHeight(180); self.v.addWidget(self.notes)
        self.bar = QProgressBar(); self.bar.setVisible(False); self.v.addWidget(self.bar)
        h = QHBoxLayout(); self.v.addLayout(h)
        self.bcheck = QPushButton("Check now"); self.bcheck.clicked.connect(app.check_update_manual_inner); h.addWidget(self.bcheck)
        self.bfile = QPushButton("Install from file ..."); self.bfile.clicked.connect(app.install_update_file); h.addWidget(self.bfile)
        h.addStretch(1)
        self.brestart = QPushButton("Restart now"); self.brestart.setObjectName("primary"); self.brestart.setVisible(False); self.brestart.clicked.connect(app.restart); h.addWidget(self.brestart)
        bc = QPushButton("Close"); bc.clicked.connect(self.accept); h.addWidget(bc)

    def show_status(self, status, notice, info):
        cur = self.app.version
        txt = {"offline": f"Update server not reachable. You are using version {cur}. ({info})",
               "badsig": "An update notice was found but its digital signature is NOT valid - it was ignored.",
               "latest": f"You are using the latest version ({cur}).",
               "available": f"Version {notice and notice.get('version')} is available.",
               "ready": f"Version {notice and notice.get('version')} is installed and will run after restart.",
               "failed": f"Download failed: {info}"}.get(status, status)
        self.lbl.setText(f"<b>{txt}</b>")
        if notice:
            self.notes.setPlainText(notice.get("notes", ""))
        self.brestart.setVisible(status == "ready")


def about_html(version, boot):
    return (f"<h2>ALIEF CAD PRO {version}</h2><p>2D drafting, surfaces, 3D solids, 3D Plate &amp; 3D Profile, piping &amp; electrical "
            f"symbols and 3D fittings, frame connection details, BOM, CAM cutting, PDF / raster redrawing.</p>"
            f"<p><b>PT. ALIEF ENERGY UTAMA</b><br>Naval Architect &amp; Marine Engineer Consultant<br>Komplek Pertokoan Dreamland G1 No. 31, "
            f"Tanjung Riau, Sekupang, Batam</p><p style='color:#9AA6B6'>Running from: {boot.get('app_dir', '-')}<br>"
            f"Launcher {boot.get('launcher', '-')}, update channel aliefen/alief-cadpro-update</p>"
            f"<p style='color:#9AA6B6; font-size:8pt'>Built with Qt / PySide6 (LGPL), numpy (BSD), manifold3d (Apache-2.0), ezdxf (MIT), "
            f"PDFium / pypdfium2 (Apache-2.0 / BSD), openpyxl (MIT), PyOpenGL (BSD).</p>")


class TextDialog(Dlg):
    def __init__(self, parent, title, text):
        super().__init__(parent, title, 640)
        t = QPlainTextEdit(text); t.setReadOnly(True); t.setMinimumHeight(360); t.setStyleSheet("font-family:Consolas,monospace;")
        self.v.addWidget(t)
        b = QPushButton("Close"); b.clicked.connect(self.accept); self.v.addWidget(b)


# =========================================================================================== tables / find (v1.2)
class TableDialog(Dlg):
    def __init__(self, parent):
        super().__init__(parent, "Insert Table", 380)
        f = QFormLayout(); self.v.addLayout(f)
        self.title = QLineEdit(""); f.addRow("Title (optional)", self.title)
        self.cols = ispin(4, 1, 40); self.rows = ispin(5, 1, 500); f.addRow("Columns", self.cols); f.addRow("Rows (incl. header)", self.rows)
        self.width = spin(30, 3, 500, 1, 5, "mm"); self.rh = spin(7, 2, 50, 1, 0.5, "mm"); self.th = spin(2.5, 1, 20, 1, 0.5, "mm")
        f.addRow("Column width (paper)", self.width); f.addRow("Row height (paper)", self.rh); f.addRow("Text height (paper)", self.th)
        self.buttons("Insert")

    def values(self):
        return {"title": self.title.text().strip(), "cols": self.cols.value(), "rows": self.rows.value(), "width": self.width.value(),
                "rh": self.rh.value(), "th": self.th.value()}


class TableEditDialog(Dlg):
    """Spreadsheet-like editor for a table entity (cells, title, rows / columns, column widths)."""
    def __init__(self, parent, table):
        super().__init__(parent, "Edit Table", 760); self.t = table
        from PySide6.QtWidgets import QTableWidget, QTableWidgetItem
        self._Item = QTableWidgetItem
        h = QHBoxLayout(); self.v.addLayout(h)
        h.addWidget(QLabel("Title")); self.title = QLineEdit(table.title); h.addWidget(self.title, 1)
        self.grid = QTableWidget(len(table.rows), len(table.widths)); self.v.addWidget(self.grid, 1)
        self.grid.setMinimumHeight(320)
        for i, r in enumerate(table.rows):
            for j in range(len(table.widths)):
                self.grid.setItem(i, j, QTableWidgetItem(r[j] if j < len(r) else ""))
        for j, w in enumerate(table.widths):
            self.grid.setColumnWidth(j, int(max(40, w * 4)))
        h = QHBoxLayout(); self.v.addLayout(h)
        for text, fn in (("+ Row", lambda: self.grid.insertRow(self.grid.currentRow() + 1 if self.grid.currentRow() >= 0 else self.grid.rowCount())),
                         ("- Row", lambda: self.grid.rowCount() > 1 and self.grid.removeRow(max(0, self.grid.currentRow()))),
                         ("+ Column", lambda: self.grid.insertColumn(self.grid.currentColumn() + 1 if self.grid.currentColumn() >= 0 else self.grid.columnCount())),
                         ("- Column", lambda: self.grid.columnCount() > 1 and self.grid.removeColumn(max(0, self.grid.currentColumn()))),
                         ("Paste from Excel", self._paste)):
            b = QPushButton(text); b.clicked.connect(fn); h.addWidget(b)
        h.addStretch(1)
        self.fit = QCheckBox("Fit column widths to the text"); self.fit.setChecked(True); h.addWidget(self.fit)
        self.buttons("Apply")

    def _paste(self):
        from PySide6.QtWidgets import QApplication
        txt = QApplication.clipboard().text()
        if not txt.strip():
            return
        r0 = max(0, self.grid.currentRow()); c0 = max(0, self.grid.currentColumn())
        for i, line in enumerate(txt.rstrip("\n").split("\n")):
            cells = line.rstrip("\r").split("\t")
            while self.grid.rowCount() <= r0 + i:
                self.grid.insertRow(self.grid.rowCount())
            for j, v in enumerate(cells):
                while self.grid.columnCount() <= c0 + j:
                    self.grid.insertColumn(self.grid.columnCount())
                self.grid.setItem(r0 + i, c0 + j, self._Item(v))

    def result_rows(self):
        out = []
        for i in range(self.grid.rowCount()):
            out.append([(self.grid.item(i, j).text() if self.grid.item(i, j) else "") for j in range(self.grid.columnCount())])
        return out


class FindDialog(Dlg):
    """Find and replace in text, multiline text, leaders, tables and dimension text overrides."""
    def __init__(self, parent, app):
        super().__init__(parent, "Find and Replace", 460); self.app = app
        f = QFormLayout(); self.v.addLayout(f)
        self.find = QLineEdit(); self.repl = QLineEdit(); f.addRow("Find what", self.find); f.addRow("Replace with", self.repl)
        self.case = QCheckBox("Match case"); self.sel = QCheckBox("Selected objects only"); self.sel.setChecked(bool(app.view.selection))
        f.addRow(self.case); f.addRow(self.sel)
        self.info = QLabel(""); self.v.addWidget(self.info)
        h = QHBoxLayout(); self.v.addLayout(h)
        for text, fn in (("Find / Zoom", self.do_find), ("Replace All", self.do_replace)):
            b = QPushButton(text); b.clicked.connect(fn); h.addWidget(b)
        b = QPushButton("Close"); b.clicked.connect(self.accept); h.addWidget(b)

    def _ents(self):
        doc = self.app.doc
        ents = self.app.selected_ents() if self.sel.isChecked() else list(doc.ents.values())
        return [e for e in ents if e.kind in ("text", "leader", "table", "dimension")]

    def _has(self, s, key):
        return (key in s) if self.case.isChecked() else (key.lower() in s.lower())

    def _strings(self, e):
        if e.kind in ("text", "leader"):
            return [e.s]
        if e.kind == "dimension":
            return [e.override]
        return [e.title] + [c for r in e.rows for c in r]

    def do_find(self):
        key = self.find.text()
        if not key:
            return
        hits = [e for e in self._ents() if any(self._has(s, key) for s in self._strings(e))]
        self.info.setText(f"{len(hits)} object(s) contain the text")
        if hits:
            self.app.set_selection([e.id for e in hits]); self.app.view.zoom_extents(hits)

    def do_replace(self):
        import re
        key = self.find.text(); new = self.repl.text()
        if not key:
            return
        rx = re.compile(re.escape(key), 0 if self.case.isChecked() else re.IGNORECASE)
        doc = self.app.doc; n = 0
        doc.begin("find")
        for e in self._ents():
            if not any(self._has(s, key) for s in self._strings(e)):
                continue
            doc.modify(e)
            if e.kind in ("text", "leader"):
                e.s, k = rx.subn(lambda m: new, e.s); n += k
            elif e.kind == "dimension":
                e.override, k = rx.subn(lambda m: new, e.override); n += k
            else:
                e.title, k = rx.subn(lambda m: new, e.title); n += k
                for r in e.rows:
                    for j in range(len(r)):
                        r[j], k = rx.subn(lambda m: new, r[j]); n += k
            e.touch()
        doc.end()
        self.info.setText(f"{n} replacement(s) made")


def export_table_xlsx(fn, table):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Table"
    thin = Side(style="thin", color="7F9F7F"); B = Border(left=thin, right=thin, top=thin, bottom=thin)
    r0 = 1
    if table.title:
        ws["A1"] = table.title; ws["A1"].font = Font(name="Cambria", size=13, bold=True, color="1F4E3D"); r0 = 3
    hdr = PatternFill("solid", fgColor="C6E0B4")
    for i, r in enumerate(table.rows):
        for j, v in enumerate(r):
            try:
                val = float(v.replace(",", "")) if v and v.replace(",", "").replace(".", "", 1).replace("-", "", 1).isdigit() else v
            except ValueError:
                val = v
            c = ws.cell(r0 + i, j + 1, val); c.font = Font(name="Cambria", size=10, bold=(i == 0)); c.border = B
            c.alignment = Alignment(horizontal="center" if i == 0 else None, vertical="center")
            if i == 0:
                c.fill = hdr
    for j, w in enumerate(table.widths):
        ws.column_dimensions[get_column_letter(j + 1)].width = max(8, w / 2.2)
    ws.page_setup.orientation = "portrait"; ws.page_setup.paperSize = ws.PAPERSIZE_A4; ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True; ws.page_setup.fitToHeight = 0
    ws.page_margins.top = 0.75 / 2.54; ws.page_margins.left = 0.95 / 2.54; ws.page_margins.right = 0.55 / 2.54; ws.page_margins.bottom = 0.55 / 2.54
    wb.save(fn)


# =========================================================================================== blocks (v1.2)
class AttDefDialog(Dlg):
    def __init__(self, parent):
        super().__init__(parent, "Attribute Definition", 420)
        f = QFormLayout(); self.v.addLayout(f)
        self.tag = QLineEdit("TAG"); self.prompt = QLineEdit(""); self.default = QLineEdit("")
        f.addRow("Tag (name, no spaces)", self.tag); f.addRow("Prompt (question at insert)", self.prompt); f.addRow("Default value", self.default)
        self.h = spin(2.5, 0.5, 50, 1, 0.5, "mm"); f.addRow("Text height (paper)", self.h)
        self.al = QComboBox(); self.al.addItems(["Left", "Center", "Right"]); f.addRow("Justification", self.al)
        self.inv = QCheckBox("Invisible (kept as data only, e.g. for the attribute list)"); f.addRow(self.inv)
        self.buttons("OK")

    def values(self):
        t = self.tag.text().strip().upper().replace(" ", "_") or "TAG"
        return {"tag": t, "prompt": self.prompt.text().strip() or t, "default": self.default.text(), "h": self.h.value(),
                "halign": self.al.currentIndex(), "invisible": self.inv.isChecked()}


class BlockPropsDialog(Dlg):
    """One form for everything a block reference can be given: attribute values, visibility state, lengths, flips."""
    def __init__(self, parent, blk, ins, title):
        super().__init__(parent, title, 440); self.blk = blk; self.w = {}; self.p = {}
        f = QFormLayout(); self.v.addLayout(f)
        atts = blk.attdefs()
        if atts:
            f.addRow(QLabel("<b>Attributes</b>"))
        for a in atts:
            e = QLineEdit(ins.attribs.get(a.tag, a.default)); f.addRow(a.prompt or a.tag, e); self.w[a.tag] = e
        if blk.params:
            f.addRow(QLabel("<b>Dynamic options</b>"))
        for p in blk.params:
            v = ins.dyn_value(p)
            if p["type"] == "visibility":
                c = QComboBox(); c.addItems(p.get("states", [])); c.setCurrentText(v); f.addRow(p["name"], c); self.p[p["name"]] = (p, c)
            elif p["type"] == "linear":
                lo = p.get("min") if p.get("min") is not None else 1e-6; hi = p.get("max") if p.get("max") is not None else 1e9
                c = spin(v, lo, hi, 3, max(1.0, float(p.get("base", 10)) / 10)); f.addRow(f"{p['name']}  (base {p.get('base', 0):g})", c); self.p[p["name"]] = (p, c)
            else:
                c = QCheckBox("Flipped"); c.setChecked(bool(v)); f.addRow(p["name"], c); self.p[p["name"]] = (p, c)
        self.buttons("OK")
        if self.w:
            first = next(iter(self.w.values())); first.setFocus(); first.selectAll()

    def values(self):
        att = {t: e.text() for t, e in self.w.items()}
        dyn = {}
        for n, (p, c) in self.p.items():
            dyn[n] = c.currentText() if p["type"] == "visibility" else (c.value() if p["type"] == "linear" else c.isChecked())
        return att, dyn


class FrameSpacingDialog(Dlg):
    """Frame spacing ruler: numbering range and spacing per segment."""
    def __init__(self, parent, opt):
        super().__init__(parent, "Frame Spacing", 620)
        from PySide6.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView
        self._Item = QTableWidgetItem
        g = QGroupBox("Frame numbering"); f = QFormLayout(g); self.v.addWidget(g)
        self.first = ispin(int(opt["first"]), -10000, 10000); self.last = ispin(int(opt["last"]), -10000, 10000)
        h = QHBoxLayout(); h.addWidget(QLabel("from")); h.addWidget(self.first); h.addWidget(QLabel("to")); h.addWidget(self.last); h.addStretch(1)
        f.addRow("Frame numbers", h)
        self.step = ispin(int(opt.get("label_step", 1)), 1, 100); f.addRow("Write a number every", self.step)
        self.prefix = QLineEdit(opt.get("prefix", "")); self.prefix.setPlaceholderText("e.g. FR"); f.addRow("Number prefix (optional)", self.prefix)
        self.rev = QCheckBox("Numbers increase to the left (bow on the left)"); self.rev.setChecked(bool(opt.get("reverse"))); f.addRow("", self.rev)
        g = QGroupBox("Spacing by segment"); vb = QVBoxLayout(g); self.v.addWidget(g)
        f2 = QFormLayout(); vb.addLayout(f2)
        self.sp = spin(float(opt["spacing"]), 1, 1e6, 2, 50, "mm"); f2.addRow("Default frame spacing", self.sp)
        vb.addWidget(QLabel("Segments with a different spacing (frames not listed use the default):"))
        self.grid = QTableWidget(0, 3); self.grid.setHorizontalHeaderLabels(["From frame", "To frame", "Spacing (mm)"])
        self.grid.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.grid.setMinimumHeight(130); vb.addWidget(self.grid)
        for a, b, s in (opt.get("segments") or []):
            self._row(a, b, s)
        hb = QHBoxLayout(); vb.addLayout(hb)
        b1 = QPushButton("+ Add segment"); b2 = QPushButton("- Remove selected"); hb.addWidget(b1); hb.addWidget(b2); hb.addStretch(1)
        b1.clicked.connect(lambda: self._row(self._next_from(), self.last.value(), self.sp.value())); b2.clicked.connect(self._del)
        self.info = QLabel(""); self.info.setStyleSheet("color:#2EC5FF;"); vb.addWidget(self.info)
        g = QGroupBox("Drawing"); f = QFormLayout(g); self.v.addWidget(g)
        self.th = spin(float(opt["th"]), 1, 20, 1, 0.5, "mm"); self.tick = spin(float(opt["tick"]), 0.5, 20, 1, 0.5, "mm")
        f.addRow("Number height (paper)", self.th); f.addRow("Tick height (paper)", self.tick)
        self.notes = QCheckBox("Write the spacing note with arrow for every segment"); self.notes.setChecked(bool(opt.get("notes", True))); f.addRow("", self.notes)
        self.note = QLineEdit(opt.get("note_text", "FRAME SPACE")); f.addRow("Note text", self.note)
        self.npos = QComboBox(); self.npos.addItems(["Below the frame numbers", "Above the ruler"])
        self.npos.setCurrentIndex(1 if opt.get("note_pos", "below") == "above" else 0); f.addRow("Note position", self.npos)
        self.feet = QCheckBox("Show feet when the spacing is in whole feet, e.g. 6FT (1828.8mm)"); self.feet.setChecked(bool(opt.get("feet", True))); f.addRow("", self.feet)
        self.lines = QCheckBox("Draw frame lines at every frame"); self.lines.setChecked(bool(opt.get("lines", False))); f.addRow("", self.lines)
        self.up = spin(float(opt.get("line_up", 2000)), 0, 1e7, 1, 500, "mm"); self.down = spin(float(opt.get("line_down", 0)), 0, 1e7, 1, 500, "mm")
        f.addRow("Frame line length above the ruler", self.up); f.addRow("Frame line length below the ruler", self.down)
        for w in (self.first, self.last, self.sp):
            w.valueChanged.connect(self._info)
        self.grid.itemChanged.connect(self._info)
        self.buttons("Place"); self._info()

    def _row(self, a, b, s):
        r = self.grid.rowCount(); self.grid.blockSignals(True); self.grid.insertRow(r)
        for j, v in enumerate((int(a), int(b), ("%.4f" % float(s)).rstrip("0").rstrip("."))):
            self.grid.setItem(r, j, self._Item(str(v)))
        self.grid.blockSignals(False)
        if hasattr(self, "info"):
            self._info()

    def _next_from(self):
        segs = self.segments()
        return max([b for a, b, s in segs], default=min(self.first.value(), self.last.value()))

    def _del(self):
        r = self.grid.currentRow()
        if r >= 0:
            self.grid.removeRow(r); self._info()

    def segments(self):
        out = []
        for r in range(self.grid.rowCount()):
            try:
                a = int(float(self.grid.item(r, 0).text())); b = int(float(self.grid.item(r, 1).text()))
                s = float(self.grid.item(r, 2).text().replace(",", "."))
                if a != b and s > 0:
                    out.append((min(a, b), max(a, b), s))
            except (ValueError, AttributeError):
                pass
        return out

    def _info(self, *a):
        from ..cmd.frames import frame_positions
        f, l = self.first.value(), self.last.value()
        if f == l:
            self.info.setText("The first and last frame numbers must differ"); return
        pos, org, sp = frame_positions(f, l, self.sp.value(), self.segments())
        lo, hi = min(f, l), max(f, l)
        self.info.setText(f"{hi - lo + 1} frames ({lo} .. {hi}),  total length {pos[hi] - pos[lo]:,.1f} mm,  origin = frame {org}")

    def values(self):
        return {"first": self.first.value(), "last": self.last.value(), "spacing": self.sp.value(), "segments": [list(s) for s in self.segments()],
                "label_step": self.step.value(), "prefix": self.prefix.text(), "reverse": self.rev.isChecked(), "tick": self.tick.value(),
                "th": self.th.value(), "lines": self.lines.isChecked(), "line_up": self.up.value(), "line_down": self.down.value(),
                "notes": self.notes.isChecked(), "note_text": self.note.text().strip(), "feet": self.feet.isChecked(),
                "note_pos": "above" if self.npos.currentIndex() == 1 else "below"}

    def accept(self):
        if self.first.value() == self.last.value():
            return
        super().accept()
