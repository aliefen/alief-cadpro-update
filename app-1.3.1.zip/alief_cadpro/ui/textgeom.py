"""Text -> filled triangles (Qt font outlines triangulated with manifold3d), cached per string."""
import numpy as np
from PySide6.QtGui import QFont, QFontMetricsF, QPainterPath
from PySide6.QtCore import QPointF

_cache = {}
_fonts = {}
BASE = 100.0


def _font(name):
    f = _fonts.get(name)
    if f is None:
        f = QFont(name or "Arial"); f.setPixelSize(int(BASE)); f.setStyleStrategy(QFont.PreferOutline)
        fm = QFontMetricsF(f)
        _fonts[name] = f = (f, fm, fm.capHeight() or BASE * 0.7)
    return f


def local_tris(s, font, halign, valign, wf):
    key = (s, font, halign, valign, round(wf, 4))
    r = _cache.get(key)
    if r is not None:
        return r
    import manifold3d as m3
    f, fm, cap = _font(font)
    lines = s.split("\n")
    sp = 1.666 * cap
    polys = []
    widths = [fm.horizontalAdvance(l) for l in lines]
    Wmax = max(widths) if widths else 0
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        path = QPainterPath(); path.addText(QPointF(0, 0), f, line)
        dx = [0.0, -widths[i] / 2, -widths[i]][halign]
        for poly in path.toSubpathPolygons():
            pts = np.array([[p.x(), p.y()] for p in poly], float)
            if len(pts) < 3:
                continue
            pts[:, 0] = (pts[:, 0] + dx) * wf
            pts[:, 1] = -pts[:, 1] - i * sp
            polys.append(pts / cap)
    if not polys:
        _cache[key] = None
        return None
    total_h = (len(lines) - 1) * sp / cap
    oy = [0.0, fm.descent() / cap, -0.5 + total_h / 2 - 0.0, -1.0][valign]
    if valign == 2:
        oy = -0.5 + total_h / 2
    elif valign == 3:
        oy = -1.0
    cs = m3.CrossSection(polys, m3.FillRule.NonZero)
    P = [np.asarray(p, float) for p in cs.to_polygons()]
    if not P:
        _cache[key] = None
        return None
    F = np.asarray(m3.triangulate(P), np.int32)
    V = np.vstack(P); V[:, 1] += oy
    r = (V, F)
    if len(_cache) > 20000:
        _cache.clear()
    _cache[key] = r
    return r


def text_tris(t):
    r = local_tris(t.s, t.font, t.halign, t.valign, t.wf)
    if r is None:
        return None
    V2, F = r
    x = t.xdir; y = t.ydir(); h = t.h
    V = t.p + (V2[:, :1] * h) * x + (V2[:, 1:2] * h) * y
    return V, F


def text_width(s, font="Arial"):
    """Advance width of the longest line in units of the text height (cap height)."""
    f, fm, cap = _font(font)
    return max((fm.horizontalAdvance(l) for l in str(s).split("\n")), default=0.0) / cap


def install():
    from ..core.entities import Entity
    Entity.text_tess = staticmethod(text_tris)
    Entity.text_measure = staticmethod(text_width)
