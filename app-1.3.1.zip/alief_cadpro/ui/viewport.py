"""OpenGL viewport: camera, light renderer (VBO batches), picking, OSNAP, grips, ViewCube, UCS icon, overlays."""
import math
import time
import numpy as np
from PySide6.QtCore import Qt, QPointF, QRectF, QTimer, Signal
from PySide6.QtGui import QPainter, QColor, QPen, QFont, QPolygonF, QBrush, QSurfaceFormat, QCursor, QImage
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL import GL as gl
from ..core.geom import unit, norm, Plane, prim_tess, prim_closest, prim_intersect, prim_len, arc_pt, v3, EPS
from ..core.aci import aci_rgb
from ..core.document import LINETYPES
from ..core import entities as E

SNAP_KINDS = ["end", "mid", "cen", "quad", "int", "perp", "tan", "near", "node", "ins", "img"]
SNAP_LABEL = {"end": "Endpoint", "mid": "Midpoint", "cen": "Center", "quad": "Quadrant", "int": "Intersection", "perp": "Perpendicular",
              "tan": "Tangent", "near": "Nearest", "node": "Node", "ins": "Insertion", "img": "Image line", "grid": "Grid"}


def default_format():
    f = QSurfaceFormat()
    f.setRenderableType(QSurfaceFormat.OpenGL); f.setProfile(QSurfaceFormat.CompatibilityProfile); f.setVersion(2, 1)
    f.setDepthBufferSize(24); f.setStencilBufferSize(8); f.setSamples(4)
    return f


def quat_from_R(R):
    t = np.trace(R)
    if t > 0:
        s = math.sqrt(t + 1) * 2; return np.array([0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s])
    i = int(np.argmax(np.diag(R)))
    if i == 0:
        s = math.sqrt(1 + R[0, 0] - R[1, 1] - R[2, 2]) * 2; return np.array([(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s])
    if i == 1:
        s = math.sqrt(1 + R[1, 1] - R[0, 0] - R[2, 2]) * 2; return np.array([(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s])
    s = math.sqrt(1 + R[2, 2] - R[0, 0] - R[1, 1]) * 2; return np.array([(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s])


def R_from_quat(q):
    w, x, y, z = q / np.linalg.norm(q)
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def slerp(a, b, t):
    d = np.dot(a, b)
    if d < 0:
        b = -b; d = -d
    if d > 0.9995:
        r = a + t * (b - a); return r / np.linalg.norm(r)
    th = math.acos(d); return (math.sin((1 - t) * th) * a + math.sin(t * th) * b) / math.sin(th)


VIEWS = {   # name: (back(eye) direction, up)
    "top": ((0, 0, 1), (0, 1, 0)), "bottom": ((0, 0, -1), (0, 1, 0)), "front": ((0, -1, 0), (0, 0, 1)), "back": ((0, 1, 0), (0, 0, 1)),
    "left": ((-1, 0, 0), (0, 0, 1)), "right": ((1, 0, 0), (0, 0, 1)), "swiso": ((-1, -1, 1), (0, 0, 1)), "seiso": ((1, -1, 1), (0, 0, 1)),
    "neiso": ((1, 1, 1), (0, 0, 1)), "nwiso": ((-1, 1, 1), (0, 0, 1)),
}


def R_view(back, up):
    b = unit(np.array(back, float)); u = np.array(up, float); u = unit(u - np.dot(u, b) * b)
    r = np.cross(u, b)
    return np.stack([r, u, b], axis=1)


class Camera:
    def __init__(self):
        self.target = np.zeros(3); self.R = np.eye(3); self.h = 300.0; self.persp = False; self.fov = 40.0
        self.W = 800; self.H = 600; self.radius = 1000.0

    def right(self):
        return self.R[:, 0]

    def up(self):
        return self.R[:, 1]

    def back(self):
        return self.R[:, 2]

    def dist(self):
        return self.h / (2 * math.tan(math.radians(self.fov) / 2))

    def eye(self):
        return self.target + self.back() * self.dist()

    def view(self):
        e = self.eye() if self.persp else self.target
        M = np.eye(4); M[:3, :3] = self.R.T; M[:3, 3] = -self.R.T @ e
        return M

    def proj(self):
        a = self.W / max(1, self.H)
        if self.persp:
            d = self.dist(); n = max(d * 0.002, 1e-3); f = d + self.radius * 4 + 10
            t = n * math.tan(math.radians(self.fov) / 2); r = t * a
            return np.array([[n / r, 0, 0, 0], [0, n / t, 0, 0], [0, 0, -(f + n) / (f - n), -2 * f * n / (f - n)], [0, 0, -1, 0]])
        hh = self.h / 2; ww = hh * a; D = max(self.radius * 4, self.h * 4, 10.0)
        n, f = -D, D
        return np.array([[1 / ww, 0, 0, 0], [0, 1 / hh, 0, 0], [0, 0, -2 / (f - n), -(f + n) / (f - n)], [0, 0, 0, 1]])

    def mvp(self):
        return self.proj() @ self.view()

    def key(self):
        return (tuple(np.round(self.target, 9)), tuple(np.round(self.R.ravel(), 9)), round(self.h, 9), self.persp, self.W, self.H)

    def project(self, P):
        P = np.asarray(P, float)
        M = self.mvp()
        c = P @ M[:3, :3].T + M[:3, 3]
        w = P @ M[3, :3] + M[3, 3]
        w = np.where(np.abs(w) < 1e-12, 1e-12, w)
        x = (c[..., 0] / w + 1) * 0.5 * self.W; y = (1 - c[..., 1] / w) * 0.5 * self.H; z = c[..., 2] / w
        return np.stack([x, y], axis=-1), z

    def ray(self, x, y):
        nx = 2 * x / self.W - 1; ny = 1 - 2 * y / self.H
        a = self.W / max(1, self.H)
        if self.persp:
            t = math.tan(math.radians(self.fov) / 2)
            d = unit(-self.back() + self.right() * nx * t * a + self.up() * ny * t)
            return self.eye(), d
        p = self.target + self.right() * nx * self.h / 2 * a + self.up() * ny * self.h / 2
        return p + self.back() * self.radius * 4, -self.back()

    def px(self):
        return self.h / max(1, self.H)

    def screen_to_plane(self, x, y, pl):
        ro, rd = self.ray(x, y)
        q = pl.ray_hit(ro, rd)
        if q is None:   # view edge-on: project on view plane through target
            q = Plane(self.target, self.right(), self.up()).ray_hit(ro, rd)
        return q


def resolve_rgb(c, light_bg):
    if isinstance(c, str) and c.startswith("#"):
        return int(c[1:3], 16) / 255, int(c[3:5], 16) / 255, int(c[5:7], 16) / 255
    c = int(c) if c is not None else 7
    if c in (7, 0, 256):
        return (0.05, 0.05, 0.05) if light_bg else (1, 1, 1)
    return aci_rgb(c)


class Batch:
    """GPU buffers of one group (lines or triangles)."""
    def __init__(self, mode, V, C, N=None, width=1.0, stipple=None):
        self.mode = mode; self.n = len(V); self.width = width; self.stipple = stipple
        self.bufs = []
        self.V = np.ascontiguousarray(V, np.float32); self.C = np.ascontiguousarray(C, np.float32)
        self.N = None if N is None else np.ascontiguousarray(N, np.float32)
        self.vbo = None

    def upload(self):
        if self.vbo is not None or self.n == 0:
            return
        ids = gl.glGenBuffers(3 if self.N is not None else 2)
        ids = list(ids) if hasattr(ids, "__len__") else [ids]
        self.vbo = ids
        for buf, arr in zip(ids, (self.V, self.C, self.N)):
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, buf); gl.glBufferData(gl.GL_ARRAY_BUFFER, arr.nbytes, arr, gl.GL_STATIC_DRAW)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)

    def draw(self, color_override=None, alpha=None):
        if self.n == 0:
            return
        self.upload()
        gl.glEnableClientState(gl.GL_VERTEX_ARRAY)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo[0]); gl.glVertexPointer(3, gl.GL_FLOAT, 0, None)
        if color_override is None:
            gl.glEnableClientState(gl.GL_COLOR_ARRAY)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo[1]); gl.glColorPointer(4, gl.GL_FLOAT, 0, None)
        else:
            gl.glColor4f(*color_override)
        if self.N is not None:
            gl.glEnableClientState(gl.GL_NORMAL_ARRAY)
            gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self.vbo[2]); gl.glNormalPointer(gl.GL_FLOAT, 0, None)
        if self.mode == gl.GL_LINES:
            gl.glLineWidth(self.width)
            if self.stipple:
                gl.glEnable(gl.GL_LINE_STIPPLE); gl.glLineStipple(self.stipple[0], self.stipple[1])
        gl.glDrawArrays(self.mode, 0, self.n)
        if self.stipple:
            gl.glDisable(gl.GL_LINE_STIPPLE)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, 0)
        gl.glDisableClientState(gl.GL_VERTEX_ARRAY); gl.glDisableClientState(gl.GL_COLOR_ARRAY); gl.glDisableClientState(gl.GL_NORMAL_ARRAY)

    def free(self):
        if self.vbo:
            try:
                gl.glDeleteBuffers(len(self.vbo), self.vbo)
            except Exception:
                pass
            self.vbo = None


def smooth_normals(V, F, fn, ang=32.0):
    """Crease-aware per-corner normals."""
    nf = len(F)
    if nf == 0:
        return np.zeros((0, 3))
    key = np.round(V / max(1e-9, float(np.ptp(V, axis=0).max()) * 1e-7)).astype(np.int64)
    _, vid = np.unique(key, axis=0, return_inverse=True)
    vid = vid.ravel()
    cv = vid[F].ravel(); cn = np.repeat(fn, 3, axis=0)
    a = V[F[:, 0]]; b = V[F[:, 1]]; c = V[F[:, 2]]
    w = np.repeat(np.linalg.norm(np.cross(b - a, c - a), axis=1), 3) + 1e-30
    order = np.argsort(cv, kind="stable"); cvs = cv[order]
    starts = np.concatenate([[0], np.flatnonzero(np.diff(cvs)) + 1]); counts = np.diff(np.concatenate([starts, [len(cvs)]]))
    if (counts.astype(np.int64) ** 2).sum() > 6e6:
        return cn
    gsz = np.repeat(counts, counts); gst = np.repeat(starts, counts)
    N = len(cvs)
    I = np.repeat(np.arange(N), gsz)
    off = np.arange(len(I)) - np.repeat(np.cumsum(gsz) - gsz, gsz)
    J = np.repeat(gst, gsz) + off
    ni = cn[order][I]; nj = cn[order][J]
    m = np.einsum("ij,ij->i", ni, nj) > math.cos(math.radians(ang))
    acc = np.zeros((N, 3)); np.add.at(acc, I[m], nj[m] * w[order][J[m]][:, None])
    acc /= np.maximum(np.linalg.norm(acc, axis=1, keepdims=True), 1e-30)
    out = np.empty_like(acc); out[order] = acc
    return out


def _rgbf(h):
    """'#rrggbb' -> (r, g, b) floats, or None for an empty value."""
    if not h:
        return None
    c = QColor(h)
    return (c.redF(), c.greenF(), c.blueF()) if c.isValid() else None


class Viewport(QOpenGLWidget):
    mouse_moved = Signal(object)
    view_changed = Signal()

    def __init__(self, ctl):
        super().__init__()
        self.ctl = ctl
        self.cam = Camera()
        self.setMouseTracking(True); self.setFocusPolicy(Qt.StrongFocus); self.setCursor(Qt.BlankCursor)
        self.mode = "shadededges"       # wire | hidden | shaded | shadededges | xray
        self.light = False
        self.show_grid = True; self.osnap_on = True; self.ortho = False; self.snap_on = False; self.dyn = True; self.lwt = False
        self.snap_modes = {"end", "mid", "cen", "quad", "int", "perp", "node", "ins", "img"}
        self.color_by_thk = False
        self.aperture = 12
        from .options import DEFAULTS
        self.opt = dict(DEFAULTS)        # user options (Options dialog); the main window loads the saved profile
        self.click_win = None            # first corner of a click-click selection window
        self.snap_override = None        # one-shot object snap override (Shift + right-click menu)
        self.ucs = Plane()
        self.mouse = QPointF(-100, -100); self.mouse_world = np.zeros(3); self.snap_hit = None
        self.selection = []      # entity ids
        self.hover = None
        self.preview = []        # temp entities
        self.preview_base = None
        self.drag = None         # (kind, start QPointF, extra)
        self.batches = {}; self._built = None; self._pick = None; self._proj = None
        self.textures = {}
        self._recent = []
        self._anim = None
        self.grips = []; self.hot_grip = None
        self.status_text = ""
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick); self._last_move = 0
        self.overlay_msg = None
        self.highlight_extra = []
        self.cam.R = R_view(*VIEWS["top"])

    # ================================================================ doc helpers
    @property
    def doc(self):
        return self.ctl.doc

    def invalidate(self):
        self._built = None; self._proj = None; self.update()

    # ================================================================ GL lifecycle
    def initializeGL(self):
        gl.glEnable(gl.GL_DEPTH_TEST); gl.glDepthFunc(gl.GL_LEQUAL)
        gl.glEnable(gl.GL_BLEND); gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
        gl.glEnable(gl.GL_LINE_SMOOTH); gl.glHint(gl.GL_LINE_SMOOTH_HINT, gl.GL_NICEST)
        gl.glEnable(gl.GL_MULTISAMPLE)

    def resizeGL(self, w, h):
        self.cam.W = max(1, w); self.cam.H = max(1, h); self._proj = None

    # ================================================================ batch building
    def _colorize(self, e, rgb):
        return rgb

    def build(self):
        doc = self.doc
        key = (id(doc), doc.version, doc.rev, self.mode, self.light, self.color_by_thk, self.lwt, E.Entity.anno_scale)
        if self._built == key:
            return
        for b in self.batches.values():
            b.free()
        light = self.light
        lines = {}; fills_V = []; fills_C = []; mesh_V = []; mesh_N = []; mesh_C = []
        pick_s = []; pick_so = []; pick_t = []; pick_to = []; img_list = []
        thk = [e.meta.get("thk", 0) for e in doc.ents.values() if isinstance(e, E.Body) and e.role == "plate"]
        tmin, tmax = (min(thk), max(thk)) if thk else (0, 0)
        from ..core.ship import thickness_colour
        edge_dark = (0.12, 0.13, 0.15) if not light else (0.15, 0.15, 0.17)
        def emit(e, owner, parent=None):
            if isinstance(e, (E.Insert, E.DetailView)) or e.kind == "array":
                for ch in e.children():
                    emit(ch, owner, e)
                return
            try:
                col = doc.color_of(e) if parent is None else (e.color if e.color not in (256, None) else (doc.layer_of(e).color if e.layer != "0" else doc.color_of(parent)))
                rgb = resolve_rgb(col, light)
                lt = doc.ltype_of(e); lw = doc.lw_of(e) if self.lwt else 0
                width = 1.0 if lw <= 25 else min(6.0, lw / 25.0)
                stip = LINETYPES.get(lt)
                key2 = (width, stip)
                if isinstance(e, E.ImageE):
                    img_list.append(e)
                    c = e.corners(); pick_t.extend([c[[0, 1, 2]], c[[0, 2, 3]]]); pick_to.extend([-owner, -owner])
                is_body = isinstance(e, E.Body)
                if is_body:
                    brgb = rgb
                    if self.color_by_thk and e.role == "plate":
                        brgb = thickness_colour(e.meta.get("thk", 0), tmin, tmax)
                    V, F = e.V, e.F
                    if len(F):
                        tri = V[F].reshape(-1, 3)
                        pick_t.append(V[F]); pick_to.append(np.full(len(F), owner))
                        if self.mode != "wire":
                            fn = e.normals()
                            nrm = smooth_normals(V, F, fn) if e.role != "plate" else np.repeat(fn, 3, axis=0)
                            mesh_V.append(tri); mesh_N.append(nrm)
                            a = 0.32 if self.mode == "xray" else 1.0
                            col = brgb if self.mode != "hidden" else ((0.13, 0.15, 0.19) if not light else (1, 1, 1))
                            mesh_C.append(np.tile([*col, a], (len(tri), 1)))
                    erg = (edge_dark if self.mode in ("shadededges", "hidden") else rgb)
                    if self.mode == "shaded":
                        erg = None
                    segs = e.edges()
                    if len(segs) and erg is not None:
                        L = lines.setdefault((1.0, None), ([], []))
                        L[0].append(segs.reshape(-1, 3)); L[1].append(np.tile([*erg, 1.0], (len(segs) * 2, 1)))
                    if len(segs):
                        pick_s.append(segs); pick_so.append(np.full(len(segs), owner))
                    if e.iso is not None and self.mode in ("wire", "xray", "shadededges", "hidden"):
                        for w in e.iso:
                            s = np.stack([w[:-1], w[1:]], axis=1)
                            L = lines.setdefault((1.0, None), ([], []))
                            L[0].append(s.reshape(-1, 3)); L[1].append(np.tile([*(rgb if self.mode == "wire" else erg), 1.0], (len(s) * 2, 1)))
                            pick_s.append(s); pick_so.append(np.full(len(s), owner))
                    return
                for w in e.wire():
                    if len(w) < 2:
                        continue
                    s = np.stack([w[:-1], w[1:]], axis=1)
                    L = lines.setdefault(key2, ([], []))
                    L[0].append(s.reshape(-1, 3)); L[1].append(np.tile([*rgb, 1.0], (len(s) * 2, 1)))
                    pick_s.append(s); pick_so.append(np.full(len(s), owner))
                t = e.tris()
                if t is not None and len(t[1]):
                    V, F = t
                    tri = V[F]
                    fills_V.append(tri.reshape(-1, 3)); fills_C.append(np.tile([*rgb, 1.0], (len(F) * 3, 1)))
                    pick_t.append(tri); pick_to.append(np.full(len(F), owner))
                    if e.kind in ("text", "dimension", "leader", "table"):
                        # 1 px outline of the glyph triangles keeps thin strokes (1, l, i) visible when zoomed out
                        ed = tri[:, [0, 1, 1, 2, 2, 0]].reshape(-1, 3)
                        L = lines.setdefault((1.0, None), ([], []))
                        L[0].append(ed); L[1].append(np.tile([*rgb, 1.0], (len(ed), 1)))
                if isinstance(e, E.PointE):
                    s = self._point_marker(e.p)
                    L = lines.setdefault((1.0, None), ([], []))
                    L[0].append(s.reshape(-1, 3)); L[1].append(np.tile([*rgb, 1.0], (len(s) * 2, 1)))
                    pick_s.append(s); pick_so.append(np.full(len(s), owner))
            except Exception as ex:
                import traceback; traceback.print_exc()
        for e in doc.visible_ents():
            emit(e, e.id)
        self.batches = {}
        for k, (Vs, Cs) in lines.items():
            self.batches[("L",) + k] = Batch(gl.GL_LINES, np.vstack(Vs), np.vstack(Cs), None, k[0], (2, k[1]) if k[1] else None)
        if fills_V:
            self.batches[("F",)] = Batch(gl.GL_TRIANGLES, np.vstack(fills_V), np.vstack(fills_C))
        if mesh_V:
            self.batches[("M",)] = Batch(gl.GL_TRIANGLES, np.vstack(mesh_V), np.vstack(mesh_C), np.vstack(mesh_N))
        self.images = img_list
        S = np.vstack(pick_s) if pick_s else np.zeros((0, 2, 3)); So = np.concatenate(pick_so) if pick_so else np.zeros(0, int)
        T = np.vstack([np.asarray(t).reshape(-1, 3, 3) for t in pick_t]) if pick_t else np.zeros((0, 3, 3))
        To = np.concatenate([np.atleast_1d(np.asarray(o)) for o in pick_to]) if pick_to else np.zeros(0, int)
        self._pick = (S, So, T, To)
        self._proj = None
        bb = doc.extents()
        if bb is not None:
            self.cam.radius = max(1.0, float(norm(bb[1] - bb[0])) * 0.6 + norm((bb[0] + bb[1]) / 2 - self.cam.target))
        self._built = key

    def _point_marker(self, p):
        r = self.cam.px() * 4
        x, y = self.cam.right() * r, self.cam.up() * r
        return np.array([[p - x, p + x], [p - y, p + y]])

    # ================================================================ drawing
    def paintGL(self):
        p = QPainter(self)
        p.beginNativePainting()
        try:
            self.build()
            self._gl_scene()
        except Exception:
            import traceback; traceback.print_exc()
        p.endNativePainting()
        try:
            self._overlay(p)
        except Exception:
            import traceback; traceback.print_exc()
        p.end()

    def _gl_scene(self):
        from .theme import DARK, LIGHT
        th = LIGHT if self.light else DARK
        dpr = self.devicePixelRatioF()
        gl.glViewport(0, 0, int(self.width() * dpr), int(self.height() * dpr))
        bot = _rgbf(self.opt.get("bg_bot")) or th["view_bot"]; top = _rgbf(self.opt.get("bg_top")) or th["view_top"]
        gl.glClearColor(*bot, 1); gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT | gl.GL_STENCIL_BUFFER_BIT)
        # gradient background
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity(); gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()
        gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING)
        gl.glBegin(gl.GL_QUADS)
        gl.glColor3f(*bot); gl.glVertex2f(-1, -1); gl.glVertex2f(1, -1)
        gl.glColor3f(*top); gl.glVertex2f(1, 1); gl.glVertex2f(-1, 1)
        gl.glEnd()
        gl.glEnable(gl.GL_DEPTH_TEST)
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadMatrixd(self.cam.proj().T.ravel())
        gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadMatrixd(self.cam.view().T.ravel())
        if self.show_grid:
            self._draw_grid(th)
        self._draw_images()
        # meshes
        mb = self.batches.get(("M",))
        if mb is not None:
            gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(1.0, 1.0)
            if self.mode != "hidden":
                self._lights()
            if self.mode == "xray":
                gl.glDepthMask(gl.GL_FALSE)
            mb.draw()
            gl.glDepthMask(gl.GL_TRUE)
            gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
        fb = self.batches.get(("F",))
        if fb is not None:
            gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-0.5, -0.5)
            fb.draw(); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
        for k, b in self.batches.items():
            if k[0] == "L":
                b.draw()
        self._draw_highlights()
        self._draw_preview()
        # leave a clean state for QPainter
        gl.glDisable(gl.GL_DEPTH_TEST); gl.glDisable(gl.GL_LIGHTING); gl.glDisable(gl.GL_LINE_STIPPLE); gl.glDisable(gl.GL_TEXTURE_2D)
        gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDepthMask(gl.GL_TRUE); gl.glLineWidth(1.0)
        gl.glMatrixMode(gl.GL_PROJECTION); gl.glLoadIdentity(); gl.glMatrixMode(gl.GL_MODELVIEW); gl.glLoadIdentity()

    def _lights(self):
        gl.glEnable(gl.GL_LIGHTING); gl.glEnable(gl.GL_COLOR_MATERIAL); gl.glColorMaterial(gl.GL_FRONT_AND_BACK, gl.GL_AMBIENT_AND_DIFFUSE)
        gl.glLightModeli(gl.GL_LIGHT_MODEL_TWO_SIDE, 1); gl.glEnable(gl.GL_NORMALIZE)
        gl.glLightModelfv(gl.GL_LIGHT_MODEL_AMBIENT, (0.32, 0.32, 0.34, 1))
        gl.glPushMatrix(); gl.glLoadIdentity()
        gl.glEnable(gl.GL_LIGHT0); gl.glLightfv(gl.GL_LIGHT0, gl.GL_POSITION, (0.35, 0.55, 1.0, 0)); gl.glLightfv(gl.GL_LIGHT0, gl.GL_DIFFUSE, (0.72, 0.72, 0.72, 1))
        gl.glLightfv(gl.GL_LIGHT0, gl.GL_SPECULAR, (0.25, 0.25, 0.25, 1))
        gl.glEnable(gl.GL_LIGHT1); gl.glLightfv(gl.GL_LIGHT1, gl.GL_POSITION, (-0.6, -0.3, 0.4, 0)); gl.glLightfv(gl.GL_LIGHT1, gl.GL_DIFFUSE, (0.22, 0.24, 0.28, 1))
        gl.glPopMatrix()
        gl.glMaterialfv(gl.GL_FRONT_AND_BACK, gl.GL_SPECULAR, (0.3, 0.3, 0.3, 1)); gl.glMaterialf(gl.GL_FRONT_AND_BACK, gl.GL_SHININESS, 40)

    def _draw_images(self):
        imgs = getattr(self, "images", [])
        if not imgs:
            return
        gl.glEnable(gl.GL_TEXTURE_2D); gl.glDepthMask(gl.GL_FALSE)
        for e in imgs:
            tex = self._texture(e)
            if tex is None:
                continue
            gl.glBindTexture(gl.GL_TEXTURE_2D, tex)
            gl.glTexEnvi(gl.GL_TEXTURE_ENV, gl.GL_TEXTURE_ENV_MODE, gl.GL_MODULATE)
            gl.glColor4f(1, 1, 1, 1 - e.fade)
            c = e.corners()
            gl.glBegin(gl.GL_QUADS)
            for (u, v), q in zip(((0, 1), (1, 1), (1, 0), (0, 0)), c):
                gl.glTexCoord2f(u, v); gl.glVertex3d(*q)
            gl.glEnd()
        gl.glBindTexture(gl.GL_TEXTURE_2D, 0); gl.glDisable(gl.GL_TEXTURE_2D); gl.glDepthMask(gl.GL_TRUE)

    def _texture(self, e):
        k = (e.id, len(e.data))
        t = self.textures.get(k)
        if t is not None:
            return t
        img = QImage.fromData(e.data)
        if img.isNull():
            return None
        mx = 4096
        if img.width() > mx or img.height() > mx:
            img = img.scaled(mx, mx, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        img = img.convertToFormat(QImage.Format_RGBA8888)
        buf = np.frombuffer(img.constBits(), np.uint8, img.sizeInBytes()).reshape(img.height(), img.bytesPerLine())[:, :img.width() * 4].copy()
        tid = gl.glGenTextures(1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, tid)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR); gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGBA, img.width(), img.height(), 0, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE, buf)
        self.textures[k] = tid
        return tid

    def _draw_grid(self, th):
        pl = self.ucs; px = self.cam.px()
        if abs(np.dot(pl.z, self.cam.back())) < 0.05:
            return
        step = 10 ** math.floor(math.log10(max(px * 18, 1e-9)))
        for m in (1, 2, 5, 10):
            if step * m / px >= 18:
                step *= m; break
        major = step * 5
        c = pl.to_local(self.cam.target)
        halfw = self.cam.h * self.cam.W / max(1, self.cam.H) / 2 / max(0.2, abs(np.dot(pl.z, self.cam.back())))
        R = max(halfw, self.cam.h / 2) * 1.4
        if R / step > 400:
            step = major; major *= 5
        x0 = math.floor((c[0] - R) / step) * step; x1 = c[0] + R
        y0 = math.floor((c[1] - R) / step) * step; y1 = c[1] + R
        gl.glLineWidth(1.0); gl.glDepthMask(gl.GL_FALSE)
        gl.glBegin(gl.GL_LINES)
        xs = np.arange(x0, x1, step); ys = np.arange(y0, y1, step)
        for x in xs:
            maj = abs(round(x / major) * major - x) < step * 0.01
            col = th["grid_major"] if maj else th["grid"]
            gl.glColor4f(*col, 0.42 if maj else 0.16)
            a = pl.to_world(np.array([x, y0])); b = pl.to_world(np.array([x, y1])); gl.glVertex3d(*a); gl.glVertex3d(*b)
        for y in ys:
            maj = abs(round(y / major) * major - y) < step * 0.01
            col = th["grid_major"] if maj else th["grid"]
            gl.glColor4f(*col, 0.42 if maj else 0.16)
            a = pl.to_world(np.array([x0, y])); b = pl.to_world(np.array([x1, y])); gl.glVertex3d(*a); gl.glVertex3d(*b)
        # axes
        o = pl.o
        gl.glColor4f(0.85, 0.25, 0.25, 0.8); gl.glVertex3d(*(o)); gl.glVertex3d(*(o + pl.x * R))
        gl.glColor4f(0.25, 0.75, 0.35, 0.8); gl.glVertex3d(*(o)); gl.glVertex3d(*(o + pl.y * R))
        gl.glEnd(); gl.glDepthMask(gl.GL_TRUE)
        self.grid_step = step

    def _draw_ent_lines(self, ents, rgba, width):
        gl.glLineWidth(width); gl.glColor4f(*rgba)
        gl.glBegin(gl.GL_LINES)
        for e in ents:
            if isinstance(e, E.Body):
                for s in e.edges()[:20000]:
                    gl.glVertex3d(*s[0]); gl.glVertex3d(*s[1])
                if e.iso is not None:
                    for w in e.iso:
                        for i in range(len(w) - 1):
                            gl.glVertex3d(*w[i]); gl.glVertex3d(*w[i + 1])
                continue
            for w in e.wire():
                for i in range(len(w) - 1):
                    gl.glVertex3d(*w[i]); gl.glVertex3d(*w[i + 1])
            if isinstance(e, E.PointE):
                for s in self._point_marker(e.p):
                    gl.glVertex3d(*s[0]); gl.glVertex3d(*s[1])
        gl.glEnd()

    def _draw_ent_fills(self, ents, rgba):
        gl.glColor4f(*rgba)
        gl.glBegin(gl.GL_TRIANGLES)
        for e in ents:
            t = e.tris()
            if t is None:
                continue
            V, F = t
            if len(F) > 60000:
                continue
            for tri in V[F]:
                gl.glVertex3d(*tri[0]); gl.glVertex3d(*tri[1]); gl.glVertex3d(*tri[2])
        gl.glEnd()

    def _draw_highlights(self):
        doc = self.doc
        sel = [doc.ents[i] for i in self.selection if i in doc.ents]
        hl = (0.18, 0.62, 1.0, 1.0)
        gl.glDisable(gl.GL_DEPTH_TEST)
        if sel:
            bodies = [e for e in sel if isinstance(e, E.Body) or e.kind in ("text", "hatch", "table", "dimension", "leader", "insert", "detailview", "array", "attdef")]
            if bodies:
                gl.glEnable(gl.GL_DEPTH_TEST); gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-1, -1)
                self._draw_ent_fills(bodies, (0.18, 0.62, 1.0, 0.35)); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDisable(gl.GL_DEPTH_TEST)
            self._draw_ent_lines(sel, hl, 2.2)
        if self.opt.get("hover", True) and self.hover is not None and self.hover in doc.ents and self.hover not in self.selection:
            e = doc.ents[self.hover]
            self._draw_ent_lines([e], (0.55, 0.85, 1.0, 0.95), 2.0)
            if isinstance(e, E.Body) or e.kind in ("text", "hatch"):
                gl.glEnable(gl.GL_DEPTH_TEST); gl.glEnable(gl.GL_POLYGON_OFFSET_FILL); gl.glPolygonOffset(-1, -1)
                self._draw_ent_fills([e], (0.55, 0.85, 1.0, 0.18)); gl.glDisable(gl.GL_POLYGON_OFFSET_FILL); gl.glDisable(gl.GL_DEPTH_TEST)
        if self.highlight_extra:
            self._draw_ent_lines(self.highlight_extra, (1.0, 0.7, 0.15, 1.0), 2.4)
        gl.glEnable(gl.GL_DEPTH_TEST)

    def _draw_preview(self):
        if not self.preview:
            return
        col = (1.0, 0.85, 0.3, 1.0) if not self.light else (0.85, 0.35, 0.0, 1.0)
        gl.glDisable(gl.GL_DEPTH_TEST)
        ents = [e for e in self.preview if e is not None]
        self._draw_ent_lines(ents, col, 1.4)
        fills = [e for e in ents if not isinstance(e, E.Body)]
        self._draw_ent_fills(fills, (col[0], col[1], col[2], 0.85))
        bodies = [e for e in ents if isinstance(e, E.Body)]
        if bodies:
            gl.glEnable(gl.GL_DEPTH_TEST); self._draw_ent_fills(bodies, (col[0], col[1], col[2], 0.25))
        gl.glEnable(gl.GL_DEPTH_TEST)

    # ================================================================ overlay (QPainter)
    def _overlay(self, p):
        p.setRenderHint(QPainter.Antialiasing)
        fg = QColor(30, 30, 30) if self.light else QColor(235, 240, 248)
        acc = QColor("#2EC5FF") if not self.light else QColor("#0A84C6")
        # block editor: dynamic parameters (linear = dimension line + stretch frame, flip = mirror axis)
        for prm in (getattr(self, "be_params", None) or []):
            try:
                if prm["type"] not in ("linear", "flip"):
                    continue
                col = QColor("#FF9F1A") if prm["type"] == "linear" else QColor("#B37CFF")
                s2, _ = self.cam.project(np.array([prm["p0"], prm["p1"]], float))
                a, b = QPointF(*s2[0]), QPointF(*s2[1])
                p.setPen(QPen(col, 2, Qt.DashLine)); p.setBrush(Qt.NoBrush); p.drawLine(a, b)
                if prm["type"] == "linear":
                    f = prm.get("frame")
                    if f:
                        c4, _ = self.cam.project(np.array([[f[0], f[1], 0], [f[2], f[1], 0], [f[2], f[3], 0], [f[0], f[3], 0]], float))
                        p.setPen(QPen(col, 1, Qt.DotLine)); p.drawPolygon(QPolygonF([QPointF(*q) for q in c4]))
                    p.setPen(QPen(QColor("white"), 1)); p.setBrush(col)
                    p.drawPolygon(QPolygonF([b + QPointF(0, -7), b + QPointF(7, 0), b + QPointF(0, 7), b + QPointF(-7, 0)]))
                    lab = "%s = %g" % (prm["name"], prm.get("base", 0))
                else:
                    lab = "%s (flip)" % prm["name"]
                f9 = QFont("Segoe UI"); f9.setPixelSize(12); f9.setBold(True); p.setFont(f9)
                m9 = (a + b) / 2; r9 = QRectF(m9.x() - 70, m9.y() - 24, 140, 18)
                p.setPen(Qt.NoPen); p.setBrush(QColor(20, 24, 32, 210)); p.drawRoundedRect(r9, 4, 4)
                from PySide6.QtGui import QPainterPath, QFontMetricsF
                pp = QPainterPath(); tw9 = QFontMetricsF(f9).horizontalAdvance(lab)
                pp.addText(QPointF(m9.x() - tw9 / 2, m9.y() - 10.5), f9, lab)          # outline text: independent of the GL glyph cache
                p.setPen(Qt.NoPen); p.setBrush(col); p.drawPath(pp)
            except Exception:
                pass
        # grips
        o = self.opt
        if self.selection and self.ctl.req is None and o.get("grips", True):
            gs = float(o.get("grip_size", 4))
            self.grips = self._compute_grips()
            for i, (pt, eid, gi) in enumerate(self.grips):
                s, _ = self.cam.project(pt[None])
                x, y = s[0]
                hot = self.hot_grip is not None and self.hot_grip[0] == i
                p.setPen(QPen(QColor("white"), 1)); p.setBrush(QColor(o.get("grip_hot") or "#FF4D4F") if hot else QColor(o.get("grip_color") or "#2F80ED"))
                p.drawRect(QRectF(x - gs, y - gs, 2 * gs, 2 * gs))
        else:
            self.grips = []
        # selection rectangle
        if (self.drag and self.drag[0] == "window") or self.click_win is not None:
            a = self.drag[1] if (self.drag and self.drag[0] == "window") else self.click_win; b = self.mouse
            crossing = b.x() < a.x()
            col = QColor(70, 200, 120) if crossing else QColor(46, 150, 255)
            pen = QPen(col, 1); pen.setStyle(Qt.DashLine if crossing else Qt.SolidLine); p.setPen(pen)
            fill = QColor(col); fill.setAlpha(40); p.setBrush(fill)
            p.drawRect(QRectF(a, b).normalized())
        if o.get("viewcube", True):
            self._draw_viewcube(p)
        if o.get("ucsicon", True):
            self._draw_ucs_icon(p, fg)
        # osnap marker
        if self.snap_hit is not None and o.get("snap_marker", True):
            kind, wp = self.snap_hit[0], self.snap_hit[1]
            s, _ = self.cam.project(np.asarray(wp)[None]); x, y = s[0]
            self._snap_marker(p, kind, x, y)
            f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f)
            txt = SNAP_LABEL.get(kind, kind)
            if o.get("snap_tooltip", True):
                r = QRectF(x + 12, y + 10, 8 + 6.5 * len(txt), 18)
                p.setPen(Qt.NoPen); p.setBrush(QColor(255, 214, 80, 230)); p.drawRoundedRect(r, 3, 3)
                p.setPen(QColor(20, 20, 20)); p.drawText(r, Qt.AlignCenter, txt)
        # crosshair cursor
        if self.underMouse() or self.drag:
            mx, my = self.mouse.x(), self.mouse.y()
            req = self.ctl.req
            pick_only = req is not None and req.kind in ("select", "entity")
            idle = req is None
            pen = QPen(QColor(o["crosshair_color"]) if o.get("crosshair_color") else fg, 1); p.setPen(pen); p.setBrush(Qt.NoBrush)
            pb = float(o.get("pickbox", 5))
            full = max(self.width(), self.height()); pct = float(o.get("crosshair_size", 100))
            L = full if pct >= 100 else max(pb + 6, full * pct / 200.0)          # AutoCAD CURSORSIZE: percent of the screen
            if not pick_only:
                p.drawLine(QPointF(mx - L, my), QPointF(mx - pb, my)); p.drawLine(QPointF(mx + pb, my), QPointF(mx + L, my))
                p.drawLine(QPointF(mx, my - L), QPointF(mx, my - pb)); p.drawLine(QPointF(mx, my + pb), QPointF(mx, my + L))
            if pick_only or idle:
                p.drawRect(QRectF(mx - pb, my - pb, 2 * pb, 2 * pb))
        # dynamic input tooltip
        if self.dyn and self.ctl.req is not None and self.underMouse():
            self._dyn_tip(p)
        if self.overlay_msg:
            f = QFont("Segoe UI"); f.setPixelSize(13); f.setBold(True); p.setFont(f)
            r = QRectF(self.width() / 2 - 240, 14, 480, 30)
            p.setPen(Qt.NoPen); p.setBrush(QColor(20, 30, 45, 210)); p.drawRoundedRect(r, 8, 8)
            p.setPen(QColor("#9FE3FF")); p.drawText(r, Qt.AlignCenter, self.overlay_msg)

    def _dyn_tip(self, p):
        req = self.ctl.req
        mx, my = self.mouse.x(), self.mouse.y()
        lines = [req.prompt.split("[")[0].strip()[:60]]
        wp = self.mouse_world
        if req.kind in ("point", "distance", "angle", "corner"):
            base = req.base
            if base is not None:
                d = wp - base
                q = self.ucs.to_local(wp) - self.ucs.to_local(base)
                ang = math.degrees(math.atan2(q[1], q[0])) % 360
                lines.append(f"L {norm(d):.3f}   ∠ {ang:.2f}°")
            else:
                q = self.ucs.to_local(wp)
                lines.append(f"X {q[0]:.3f}   Y {q[1]:.3f}" + (f"   Z {q[2]:.3f}" if abs(q[2]) > 1e-9 else ""))
        typed = self.ctl.typed_text()
        if typed:
            lines.append("▸ " + typed)
        f = QFont("Segoe UI"); f.setPixelSize(11); p.setFont(f)
        w = max(len(l) for l in lines) * 6.6 + 14; h = 16 * len(lines) + 6
        r = QRectF(mx + 22, my + 22, w, h)
        if r.right() > self.width():
            r.moveLeft(mx - w - 20)
        if r.bottom() > self.height():
            r.moveTop(my - h - 20)
        p.setPen(QPen(QColor(46, 197, 255, 160), 1)); p.setBrush(QColor(22, 28, 38, 225) if not self.light else QColor(255, 255, 255, 235)); p.drawRoundedRect(r, 5, 5)
        p.setPen(QColor("#E6EBF2") if not self.light else QColor("#1E2733"))
        for i, l in enumerate(lines):
            p.drawText(QPointF(r.left() + 7, r.top() + 16 + i * 16), l)

    def _snap_marker(self, p, kind, x, y):
        p.setPen(QPen(QColor(self.opt.get("marker_color") or "#FFC400"), 2)); p.setBrush(Qt.NoBrush); s = float(self.opt.get("marker_size", 6))
        if kind == "end":
            p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s))
        elif kind == "mid":
            p.drawPolygon(QPolygonF([QPointF(x, y - s), QPointF(x + s, y + s), QPointF(x - s, y + s)]))
        elif kind == "cen":
            p.drawEllipse(QPointF(x, y), s, s)
        elif kind == "quad":
            p.drawPolygon(QPolygonF([QPointF(x, y - s), QPointF(x + s, y), QPointF(x, y + s), QPointF(x - s, y)]))
        elif kind == "int":
            p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y - s))
        elif kind == "perp":
            p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x - s, y - s))
            p.drawLine(QPointF(x - s, y), QPointF(x, y)); p.drawLine(QPointF(x, y), QPointF(x, y + s))
        elif kind == "tan":
            p.drawEllipse(QPointF(x, y), s, s); p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y - s))
        elif kind == "near":
            p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y - s)); p.drawLine(QPointF(x + s, y - s), QPointF(x - s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y + s))
        elif kind == "node":
            p.drawEllipse(QPointF(x, y), s, s); p.drawLine(QPointF(x - s, y - s), QPointF(x + s, y + s)); p.drawLine(QPointF(x - s, y + s), QPointF(x + s, y - s))
        elif kind == "img":
            p.setPen(QPen(QColor(80, 230, 140), 2)); p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s)); p.drawPoint(QPointF(x, y))
        else:
            p.drawRect(QRectF(x - s, y - s, 2 * s, 2 * s)); p.drawLine(QPointF(x - s, y), QPointF(x + s, y))

    # ---------------------------------------------------------------- ViewCube
    def _cube_geom(self):
        S = 34; cx, cy = self.width() - 70, 70
        R = self.cam.R
        faces = {"top": ((0, 0, 1), "TOP"), "bottom": ((0, 0, -1), "BOTTOM"), "front": ((0, -1, 0), "FRONT"), "back": ((0, 1, 0), "BACK"),
                 "right": ((1, 0, 0), "RIGHT"), "left": ((-1, 0, 0), "LEFT")}
        out = []
        for key, (n, lab) in faces.items():
            n = np.array(n, float)
            a = np.argmax(np.abs(n)); u = np.zeros(3); u[(a + 1) % 3] = 1; v = np.cross(n, u)
            corners = [n + u + v, n - u + v, n - u - v, n + u - v]
            pts = []
            depth = float(np.dot(n, R[:, 2]))
            for c in corners:
                q = R.T @ (c * S / 1.0 * 0.6)
                pts.append(QPointF(cx + q[0], cy - q[1]))
            out.append((depth, key, lab, QPolygonF(pts), n))
        out.sort(key=lambda t: t[0])
        return out, (cx, cy, S)

    def _draw_viewcube(self, p):
        faces, (cx, cy, S) = self._cube_geom()
        # compass ring
        p.setPen(QPen(QColor(150, 165, 185, 120), 2)); p.setBrush(Qt.NoBrush)
        ring = []
        for k in range(49):
            a = k / 48 * 2 * math.pi; w = np.array([math.cos(a), math.sin(a), -0.95]) * S * 1.15
            q = self.cam.R.T @ w; ring.append(QPointF(cx + q[0], cy - q[1]))
        p.drawPolyline(QPolygonF(ring))
        f = QFont("Segoe UI"); f.setPixelSize(9); f.setBold(True); p.setFont(f)
        hov = getattr(self, "_cube_hover", None)
        for depth, key, lab, poly, n in faces:
            if depth <= 0.02:
                continue
            col = QColor(46, 197, 255, 220) if key == hov else QColor(212, 222, 235, 235) if not self.light else QColor(235, 240, 246, 245)
            shade = int(150 + 80 * depth)
            if key != hov:
                col = QColor(min(255, shade), min(255, shade + 6), min(255, shade + 14), 235)
            p.setPen(QPen(QColor(70, 85, 105), 1)); p.setBrush(col); p.drawPolygon(poly)
            if depth > 0.3:
                c = poly.boundingRect().center()
                p.setPen(QColor(30, 40, 55)); p.drawText(QRectF(c.x() - 30, c.y() - 8, 60, 16), Qt.AlignCenter, lab)

    def cube_hit(self, pos):
        faces, (cx, cy, S) = self._cube_geom()
        if abs(pos.x() - cx) > S * 1.6 or abs(pos.y() - cy) > S * 1.6:
            return None
        for depth, key, lab, poly, n in reversed(faces):
            if depth > 0.02 and poly.containsPoint(pos, Qt.OddEvenFill):
                # corners of the face -> iso views
                br = poly.boundingRect(); c = br.center()
                dx = (pos.x() - c.x()) / max(1, br.width() / 2); dy = (pos.y() - c.y()) / max(1, br.height() / 2)
                if abs(dx) > 0.55 and abs(dy) > 0.55 and key in ("top", "bottom"):
                    # map to iso direction
                    R = self.cam.R
                    w = R @ np.array([np.sign(dx), -np.sign(dy), 0.0]) + np.array(n) * 1.0
                    return ("dir", w)
                return ("face", key)
        return None

    def _draw_ucs_icon(self, p, fg):
        ox, oy = 46, self.height() - 46; L = 30
        cols = [QColor(240, 80, 80), QColor(80, 210, 110), QColor(90, 150, 255)]
        labels = "XYZ"
        for k, ax in enumerate((self.ucs.x, self.ucs.y, self.ucs.z)):
            q = self.cam.R.T @ ax
            if norm(q[:2]) < 0.08:
                continue
            ex, ey = ox + q[0] * L, oy - q[1] * L
            p.setPen(QPen(cols[k], 2.4)); p.drawLine(QPointF(ox, oy), QPointF(ex, ey))
            f = QFont("Segoe UI"); f.setPixelSize(11); f.setBold(True); p.setFont(f); p.setPen(cols[k])
            p.drawText(QPointF(ex + q[0] * 8 - 4, ey - q[1] * 8 + 4), labels[k])
        p.setPen(QPen(fg, 1)); p.setBrush(fg); p.drawEllipse(QPointF(ox, oy), 2, 2)

    # ================================================================ picking
    def _projected(self):
        key = (self.cam.key(), self._built)
        if self._proj is not None and self._proj[0] == key:
            return self._proj[1]
        S, So, T, To = self._pick
        s2, sz = self.cam.project(S.reshape(-1, 3)) if len(S) else (np.zeros((0, 2)), np.zeros(0))
        t2, tz = self.cam.project(T.reshape(-1, 3)) if len(T) else (np.zeros((0, 2)), np.zeros(0))
        res = (s2.reshape(-1, 2, 2), sz.reshape(-1, 2), t2.reshape(-1, 3, 2), tz.reshape(-1, 3))
        self._proj = (key, res)
        return res

    def seg_dist(self, x, y):
        s2, sz, t2, tz = self._projected()
        if not len(s2):
            return np.zeros(0), np.zeros(0)
        a = s2[:, 0]; b = s2[:, 1]; d = b - a
        L2 = np.einsum("ij,ij->i", d, d); L2[L2 == 0] = 1e-12
        t = np.clip(((x - a[:, 0]) * d[:, 0] + (y - a[:, 1]) * d[:, 1]) / L2, 0, 1)
        px = a[:, 0] + t * d[:, 0]; py = a[:, 1] + t * d[:, 1]
        dist = np.hypot(px - x, py - y)
        depth = sz[:, 0] + t * (sz[:, 1] - sz[:, 0])
        return dist, depth

    def pick(self, x, y, tol=6, filt=None):
        self.build()
        S, So, T, To = self._pick
        doc = self.doc
        best = None
        if len(S):
            dist, depth = self.seg_dist(x, y)
            m = dist <= tol
            if m.any():
                idx = np.flatnonzero(m)
                order = idx[np.lexsort((depth[idx], np.round(dist[idx])))]
                for i in order:
                    eid = int(So[i]); e = doc.ents.get(eid)
                    if e is not None and doc.selectable(e) and (filt is None or filt(e)):
                        best = e; break
        if best is None and len(T):
            s2, sz, t2, tz = self._projected()
            mn = t2.min(axis=1); mx = t2.max(axis=1)
            cand = np.flatnonzero((mn[:, 0] <= x) & (mx[:, 0] >= x) & (mn[:, 1] <= y) & (mx[:, 1] >= y))
            if len(cand):
                a = t2[cand, 0]; b = t2[cand, 1]; c = t2[cand, 2]
                v0 = c - a; v1 = b - a; v2 = np.array([x, y]) - a
                d00 = np.einsum("ij,ij->i", v0, v0); d01 = np.einsum("ij,ij->i", v0, v1); d11 = np.einsum("ij,ij->i", v1, v1)
                d20 = np.einsum("ij,ij->i", v2, v0); d21 = np.einsum("ij,ij->i", v2, v1)
                den = d00 * d11 - d01 * d01; den[den == 0] = 1e-12
                u = (d11 * d20 - d01 * d21) / den; v = (d00 * d21 - d01 * d20) / den
                ins = (u >= -1e-6) & (v >= -1e-6) & (u + v <= 1 + 1e-6)
                if ins.any():
                    ci = cand[ins]; uu = u[ins]; vv = v[ins]
                    z = tz[ci, 0] * (1 - uu - vv) + tz[ci, 2] * uu + tz[ci, 1] * vv
                    owners = To[ci]
                    # images (negative ids) last
                    z = z + (owners < 0) * 10.0
                    for k in np.argsort(z):
                        eid = int(abs(owners[k])); e = doc.ents.get(eid)
                        if e is not None and doc.selectable(e) and (filt is None or filt(e)):
                            best = e; break
        return best

    def window_select(self, a, b, crossing):
        self.build()
        x0, x1 = sorted((a.x(), b.x())); y0, y1 = sorted((a.y(), b.y()))
        S, So, T, To = self._pick
        s2, sz, t2, tz = self._projected()
        ids = set()
        n_own = {}
        def inside(P):
            return (P[..., 0] >= x0) & (P[..., 0] <= x1) & (P[..., 1] >= y0) & (P[..., 1] <= y1)
        all_in = {}; any_in = {}
        if len(s2):
            ins = inside(s2)
            seg_in = ins.all(axis=1)
            seg_any = ins.any(axis=1)
            if crossing:
                # segments crossing the rectangle edges
                cr = self._seg_rect_cross(s2, x0, y0, x1, y1)
                seg_any = seg_any | cr
            for flag, store in ((seg_in, all_in), (seg_any, any_in)):
                pass
            uo, inv = np.unique(So, return_inverse=True)
            cnt = np.bincount(inv); cin = np.bincount(inv, weights=seg_in); cany = np.bincount(inv, weights=seg_any)
            for o, c, ci, ca in zip(uo, cnt, cin, cany):
                all_in[int(o)] = ci == c
                any_in[int(o)] = ca > 0
        if len(t2):
            ins = inside(t2).all(axis=1); insa = inside(t2).any(axis=1)
            uo, inv = np.unique(np.abs(To), return_inverse=True)
            cnt = np.bincount(inv); cin = np.bincount(inv, weights=ins); cany = np.bincount(inv, weights=insa)
            for o, c, ci, ca in zip(uo, cnt, cin, cany):
                o = int(o)
                all_in[o] = all_in.get(o, True) and ci == c
                any_in[o] = any_in.get(o, False) or ca > 0
        doc = self.doc
        for o in set(all_in) | set(any_in):
            ok = any_in.get(o, False) if crossing else all_in.get(o, False)
            e = doc.ents.get(o)
            if ok and e is not None and doc.selectable(e):
                ids.add(o)
        return [doc.ents[i] for i in sorted(ids)]

    @staticmethod
    def _seg_rect_cross(s2, x0, y0, x1, y1):
        a = s2[:, 0]; b = s2[:, 1]
        res = np.zeros(len(s2), bool)
        edges = [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)), ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
        for (cx, cy), (dx, dy) in edges:
            c = np.array([cx, cy]); d = np.array([dx, dy])
            def orient(p, q, r):
                return (q[..., 0] - p[..., 0]) * (r[..., 1] - p[..., 1]) - (q[..., 1] - p[..., 1]) * (r[..., 0] - p[..., 0])
            o1 = orient(a, b, c); o2 = orient(a, b, d)
            o3 = orient(np.broadcast_to(c, a.shape), np.broadcast_to(d, a.shape), a); o4 = orient(np.broadcast_to(c, a.shape), np.broadcast_to(d, a.shape), b)
            res |= (o1 * o2 < 0) & (o3 * o4 < 0)
        return res

    # ================================================================ OSNAP
    def compute_snap(self, x, y, base=None):
        if not self.osnap_on and not self.snap_override:
            return None
        self.build()
        S, So, T, To = self._pick
        doc = self.doc
        ap = self.aperture
        cand = []
        if len(S):
            dist, depth = self.seg_dist(x, y)
            m = dist <= ap * 1.4
            if m.any():
                idx = np.flatnonzero(m); idx = idx[np.argsort(dist[idx])]
                seen = []
                for i in idx:
                    o = int(So[i])
                    if o not in seen:
                        seen.append(o)
                    if len(seen) >= 8:
                        break
                cand = seen
        for o in cand:
            if o in self._recent:
                self._recent.remove(o)
            self._recent.insert(0, o)
        del self._recent[6:]
        pool = list(dict.fromkeys(cand + self._recent))
        ents = [doc.ents[o] for o in pool if o in doc.ents]
        best = None
        def consider(kind, P, prio=0):
            nonlocal best
            P = np.asarray(P, float).reshape(-1, 3)
            if not len(P):
                return
            s2, z = self.cam.project(P)
            d = np.hypot(s2[:, 0] - x, s2[:, 1] - y)
            k = int(np.argmin(d))
            if d[k] <= ap and (best is None or (prio, d[k]) < (best[2], best[3])):
                best = (kind, P[k].copy(), prio, d[k])
        modes = {self.snap_override} if self.snap_override else self.snap_modes
        for e in ents:
            try:
                sn = e.snaps()
            except Exception:
                continue
            for kind in ("end", "mid", "cen", "quad", "node", "ins"):
                if kind in modes and kind in sn and (e.id in cand or kind in ("cen", "node", "ins")):
                    consider(kind, sn[kind])
        touched = [doc.ents[o] for o in cand[:5] if o in doc.ents]
        if "int" in modes and len(touched) >= 1:
            pts = []
            prs = []
            for e in touched:
                pr = e.prims()
                if len(pr) > 400:
                    pr = [q for q in pr if self._prim_near(q, x, y, ap * 3)]
                prs.append(pr)
            for i in range(len(touched)):
                for j in range(i + 1, len(touched)):
                    for a in prs[i]:
                        for b in prs[j]:
                            for sa, sb, q in prim_intersect(a, b):
                                pts.append(q)
            if pts:
                consider("int", pts, 0)
        if best is None and base is not None:
            if "perp" in modes:
                pts = []
                for e in touched:
                    for pr in e.prims()[:400]:
                        if pr[0] == "L":
                            a, b = pr[1], pr[2]; d = b - a; L2 = np.dot(d, d)
                            if L2 > 0:
                                t = np.dot(base - a, d) / L2
                                if -1e-9 <= t <= 1 + 1e-9:
                                    pts.append(a + t * d)
                        else:
                            c, r, n, u = pr[1:5]
                            dd = base - c; dd = dd - np.dot(dd, n) * n
                            if norm(dd) > EPS:
                                pts.append(c + unit(dd) * r)
                if pts:
                    consider("perp", pts, 1)
            if "tan" in modes:
                pts = []
                for e in touched:
                    for pr in e.prims()[:50]:
                        if pr[0] == "A":
                            c, r, n, u = pr[1:5]
                            dd = base - c; dd = dd - np.dot(dd, n) * n; L = norm(dd)
                            if L > r:
                                a = math.acos(r / L); ux = unit(dd); vy = np.cross(n, ux)
                                for s in (1, -1):
                                    pts.append(c + r * (math.cos(a) * ux + s * math.sin(a) * vy))
                if pts:
                    consider("tan", pts, 1)
        if best is None and "near" in modes and touched:
            e = touched[0]
            pts = []
            for pr in e.prims()[:2000]:
                P = prim_tess(pr) if pr[0] == "A" else np.array([pr[1], pr[2]])
                s2, z = self.cam.project(P)
                for k in range(len(P) - 1):
                    a, b = s2[k], s2[k + 1]; d = b - a; L2 = np.dot(d, d)
                    if L2 <= 0:
                        continue
                    t = min(1, max(0, ((x - a[0]) * d[0] + (y - a[1]) * d[1]) / L2))
                    if np.hypot(*(a + t * d - [x, y])) <= ap:
                        pts.append(P[k] + t * (P[k + 1] - P[k]))
            if pts:
                consider("near", pts, 2)
        if best is None and "img" in modes and getattr(self, "images", None):
            q = self._image_snap(x, y)
            if q is not None:
                best = ("img", q, 3, 0)
        return best

    def _prim_near(self, pr, x, y, tol):
        P = np.array(prim_ends(pr)) if pr[0] == "L" else prim_tess(pr)[::8]
        s2, _ = self.cam.project(P)
        mn = s2.min(axis=0) - tol; mx = s2.max(axis=0) + tol
        return mn[0] <= x <= mx[0] and mn[1] <= y <= mx[1]

    def _image_snap(self, x, y):
        from ..core import raster
        for e in self.images:
            pl = Plane(e.o, e.u, e.v)
            ro, rd = self.cam.ray(x, y)
            q = pl.ray_hit(ro, rd)
            if q is None:
                continue
            px, py = e.world_to_pixel(q)
            if not (0 <= px < e.wpx and 0 <= py < e.hpx):
                continue
            sk = raster.skeleton_cached(e)
            if sk is None:
                continue
            scale = sk.shape[1] / e.wpx
            apx = self.aperture * self.cam.px() / (norm(e.u) / e.wpx) * scale
            r = raster.nearest_on(sk, px * scale, py * scale, max(2, apx))
            if r is not None:
                return e.pixel_to_world(r[0] / scale, r[1] / scale)
        return None

    # ================================================================ grips
    def _compute_grips(self):
        out = []
        doc = self.doc
        for eid in self.selection[:60]:
            e = doc.ents.get(eid)
            if e is None:
                continue
            for gi, pt in enumerate(grip_points(e)):
                out.append((pt, eid, gi))
        return out

    def grip_at(self, x, y):
        for i, (pt, eid, gi) in enumerate(self.grips):
            s, _ = self.cam.project(pt[None])
            g = float(self.opt.get("grip_size", 4)) + 2
            if abs(s[0, 0] - x) <= g and abs(s[0, 1] - y) <= g:
                return i
        return None

    # ================================================================ view control
    def zoom_extents(self, ents=None, animate=True):
        bb = self.doc.extents(ents)
        if bb is None:
            bb = (np.array([-100, -100, 0.0]), np.array([100, 100, 0.0]))
        c = (bb[0] + bb[1]) / 2
        corners = np.array([[bb[i][0], bb[j][1], bb[k][2]] for i in (0, 1) for j in (0, 1) for k in (0, 1)])
        q = (corners - c) @ self.cam.R
        w = np.ptp(q[:, 0]); h = np.ptp(q[:, 1])
        a = self.cam.W / max(1, self.cam.H)
        hh = max(h, w / a, 1e-6) * 1.12
        self._animate_to(c, self.cam.R, hh if norm(bb[1] - bb[0]) > 0 else 100)

    def zoom_window(self, a, b):
        x0, x1 = sorted((a.x(), b.x())); y0, y1 = sorted((a.y(), b.y()))
        if x1 - x0 < 4 or y1 - y0 < 4:
            return
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        ro, rd = self.cam.ray(cx, cy)
        c = Plane(self.cam.target, self.cam.right(), self.cam.up()).ray_hit(ro, rd)
        hh = max((y1 - y0), (x1 - x0) * self.cam.H / max(1, self.cam.W)) * self.cam.px()
        self._animate_to(c, self.cam.R, hh)

    def set_view(self, name=None, direction=None):
        if name in VIEWS:
            R = R_view(*VIEWS[name])
        else:
            d = unit(np.asarray(direction, float))
            up = (0, 0, 1) if abs(d[2]) < 0.999 else (0, 1, 0)
            R = R_view(d, up)
        self._animate_to(self.cam.target, R, self.cam.h)

    def plan_view(self, pl):
        R = np.stack([pl.x, pl.y, pl.z], axis=1)
        self._animate_to(self.cam.target, R, self.cam.h)

    def _animate_to(self, target, R, h, dur=None):
        dur = float(self.opt.get("anim_ms", 280)) / 1000.0 if dur is None else dur
        if not self.opt.get("anim", True) or dur <= 0.0:
            self.cam.target = np.asarray(target, float); self.cam.R = np.asarray(R, float); self.cam.h = float(h)
            self._anim = None; self._proj = None; self.update(); self.view_changed.emit(); return
        self._anim = (time.time(), dur, self.cam.target.copy(), quat_from_R(self.cam.R), self.cam.h, np.asarray(target, float), quat_from_R(R), float(h))
        if not self.timer.isActive():
            self.timer.start(15)

    def _tick(self):
        if self._anim is None:
            self.timer.stop(); return
        t0, dur, ta, qa, ha, tb, qb, hb = self._anim
        t = min(1.0, (time.time() - t0) / dur)
        s = t * t * (3 - 2 * t)
        self.cam.target = ta + (tb - ta) * s
        self.cam.R = R_from_quat(slerp(qa, qb, s))
        self.cam.h = ha * (hb / ha) ** s if ha > 0 and hb > 0 else hb
        if t >= 1.0:
            self.cam.R = R_from_quat(qb); self._anim = None; self.timer.stop()
        self._proj = None; self.update(); self.view_changed.emit()

    def zoom_at(self, x, y, f):
        ro, rd = self.cam.ray(x, y)
        P = Plane(self.cam.target, self.cam.right(), self.cam.up())
        q = P.ray_hit(ro, rd) if not self.cam.persp else self._depth_point(x, y)
        self.cam.h *= f
        if q is not None:
            self.cam.target = q + (self.cam.target - q) * f
        self._proj = None; self.update(); self.view_changed.emit()

    def _depth_point(self, x, y):
        e = self.pick(x, y, 8)
        ro, rd = self.cam.ray(x, y)
        P = Plane(self.cam.target, self.cam.right(), self.cam.up())
        return P.ray_hit(ro, rd)

    def pan_px(self, dx, dy):
        k = self.cam.px()
        self.cam.target = self.cam.target - self.cam.right() * dx * k + self.cam.up() * dy * k
        self._proj = None; self.update(); self.view_changed.emit()

    def orbit_px(self, dx, dy, pivot=None):
        a = -dx * 0.008; b = -dy * 0.008
        from ..core.geom import m_rotate
        Rz = m_rotate((0, 0, 0), (0, 0, 1), a)[:3, :3]
        R = Rz @ self.cam.R
        Rx = m_rotate((0, 0, 0), R[:, 0], b)[:3, :3]
        R2 = Rx @ R
        if R2[2, 1] < -1e-3 and False:
            R2 = R
        piv = self.cam.target if pivot is None else pivot
        rel = self.cam.target - piv
        self.cam.target = piv + (Rx @ Rz) @ rel
        self.cam.R = R2
        self._proj = None; self.update(); self.view_changed.emit()

    # ================================================================ point resolution
    def world_point(self, x, y, base=None):
        """Mouse -> snapped world point. Returns (point, snap_kind)."""
        hit = self.compute_snap(x, y, base)
        if hit is not None:
            return hit[1], hit[0]
        q = self.cam.screen_to_plane(x, y, self.ucs)
        if q is None:
            q = self.cam.target.copy()
        loc = self.ucs.to_local(q)
        if self.snap_on:
            st = getattr(self, "grid_step", 10.0)
            loc[:2] = np.round(loc[:2] / st) * st
        if self.ortho and base is not None:
            b = self.ucs.to_local(base)
            d = loc - b
            if abs(d[0]) >= abs(d[1]):
                loc[1] = b[1]
            else:
                loc[0] = b[0]
            loc[2] = b[2]
        return self.ucs.to_world(loc), None

    # ================================================================ events
    def mouseMoveEvent(self, ev):
        pos = ev.position(); self.mouse = pos
        if self.drag and self.drag[0] in ("pan", "orbit"):
            last = self.drag[2]
            dx, dy = pos.x() - last.x(), pos.y() - last.y()
            if self.drag[0] == "pan":
                self.pan_px(dx, dy)
            else:
                if not self.drag[3] and abs(pos.x() - self.drag[1].x()) + abs(pos.y() - self.drag[1].y()) > 4:
                    self.drag = (self.drag[0], self.drag[1], last, True)
                if self.drag[3]:
                    self.orbit_px(dx, dy, self.drag[4] if len(self.drag) > 4 else None)
            self.drag = (self.drag[0], self.drag[1], pos) + tuple(self.drag[3:])
            return
        req = self.ctl.req
        base = req.base if req is not None else None
        hk = getattr(self, "_cube_hover", None)
        ch = self.cube_hit(pos)
        self._cube_hover = ch[1] if ch and ch[0] == "face" else None
        if req is not None and req.kind in ("point", "distance", "angle", "corner") or self.hot_grip is not None:
            if self.hot_grip is not None:
                base = self.grips[self.hot_grip[0]][0] if self.hot_grip[0] < len(self.grips) else None
            wp, kind = self.world_point(pos.x(), pos.y(), base)
            self.snap_hit = (kind, wp) if kind else None
            self.mouse_world = wp
            if self.hot_grip is not None:
                self.preview = self.ctl.grip_preview(self.hot_grip, wp)
            elif req.preview is not None:
                try:
                    self.preview = [e for e in (req.preview(wp) or []) if e is not None]
                except Exception:
                    self.preview = []
            self.hover = None
        else:
            self.snap_hit = None
            q = self.cam.screen_to_plane(pos.x(), pos.y(), self.ucs)
            if q is not None:
                self.mouse_world = q
            if not self.drag and time.time() - self._last_move > 0.03:
                filt = req.filter if (req is not None and req.kind == "entity") else None
                e = self.pick(pos.x(), pos.y(), self.opt.get('pickbox', 5) + 1, filt)
                self.hover = e.id if e is not None else None
                self._last_move = time.time()
        self.mouse_moved.emit(self.mouse_world)
        self.update()

    def mousePressEvent(self, ev):
        pos = ev.position(); self.mouse = pos
        self.setFocus()
        if ev.button() == Qt.MiddleButton:
            if ev.modifiers() & Qt.ShiftModifier:
                self.drag = ("orbit", pos, pos, True)
            else:
                self.drag = ("pan", pos, pos)
            return
        if ev.button() == Qt.RightButton:
            piv = None
            if self.selection and self.opt.get("orbit_sel", True):
                bb = self.doc.extents([self.doc.ents[i] for i in self.selection if i in self.doc.ents])
                if bb is not None:
                    piv = (bb[0] + bb[1]) / 2
            self.drag = ("orbit", pos, pos, False, piv)
            return
        if ev.button() != Qt.LeftButton:
            return
        ch = self.cube_hit(pos)
        if ch is not None:
            if ch[0] == "face":
                self.set_view(ch[1])
            else:
                self.set_view(direction=ch[1])
            return
        req = self.ctl.req
        if self.click_win is not None:                      # second click of a click-click window
            a = self.click_win; self.click_win = None
            if abs(pos.x() - a.x()) < 3 and abs(pos.y() - a.y()) < 3:
                self.update(); return
            if getattr(self.ctl, "zoom_window_pending", False):
                self.ctl.zoom_window_pending = False; self.zoom_window(a, pos); return
            ents = self.window_select(a, pos, pos.x() < a.x())
            self.ctl.pick_window(ents, bool(ev.modifiers() & Qt.ShiftModifier), (a, pos))
            self.update(); return
        if self.hot_grip is not None:
            base = self.grips[self.hot_grip[0]][0] if self.hot_grip[0] < len(self.grips) else None
            wp, kind = self.world_point(pos.x(), pos.y(), base)
            self.ctl.grip_finish(self.hot_grip, wp); self.hot_grip = None; self.preview = []; self.update()
            return
        if req is not None and req.kind in ("point", "distance", "angle", "corner"):
            wp, kind = self.world_point(pos.x(), pos.y(), req.base)
            self.ctl.feed_point(wp)
            return
        if req is not None and req.kind == "entity":
            e = self.pick(pos.x(), pos.y(), self.opt.get('pickbox', 5) + 1, req.filter)
            if e is not None:
                q = self.cam.screen_to_plane(pos.x(), pos.y(), self.ucs)
                ps = self._pick_point_on(e, pos.x(), pos.y())
                self.ctl.feed_entity(e, ps if ps is not None else q)
            return
        # idle or selection request
        if req is None:
            g = self.grip_at(pos.x(), pos.y())
            if g is not None:
                self.hot_grip = (g, self.grips[g][1], self.grips[g][2]); self.update()
                return
        e = self.pick(pos.x(), pos.y(), self.opt.get('pickbox', 5) + 1, req.filter if req is not None else None)
        if e is not None:
            self.ctl.pick_entity(e, bool(ev.modifiers() & Qt.ShiftModifier))
            self.update()
            return
        self.drag = ("window", pos, pos)

    def refresh_preview(self):
        """Recompute the rubber-band preview at the current cursor position (called after every accepted input)."""
        req = self.ctl.req
        if req is None or req.preview is None or req.kind not in ("point", "distance", "angle", "corner"):
            return
        if self.mouse.x() < 0 or self.mouse.y() < 0:
            return
        try:
            wp, kind = self.world_point(self.mouse.x(), self.mouse.y(), req.base)
            self.mouse_world = wp
            self.preview = [e for e in (req.preview(wp) or []) if e is not None]
        except Exception:
            self.preview = []

    def curve_at_cursor(self, tol=None):
        """(entity, world point on it, unit tangent) for the line / curve under the cursor, else None."""
        x, y = self.mouse.x(), self.mouse.y()
        e = self.pick(x, y, tol or max(8, self.aperture), lambda q: q.kind in ("line", "polyline", "arc", "circle", "spline", "ellipse"))
        if e is None:
            return None
        best = None
        try:
            prs = e.prims()[:3000]
        except Exception:
            return None
        for pr in prs:
            P = prim_tess(pr) if pr[0] == "A" else np.array([pr[1], pr[2]])
            s2, z = self.cam.project(P)
            for k in range(len(P) - 1):
                a, b = s2[k], s2[k + 1]; d = b - a; L2 = np.dot(d, d)
                t = 0 if L2 <= 0 else min(1, max(0, ((x - a[0]) * d[0] + (y - a[1]) * d[1]) / L2))
                dist = np.hypot(*(a + t * d - [x, y]))
                if best is None or dist < best[0]:
                    best = (dist, P[k] + t * (P[k + 1] - P[k]), P[k + 1] - P[k])
        if best is None or np.linalg.norm(best[2]) < 1e-12:
            return None
        return e, best[1], best[2] / np.linalg.norm(best[2])

    def _pick_point_on(self, e, x, y):
        """World point on entity e under cursor (for trim / fillet picks)."""
        best = None
        for pr in e.prims()[:3000]:
            P = prim_tess(pr) if pr[0] == "A" else np.array([pr[1], pr[2]])
            s2, z = self.cam.project(P)
            for k in range(len(P) - 1):
                a, b = s2[k], s2[k + 1]; d = b - a; L2 = np.dot(d, d)
                t = 0 if L2 <= 0 else min(1, max(0, ((x - a[0]) * d[0] + (y - a[1]) * d[1]) / L2))
                dist = np.hypot(*(a + t * d - [x, y]))
                if best is None or dist < best[0]:
                    best = (dist, P[k] + t * (P[k + 1] - P[k]))
        return best[1] if best else None

    def mouseReleaseEvent(self, ev):
        pos = ev.position()
        if self.drag is None:
            return
        kind = self.drag[0]
        if kind == "orbit" and ev.button() == Qt.RightButton:
            moved = self.drag[3]
            self.drag = None
            if not moved:
                if ev.modifiers() & Qt.ShiftModifier:
                    self.ctl.osnap_menu(ev.globalPosition().toPoint(), override=True)      # AutoCAD: Shift + right-click = snap override
                else:
                    self.ctl.right_click(ev.globalPosition().toPoint())
            return
        if kind == "pan" and ev.button() == Qt.MiddleButton:
            self.drag = None; return
        if kind == "orbit":
            self.drag = None; return
        if kind == "window" and ev.button() == Qt.LeftButton:
            a = self.drag[1]; self.drag = None
            if abs(pos.x() - a.x()) < 3 and abs(pos.y() - a.y()) < 3:
                if self.opt.get("pickdrag", "Both") != "Press and drag":
                    self.click_win = a              # click, move, click (AutoCAD implied windowing); Esc cancels
                elif self.ctl.req is None and not (ev.modifiers() & Qt.ShiftModifier):
                    self.ctl.clear_selection()
                self.update(); return
            if getattr(self.ctl, "zoom_window_pending", False):
                self.ctl.zoom_window_pending = False; self.zoom_window(a, pos); return
            ents = self.window_select(a, pos, pos.x() < a.x())
            self.ctl.pick_window(ents, bool(ev.modifiers() & Qt.ShiftModifier), (a, pos))
            self.update()

    def mouseDoubleClickEvent(self, ev):
        if ev.button() == Qt.MiddleButton:
            self.zoom_extents()
        elif ev.button() == Qt.LeftButton and self.ctl.req is None:
            e = self.pick(ev.position().x(), ev.position().y(), self.opt.get('pickbox', 5) + 1) if self.opt.get('dblclick_edit', True) else None
            if e is not None:
                self.ctl.edit_entity(e)

    def wheelEvent(self, ev):
        d = ev.angleDelta().y()
        if d == 0:
            return
        zf = min(100.0, max(3.0, float(self.opt.get("zoom_factor", 60))))        # AutoCAD ZOOMFACTOR 3..100
        f = (1.0 - 0.25 * zf / 100.0) ** (d / 120)
        if self.opt.get("wheel_reverse", False):
            f = 1.0 / f
        self.zoom_at(ev.position().x(), ev.position().y(), f)

    def leaveEvent(self, ev):
        self.hover = None; self.update()

    def keyPressEvent(self, ev):
        self.ctl.viewport_key(ev)

    def window_contains_screen(self, rect, P):
        s2, _ = self.cam.project(np.asarray(P, float))
        x0, x1 = sorted((rect[0].x(), rect[1].x())); y0, y1 = sorted((rect[0].y(), rect[1].y()))
        return (s2[:, 0] >= x0) & (s2[:, 0] <= x1) & (s2[:, 1] >= y0) & (s2[:, 1] <= y1)

    def grab_image(self):
        return self.grabFramebuffer()


def grip_points(e):
    k = e.kind
    if k == "line":
        return [e.p0, e.p1, (e.p0 + e.p1) / 2]
    if k == "circle":
        u = e.u(); v = np.cross(e.n, u)
        return [e.c, e.c + e.r * u, e.c + e.r * v, e.c - e.r * u, e.c - e.r * v]
    if k == "arc":
        p0, p1 = e.ends(); return [e.c, p0, p1]
    if k == "polyline":
        return list(e.pts[:200])
    if k == "point":
        return [e.p]
    if k in ("text", "table"):
        return [e.p]
    if k == "insert":
        return [e.snaps()["ins"][0]] + e.dyn_grips()
    if k == "detailview":
        return [e.snaps()["ins"][0]]
    if k == "array":
        return e.grips()
    if k == "ellipse":
        return [e.c, e.c + e.major]
    if k == "spline":
        return list((e.fit if e.fit is not None else e.ctrl)[:100])
    if k == "image":
        return list(e.corners())
    if k == "dimension":
        return list(e.dpts)
    if k == "leader":
        return list(e.pts)
    if k == "body":
        bb = e.bbox()
        return [(bb[0] + bb[1]) / 2] if bb is not None else []
    return []


def grip_apply(e, gi, p):
    """Move grip gi of entity e to p (in place)."""
    k = e.kind
    from ..core.geom import m_translate
    if k == "line":
        if gi == 0:
            e.p0 = p.copy()
        elif gi == 1:
            e.p1 = p.copy()
        else:
            e.transform(m_translate(p - (e.p0 + e.p1) / 2))
    elif k == "circle":
        if gi == 0:
            e.c = p.copy()
        else:
            r = norm(p - e.c)
            if r > 0:
                e.r = r
    elif k == "arc":
        if gi == 0:
            e.c = p.copy()
        else:
            p0, p1 = e.ends(); pm = arc_pt(e.c, e.r, e.n, e.u(), (e.a0 + e.a1) / 2)
            a = E.Arc.through(p if gi == 1 else p0, pm, p if gi == 2 else p1)
            if a is not None:
                e.c, e.r, e.n, e.a0, e.a1 = a.c, a.r, a.n, a.a0, a.a1
    elif k == "polyline":
        e.pts[gi] = p
    elif k == "spline":
        if e.fit is not None:
            f = e.fit.copy(); f[gi] = p
            s = E.Spline.through(f); e.ctrl, e.knots, e.deg, e.fit = s.ctrl, s.knots, s.deg, s.fit
        else:
            e.ctrl[gi] = p
    elif k == "array":
        e.grip_set(gi, p)
    elif k == "insert" and gi >= 1:
        e.dyn_grip_set(gi - 1, p)
    elif k == "dimension":
        e.dpts[gi] = p.copy()
    elif k == "leader":
        e.pts[gi] = p
    elif k == "ellipse" and gi == 1:
        e.major = p - e.c
    else:
        pts = grip_points(e)
        if gi < len(pts):
            e.transform(m_translate(p - pts[gi]))
    e.touch()


def prim_ends(pr):
    from ..core.geom import prim_ends as pe
    return pe(pr)
