"""Automatic update without reinstalling the program.

The installed launcher (ALIEF_CADPRO.exe + runtime) never changes. Updates are small signed packages:
    app-<ver>.zip   the 'alief_cadpro' package of the new version
    libs-<id>.zip   optional extra / newer Python libraries
They are downloaded to %LOCALAPPDATA%\\AliefEnergy\\ALIEF_CADPRO\\app\\<ver> (no admin rights needed), verified
(Ed25519 signature of the notice + SHA-256 of every package) and used from the next start. boot.py picks the newest
healthy version and falls back to the previous one if a new version fails to start twice.
"""
import hashlib
import json
import os
import shutil
import sys
import threading
import time
import zipfile

PRODUCT = "ALIEF_CADPRO"
REPO = "aliefen/alief-cadpro-update"
NOTICE = "alief_cadpro_update.json"
URLS = [f"https://raw.githubusercontent.com/{REPO}/main/{NOTICE}",
        f"https://cdn.jsdelivr.net/gh/{REPO}@main/{NOTICE}"]
PUBLIC_KEY_HEX = "aaf3b10db14bdbd9de96b4595d04aeb545127ad5f9db6717aa0ead64290a5709"


def local_root():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "AliefEnergy", PRODUCT)


def vtuple(v):
    out = []
    for p in str(v).split("."):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


# ------------------------------------------------------------------------------------------- Ed25519 (RFC 8032)
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _inv(x):
    return pow(x, _p - 2, _p)


def _xrec(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p:
        x = x * _I % _p
    if x % 2:
        x = _p - x
    return x


_By = 4 * _inv(5) % _p
_Bx = _xrec(_By)
_B = (_Bx, _By, 1, _Bx * _By % _p)


def _add(P, Q):
    x1, y1, z1, t1 = P; x2, y2, z2, t2 = Q
    A = (y1 - x1) * (y2 - x2) % _p; B = (y1 + x1) * (y2 + x2) % _p
    C = t1 * 2 * _d * t2 % _p; D = z1 * 2 * z2 % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P); s >>= 1
    return Q


def _enc(P):
    x, y, z, t = P; zi = _inv(z); x = x * zi % _p; y = y * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _dec(s):
    y = int.from_bytes(s, "little"); sign = y >> 255; y &= (1 << 255) - 1
    x = _xrec(y)
    if (x & 1) != sign:
        x = _p - x
    P = (x, y, 1, x * y % _p)
    if (-x * x + y * y - 1 - _d * x * x * y * y) % _p:
        raise ValueError("invalid point")
    return P


def _h(m):
    return int.from_bytes(hashlib.sha512(m).digest(), "little")


def keypair(seed=None):
    seed = seed or os.urandom(32)
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little"); a &= (1 << 254) - 8; a |= 1 << 254
    return seed, _enc(_mul(a, _B))


def sign(seed, msg):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little"); a &= (1 << 254) - 8; a |= 1 << 254
    A = _enc(_mul(a, _B))
    r = _h(h[32:] + msg) % _q
    R = _enc(_mul(r, _B))
    S = (r + _h(R + A + msg) * a) % _q
    return R + int.to_bytes(S, 32, "little")


def verify(pub, msg, sig):
    try:
        if len(sig) != 64:
            return False
        R = _dec(sig[:32]); A = _dec(pub); S = int.from_bytes(sig[32:], "little")
        if S >= _q:
            return False
        h = _h(sig[:32] + pub + msg) % _q
        return _enc(_mul(S, _B)) == _enc(_add(R, _mul(h, A)))
    except Exception:
        return False


def canonical(notice):
    d = {k: v for k, v in notice.items() if k != "sig"}
    return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()


def notice_valid(notice, pub_hex=None):
    import base64
    pub = bytes.fromhex(pub_hex or PUBLIC_KEY_HEX)
    try:
        return notice.get("product") == PRODUCT and verify(pub, canonical(notice), base64.b64decode(notice.get("sig", "")))
    except Exception:
        return False


# ------------------------------------------------------------------------------------------- network
def _get(url, timeout=20, progress=None):
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": f"{PRODUCT}-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        total = int(r.headers.get("Content-Length") or 0); buf = bytearray()
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            buf += chunk
            if progress:
                progress(len(buf), total)
        return bytes(buf)


def fetch_notice():
    last = None
    for u in URLS:
        try:
            data = _get(u + f"?t={int(time.time())}" if "raw.githubusercontent" in u else u, 15)
            n = json.loads(data.decode("utf-8"))
            return n
        except Exception as ex:
            last = ex
    raise RuntimeError(f"update server not reachable ({last})")


def installed_versions():
    root = os.path.join(local_root(), "app")
    out = []
    if os.path.isdir(root):
        for v in os.listdir(root):
            if os.path.exists(os.path.join(root, v, "ok.flag")):
                out.append(v)
    return sorted(out, key=vtuple)


def install_packages(notice, blobs):
    """blobs: {name: bytes}. Extract app + libs; returns target folder."""
    ver = notice["version"]
    root = local_root(); appdir = os.path.join(root, "app", ver); tmp = appdir + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True); os.makedirs(tmp, exist_ok=True)
    libs = []
    for pk in notice["packages"]:
        data = blobs[pk["name"]]
        if hashlib.sha256(data).hexdigest() != pk["sha256"] or len(data) != pk["size"]:
            raise RuntimeError(f"package {pk['name']} is corrupt")
        import io
        z = zipfile.ZipFile(io.BytesIO(data))
        if pk["name"].startswith("libs"):
            dst = os.path.join(root, "libs", pk["name"])
            if not os.path.exists(os.path.join(dst, "ok.flag")):
                shutil.rmtree(dst, ignore_errors=True); z.extractall(dst)
                open(os.path.join(dst, "ok.flag"), "w").write(pk["sha256"])
            libs.append(pk["name"])
        else:
            z.extractall(tmp)
    json.dump({"version": ver, "libs": libs, "min_launcher": notice.get("min_launcher", 1), "installed": time.strftime("%Y-%m-%d %H:%M")},
              open(os.path.join(tmp, "version.json"), "w"))
    shutil.rmtree(appdir, ignore_errors=True)
    os.replace(tmp, appdir)
    open(os.path.join(appdir, "ok.flag"), "w").write(ver)
    # keep the newest 3 versions
    vers = installed_versions()
    for old in vers[:-3]:
        shutil.rmtree(os.path.join(root, "app", old), ignore_errors=True)
    return appdir


def download_and_install(notice, progress=None):
    blobs = {}
    total = sum(p["size"] for p in notice["packages"]); done = 0
    for pk in notice["packages"]:
        if pk["name"].startswith("libs") and os.path.exists(os.path.join(local_root(), "libs", pk["name"], "ok.flag")):
            blobs[pk["name"]] = None
            continue
        base = done
        blobs[pk["name"]] = _get(pk["url"], 120, (lambda a, b, base=base: progress(base + a, total)) if progress else None)
        done += pk["size"]
    for k in list(blobs):
        if blobs[k] is None:
            notice = dict(notice); notice["packages"] = [p for p in notice["packages"] if p["name"] != k]
            blobs.pop(k)
    return install_packages(notice, blobs)


def install_offline(path):
    """Offline update file (.cadpro-update = zip with the notice + packages)."""
    z = zipfile.ZipFile(path)
    notice = json.loads(z.read(NOTICE))
    if not notice_valid(notice):
        raise RuntimeError("update file signature is not valid")
    blobs = {pk["name"]: z.read(pk["file"]) for pk in notice["packages"]}
    return notice, install_packages(notice, blobs)


class Checker:
    """Background check: calls on_result(status, notice, info) in the worker thread."""
    def __init__(self, current, on_result, auto_install=True):
        self.current = current; self.on_result = on_result; self.auto = auto_install

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            n = fetch_notice()
        except Exception as ex:
            self.on_result("offline", None, str(ex)); return
        if not notice_valid(n):
            self.on_result("badsig", n, "signature check failed"); return
        if vtuple(n.get("version")) <= vtuple(self.current):
            self.on_result("latest", n, ""); return
        if n.get("version") in installed_versions():
            self.on_result("ready", n, "already downloaded"); return
        if not self.auto:
            self.on_result("available", n, ""); return
        try:
            d = download_and_install(n)
            self.on_result("ready", n, d)
        except Exception as ex:
            self.on_result("failed", n, str(ex))
