"""PDF import with PDFium (pypdfium2, Apache-2.0 / BSD): vector paths -> lines / polylines, text -> text,
fills -> solid hatch, embedded images or the whole rendered page -> raster underlay. Loaded only when used."""
import ctypes
import math
import numpy as np
from . import entities as E
from .geom import norm

PT_MM = 25.4 / 72.0


def _qimage_png(arr):
    from PySide6.QtGui import QImage
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice
    a = np.ascontiguousarray(arr)
    h, w = a.shape[:2]
    fmt = QImage.Format_RGB888 if a.shape[2] == 3 else QImage.Format_RGBA8888
    img = QImage(a.data, w, h, a.strides[0], fmt).copy()
    ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly); img.save(buf, "PNG")
    return bytes(ba), w, h


def page_count(path):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    n = len(pdf); pdf.close()
    return n


def page_thumb(path, i, width=220):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path); pg = pdf[i]
    W, H = pg.get_size()
    bm = pg.render(scale=width / W, rev_byteorder=True)
    png = _qimage_png(bm.to_numpy())[0]
    pdf.close()
    return png, (W * PT_MM, H * PT_MM)


def _mat(obj):
    import pypdfium2.raw as R
    m = R.FS_MATRIX()
    R.FPDFPageObj_GetMatrix(obj, ctypes.byref(m))
    return np.array([[m.a, m.c, m.e], [m.b, m.d, m.f], [0, 0, 1.0]])


def _color(fn, obj):
    r, g, b, a = (ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint())
    if not fn(obj, ctypes.byref(r), ctypes.byref(g), ctypes.byref(b), ctypes.byref(a)):
        return None
    if a.value == 0:
        return None
    if r.value < 40 and g.value < 40 and b.value < 40:
        return 7
    if r.value > 235 and g.value > 235 and b.value > 235:
        return "#ffffff"
    return "#%02x%02x%02x" % (r.value, g.value, b.value)


def import_pdf(path, page=0, scale=1.0, origin=(0, 0, 0), vectors=True, texts=True, fills=False, images=True,
               raster_page=False, dpi=200, layer_prefix="PDF", join=True):
    """Return list of entities. scale = model units per paper mm (e.g. 100 for a 1:100 drawing in mm)."""
    import pypdfium2 as pdfium
    import pypdfium2.raw as R
    out = []
    o = np.asarray(origin, float)
    pdf = pdfium.PdfDocument(path)
    pg = pdf[page]
    Wp, Hp = pg.get_size()
    k = PT_MM * scale
    def W(x, y):
        return o + np.array([x * k, y * k, 0.0])
    if raster_page:
        bm = pg.render(scale=dpi / 72.0, rev_byteorder=True)
        png, w, h = _qimage_png(bm.to_numpy())
        img = E.ImageE(png, o, (Wp * k, 0, 0), (0, Hp * k, 0), w, h, f"page {page + 1}")
        img.layer = layer_prefix + "_IMAGE"; out.append(img)
    tp = pg.get_textpage() if texts else None
    def walk(obj, M):
        t = R.FPDFPageObj_GetType(obj)
        Mo = M @ _mat(obj)
        if t == R.FPDF_PAGEOBJ_FORM:
            for i in range(R.FPDFFormObj_CountObjects(obj)):
                walk(R.FPDFFormObj_GetObject(obj, i), Mo)
            return
        if t == R.FPDF_PAGEOBJ_PATH and (vectors or fills):
            fm = ctypes.c_int(); st = ctypes.c_int()
            R.FPDFPath_GetDrawMode(obj, ctypes.byref(fm), ctypes.byref(st))
            col = _color(R.FPDFPageObj_GetStrokeColor, obj) or 7
            fcol = _color(R.FPDFPageObj_GetFillColor, obj)
            wd = ctypes.c_float(); R.FPDFPageObj_GetStrokeWidth(obj, ctypes.byref(wd))
            n = R.FPDFPath_CountSegments(obj)
            polys = []; cur = []; closed = []
            pend = []
            for i in range(n):
                sg = R.FPDFPath_GetPathSegment(obj, i)
                x = ctypes.c_float(); y = ctypes.c_float()
                R.FPDFPathSegment_GetPoint(sg, ctypes.byref(x), ctypes.byref(y))
                q = Mo @ np.array([x.value, y.value, 1.0])
                pt = W(q[0], q[1])
                typ = R.FPDFPathSegment_GetType(sg)
                if typ == R.FPDF_SEGMENT_MOVETO:
                    if len(cur) >= 2:
                        polys.append(cur); closed.append(False)
                    cur = [pt]; pend = []
                elif typ == R.FPDF_SEGMENT_LINETO:
                    cur.append(pt)
                elif typ == R.FPDF_SEGMENT_BEZIERTO:
                    pend.append(pt)
                    if len(pend) == 3:
                        p0 = cur[-1] if cur else pend[0]
                        c1, c2, p3 = pend
                        for u in np.linspace(0, 1, 13)[1:]:
                            cur.append((1 - u) ** 3 * p0 + 3 * (1 - u) ** 2 * u * c1 + 3 * (1 - u) * u * u * c2 + u ** 3 * p3)
                        pend = []
                if R.FPDFPathSegment_GetClose(sg) and len(cur) >= 2:
                    polys.append(cur); closed.append(True); cur = [cur[0]]
            if len(cur) >= 2:
                polys.append(cur); closed.append(False)
            for pp, cl in zip(polys, closed):
                pp = np.array(pp)
                if len(pp) >= 2 and norm(pp[0] - pp[-1]) < 1e-9 * max(1, k):
                    cl = True; pp = pp[:-1]
                if fills and fm.value and fcol not in (None, "#ffffff") and cl and len(pp) >= 3:
                    h = E.Hatch([pp], (0, 0, 1), "SOLID"); h.color = fcol; h.layer = layer_prefix + "_FILL"; out.append(h)
                if not vectors or len(pp) < 2:
                    continue
                lay = layer_prefix + "_GEOMETRY"
                if not st.value:
                    if not fm.value or fcol in (None, "#ffffff"):
                        continue
                    lay = layer_prefix + "_OUTLINE"; col = fcol      # filled shape / stroke converted to fill
                e = E.Line(pp[0], pp[1]) if len(pp) == 2 and not cl else E.Polyline(pp, cl)
                e.color = col; e.layer = lay
                if wd.value * math.sqrt(abs(np.linalg.det(Mo[:2, :2]))) * PT_MM >= 0.45:
                    e.lw = 50
                out.append(e)
        elif t == R.FPDF_PAGEOBJ_TEXT and False:
            n = R.FPDFTextObj_GetText(obj, tp.raw, None, 0)
            if n <= 2:
                return
            buf = ctypes.create_string_buffer(n * 2)
            R.FPDFTextObj_GetText(obj, tp.raw, ctypes.cast(buf, ctypes.POINTER(ctypes.c_ushort)), n * 2)
            s = buf.raw[:n * 2 - 2].decode("utf-16-le", errors="ignore").strip()
            if not s:
                return
            fs = ctypes.c_float(); R.FPDFTextObj_GetFontSize(obj, ctypes.byref(fs))
            sc = math.sqrt(abs(np.linalg.det(Mo[:2, :2])))
            hgt = fs.value * sc * 0.70 * PT_MM * scale
            q = Mo @ np.array([0, 0, 1.0])
            dx, dy = Mo[0, 0], Mo[1, 0]
            tx = E.Text(W(q[0], q[1]), s, max(hgt, 1e-6), (dx, dy, 0), (0, 0, 1), 0, 0)
            tx.color = _color(R.FPDFPageObj_GetFillColor, obj) or 7; tx.layer = layer_prefix + "_TEXT"
            out.append(tx)
        elif t == R.FPDF_PAGEOBJ_IMAGE and images and not raster_page:
            try:
                im = pdfium.PdfImage(obj, pg, pdf) if hasattr(pdfium, "PdfImage") else None
                bm = im.get_bitmap(render=True)
                png, w, h = _qimage_png(bm.to_numpy()[..., ::-1] if bm.to_numpy().shape[2] == 3 else bm.to_numpy())
                c = Mo @ np.array([[0, 1, 1, 0], [0, 0, 1, 1], [1, 1, 1, 1.0]])
                x0, y0 = c[0].min(), c[1].min(); x1, y1 = c[0].max(), c[1].max()
                img = E.ImageE(png, W(x0, y0), ((x1 - x0) * k, 0, 0), (0, (y1 - y0) * k, 0), w, h, "pdf image")
                img.layer = layer_prefix + "_IMAGE"; out.append(img)
            except Exception:
                pass
    nobj = R.FPDFPage_CountObjects(pg.raw)
    for i in range(nobj):
        walk(R.FPDFPage_GetObject(pg.raw, i), np.eye(3))
    if tp is not None:
        runs = []
        for i in range(tp.count_rects()):
            try:
                l, b, r, t_ = tp.get_rect(i)
                st = tp.get_text_bounded(l, b, r, t_).strip()
            except Exception:
                continue
            if st:
                runs.append([l, b, r, t_, st])
        runs.sort(key=lambda q: (round(q[1], 0), q[0]))
        merged = []
        for q in runs:
            if merged:
                m = merged[-1]; h = max(m[3] - m[1], q[3] - q[1])
                if abs(m[1] - q[1]) < 0.25 * h and -0.2 * h < q[0] - m[2] < 0.9 * h:
                    gap = q[0] - m[2]
                    m[4] += (" " if gap > 0.22 * h else "") + q[4]; m[2] = max(m[2], q[2]); m[3] = max(m[3], q[3]); continue
            merged.append(list(q))
        for l, b, r, t_, st in merged:
            hh = t_ - b; ww = r - l
            vertical = hh > ww * 1.5 and len(st) > 2
            if vertical:
                tx = E.Text(W(r - ww * 0.2, b), st, ww * 0.72 * PT_MM * scale, (0, 1, 0), (0, 0, 1), 0, 0)
            else:
                tx = E.Text(W(l, b + hh * 0.2), st, hh * 0.72 * PT_MM * scale, (1, 0, 0), (0, 0, 1), 0, 0)
            tx.color = 7; tx.layer = layer_prefix + "_TEXT"; out.append(tx)
        tp.close()
    pdf.close()
    if join:
        out = merge_segments(out)
    return out


def merge_segments(ents):
    """Join PDF line segments that share end points (same colour / layer) into polylines."""
    from .editops import join
    lines = [e for e in ents if e.kind == "line"]
    others = [e for e in ents if e.kind != "line"]
    if len(lines) < 2:
        return ents
    groups = {}
    for l in lines:
        groups.setdefault((l.layer, str(l.color), l.lw), []).append(l)
    res = []
    for key, ls in groups.items():
        if len(ls) > 2500:
            res += ls; continue
        joined, used = join(ls, tol=1e-4)
        used_ids = set(id(u) for u in used)
        for j in joined:
            j.layer, j.color, j.lw = ls[0].layer, ls[0].color, ls[0].lw
        res += joined + [l for l in ls if id(l) not in used_ids]
    return others + res
