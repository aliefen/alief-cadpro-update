"""Command engine: commands are generators that yield input requests (point, selection, entity, number, ...)."""
import math
import re
import numpy as np
from ..core.geom import unit, norm, v3


class Cancel(Exception):
    pass


class Pt(np.ndarray):
    """Point array that compares unequal to option strings (so `p == "Close"` is simply False)."""
    def __eq__(self, other):
        if isinstance(other, str):
            return False
        return np.ndarray.__eq__(self, other)

    def __ne__(self, other):
        if isinstance(other, str):
            return True
        return np.ndarray.__ne__(self, other)

    __hash__ = None


def P(v):
    return np.asarray(v3(v), float).view(Pt)


class Req:
    def __init__(self, kind, prompt, base=None, preview=None, options=None, default=None, filt=None, allow_none=True):
        self.kind = kind; self.prompt = prompt; self.base = None if base is None else v3(base); self.preview = preview
        self.options = options or []; self.default = default; self.filter = filt; self.allow_none = allow_none
        self.picked = []      # for select


class Ctx:
    """Helpers handed to every command."""
    def __init__(self, app):
        self.app = app

    @property
    def doc(self):
        return self.app.doc

    @property
    def view(self):
        return self.app.view

    @property
    def ucs(self):
        return self.app.view.ucs

    def pt(self, prompt, base=None, preview=None, options=None, default=None, numeric=False):
        r = Req("point", prompt, base, preview, options, default); r.numeric = numeric
        return r

    def height(self, prompt, base, preview=None, options=None):
        """Point (signed distance along the work-plane normal) or a typed number."""
        return self.pt(prompt, base, preview, options, numeric=True)

    def corner(self, prompt, base, preview=None, options=None):
        return Req("corner", prompt, base, preview, options)

    def dist(self, prompt, base=None, default=None, preview=None, options=None):
        return Req("distance", prompt, base, preview, options, default)

    def num(self, prompt, default=None, options=None):
        return Req("number", prompt, None, None, options, default)

    def angle(self, prompt, base=None, default=None, preview=None, options=None):
        return Req("angle", prompt, base, preview, options, default)

    def text(self, prompt, default=None):
        return Req("string", prompt, None, None, None, default)

    def opt(self, prompt, options, default=None):
        return Req("option", prompt, None, None, options, default)

    def sel(self, prompt="Select objects", filt=None):
        return Req("select", prompt, filt=filt)

    def ent(self, prompt, filt=None, options=None):
        return Req("entity", prompt, filt=filt, options=options)

    def msg(self, s):
        self.app.message(s)

    def add(self, e, layer=None):
        return self.doc.add(e, layer)

    def plane(self):
        return self.view.ucs


def match_option(s, options):
    s = s.strip().upper()
    if not s:
        return None
    for o in options:
        key = re.sub(r"[^A-Z0-9]", "", "".join(ch for ch in o if ch.isupper() or ch.isdigit()))
        if s == o.upper() or (key and s == key) or o.upper().startswith(s):
            return o
    return None


def parse_point(s, last, ucs):
    """AutoCAD-style coordinate entry in the UCS: x,y[,z]  @dx,dy[,dz]  @d<a  d<a  #x,y"""
    t = s.strip().replace(" ", "")
    if not t:
        return None
    rel = t.startswith("@")
    if t.startswith("#"):
        t = t[1:]
    if rel:
        t = t[1:]
    m = re.fullmatch(r"([-+\d.eE]+)<([-+\d.eE]+)(?:,([-+\d.eE]+))?", t)
    if m:
        d = float(m.group(1)); a = math.radians(float(m.group(2))); z = float(m.group(3) or 0)
        loc = np.array([d * math.cos(a), d * math.sin(a), z])
    else:
        parts = t.split(",")
        if len(parts) < 2 or len(parts) > 3:
            return None
        try:
            loc = np.array([float(p) for p in parts] + ([0.0] if len(parts) == 2 else []))
        except ValueError:
            return None
    if rel:
        if last is None:
            return ucs.to_world(loc)
        return v3(last) + ucs.x * loc[0] + ucs.y * loc[1] + ucs.z * loc[2]
    if len(t.split(",")) == 2 and last is not None and not m:
        loc[2] = ucs.to_local(last)[2] if False else 0.0
    return ucs.to_world(loc)


def parse_float(s):
    try:
        v = eval(s.replace("^", "**"), {"__builtins__": {}}, {"pi": math.pi, "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos,
                                                              "tan": math.tan})
        return float(v)
    except Exception:
        return None


class Engine:
    def __init__(self, app):
        self.app = app; self.cmds = {}; self.alias = {}; self.desc = {}
        self.gen = None; self.req = None; self.name = None; self.last_cmd = None; self.last_point = None
        self.ctx = Ctx(app)

    def register(self, name, fn, aliases=(), desc=""):
        self.cmds[name] = fn; self.desc[name] = desc
        for a in aliases:
            self.alias[a] = name

    def resolve(self, name):
        n = name.strip().upper().lstrip("_").lstrip("'")
        return self.alias.get(n, n) if self.alias.get(n, n) in self.cmds else None

    def busy(self):
        return self.gen is not None

    def run(self, name, *args):
        cmd = self.resolve(name)
        if cmd is None:
            self.app.message(f'Unknown command "{name.strip().upper()}". Press F1 or type HELP for the command list.')
            return False
        fn = self.cmds[cmd]
        if getattr(fn, "transparent", False):
            g = fn(self.ctx, *args)
            if g is not None and hasattr(g, "send"):
                for _ in g:
                    pass
            return True
        if self.gen is not None:
            self.cancel()
        self.name = cmd; self.last_cmd = cmd
        self.app.message(f"Command: {cmd}", echo=True)
        self.app.doc.begin(cmd)
        try:
            g = fn(self.ctx, *args)
        except Exception as ex:
            self._fail(ex); return False
        if g is None or not hasattr(g, "send"):
            self._finish(); return True
        self.gen = g
        self._step(None, first=True)
        return True

    def _step(self, value, first=False, throw=None):
        try:
            if throw is not None:
                req = self.gen.throw(throw)
            elif first:
                req = next(self.gen)
            else:
                req = self.gen.send(value)
            if (req.kind == "select" and self.app.view.selection and getattr(req, "use_pre", True) and getattr(self, "noun_verb", True)
                    and not getattr(self, "_consumed_pre", False)):
                pre = [self.app.doc.ents[i] for i in self.app.view.selection if i in self.app.doc.ents]
                if req.filter:
                    pre = [e for e in pre if req.filter(e)]
                if pre:
                    self._consumed_pre = True
                    self.app.clear_selection(silent=True)
                    return self._step(pre)
            self.req = req
            self.app.on_request(req)
        except StopIteration:
            self._finish()
        except Cancel:
            self._finish(cancelled=True)
        except Exception as ex:
            self._fail(ex)

    def _finish(self, cancelled=False):
        self.gen = None; self.req = None; self.name = None; self._consumed_pre = False
        self.app.doc.end()
        self.app.on_request(None)
        if cancelled:
            self.app.message("*Cancel*")

    def _fail(self, ex):
        import traceback; traceback.print_exc()
        self.gen = None; self.req = None; self.name = None; self._consumed_pre = False
        self.app.doc.end()
        self.app.on_request(None)
        self.app.message(f"Error: {ex}")

    def cancel(self):
        if self.gen is not None:
            self._step(None, throw=Cancel())

    # ---------------------------------------------------------------- inputs
    def feed_point(self, p):
        r = self.req
        if r is None:
            return
        p = P(p)
        if r.kind == "distance" and r.base is not None:
            self.last_point = p; self._step(norm(p - r.base)); return
        if r.kind == "angle" and r.base is not None:
            q = self.app.view.ucs.to_local(p) - self.app.view.ucs.to_local(r.base)
            self.last_point = p; self._step(math.degrees(math.atan2(q[1], q[0]))); return
        if r.kind in ("distance", "angle"):
            # first of two points
            self._two_point = p
            r.base = p
            self.app.on_request(r)
            return
        self.last_point = p
        self._step(p)

    def feed_entity(self, e, p):
        if self.req is not None and self.req.kind == "entity":
            self._step((e, P(p) if p is not None else None))

    def feed_selection_done(self, ents):
        if self.req is not None and self.req.kind == "select":
            self._step(ents)

    def feed_enter(self):
        r = self.req
        if r is None:
            if self.last_cmd:
                self.run(self.last_cmd)
            return
        if r.kind == "select":
            self._step(list(r.picked)); return
        if r.default is not None:
            d = r.default
            self._step(P(d) if isinstance(d, np.ndarray) else d); return
        self._step(None)

    def feed_text(self, s):
        r = self.req
        if r is None:
            if s.strip():
                parts = s.strip().split()
                self.run(parts[0])
            elif self.last_cmd:
                self.run(self.last_cmd)
            return
        s0 = s.strip()
        if s0 == "":
            return self.feed_enter()
        opt = match_option(s0, r.options) if r.options else None
        if opt is not None and r.kind != "string":
            self._step(opt); return
        k = r.kind
        if k == "string":
            self._step(s); return
        if k == "point" and getattr(r, "numeric", False):
            v = parse_float(s0)
            if v is not None:
                self._step(v); return
        if k in ("point", "corner"):
            p = parse_point(s0, r.base if r.base is not None else self.last_point, self.app.view.ucs)
            if p is None:
                v = parse_float(s0)
                if v is not None and r.base is not None:
                    d = unit(self.app.view.mouse_world - r.base)
                    if norm(d) < 1e-12:
                        d = self.app.view.ucs.x
                    p = r.base + d * v
            if p is None:
                self.app.message("Invalid point. Use x,y  x,y,z  @dx,dy  @dist<angle or a distance.")
                return
            self.last_point = p
            self._step(P(p)); return
        if k in ("distance", "number", "angle"):
            v = parse_float(s0)
            if v is None:
                self.app.message("Requires a number."); return
            self._step(v); return
        if k == "option":
            self.app.message("Invalid option."); return
        if k == "select":
            u = s0.upper()
            if u in ("ALL", "A"):
                ents = [e for e in self.app.doc.visible_ents() if self.app.doc.selectable(e) and (r.filter is None or r.filter(e))]
                r.picked = ents; self.app.set_selection([e.id for e in ents]); return
            if u in ("L", "LAST"):
                ents = list(self.app.doc.ents.values())[-1:]
                r.picked += ents; self.app.set_selection([e.id for e in r.picked]); return
            self.app.message("Select objects (ALL / Last) or press Enter."); return
        if k == "entity":
            self.app.message("Pick an object."); return
