"""Commands of version 2.0: SPLIT, JOIN for every curve type, PROJECT, SCALE2D / SCALE1D / SCALENU, DEVLOFT,
PROFILE2D, TEXTALIGN, BOLT (bolt & nut drawings), TABLEXLS (table from Excel / clipboard)."""
import math
import numpy as np

from ..core import entities as E, editops as X, nurbs as NB
from ..core.geom import unit, norm, m_translate, prim_intersect, prim_len, prim_closest
from .misc import T

CURVES = ("line", "arc", "circle", "polyline", "spline", "ellipse")


def _presel(c, prompt, filt=None):
    ents = [e for e in c.app.selected_ents() if filt is None or filt(e)]
    if not ents:
        ents = yield c.sel(prompt, filt=filt)
    c.app.clear_selection(silent=True)
    return [e for e in (ents or []) if filt is None or filt(e)]


def _styled(new, src):
    for e in new:
        e.style_from(src)
    return new


# ------------------------------------------------------------------------------------------------- SPLIT
def _chain_len(segs, n=24):
    """Cumulative parameter table of Bezier pieces: [(segment, t, point)] sampled, for nearest-point searches."""
    out = []
    for i, B in enumerate(segs):
        for t in np.linspace(0, 1, n + 1)[:-1] if i < len(segs) - 1 else np.linspace(0, 1, n + 1):
            out.append((i, float(t), NB.seg_point(B, float(t))))
    return out


def _closest_param(segs, p, table=None):
    table = table or _chain_len(segs)
    P = np.array([q for _, _, q in table]); k = int(np.argmin(((P - p) ** 2).sum(axis=1)))
    i, t, _ = table[k]; h = 1.0 / 24
    lo, hi = max(0.0, t - h), min(1.0, t + h)
    for _ in range(40):                                  # golden-section style refinement on one piece
        a = lo + (hi - lo) / 3; b = hi - (hi - lo) / 3
        if norm(NB.seg_point(segs[i], a) - p) < norm(NB.seg_point(segs[i], b) - p):
            hi = b
        else:
            lo = a
    t = (lo + hi) / 2
    return i, t, float(norm(NB.seg_point(segs[i], t) - p))


def split_curve(e, pts, tol=1e-6):
    """Split curve e at the points pts (on the curve).  Returns the pieces (same kind where possible), or None."""
    pts = [np.asarray(p, float) for p in pts]
    if e.kind in ("line", "arc", "circle", "polyline"):
        pr = X.curve_prims(e); L = sum(prim_len(q) for q in pr); ss = []
        for p in pts:
            acc = 0.0; best = None
            for q in pr:
                sq, pq = prim_closest(q, p); d = float(norm(np.asarray(pq, float) - p))
                if best is None or d < best[0]:
                    best = (d, acc + sq)
                acc += prim_len(q)
            if best is not None and best[0] <= max(tol, 1e-6 * max(L, 1.0)):
                ss.append(best[1])
        closed = bool(getattr(e, "closed", False)) or e.kind == "circle"
        ss = sorted({round(s, 9) for s in ss if (closed or 1e-9 * L < s < L * (1 - 1e-9))})
        if not ss or (closed and len(ss) < 1):
            return None
        out = []
        def sub(a, b):
            r = X.sub_curve(e, a, b)
            return list(r) if isinstance(r, (list, tuple)) else [r]
        if closed:
            rng = [(ss[0], ss[0] + L)] if len(ss) == 1 else list(zip(ss, ss[1:] + [ss[0] + L]))
            for a, b in rng:
                out += sub(a, b)
        else:
            for a, b in zip([0.0] + ss, ss + [L]):
                out += sub(a, b)
        return _styled([o for o in out if o is not None], e) or None
    segs = NB.entity_beziers(e)
    if not segs:
        return None
    table = _chain_len(segs); cuts = []
    span = max(1e-9, float(np.ptp(np.array([q for _, _, q in table]), axis=0).max()))
    for p in pts:
        i, t, d = _closest_param(segs, p, table)
        if d <= max(tol, 3e-3 * span):                     # crossing points come from the displayed (faceted) spline
            cuts.append(i + t)
    closed = bool(getattr(e, "closed", False))
    n = len(segs)
    cuts = sorted({round(u, 9) for u in cuts if (closed or 1e-7 < u < n - 1e-7)})
    if not cuts:
        return None
    def piece(u0, u1):
        res = []
        i0 = min(int(math.floor(u0)), n - 1); i1 = min(int(math.floor(u1 - 1e-12)), n - 1)
        for i in range(i0, i1 + 1):
            B = segs[i % n]; a = u0 - i if i == i0 else 0.0; b = u1 - i if i == i1 else 1.0
            if b - a < 1e-10:
                continue
            if b < 1 - 1e-12:
                B = NB.seg_split(B, b)[0]; a = a / b if b > 1e-12 else 0.0
            if a > 1e-12:
                B = NB.seg_split(B, a)[1]
            res.append(B)
        return res
    out = []
    if closed:
        rng = [(cuts[0], cuts[0] + n)] if len(cuts) == 1 else list(zip(cuts, cuts[1:] + [cuts[0] + n]))
        for a, b in rng:
            sg = (piece(a, min(b, n)) + (piece(0.0, b - n) if b > n else []))
            if sg:
                out.append(NB.simplify(sg))
    else:
        for a, b in zip([0.0] + cuts, cuts + [float(n)]):
            sg = piece(a, b)
            if sg:
                out.append(NB.simplify(sg))
    return _styled(out, e) or None


def _intersections(e, cutters):
    """Points where curve e meets the cutting objects."""
    one, many = X._box_tests(e)
    oprims = X.prims_near(cutters, e, one, many)
    pts = []
    for p in e.prims():
        for q in oprims:
            for sa, sb, pt in prim_intersect(p, q):
                pts.append(np.asarray(pt, float))
    return pts


def cmd_split(c):
    """SPLIT (as in Rhino): cut curves into pieces with other objects or at picked points; every piece is kept."""
    ents = yield from _presel(c, "SPLIT  Select curves to split", lambda e: e.kind in CURVES)
    if not ents:
        return
    r = yield c.sel("Select cutting objects  or [Point]  (Enter with nothing selected = pick points)")
    cutters = [e for e in (r or [])]
    npieces = 0
    if cutters:
        for e in ents:
            pts = _intersections(e, [k for k in cutters if k is not e])
            pcs = split_curve(e, pts) if pts else None
            if pcs and len(pcs) > 1:
                c.doc.remove(e)
                for q in pcs:
                    c.doc.add_keep(q)
                npieces += len(pcs)
    else:
        pts = []
        while True:
            p = yield c.pt("Specify split point on the curve <done>")
            if p is None:
                break
            pts.append(p)
        if not pts:
            return
        for e in ents:
            pcs = split_curve(e, pts, tol=c.view.cam.px() * 6)
            if pcs and (len(pcs) > 1 or getattr(e, "closed", False) or e.kind == "circle"):
                c.doc.remove(e)
                for q in pcs:
                    c.doc.add_keep(q)
                npieces += len(pcs)
    c.app.clear_selection(silent=True)
    c.msg(f"SPLIT: {npieces} piece(s)" if npieces else "SPLIT: the objects do not cross - nothing was split")


# ------------------------------------------------------------------------------------------------- JOIN
def join_any(ents, tol=1e-6):
    """Join curves of any type whose ends meet.  Lines / arcs / polylines give a polyline (as before); as soon as a spline
    or an ellipse is part of a chain the result is one spline that keeps the exact shape.  Returns (new, used)."""
    simple = [e for e in ents if e.kind in ("line", "arc", "polyline") and not getattr(e, "closed", False)]
    others = [e for e in ents if e.kind in ("spline", "ellipse") and not getattr(e, "closed", False)]
    if not others:
        return X.join(simple, tol)
    pool = []
    for e in simple + others:
        sg = NB.entity_beziers(e)
        if sg:
            pool.append((e, sg))
    new = []; used = []
    while pool:
        e, chain = pool.pop(0); members = [e]; grown = True
        while grown:
            grown = False
            s, t = NB.ends(chain)
            for k, (f, fs) in enumerate(pool):
                a, b = NB.ends(fs)
                if norm(a - t) < tol:
                    chain = chain + fs
                elif norm(b - t) < tol:
                    chain = chain + NB.reverse(fs)
                elif norm(b - s) < tol:
                    chain = fs + chain
                elif norm(a - s) < tol:
                    chain = NB.reverse(fs) + chain
                else:
                    continue
                members.append(f); pool.pop(k); grown = True
                break
        if len(members) > 1:
            if all(m.kind in ("line", "arc", "polyline") for m in members):
                n2, u2 = X.join(members, tol)
                new += [x.style_from(members[0]) for x in n2]; used += u2
                continue
            s, t = NB.ends(chain)
            o = NB.simplify(chain, closed=norm(s - t) < tol); o.style_from(members[0])
            new.append(o); used += members
    return new, used


def cmd_join(c):
    ents = yield from _presel(c, "JOIN  Select curves to join (lines, arcs, polylines, splines, elliptical arcs)",
                              lambda e: e.kind in CURVES)
    if not ents:
        return
    tol = max(1e-6, 1e-7 * max((float(np.abs(np.asarray(e.bbox()[1]) - np.asarray(e.bbox()[0])).max()) for e in ents), default=1.0))
    new, used = join_any(ents, tol)
    if not new:
        c.msg("JOIN: the ends of the selected curves do not touch (closed curves such as circles and rectangles cannot be joined)"); return
    for e in used:
        c.doc.remove(e)
    for e in new:
        c.doc.add_keep(e)
    kinds = ", ".join(sorted({e.label for e in new}))
    c.msg(f"JOIN: {len(used)} curve(s) joined into {len(new)} object(s) ({kinds})")


# ------------------------------------------------------------------------------------------------- PROJECT
def _ray_tris(P, d, V):
    """First hits of the rays P + t d (both directions) with the triangles V (M,3,3).  Returns (points, hit mask)."""
    P = np.asarray(P, float); out = np.zeros_like(P); ok = np.zeros(len(P), bool)
    if not len(V):
        return out, ok
    v0 = V[:, 0]; e1 = V[:, 1] - v0; e2 = V[:, 2] - v0
    h = np.cross(d, e2); a = (e1 * h).sum(axis=1)
    good = np.abs(a) > 1e-14
    v0, e1, e2, h, a = v0[good], e1[good], e2[good], h[good], a[good]
    if not len(a):
        return out, ok
    f = 1.0 / a
    for i, p in enumerate(P):
        s = p - v0; u = f * (s * h).sum(axis=1)
        q = np.cross(s, e1); v = f * (q @ d); t = f * (e2 * q).sum(axis=1)
        m = (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9)
        if m.any():
            tt = t[m]; k = int(np.argmin(np.abs(tt)))
            out[i] = p + tt[k] * d; ok[i] = True
    return out, ok


def cmd_project(c):
    """PROJECT (as in Rhino): project curves / points onto surfaces, solids or meshes along the Z axis of the work plane."""
    ents = yield from _presel(c, "PROJECT  Select curves and points to project", lambda e: e.kind in CURVES + ("point",))
    if not ents:
        return
    tg = yield c.sel("Select surfaces / solids to project onto  <Enter = onto the work plane>",
                     filt=lambda e: getattr(e, "tris", None) is not None and e.kind not in CURVES + ("point", "text", "dimension", "leader"))
    c.app.clear_selection(silent=True)
    d = unit(np.asarray(c.ucs.z, float)); made = 0
    V = []
    for t in (tg or []):
        try:
            tr = t.tris()
            if tr is not None and len(tr[1]):
                V.append(np.asarray(tr[0], float)[np.asarray(tr[1], int)])
        except Exception:
            pass
    V = np.concatenate(V) if V else np.zeros((0, 3, 3))
    o = yield c.opt("Delete the input curves? [Yes/No] <No>", ["Yes", "No"], "No")
    from .rhinosrf import _out_layer
    lay = _out_layer(c, "PROJECTION", 6)                     # all projected curves are collected on one layer
    for e in ents:
        if e.kind == "point":
            P = np.array([e.p])
        else:
            P = np.asarray(e.pts(400) if e.kind in ("spline", "ellipse") else np.array([q for w in e.wire() for q in w]), float)
            if e.kind in ("line",):
                P = np.linspace(e.p0, e.p1, 81)
            elif e.kind == "polyline" and not np.any(np.abs(np.asarray(e.bulges, float)) > 1e-12) and len(V):
                Q = []; pts = list(e.pts) + ([e.pts[0]] if e.closed else [])
                for a, b in zip(pts[:-1], pts[1:]):
                    Q += list(np.linspace(a, b, 41)[:-1])
                P = np.array(Q + [pts[-1]])
        if len(V):
            H, ok = _ray_tris(P, d, V)
        else:                                               # onto the work plane
            org = np.asarray(c.ucs.o, float); H = P - np.outer((P - org) @ d, d); ok = np.ones(len(P), bool)
        if e.kind == "point":
            if ok[0]:
                pe = E.PointE(H[0]).style_from(e); pe.layer = lay; c.doc.add_keep(pe); made += 1
            continue
        runs = []; cur = []
        for q, k in zip(H, ok):                              # the curve may leave the surface: one polyline per hit run
            if k:
                cur.append(q)
            elif cur:
                runs.append(cur); cur = []
        if cur:
            runs.append(cur)
        for r_ in runs:
            if len(r_) >= 2:
                pl = E.Polyline(np.array(r_), False, None, d, True).style_from(e); pl.layer = lay; c.doc.add_keep(pl); made += 1
        if o == "Yes" and runs:
            c.doc.remove(e)
    c.msg(f"PROJECT: {made} projected object(s) on layer PROJECTION" if made else "PROJECT: the curves do not lie over the selected surfaces (direction = Z of the work plane)")


def solid_outline(V, F, d, angle=25.0):
    """Edges of a mesh that show in a view along d: silhouette edges, open edges and sharp edges.  Returns (N,2,3)."""
    V = np.asarray(V, float); F = np.asarray(F, int)
    if not len(F):
        return np.zeros((0, 2, 3))
    n = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    ln = np.linalg.norm(n, axis=1); n = n / np.maximum(ln, 1e-30)[:, None]
    Vk = np.round(V / max(1e-9, float(np.ptp(V, axis=0).max()) * 1e-7)).astype(np.int64)        # weld coincident vertices
    _, inv = np.unique(Vk, axis=0, return_inverse=True); G = inv.reshape(-1)[F]
    e = np.concatenate([G[:, [0, 1]], G[:, [1, 2]], G[:, [2, 0]]]); fi = np.tile(np.arange(len(F)), 3)
    raw = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
    key = np.sort(e, axis=1); order = np.lexsort((key[:, 1], key[:, 0])); key = key[order]; fi = fi[order]; raw = raw[order]
    same = np.all(key[1:] == key[:-1], axis=1)
    keep = []
    i = 0; m = len(key); cosa = math.cos(math.radians(angle)); front = (n @ d)
    while i < m:
        if key[i, 0] == key[i, 1]:
            i += 1; continue
        if i + 1 < m and same[i]:
            a, b = fi[i], fi[i + 1]
            if front[a] * front[b] < 0 or float(n[a] @ n[b]) < cosa:
                keep.append(i)
            j = i + 2
            while j < m and same[j - 1]:
                j += 1
            i = j
        else:
            keep.append(i); i += 1
    return V[raw[keep]] if keep else np.zeros((0, 2, 3))


def cmd_flatshot(c):
    """FLATSHOT: the outline and visible edges of solids / surfaces projected flat onto the work plane (a 2D view of
    the 3D model), collected on the layer PROJECTION."""
    ents = yield from _presel(c, "FLATSHOT  Select solids / surfaces to project onto the work plane",
                              lambda e: getattr(e, "V", None) is not None and getattr(e, "F", None) is not None)
    if not ents:
        return
    from .rhinosrf import _out_layer
    lay = _out_layer(c, "PROJECTION", 6); u = c.ucs; d = unit(np.asarray(u.z, float)); org = np.asarray(u.o, float); n = 0
    for e in ents:
        S = solid_outline(e.V, e.F, d)
        if not len(S):
            continue
        P = S.reshape(-1, 3); P = P - np.outer((P - org) @ d, d); S = P.reshape(-1, 2, 3)
        tol = 1e-6 * max(1.0, float(np.ptp(P, axis=0).max())); seen = set(); ln = []
        for a, b in S:                                      # edges that fall on each other in the view are drawn once
            if norm(b - a) <= tol:
                continue
            ka, kb = tuple(np.round(a / tol / 10).astype(np.int64)), tuple(np.round(b / tol / 10).astype(np.int64))
            k = (ka, kb) if ka <= kb else (kb, ka)
            if k not in seen:
                seen.add(k); ln.append(E.Line(a, b))
        try:
            joined, used = X.join(ln, 1e-6 * max(1.0, float(np.ptp(P, axis=0).max())))
            rest = [x for x in ln if x not in used]
        except Exception:
            joined, rest = [], ln
        for o in joined + rest:
            o.layer = lay; c.doc.add_keep(o); n += 1
    c.msg(f"FLATSHOT: {n} curve(s) on layer PROJECTION" if n else "FLATSHOT: nothing to project")


# ------------------------------------------------------------------------------------------------- SCALE 1D / 2D / non-uniform
def nu_entity(e, M):
    """Copy of e under the affine map M that may stretch differently per axis.  Circles, arcs and ellipses become
    exact splines (ellipses stay curves), polylines with arcs too; text keeps its height and only moves."""
    k = e.kind
    if k in ("line",):
        n = E.Line(M[:3, :3] @ e.p0 + M[:3, 3], M[:3, :3] @ e.p1 + M[:3, 3])
    elif k == "point":
        n = E.PointE(M[:3, :3] @ e.p + M[:3, 3])
    elif k == "polyline" and not np.any(np.abs(np.asarray(e.bulges, float)) > 1e-12):
        n = e.copy(); n.pts = np.asarray(e.pts, float) @ M[:3, :3].T + M[:3, 3]; n.touch()
    elif k in CURVES:
        sg = NB.entity_beziers(e)
        if not sg:
            return None
        n = NB.compose(NB.affine(sg, M), bool(getattr(e, "closed", False)) or k == "circle")
    elif k == "hatch":
        n = e.copy(); n.loops = [np.asarray(l, float) @ M[:3, :3].T + M[:3, 3] for l in e.loops]; n.touch()
    elif k in ("text", "dimension", "leader", "table"):
        n = e.copy(); q = getattr(e, "p", None)
        if q is None:
            return None
        n.transform(m_translate((M[:3, :3] @ q + M[:3, 3]) - q))
    else:
        return None
    n.style_from(e)
    return n


def _scale_matrix(c, base, fx, fy, fz):
    u = c.ucs; R = np.column_stack([u.x, u.y, u.z]); S = R @ np.diag([fx, fy, fz]) @ R.T
    M = np.eye(4); M[:3, :3] = S; M[:3, 3] = np.asarray(base, float) - S @ np.asarray(base, float)
    return M


def _scale_apply(c, ents, M, name):
    done = 0; skipped = {}
    for e in ents:
        n = nu_entity(e, M)
        if n is None:
            skipped[e.label] = skipped.get(e.label, 0) + 1; continue
        c.doc.remove(e); c.doc.add_keep(n); done += 1
    msg = f"{name}: {done} object(s) scaled"
    if skipped:
        msg += "; not scaled (explode them first): " + ", ".join(f"{k} x{v}" for k, v in skipped.items())
    c.msg(msg)


def _factor(c, prompt, default=1.0):
    f = yield c.num(prompt, default=default, options=["Reference"])
    if f == "Reference":
        r1 = yield c.dist("Specify reference length <1>", default=1.0)
        r2 = yield c.dist("Specify new length")
        f = (r2 or 1) / (r1 or 1)
    return f if isinstance(f, float) and f > 0 else None


def cmd_scale2d(c):
    """Scale in the two directions of the work plane only (heights along Z stay as they are)."""
    ents = yield from _presel(c, "SCALE2D  Select objects")
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    f = yield from _factor(c, "Specify scale factor for X and Y or [Reference]")
    if f:
        _scale_apply(c, ents, _scale_matrix(c, b, f, f, 1.0), "SCALE2D")


def cmd_scale1d(c):
    """Scale in ONE direction (stretch a drawing in X, Y or Z, or along two picked points)."""
    ents = yield from _presel(c, "SCALE1D  Select objects")
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    ax = yield c.opt("Scale direction [X/Y/Z] <X>", ["X", "Y", "Z"], "X")
    if ax not in ("X", "Y", "Z"):
        return
    f = yield from _factor(c, f"Specify scale factor along {ax} or [Reference]")
    if f:
        _scale_apply(c, ents, _scale_matrix(c, b, f if ax == "X" else 1.0, f if ax == "Y" else 1.0, f if ax == "Z" else 1.0), "SCALE1D")


def cmd_scalenu(c):
    """Non-uniform scale: a separate factor for X, Y and Z of the work plane."""
    ents = yield from _presel(c, "SCALENU  Select objects")
    if not ents:
        return
    b = yield c.pt("Specify base point")
    if b is None:
        return
    fs = []
    for ax in ("X", "Y", "Z"):
        f = yield c.num(f"Scale factor {ax} <1>", default=1.0)
        if not isinstance(f, float) or f <= 0:
            return
        fs.append(f)
    _scale_apply(c, ents, _scale_matrix(c, b, *fs), "SCALENU")


# ------------------------------------------------------------------------------------------------- DEVLOFT
def devloft_rulings(A, B, n=60):
    """Rulings of a developable surface between the curves A and B (point arrays): for every point of A the point of B is
    chosen where both tangents and the ruling lie in one plane, keeping the order along the curves.
    Returns (points on A, points on B, largest twist angle in degrees)."""
    def resample(P, m):
        P = np.asarray(P, float); L = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
        s = np.linspace(0, L[-1], m)
        return np.column_stack([np.interp(s, L, P[:, k]) for k in range(3)])
    m = max(200, n * 5)
    A = resample(A, n); Bd = resample(B, m)
    if norm(A[0] - Bd[0]) + norm(A[-1] - Bd[-1]) > norm(A[0] - Bd[-1]) + norm(A[-1] - Bd[0]):
        Bd = Bd[::-1]
    Ta = np.gradient(A, axis=0); Ta /= np.maximum(np.linalg.norm(Ta, axis=1), 1e-12)[:, None]
    Tb = np.gradient(Bd, axis=0); Tb /= np.maximum(np.linalg.norm(Tb, axis=1), 1e-12)[:, None]
    # dynamic programming over monotone matches: cost = twist of the ruling (triple product), small bias to even spacing
    cost = np.zeros((n, m))
    for i in range(n):
        R = Bd - A[i]; Rn = R / np.maximum(np.linalg.norm(R, axis=1), 1e-12)[:, None]
        cost[i] = np.abs((np.cross(Ta[i], Tb) * Rn).sum(axis=1))
    ideal = np.linspace(0, m - 1, n)
    cost += 0.02 * np.abs(np.arange(m)[None, :] - ideal[:, None]) / m
    INF = 1e18; D = np.full((n, m), INF); prev = np.zeros((n, m), int)
    D[0, 0] = cost[0, 0]
    for i in range(1, n):
        best = np.minimum.accumulate(D[i - 1]); arg = np.zeros(m, int); a = 0
        for j in range(m):
            if D[i - 1, j] <= D[i - 1, a]:
                a = j
            arg[j] = a
        D[i] = best + cost[i]; prev[i] = arg
    j = m - 1; idx = [0] * n
    for i in range(n - 1, -1, -1):
        idx[i] = j; j = prev[i, j] if i > 0 else 0
    idx[0] = 0; idx[-1] = m - 1
    Bp = Bd[idx]
    R = Bp - A; Rn = R / np.maximum(np.linalg.norm(R, axis=1), 1e-12)[:, None]
    tw = np.degrees(np.arcsin(np.clip(np.abs((np.cross(Ta, Tb[idx]) * Rn).sum(axis=1)), 0, 1)))
    return A, Bp, float(tw[1:-1].max()) if n > 2 else 0.0


def cmd_devloft(c):
    """Developable loft between two curves (plates that can be rolled / unfolded without stretching), as DevLoft in Rhino."""
    from ..core import solids as S
    a = yield c.ent("DEVLOFT  Select first curve", filt=lambda e: e.is_curve)
    if not a or isinstance(a, str):
        return
    b = yield c.ent("Select second curve", filt=lambda e: e.is_curve and e is not a[0])
    if not b or isinstance(b, str):
        return
    try:
        A, B, tw = devloft_rulings(S.curve_points(a[0]), S.curve_points(b[0]))
        srf = S.grid_surface(np.stack([A, B], axis=1))
    except Exception as ex:
        c.msg(f"DEVLOFT failed: {ex}"); return
    c.add(srf)
    for i in range(0, len(A), max(1, len(A) // 12)):          # a few rulings, as guide lines for rolling
        l = E.Line(A[i], B[i]); l.color = 8; c.doc.add_keep(l)
    c.msg(f"Developable loft created with rulings.  Largest twist {tw:.2f} deg" +
          ("  - developable" if tw < 1.0 else "  - these two curves do not allow a fully developable surface; the closest one was built"))


# ------------------------------------------------------------------------------------------------- PROFILE2D
def scallop_radius(h):
    """Usual shipyard scallop radius for a stiffener of web height h (mm): R25 up to 100, R35 up to 250, R50 up to 400,
    R75 above.  (Yards differ: the radius can be typed.)"""
    return 25.0 if h <= 100 else 35.0 if h <= 250 else 50.0 if h <= 400 else 75.0


def profile2d_entities(ptype, dims, scallop=0.0):
    """Section of a profile in local 2D (plating along X at y = 0, web upwards), with optional scallops: the quarter-round
    cut-outs of radius `scallop` at the root of the web on both sides (as cut in the crossing plate)."""
    from ..core import ship as SH
    out = []
    for l in SH.section_loops(ptype, dims):
        l = np.asarray(l, float)
        if len(l) > 1 and norm(l[0] - l[-1]) < 1e-9:
            l = l[:-1]
        out.append(E.Polyline(np.column_stack([l[:, 0], l[:, 1], np.zeros(len(l))]), True))
    if scallop and scallop > 0 and ptype in ("FB", "L", "BP", "T"):
        if ptype == "T":
            x0, x1 = -float(dims.get("tw", 0)) / 2, float(dims.get("tw", 0)) / 2
        else:
            x0, x1 = 0.0, float(dims.get("t", 0))
        R = float(scallop)
        for cx, a0, a1 in ((x0, math.pi / 2, math.pi), (x1, 0.0, math.pi / 2)):
            ar = E.Arc((cx, 0, 0), R, a0, a1); ar.lw = 25; out.append(ar)
        base = E.Line((x0 - R * 1.6, 0, 0), (x1 + R * 1.6, 0, 0)); base.lw = 13; base.ltype = "Hidden"; base.xd = {"profile_cl": 1}
        out.append(base)                                     # the plating line the scallops sit on (thin, hidden)
    return out


def cmd_profile2d(c):
    """2D profile section as a BLOCK (flat bar, angle, bulb flat, T, H-beam, channel, pipe, round bar, hollow section):
    size from the catalogue or typed, with or without scallops, placed at a point with a rotation."""
    from ..core import ship as SH
    opt = c.app.dialog_profile()
    if not opt:
        return
    ptype = opt.get("ptype") or opt.get("type"); dims = opt.get("dims") or {}
    st = c.doc.settings; sc = st.get("profile_scallop", "None")
    label = SH.size_label(ptype, dims); h = float(dims.get("h", dims.get("D", 0)) or 0)
    can = ptype in ("FB", "L", "BP", "T")
    def radius():
        return 0.0 if (sc == "None" or not can) else (scallop_radius(h) if sc == "Auto" else float(sc))
    u = c.ucs
    def matrix(p, ang):
        ca, sa = math.cos(ang), math.sin(ang); M = np.eye(4)
        M[:3, 0] = u.x * ca + u.y * sa; M[:3, 1] = -u.x * sa + u.y * ca; M[:3, 2] = u.z; M[:3, 3] = p
        return M
    def build(p, ang=0.0):
        try:
            es = profile2d_entities(ptype, dims, radius())
        except Exception:
            return []
        M = matrix(p, ang)
        for e in es:
            e.transform(M)
        return es
    n = 0
    while True:
        sct = "no scallop" if radius() <= 0 else f"scallop R{radius():g}"
        p = yield c.pt(f"PROFILE2D {label} ({sct})  Specify insertion point or [Scallop] <done>", options=["Scallop"] if can else None,
                       preview=lambda q: build(q))
        if p == "Scallop":
            o = yield c.opt(f"Scallop [None/Auto/Radius] <{sc}>   (Auto = R{scallop_radius(h):g} for this height)", ["None", "Auto", "Radius"], "Auto")
            if o == "Radius":
                r = yield c.num("Scallop radius", default=scallop_radius(h))
                if isinstance(r, float) and r > 0:
                    sc = r; st["profile_scallop"] = r
            elif o in ("None", "Auto"):
                sc = o; st["profile_scallop"] = o
            continue
        if p is None or isinstance(p, str):
            break
        a = yield c.angle("Specify rotation angle <0>", base=p, default=0.0,
                          preview=lambda q: build(p, math.atan2(float((q - p) @ u.y), float((q - p) @ u.x)) if norm(q - p) > 1e-9 else 0.0))
        ang = math.radians(float(a)) if isinstance(a, (int, float)) else 0.0
        R = radius()
        name = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"PROF_{label}").replace("__", "_").replace("__", "_") + (f"_S{R:g}" if R > 0 else "")
        if name not in c.doc.blocks:
            try:
                c.doc.add_block(E.Block(name, (0, 0, 0), profile2d_entities(ptype, dims, R)))
            except Exception as ex:
                c.msg(f"Profile failed: {ex}"); return
        ins = E.Insert(name, matrix(p, ang)); ins.xd = {"profile": label}; c.doc.add_keep(ins); n += 1
    if n:
        c.msg(f"Profile {label}: {n} block reference(s) '{name}', {SH.kg_per_m(ptype, dims, SH.DEFAULT_GRADE):.2f} kg/m")


# ------------------------------------------------------------------------------------------------- TEXTALIGN
def cmd_textalign(c):
    """TEXTALIGN: line up several texts on one text - left / centre / right - and optionally give them equal spacing."""
    st = c.doc.settings
    ents = yield from _presel(c, "TEXTALIGN  Select text objects to align", lambda e: e.kind == "text")
    if len(ents) < 1:
        return
    mode = st.get("textalign_mode", "Left"); sp = st.get("textalign_spacing", "Current")
    while True:
        r = yield c.ent(f"Select the text to align to  or [Alignment/Spacing]  <alignment {mode}, spacing {sp}>",
                        filt=lambda e: e.kind == "text", options=["Alignment", "Spacing"])
        if r == "Alignment":
            o = yield c.opt(f"Alignment [Left/Center/Right] <{mode}>", ["Left", "Center", "Right"], mode)
            if o in ("Left", "Center", "Right"):
                mode = o; st["textalign_mode"] = o
            continue
        if r == "Spacing":
            o = yield c.opt(f"Spacing [Current/Distribute/Set] <{sp if isinstance(sp, str) else 'Set'}>", ["Current", "Distribute", "Set"], "Current")
            if o == "Set":
                v = yield c.dist("Distance between the text lines", default=float(sp) if not isinstance(sp, str) else None)
                if isinstance(v, float) and v > 0:
                    sp = v; st["textalign_spacing"] = v
            elif o in ("Current", "Distribute"):
                sp = o; st["textalign_spacing"] = o
            continue
        break
    if not r or isinstance(r, str):
        return
    ref = r[0]; u = c.ucs
    def box(e):
        bb = e.bbox(); cs = [np.array([x, y, z]) for x in (bb[0][0], bb[1][0]) for y in (bb[0][1], bb[1][1]) for z in (bb[0][2], bb[1][2])]
        xs = [float((q - u.o) @ u.x) for q in cs]; ys = [float((q - u.o) @ u.y) for q in cs]
        return min(xs), max(xs), min(ys), max(ys)
    key = {"Left": lambda b: b[0], "Center": lambda b: (b[0] + b[1]) / 2, "Right": lambda b: b[1]}[mode]
    x0 = key(box(ref))
    items = [e for e in ents if e is not ref]
    allt = sorted(items + [ref], key=lambda e: -box(e)[3])
    ytarget = {}
    if sp == "Distribute" and len(allt) > 2:
        top = box(allt[0])[3]; bot = box(allt[-1])[3]
        for i, e in enumerate(allt):
            ytarget[e.id] = top + (bot - top) * i / (len(allt) - 1)
    elif isinstance(sp, float):
        k = allt.index(ref); yr = box(ref)[3]
        for i, e in enumerate(allt):
            ytarget[e.id] = yr - (i - k) * sp
    n = 0
    for e in items + ([ref] if ytarget else []):
        b = box(e); dx = (x0 - key(b)) if e is not ref else 0.0
        dy = (ytarget[e.id] - b[3]) if e.id in ytarget else 0.0
        if abs(dx) > 1e-12 or abs(dy) > 1e-12:
            c.doc.modify(e); e.transform(m_translate(u.x * dx + u.y * dy)); n += 1
    c.msg(f"TEXTALIGN: {n} text(s) aligned ({mode.lower()}" + (f", spacing {sp:g})" if isinstance(sp, float) else f", spacing {sp.lower()})"))


# ------------------------------------------------------------------------------------------------- BOLT & NUT
# size: (thread d, pitch, s across flats, k head height, m nut height, washer OD, washer thickness), all in mm
_ISO = {"M5": (5, 0.8, 8, 3.5, 4.7, 10, 1.0), "M6": (6, 1.0, 10, 4.0, 5.2, 12, 1.6), "M8": (8, 1.25, 13, 5.3, 6.8, 16, 1.6),
        "M10": (10, 1.5, 16, 6.4, 8.4, 20, 2.0), "M12": (12, 1.75, 18, 7.5, 10.8, 24, 2.5), "M14": (14, 2.0, 21, 8.8, 12.8, 28, 2.5),
        "M16": (16, 2.0, 24, 10.0, 14.8, 30, 3.0), "M18": (18, 2.5, 27, 11.5, 15.8, 34, 3.0), "M20": (20, 2.5, 30, 12.5, 18.0, 37, 3.0),
        "M22": (22, 2.5, 34, 14.0, 19.4, 39, 3.0), "M24": (24, 3.0, 36, 15.0, 21.5, 44, 4.0), "M27": (27, 3.0, 41, 17.0, 23.8, 50, 4.0),
        "M30": (30, 3.5, 46, 18.7, 25.6, 56, 4.0), "M33": (33, 3.5, 50, 21.0, 28.7, 60, 5.0), "M36": (36, 4.0, 55, 22.5, 31.0, 66, 5.0),
        "M42": (42, 4.5, 65, 26.0, 34.0, 78, 8.0), "M48": (48, 5.0, 75, 30.0, 38.0, 92, 8.0), "M56": (56, 5.5, 85, 35.0, 45.0, 105, 10.0),
        "M64": (64, 6.0, 95, 40.0, 51.0, 115, 10.0)}
# DIN 931 / 933 / 934 and JIS B 1180 / 1181 use other widths across flats for M10, M12, M14 and M22; nuts 0.8 d high
_DIN = {k: v for k, v in _ISO.items()}
for _k, _s in (("M10", 17), ("M12", 19), ("M14", 22), ("M22", 32)):
    _DIN[_k] = (_DIN[_k][0], _DIN[_k][1], _s) + _DIN[_k][3:]
_DIN = {k: (v[0], v[1], v[2], v[3], round(0.8 * v[0], 1), v[5], v[6]) for k, v in _DIN.items()}
_IN = 25.4                                                   # ASME B18.2.1 hex cap screws, B18.2.2 hex nuts, B18.21.1 washers (UNC)
_ASME = {n: (d * _IN, _IN / tpi, f * _IN, hh * _IN, nh * _IN, wo * _IN, wt * _IN) for n, d, tpi, f, hh, nh, wo, wt in (
    ('1/4"', 0.25, 20, 7 / 16, 5 / 32, 7 / 32, 0.734, 0.065), ('5/16"', 0.3125, 18, 0.5, 13 / 64, 17 / 64, 0.875, 0.083),
    ('3/8"', 0.375, 16, 9 / 16, 15 / 64, 21 / 64, 1.0, 0.083), ('7/16"', 0.4375, 14, 0.625, 9 / 32, 0.375, 1.25, 0.083),
    ('1/2"', 0.5, 13, 0.75, 5 / 16, 7 / 16, 1.375, 0.109), ('5/8"', 0.625, 11, 15 / 16, 25 / 64, 35 / 64, 1.75, 0.134),
    ('3/4"', 0.75, 10, 1.125, 15 / 32, 41 / 64, 2.0, 0.148), ('7/8"', 0.875, 9, 1.3125, 35 / 64, 0.75, 2.25, 0.165),
    ('1"', 1.0, 8, 1.5, 39 / 64, 55 / 64, 2.5, 0.165), ('1-1/8"', 1.125, 7, 1.6875, 11 / 16, 31 / 32, 2.75, 0.165),
    ('1-1/4"', 1.25, 7, 1.875, 25 / 32, 1.0625, 3.0, 0.165), ('1-1/2"', 1.5, 6, 2.25, 15 / 16, 1.28125, 3.5, 0.18),
    ('2"', 2.0, 4.5, 3.0, 1.21875, 1.71875, 4.5, 0.213))}
BOLT_STD = {"ISO 4014 / 4032 / 7089 (metric)": _ISO, "DIN 931 / 934 / 125 (metric)": _DIN, "JIS B 1180 / 1181 (metric)": _DIN,
            "ASME B18.2.1 / B18.2.2 (inch, UNC)": _ASME}
BOLTS = _ISO
BOLT_VIEWS = ("Side (across corners)", "Side (across flats)", "Top (head / nut)")
BOLT_ITEMS = ("Bolt + nut", "Bolt only", "Nut only")


def bolt_entities(size, length, view="Side", nut=True, washer=True, grip=None, std=None, item=None):
    """2D drawing of a hexagon bolt / nut / washers in local coordinates: origin under the head on the axis, the shank
    along +X.  view: Side (across corners: three faces), Side (across flats: two faces) or Top.  item: Bolt + nut,
    Bolt only, Nut only (the nut alone is drawn with its bearing face at the origin)."""
    tab = BOLT_STD.get(std, _ISO) if std else _ISO
    d, P, s, k, m, wd, wt = tab[size]; e = s / math.cos(math.radians(30)); out = []
    item = item or ("Bolt + nut" if nut else "Bolt only")
    bolt_on = item != "Nut only"; nut_on = item != "Bolt only"
    def pl(pts, closed=False, lw=None, lt=None):
        o = E.Polyline(np.array([(x, y, 0.0) for x, y in pts]), closed)
        if lw is not None:
            o.lw = lw
        if lt:
            o.ltype = lt
        out.append(o); return o
    if view.startswith("Top"):
        pl([(e / 2 * math.cos(math.radians(60 * i)), e / 2 * math.sin(math.radians(60 * i))) for i in range(6)], True, 35)
        c1 = E.Circle((0, 0, 0), s / 2 * 0.98); c1.lw = 13; out.append(c1)             # chamfer circle
        if not bolt_on or (nut_on and False):
            pass
        if bolt_on and nut_on or not bolt_on:                                          # nut seen from the thread end
            c2 = E.Circle((0, 0, 0), d / 2 - 0.61 * P if not bolt_on else d / 2); c2.lw = 35; out.append(c2)
            a = E.Arc((0, 0, 0), d / 2 if not bolt_on else (d / 2 - 0.61 * P), math.radians(-10), math.radians(260)); a.lw = 13; out.append(a)
        for p0, p1 in (((-e / 2 - 2, 0), (e / 2 + 2, 0)), ((0, -e / 2 - 2), (0, e / 2 + 2))):
            pl([p0, p1], False, 13, "Center")
        return out
    flats = "flats" in view
    def hexside(x0, h):
        if flats:                                           # seen across flats: two faces, width = s
            pl([(x0, -s / 2), (x0 + h, -s / 2), (x0 + h, s / 2), (x0, s / 2)], True, 35); pl([(x0, 0), (x0 + h, 0)], False, 13)
        else:                                               # seen across corners: three faces, width = e
            pl([(x0, -e / 2), (x0 + h, -e / 2), (x0 + h, e / 2), (x0, e / 2)], True, 35)
            pl([(x0, -e / 4), (x0 + h, -e / 4)], False, 13); pl([(x0, e / 4), (x0 + h, e / 4)], False, 13)
    L = float(length)
    if not bolt_on:                                         # the nut alone (+ washer under it)
        x = 0.0
        if washer:
            pl([(0, -wd / 2), (wt, -wd / 2), (wt, wd / 2), (0, wd / 2)], True, 35); x = wt
        hexside(x, m)
        r3 = d / 2 - 0.61 * P
        pl([(x, d / 2), (x + m, d / 2)], False, 13, "Hidden"); pl([(x, -d / 2), (x + m, -d / 2)], False, 13, "Hidden")
        pl([(x, r3), (x + m, r3)], False, 13, "Hidden"); pl([(x, -r3), (x + m, -r3)], False, 13, "Hidden")
        pl([(-3, 0), (x + m + 3, 0)], False, 13, "Center")
        return out
    b = (2 * d + 6) if L <= 125 else (2 * d + 12 if L <= 200 else 2 * d + 25); b = min(b, L)      # thread length (ISO 4014)
    hexside(-k, k)
    ch = min(P, d * 0.1)
    pl([(0, d / 2), (L - ch, d / 2), (L, d / 2 - ch), (L, -d / 2 + ch), (L - ch, -d / 2), (0, -d / 2)], False, 35)
    pl([(L - b, d / 2), (L - b, -d / 2)], False, 13)                                            # end of thread
    r3 = d / 2 - 0.61 * P
    pl([(L - b, r3), (L, r3)], False, 13); pl([(L - b, -r3), (L, -r3)], False, 13)             # thread root: thin lines
    x = 0.0
    if washer:
        pl([(0, -wd / 2), (wt, -wd / 2), (wt, wd / 2), (0, wd / 2)], True, 35); x = wt
    if nut_on:
        g = float(grip) if grip else max(x, L - m - 2 * P - (wt if washer else 0))
        xn = min(g, L - m)
        if washer:
            pl([(xn, -wd / 2), (xn + wt, -wd / 2), (xn + wt, wd / 2), (xn, wd / 2)], True, 35); xn += wt
        xn = min(xn, L - m); hexside(xn, m)
    pl([(-k - 3, 0), (L + 3, 0)], False, 13, "Center")
    return out


def cmd_bolt(c):
    """BOLT: standard hexagon bolt / nut / washer drawing - ISO, DIN, JIS or ASME (inch) - bolt with nut, bolt only or nut
    only, in side view (across corners or across flats) or top view; inserted as a block."""
    st = c.doc.settings
    cur = {"std": st.get("bolt_std", list(BOLT_STD)[0]), "size": st.get("bolt_size", "M16"), "length": float(st.get("bolt_len", 60.0)),
           "view": st.get("bolt_view", BOLT_VIEWS[0]), "item": st.get("bolt_item", BOLT_ITEMS[0]), "washer": bool(st.get("bolt_washer", True))}
    if cur["std"] not in BOLT_STD:
        cur["std"] = list(BOLT_STD)[0]
    if cur["view"] not in BOLT_VIEWS:
        cur["view"] = BOLT_VIEWS[0]
    if cur["size"] not in BOLT_STD[cur["std"]]:
        cur["size"] = list(BOLT_STD[cur["std"]])[6]
    opt = c.app.dialog_bolt(cur) if hasattr(c.app, "dialog_bolt") else cur
    if not opt:
        return
    st.update({"bolt_std": opt["std"], "bolt_size": opt["size"], "bolt_len": opt["length"], "bolt_view": opt["view"], "bolt_item": opt["item"],
               "bolt_washer": opt["washer"]})
    mk = lambda: bolt_entities(opt["size"], opt["length"], opt["view"], True, opt["washer"], None, opt["std"], opt["item"])
    u = c.ucs
    def matrix(p, ang):
        ca, sa = math.cos(ang), math.sin(ang); M = np.eye(4)
        M[:3, 0] = u.x * ca + u.y * sa; M[:3, 1] = -u.x * sa + u.y * ca; M[:3, 2] = u.z; M[:3, 3] = p
        return M
    def ghost(p, ang=0.0):
        es = mk(); M = matrix(p, ang)
        for e in es:
            e.transform(M)
        return es
    tag = {"Bolt + nut": "BN", "Bolt only": "B", "Nut only": "N"}[opt["item"]] + ("W" if opt["washer"] else "")
    vw = "T" if opt["view"].startswith("Top") else ("F" if "flats" in opt["view"] else "S")
    sz = opt["size"].replace('"', "in").replace("/", "_")
    name = f"{opt['std'].split()[0]}_{sz}" + ("" if opt["item"] == "Nut only" else f"x{opt['length']:g}") + f"_{tag}_{vw}"
    n = 0
    while True:
        p = yield c.pt(f"BOLT {opt['size']}" + ("" if opt["item"] == "Nut only" else f" x {opt['length']:g}") +
                       f", {opt['item'].lower()}, {opt['view']}  Specify insertion point <done>", preview=lambda q: ghost(q))
        if p is None or isinstance(p, str):
            break
        ang = 0.0
        if not opt["view"].startswith("Top"):
            a = yield c.angle("Specify direction of the bolt axis <0>", base=p, default=0.0,
                              preview=lambda q: ghost(p, math.atan2(float((q - p) @ u.y), float((q - p) @ u.x)) if norm(q - p) > 1e-9 else 0.0))
            ang = math.radians(float(a)) if isinstance(a, (int, float)) else 0.0
        if name not in c.doc.blocks:
            c.doc.add_block(E.Block(name, (0, 0, 0), mk()))
        c.doc.add_keep(E.Insert(name, matrix(p, ang))); n += 1
    if n:
        c.msg(f"{n} x {opt['item'].lower()} {opt['size']} ({opt['std']}) inserted as block {name}")


# ------------------------------------------------------------------------------------------------- TABLE from Excel
def read_table_file(path):
    """Rows (list of lists of str) from an .xlsx / .xlsm / .csv / .txt file (first sheet, used range)."""
    low = path.lower()
    if low.endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True); ws = wb.active
        rows = [["" if v is None else (f"{v:g}" if isinstance(v, float) else str(v)) for v in r] for r in ws.iter_rows(values_only=True)]
    else:
        import csv
        txt = open(path, "r", encoding="utf-8-sig", errors="replace").read()
        dl = "\t" if "\t" in txt else (";" if txt.count(";") > txt.count(",") else ",")
        rows = [list(r) for r in csv.reader(txt.splitlines(), delimiter=dl)]
    return _trim_rows(rows)


def _trim_rows(rows):
    rows = [list(r) for r in rows]
    while rows and not any(str(x).strip() for x in rows[-1]):
        rows.pop()
    n = max((max((i + 1 for i, x in enumerate(r) if str(x).strip()), default=0) for r in rows), default=0)
    return [[str(x) for x in (r + [""] * n)[:n]] for r in rows] if n else []


def cmd_tablexls(c):
    """Table from Excel: an .xlsx / .csv file, or the cells copied in Excel (clipboard)."""
    from .misc import ensure_scale; ensure_scale(c)
    o = yield c.opt("TABLEXLS  Take the cells from [File/Clipboard] <File>", ["File", "Clipboard"], "File")
    rows = None
    if o == "Clipboard":
        from PySide6.QtWidgets import QApplication
        txt = QApplication.clipboard().text() or ""
        rows = _trim_rows([ln.split("\t") for ln in txt.replace("\r\n", "\n").split("\n")])
        if not rows:
            c.msg("The clipboard holds no cells: select the cells in Excel and press Ctrl+C first"); return
    elif o == "File":
        path = c.app.ask_open("Table from Excel / CSV", "Excel and CSV (*.xlsx *.xlsm *.csv *.txt)")
        if not path:
            return
        try:
            rows = read_table_file(path)
        except Exception as ex:
            c.msg(f"Cannot read the file: {ex}"); return
    if not rows:
        c.msg("No cells found"); return
    ncol = len(rows[0]); th = 2.5; rh = 6.0                      # paper mm: the table follows the drawing scale
    widths = E.Table.fit_widths(rows, [10.0] * ncol, th)
    mk = lambda p: E.Table(p, rows, widths, "", th, rh, c.ucs.x, c.ucs.z)
    p = yield c.pt(f"Specify insertion point of the table ({len(rows)} rows x {ncol} columns)", preview=lambda q: [mk(q)])
    if p is None:
        return
    t = mk(p); t.layer = "TEXT" if "TEXT" in c.doc.layers else c.doc.cur_layer; c.doc.add_keep(t)
    c.msg(f"Table inserted: {len(rows)} rows x {ncol} columns.  Double-click it to edit the cells (TABLEDIT)")


def register(eng):
    R = eng.register
    R("SPLIT", cmd_split, ["SPL2"], "Split curves with cutting objects or at points (all pieces are kept)")
    R("JOIN", cmd_join, ["J"], "Join curves of any type whose ends meet (lines, arcs, polylines, splines, elliptical arcs)")
    R("PROJECT", cmd_project, ["PROJECTCRV", "PROJ"], "Project curves / points onto surfaces or solids along Z of the work plane")
    R("FLATSHOT", cmd_flatshot, ["PROJECTSOLID", "SOLPROF"], "Outline and edges of solids / surfaces projected onto the work plane (layer PROJECTION)")
    R("SCALE2D", cmd_scale2d, ["SC2"], "Scale in X and Y of the work plane only")
    R("SCALE1D", cmd_scale1d, ["SC1"], "Scale in one direction (X, Y or Z)")
    R("SCALENU", cmd_scalenu, ["SCALENONUNIFORM", "SCNU"], "Non-uniform scale: separate factors for X, Y, Z")
    R("DEVLOFT", cmd_devloft, ["DEVSRF"], "Developable loft between two curves")
    R("PROFILE2D", cmd_profile2d, ["PR2D"], "2D profile section from the catalogue or typed dimensions")
    R("TEXTALIGN", cmd_textalign, ["TA"], "Align texts left / centre / right and set their spacing")
    R("BOLT", cmd_bolt, ["BOLT2D", "NUT"], "Standard hexagon bolt / nut / washer drawing (ISO)")
    R("TABLEXLS", cmd_tablexls, ["TABLEEXCEL", "EXCELTABLE"], "Table from an Excel / CSV file or from cells copied in Excel")
