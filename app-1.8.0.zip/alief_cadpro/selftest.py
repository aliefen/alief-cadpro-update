"""Self test used by the installer build (CADPRO_SELFTEST=<result file>)."""
import os
import sys
import tempfile
import traceback
import numpy as np


def run(w, out):
    from PySide6.QtWidgets import QApplication
    lines = []
    ok = True
    def step(name, fn):
        nonlocal ok
        try:
            r = fn(); lines.append(f"OK   {name} {r if r is not None else ''}")
        except Exception:
            ok = False; lines.append(f"FAIL {name}\n" + traceback.format_exc())
    eng = w.engine; doc = w.doc
    def feed(cmd, *inp):
        eng.run(cmd)
        for i in inp:
            if not eng.busy():
                break
            if isinstance(i, str):
                eng.feed_text(i)
            elif i is None:
                eng.feed_enter()
            else:
                eng.feed_point(np.array(i, float))
        if eng.busy():
            eng.cancel()
        return len(doc.ents)
    step("line", lambda: feed("LINE", (0, 0), (1000, 0), (1000, 500), None))
    step("circle", lambda: feed("CIRCLE", (500, 250), "100"))
    step("box", lambda: feed("BOX", (1500, 0), "@600,400", "300"))
    from .core import ship as SH, fittings3d as F, entities as E, details as D
    def plate():
        r = E.Polyline([[0, 1000, 0], [2000, 1000, 0], [2000, 2000, 0], [0, 2000, 0]], True); doc.add(r)
        w.dialog_plate = lambda: {"thk": 10, "grade": "AH36", "side": "+", "prefix": "P", "mark": "", "layer": "PLATE", "delete_src": False}
        eng.run("PLATE3D"); eng.feed_selection_done([r])
        return [e.role for e in doc.ents.values() if e.kind == "body"]
    step("plate", plate)
    def prof():
        l = E.Line((0, 1500, 0), (2000, 1500, 0)); doc.add(l)
        w.dialog_profile = lambda: {"ptype": "BP", "dims": SH.CATALOGUE["BP"]["HP 160x8"], "size": "", "grade": "A (NS)", "align": 0, "flip": False,
                                    "rot": 0, "web_dir": "UCS Z", "reverse_web": False, "prefix": "S", "mark": "", "layer": "PROFILE", "delete_src": False}
        eng.run("PROFILE3D"); eng.feed_selection_done([l])
    step("profile", prof)
    def pipe():
        w.dialog_pipe = lambda: {"dn": 80, "pipe_std": F.PIPE_STANDARDS[0], "R": None, "flanges": "both", "std": "JIS B2220 10K"}
        return feed("PIPE3D", (0, 3000, 0), (1500, 3000, 0), (1500, 4000, 0), None)
    step("pipe", pipe)
    step("symbol", lambda: (eng.run("SYMBOL", "Gate valve"), eng.feed_point(np.array([0, -500, 0.])), eng.feed_text("0"), eng.cancel()) and None)
    def det():
        w.dialog_detail = lambda: {"kind": D.DETAIL_TYPES[0], "ptype": "BP", "dims": SH.CATALOGUE["BP"]["HP 200x10"], "grade": "A (NS)", "plate_t": 10,
                                   "web_t": 10, "t_br": None, "flanged": None, "rule": "BKI", "ds": 10}
        return feed("DETAIL", (4000, 0))
    step("detail", det)
    step("bom", lambda: feed("BOM", None, (6000, 0)))
    def v12():
        from .core.entities2 import AttDef
        a = doc.add(E.Arc((8000, 0, 0), 500, 0, np.pi / 2)); c1 = doc.add(E.Circle((9000, 0, 0), 50))
        eng.run("DIMARC"); eng.feed_entity(a, np.array([8353., 353, 0])); eng.feed_point(np.array([8500., 500, 0]))
        eng.run("ARRAYRECT"); eng.feed_selection_done([c1])
        eng.run("DETAILVIEW"); eng.feed_point(np.array([500., 250, 0])); eng.feed_text("300"); eng.feed_text("5"); eng.feed_point(np.array([500., -3000, 0]))
        doc.add_block(E.Block("ST_TAG", (0, 0, 0), [E.Circle((0, 0, 0), 60), AttDef((-30, -15, 0), "NO", "No", "A1", 30)]))
        w.dialog_blockprops = lambda blk, ins, title: ({"NO": "B7"}, {})
        eng.run("INSERT", "ST_TAG"); eng.feed_point(np.array([9000., 2000, 0])); eng.feed_enter()
        if eng.busy():
            eng.cancel()
        dv = [e for e in doc.ents.values() if e.kind == "detailview"][0]; ar = [e for e in doc.ents.values() if e.kind == "array"][0]
        ins = [e for e in doc.ents.values() if e.kind == "insert" and e.name == "ST_TAG"][0]
        dm = [e for e in doc.ents.values() if e.kind == "dimension" and e.dtype == "arc"][0]
        assert abs(dm.measure() - 785.398) < 0.01 and len(ar.children()) == ar.cols * ar.rows and len(dv.children()) > 0
        assert [c.s for c in ins.children() if c.kind == "text"] == ["B7"]
        w.clear_selection()
        return (round(dm.measure(), 1), len(ar.children()), len(dv.children()))
    step("v1.2 arcdim/array/detailview/attrib", v12)
    def v13():
        from .core import rhinoio
        from .cmd import frames as FR
        n0 = len(doc.ents)
        w.dialog_frames = lambda o: dict(FR.DEFAULT, first=-5, last=12, segments=[[-5, 0, 500], [8, 12, 1828.8]])
        eng.run("FRAMESPACING"); eng.feed_point(np.array([0., -9000, 0]))
        if eng.busy():
            eng.cancel()
        nf = len(doc.ents) - n0
        assert nf > 40
        f3 = os.path.join(tempfile.mkdtemp(prefix="cadpro_selftest_"), "t.3dm")
        n = rhinoio.export_3dm(doc, f3)
        from .core.document import Document
        d2 = Document(); k, st = rhinoio.import_3dm(d2, f3); doc.activate()
        assert n > 10 and k > 10 and any(e.kind == "body" for e in d2.ents.values())
        return (nf, n, k)
    step("v1.3 framespacing/3dm", v13)
    def v15():
        from .core import entities as E, fillet2
        P = lambda *a: np.array(a, float)
        l1 = doc.add(E.Line((30000, 0, 0), (31000, 0, 0))); l2 = doc.add(E.Line((30000, 0, 0), (30000, 1000, 0)))
        okf, _m, new = fillet2.fillet(doc, l1, P(30500, 0, 0), l2, P(30000, 500, 0), 100)
        assert okf and new and abs(new[0].r - 100) < 1e-6
        a = doc.add(E.Line((32000, 0, 0), (33000, 0, 0))); b = doc.add(E.Line((33000, 0, 0), (33000, 800, 0)))
        eng.run("PEDIT"); eng.feed_entity(a, P(32500, 0, 0)); eng.feed_text("Y"); eng.feed_text("J"); eng.feed_selection_done([b])
        eng.feed_text("C"); eng.feed_enter()
        if eng.busy():
            eng.cancel()
        pl = [e for e in doc.ents.values() if e.kind == "polyline"][-1]
        assert pl.closed and len(pl.pts) == 3
        hb = [doc.add(E.Polyline([(34000, 0, 0), (34400, 0, 0), (34400, 300, 0), (34000, 300, 0)], True)), doc.add(E.Circle((34100, 150, 0), 40))]
        w.view.zoom_extents(hb, animate=False); QApplication.processEvents()      # HATCH pick looks at the visible objects (like AutoCAD)
        old = getattr(w, "dialog_hatch", None); w.dialog_hatch = lambda: {"pattern": "ANSI31", "scale": 1.0, "angle": 0.0}
        try:
            eng.run("HATCH"); eng.feed_point(P(34300, 150, 0)); eng.feed_enter()
            if eng.busy():
                eng.cancel()
        finally:
            if old is not None:
                w.dialog_hatch = old
        h = [e for e in doc.ents.values() if e.kind == "hatch"][-1]
        assert len(h.loops) == 2
        return ("fillet", round(new[0].r, 1), "pedit closed", pl.closed, "hatch loops", len(h.loops), "area", round(abs(h.area()), 1))
    step("v1.5 fillet/pedit/hatch pick", v15)
    def v16():
        from .core import entities as E, fillet2, assoc, mtext
        from .core.document import dash_segments, LINETYPES
        from .core.geom import Plane
        from .cmd import v16 as C16
        P = lambda *a: np.array(a, float)
        a = doc.add(E.Line((40000, 0, 0), (40100, 0, 0))); b = doc.add(E.Line((40100, 0, 0), (40100, 100, 0)))
        okf, _m, new = fillet2.fillet(doc, a, P(40095, 0, 0), b, P(40100, 5, 0), 20)          # picks close to the corner
        assert okf and abs(a.p1[0] - 40080) < 1e-6 and abs(b.p0[1] - 20) < 1e-6
        pl = doc.add(E.Polyline([(41000, 0, 0), (41200, 0, 0), (41200, 100, 0), (41000, 100, 0)], True))
        h = doc.add(E.Hatch([pl.pts], (0, 0, 1), "ANSI31", 1.0, 0.0)); plane = Plane((0, 0, 0), (1, 0, 0), (0, 1, 0))
        doc.begin("t"); doc.modify(h); assoc.attach(h, [pl], plane, P(41100, 50, 0), "pick"); doc.end()
        doc.begin("t"); doc.modify(pl); pl.pts[1][0] = 41300; pl.pts[2][0] = 41300; pl.touch(); doc.end()    # stretch the boundary
        assert abs(abs(h.area()) - 30000) < 1.0, h.area()
        ds = dash_segments(np.array([[0, 0, 0], [1000, 0, 0]], float), LINETYPES["Dashed"], 1.0)
        assert ds is not None and len(ds) > 20
        cl = C16.cloud_polyline([(0, 0, 0), (1000, 0, 0), (1000, 600, 0), (0, 600, 0)], 100)
        assert cl is not None and cl.closed and len(cl.pts) == 32
        v = C16.cal_eval("dist([0,0],[3,4])*2+sqrt(16)", C16.cal_namespace(None)); assert abs(v - 14) < 1e-9
        t = E.Text((42000, 0, 0), "x", 10, halign=0, valign=3); t.set_rich("{\\fArial|b1|i0;\\C1;BOLD} plain {\\Lunder}\\P1{\\S1/2;}")
        g = t.tris_groups(); assert g and len(g) == 2 and mtext.plain(t.rich) == "BOLD plain under\n11/2"
        d1 = E.Dimension("linear", [(0, 0, 0), (29.11, 0, 0), (0, 10, 0)], style={"unit": "Architectural", "dec": 4})
        assert d1.text() == "2'-5 1/8\"", d1.text()
        return ("fillet corner", "assoc hatch", round(abs(h.area())), "dashes", len(ds), "cloud arcs", len(cl.pts), "cal", v, "mtext groups", len(g), d1.text())
    step("v1.6 fillet side/assoc hatch/linetype/cloud/cal/mtext/dim units", v16)
    def v17():
        from .core import entities as E, editops as X
        from .ui import viewport as VP
        from .cmd import v15 as C15
        P = lambda *a: np.array(a, float)
        L = E.Leader([(50000, 0, 0), (50100, 80, 0)], "PLATE", 2.5, (0, 0, 1), 2.5); L.land0 = 2.0; L.arrow = "open"; doc.add(L)
        gi = [i for i, g in enumerate(L.grip_map()) if g == ("m", 0, 1)][0]
        assert [m[0] for m in VP.grip_modes(L, gi)] == ["stretch", "landing", "addleader"]
        VP.grip_apply(L, gi, P(49950, 120, 0), "addleader"); VP.grip_apply(L, gi, P(50130, 80, 0), "landing"); L.touch()
        assert len(L.lines()) == 2 and abs(L.land - 30) < 1e-6
        L2 = E.from_dict(L.to_dict()); assert len(L2.extra) == 1 and L2.arrow == "open" and len(L2.wire()) >= 4
        pr = {q[0]: q for q in L.props()}; assert "Arrowhead size" in pr and "Landing distance (0 = no landing)" in pr
        assert X.trim(E.Line((51000, 0, 0), (51100, 0, 0)), P(51050, 0, 0), []) is None          # nothing crosses: quick TRIM erases it
        for a, b in (((52000, 0, 0), (52001, 0, 0)), ((52000, 100, 0), (52001, 100, 0)), ((52000, 0, 0), (52000, 1, 0)), ((52200, 0, 0), (52200, 1, 0))):
            d_ = unit_(np.array(b, float) - np.array(a, float)); x = E.Line(np.array(a, float) - d_ * 1e7, np.array(a, float) + d_ * 1e7); x.xd = {"inf": "xline"}; doc.add(x)
        assert "MLEADER" in w.engine.cmds and w.engine.alias.get("MLD") == "MLEADER"
        from .ui.options import DEFAULTS
        assert "img" not in DEFAULTS["snap_modes"]
        return ("multileader lines", len(L.lines()), "landing", round(L.land, 1), "arrow", L2.arrow, "MLD ok")
    def unit_(v):
        return v / float(np.linalg.norm(v))
    step("v1.7 multileader / grips / trim quick / MLD", v17)
    def v18():
        from .core import entities as E, editops as X, hatchpat as HP
        from .ui import viewport as VP
        from .cmd.modify import match_props
        P = lambda *a: np.array(a, float)
        l = E.Line((60000, 0, 0), (60100, 0, 0)); l.ltype = "Dashed"; l.lts = 4.0
        o = X.offset(l, 10, P(60050, 5, 0)); assert o.lts == 4.0 and o.ltype == "Dashed"
        b = E.Line((60000, 50, 0), (60100, 50, 0)); match_props(l, b); assert b.lts == 4.0 and b.ltype == "Dashed"
        assert [m for m, _ in VP.grip_modes(l, 1)] == ["stretch", "lengthen"]
        el = E.Ellipse((61000, 0, 0), (80, 0, 0), 0.5); assert len(VP.grip_points(el)) == 5
        VP.grip_apply(el, 2, P(61000, 60, 0)); assert abs(el.ratio - 0.75) < 1e-9
        sp = E.Spline.through([(62000, 0, 0), (62050, 40, 0), (62100, 0, 0)]); VP.grip_apply(sp, 0, P(62020, 30, 0), "add"); assert len(sp.fit) == 4
        pl = E.Polyline([(63000, 0, 0), (63200, 0, 0), (63200, 100, 0), (63000, 100, 0)], True); g = pl.snaps().get("gcen")
        assert g and np.allclose(g[0], (63100, 50, 0))
        loop = [np.array([[0, 0], [100, 0], [100, 60], [0, 60.0]])]
        bad = [k for k, (c_, d_, f) in HP.LIBRARY.items() if k != "SOLID" and not HP.segments(loop, f, 0.05 if k.startswith("AR-") else 1.0)]
        assert not bad, bad
        assert "REFEDIT" in w.engine.cmds and "REFCLOSE" in w.engine.cmds
        t = E.Text((64000, 0, 0), "MAIN ENGINE ROOM AND PUMP ROOM", 5.0, (1, 0, 0), (0, 0, 1), 0, 3); t.width = 60
        assert t.tris() is not None and VP.text_width_grip(t) is not None
        return ("patterns", len(HP.LIBRARY), "ellipse ratio", el.ratio, "gcen", list(np.round(g[0], 1)), "REFEDIT ok")
    step("v1.8 linetype scale / matchprop / grips / gcen / hatch patterns / refedit", v18)
    tmp = tempfile.mkdtemp(prefix="cadpro_selftest_")
    step("save", lambda: doc.save(os.path.join(tmp, "t.acp")))
    from .core import dxfio
    step("dxf", lambda: dxfio.export_dxf(doc, os.path.join(tmp, "t.dxf")))
    def pdf():
        from .core import pdfimport as PI
        from .ui.plot import plot_pdf
        fn = os.path.join(tmp, "plot.pdf"); plot_pdf(w, fn)
        return len(PI.import_pdf(fn, 0, 1.0))
    step("plot+pdfimport", pdf)
    def xlsx():
        from .ui.dialogs import export_bom_xlsx
        from .cmd.ship import collect_bom, bom_table_rows
        rows = collect_bom(doc); export_bom_xlsx(os.path.join(tmp, "bom.xlsx"), bom_table_rows(rows), rows)
    step("excel", xlsx)
    def upd():
        from .core import update as U
        return U.notice_valid({"product": "X"})
    step("update module", upd)
    def shot():
        w.view.zoom_extents(animate=False)
        for _ in range(30):
            QApplication.processEvents()
        img = w.grab(); img.save(os.path.splitext(out)[0] + ".png")
        import OpenGL.GL as gl
        return w.view.context().format().majorVersion(), w.view.context().format().minorVersion()
    step("screenshot", shot)
    with open(out, "w", encoding="utf-8") as f:
        f.write(("SELFTEST OK\n" if ok else "SELFTEST FAILED\n") + f"version {w.version}  app {w.boot.get('app_dir', '')}\n" + "\n".join(lines) + "\n")
    doc.modified = False
    QApplication.quit()
