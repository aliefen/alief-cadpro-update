"""Main window / controller."""
import json
import os
import sys
import time
import numpy as np
from PySide6.QtCore import Qt, QTimer, QSettings, Signal, QObject, QSize, QPoint
from PySide6.QtGui import QKeySequence, QShortcut, QAction, QIcon
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QDockWidget, QLabel, QToolButton, QStatusBar,
                               QFileDialog, QMessageBox, QMenu, QComboBox, QInputDialog, QApplication, QTabWidget, QTabBar)
from ..core.document import Document, APP_VERSION
from ..core import entities as E
from ..core.geom import Plane, fmt
from ..cmd.engine import Engine, Req
from ..cmd import draw2d, modify, solid3d, rhinosrf, ship, piping, cam_redraw, misc, annot, insview, blocks, frames, dynauthor, v15, v16, v18
from .viewport import Viewport, grip_apply, R_view, VIEWS
from .ribbon import Ribbon
from .panels import CommandLine, PropertiesPanel, LayersPanel, SymbolPanel, BrowserPanel
from . import dialogs as DL
from .icons import icon, set_light
from .brand import app_icon
from .theme import DARK, LIGHT, stylesheet
from . import options as OPT
from .docks import PaletteManager


class _Bridge(QObject):
    update_result = Signal(str, object, str)
    update_progress = Signal(str, float)


class MainWindow(QMainWindow):
    def __init__(self, boot=None, files=()):
        super().__init__()
        self.boot = boot or {}
        self.version = APP_VERSION
        self.settings = QSettings("AliefEnergy", "ALIEF_CADPRO")
        try:
            from .dialogs18 import load_user_patterns
            load_user_patterns(self.settings)               # hatch patterns loaded from .pat files (Custom tab)
        except Exception:
            pass
        self.doc = Document(); self.doc.listeners.append(self._doc_changed)
        E.Entity.anno_scale = self.doc.settings.get("anno_scale", 1.0)
        self.engine = Engine(self)
        for mod in (draw2d, modify, solid3d, rhinosrf, ship, piping, cam_redraw, misc, annot, insview, blocks, frames, dynauthor, v15, v16, v18):
            mod.register(self.engine)
        self.ucs_prev = None; self.last_window = None; self.zoom_window_pending = False; self.pending_equipment = None
        self._last = {}
        self.bedit = None            # block editor session: {name, main, params, state}
        self.setWindowTitle("ALIEF CAD PRO"); self.setWindowIcon(app_icon())
        self.sel_ids = []                  # one selection shared by all viewports
        self.view = Viewport(self); self.views = [self.view]; self._view0 = self.view     # the first viewport is never deleted
        self.view.opt, self.profile = OPT.load(self.settings)
        if self.settings.contains("light") and not self.settings.contains("opt/profiles"):        # setting of version 1.0
            self.view.opt["theme"] = "Light" if self.settings.value("light", False, bool) else "Dark"
        self.view.light = self.view.opt["theme"] == "Light"; set_light(self.view.light)
        self._build_ui()
        self.apply_theme()
        self.apply_options(self.view.opt, startup=True)
        self._restore_layout()
        self.message(f"ALIEF CAD PRO {self.version} ready. Type a command or use the ribbon. HELP lists all commands.")
        QApplication.instance().installEventFilter(self)
        self.bridge = _Bridge(); self.bridge.update_result.connect(self._update_result)
        self.bridge.update_progress.connect(self._update_progress)
        self.update_dialog = None
        self.autosave = QTimer(self); self.autosave.timeout.connect(self._autosave)
        self._autosave_timer()
        for f in files:
            self.open_path(f)
        QTimer.singleShot(1500, self._startup_update)
        self._upd_timer = QTimer(self); self._upd_timer.timeout.connect(self._periodic_update)
        self._upd_timer.start(3 * 3600 * 1000)                 # also every 3 hours while the program stays open
        QTimer.singleShot(2500, self._whats_new)
        QTimer.singleShot(4000, self._boot_ok)

    # =============================================================================== UI construction
    def _build_ui(self):
        central = QWidget(); v = QVBoxLayout(central); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        self.ribbon = Ribbon(app_icon(), list(self.engine.cmds) + list(self.engine.alias))
        self.ribbon.command.connect(self.run_command)
        self.setMenuWidget(self.ribbon)            # full-width ribbon above the palettes
        # ---- drawing tabs: several files open at once
        self.docs = [self.doc]; self._tab_lock = False; self._untitled_n = 1; self.doc.untitled = "Drawing1"
        self.doc_tabs = QTabBar(); self.doc_tabs.setObjectName("doctabs"); self.doc_tabs.setTabsClosable(True); self.doc_tabs.setMovable(True)
        self.doc_tabs.setExpanding(False); self.doc_tabs.setDrawBase(False); self.doc_tabs.setElideMode(Qt.ElideMiddle); self.doc_tabs.setUsesScrollButtons(True)
        self.doc_tabs.addTab("Drawing1")
        self.doc_tabs.currentChanged.connect(self._tab_changed); self.doc_tabs.tabCloseRequested.connect(self._tab_close)
        self.doc_tabs.tabMoved.connect(self._tab_moved)
        tb = QWidget(); tb.setObjectName("doctabrow"); th = QHBoxLayout(tb); th.setContentsMargins(4, 0, 4, 0); th.setSpacing(2)
        th.addWidget(self.doc_tabs, 1)
        plus = QToolButton(); plus.setText("+"); plus.setToolTip("New drawing (Ctrl+N)"); plus.setAutoRaise(True); plus.clicked.connect(self.file_new)
        th.addWidget(plus)
        v.addWidget(tb)
        self.view_host = QWidget(); self.view_host.setObjectName("viewhost")
        vh = QVBoxLayout(self.view_host); vh.setContentsMargins(0, 0, 0, 0); vh.setSpacing(0); vh.addWidget(self.view)
        v.addWidget(self.view_host, 1)
        self.cmdline = CommandLine(list(self.engine.cmds) + list(self.engine.alias))
        self.cmdline.submitted.connect(self._cmd_text); self.cmdline.escape.connect(self.escape)
        self.setCentralWidget(central)
        self.setDockNestingEnabled(True)
        self.setCorner(Qt.BottomLeftCorner, Qt.LeftDockWidgetArea); self.setCorner(Qt.BottomRightCorner, Qt.RightDockWidgetArea)
        self._build_ribbon()
        self._build_docks()
        self._build_status()
        self._shortcuts()
        self.view.mouse_moved.connect(self._coords)

    def _build_ribbon(self):
        rb = self.ribbon
        for cmd, ic, tip in (("NEW", "new", "New (Ctrl+N)"), ("OPEN", "open", "Open (Ctrl+O)"), ("SAVE", "save", "Save (Ctrl+S)"),
                             ("UNDO", "undo", "Undo (Ctrl+Z)"), ("REDO", "redo", "Redo (Ctrl+Y)"), ("PLOT", "plot", "Plot to PDF (Ctrl+P)")):
            rb.add_qat(cmd, ic, tip)
        m = rb.app_menu
        for t, c, ic in (("New", "NEW", "new"), ("Open ...", "OPEN", "open"), ("Save", "SAVE", "save"), ("Save As ...", "SAVEAS", "saveas"),
                         (None, None, None), ("Import (DXF / DWG / STL / OBJ / PDF / image) ...", "IMPORT", "import"),
                         ("Export (DXF / STL / OBJ) ...", "EXPORT", "export"), ("Plot to PDF ...", "PLOT", "plot"), ("Save image (PNG) ...", "PNGOUT", "png"),
                         (None, None, None), ("Options ...", "OPTIONS", "options"), ("Check for updates ...", "UPDATE", "update"),
                         ("User guide (Panduan)", "GUIDE", "guide"), ("About", "ABOUT", "about"), (None, None, None), ("Exit", "QUIT", "erase")):
            if t is None:
                m.addSeparator(); continue
            a = m.addAction(icon(ic), t); a.triggered.connect(lambda _=False, c=c: self.run_command(c))
        self.recent_menu = m.addMenu(icon("open"), "Recent files"); self._recent_refresh()

        # ---------------------------------------------------------------- Home
        t = rb.add_tab("Home")
        p = t.add_panel("Draw")
        p.big("LINE", "Line", "line", "Straight segments (L)")
        p.big("PLINE", "Polyline", "pline", "Lines and arcs as one object (PL)")
        p.split("Circle", "circle", [("Center, radius", "circle", "CIRCLE"), ("2 points", "circle2p", "CIRCLE"), ("3 points", "circle3p", "CIRCLE")])
        p.split("Arc", "arc", [("3 points", "arc", "ARC"), ("Start, center, end", "arcsce", "ARC")])
        p.small("RECTANG", "Rectangle", "rect"); p.small("POLYGON", "Polygon", "polygon"); p.small("ELLIPSE", "Ellipse", "ellipse")
        p.small("SPLINE", "Spline", "spline"); p.small("HATCH", "Hatch", "hatch"); p.small("POINT", "Point", "point")
        p.small("XLINE", "Xline", "xline", "Construction line (infinite): 2 points, Hor, Ver, Ang, Bisect, Offset"); p.small("RAY", "Ray", "ray")
        p.small("REVCLOUD", "Rev. Cloud", "revcloud", "Revision cloud: rectangular, polygonal, freehand or from an object")
        p = t.add_panel("Modify")
        p.small("MOVE", "Move", "move"); p.small("COPY", "Copy", "copy"); p.small("STRETCH", "Stretch", "stretch")
        p.small("ROTATE", "Rotate", "rotate"); p.small("MIRROR", "Mirror", "mirror"); p.small("SCALE", "Scale", "scale")
        p.small("TRIM", "Trim", "trim"); p.small("EXTEND", "Extend", "extend"); p.small("OFFSET", "Offset", "offset")
        p.small("FILLET", "Fillet", "fillet"); p.small("CHAMFER", "Chamfer", "chamfer")
        p.small("BRINGTOFRONT", "Front", "tofront", "Draw order: bring to front"); p.small("SENDTOBACK", "Back", "toback", "Draw order: send to back")
        p.small("DRAWORDER", "Order", "draworder", "Draw order: above / under an object, front, back")
        p.split("Array", "array", [("Rectangular array", "array", "ARRAYRECT"), ("Polar array", "array", "ARRAYPOLAR"), ("Path array", "array", "ARRAY")], big=False)
        p.small("ERASE", "Erase", "erase"); p.small("EXPLODE", "Explode", "explode"); p.small("JOIN", "Join", "join")
        p.small("BREAK", "Break", "break"); p.small("ALIGN", "Align", "align"); p.small("MATCHPROP", "Match prop.", "matchprop")
        p = t.add_panel("Annotation")
        p.big("TEXT", "Text", "text"); p.big("MTEXT", "Mtext", "mtext")
        p.split("Dimension", "dimlin", [("Linear", "dimlin", "DIMLINEAR"), ("Aligned", "dimali", "DIMALIGNED"), ("Arc length", "dimarc", "DIMARC"),
                                         ("Radius", "dimrad", "DIMRADIUS"), ("Diameter", "dimdia", "DIMDIAMETER"), ("Angular", "dimang", "DIMANGULAR"),
                                         ("Continue", "dimcont", "DIMCONTINUE"), ("Baseline", "dimbase", "DIMBASELINE"), ("Ordinate", "dimord", "DIMORDINATE"),
                                         ("Quick dimension", "qdim", "QDIM")])
        p.small("LEADER", "Leader", "leader"); p.small("BOM", "BOM table", "bom"); p.small("ANNOSCALE", "Scale 1:N", "annoscale")
        p = t.add_panel("Layers & Properties")
        p.big("LAYER", "Layers", "layers"); p.big("PROPERTIES", "Properties", "props")
        self.layer_combo = QComboBox(); self.layer_combo.setMinimumWidth(130); self.layer_combo.currentTextChanged.connect(self._set_cur_layer)
        p.widget(self.layer_combo)
        p = t.add_panel("Utilities")
        p.small("DIST", "Distance", "dist"); p.small("AREA", "Area / CG", "area"); p.small("ID", "ID point", "id")
        p.small("VOLUME", "Volume", "volume"); p.small("MASSPROP", "Mass prop.", "massprop"); p.small("LIST", "List", "list")
        p.small("CAL", "Calculator", "cal", "CAL: geometry calculator, e.g. (end+end)/2 or dist(end,end); =expression works at any prompt")
        p.small("LINETYPE", "Linetype scale", "ltscale", "Linetypes, global linetype scale (LTSCALE) and object scale")
        p.small("SELECTSIMILAR", "Select Similar", "selsimilar", "Select all objects like the selected ones"); p.small("DSETTINGS", "Drafting Settings", "dsettings", "Snap & grid, polar tracking, object snap")
        p = t.add_panel("Block")
        p.big("INSERT", "Insert", "insert"); p.small("BLOCK", "Create", "block"); p.small("SYMLIB", "Symbols", "symlib")

        # ---------------------------------------------------------------- Annotate
        t = rb.add_tab("Annotate")
        p = t.add_panel("Text")
        p.big("MTEXT", "Multiline Text", "mtext"); p.small("TEXT", "Single line", "text"); p.small("FIND", "Find and Replace", "find")
        p.small("TEXTFIT", "Auto text height", "textfit"); p.small("TCOUNT", "Number texts", "tcount", "TCOUNT: automatic sequence numbers in texts")
        p.small("TNUMBER", "Place numbers", "tnumber", "Click to place 1, 2, 3 ... (prefix, suffix, bubble)")
        self.th_combo = QComboBox(); self.th_combo.setEditable(True); self.th_combo.setMinimumWidth(84); self.th_combo.setToolTip("Text height on paper (mm)")
        self.th_combo.addItems(["1.8", "2.5", "3.5", "5", "7", "10"]); self.th_combo.setCurrentText(f"{self.doc.settings.get('text_paper', 2.5):g}")
        self.th_combo.activated.connect(self._th_pick); self.th_combo.lineEdit().returnPressed.connect(self._th_pick)
        p.widget(self.th_combo)
        p = t.add_panel("Dimensions")
        p.split("Dimension", "dimlin", [("Linear", "dimlin", "DIMLINEAR"), ("Aligned", "dimali", "DIMALIGNED"), ("Arc length", "dimarc", "DIMARC"),
                                         ("Radius", "dimrad", "DIMRADIUS"), ("Jogged radius", "dimjog", "DIMJOGGED"), ("Diameter", "dimdia", "DIMDIAMETER"),
                                         ("Angular", "dimang", "DIMANGULAR"), ("Ordinate", "dimord", "DIMORDINATE")])
        p.big("DIMALIGNED", "Aligned", "dimali", "DAL: dimension parallel to the measured edge (DLI = Linear: horizontal / vertical, in the Dimension button)")
        p.big("DIMANGULAR", "Angular", "dimang")
        p.small("DIMARC", "Arc length", "dimarc", "Arc length dimension"); p.small("DIMCONTINUE", "Continue", "dimcont"); p.small("DIMBASELINE", "Baseline", "dimbase")
        p.small("DIMRADIUS", "Radius", "dimrad"); p.small("DIMDIAMETER", "Diameter", "dimdia"); p.small("DIMORDINATE", "Ordinate", "dimord")
        p.big("QDIM", "Quick Dim", "qdim", "Select objects, then one click: continuous, staggered, baseline, ordinate, radius or diameter dimensions")
        p.small("DIMJOGGED", "Jogged", "dimjog"); p.small("REVCLOUD", "Revision Cloud", "revcloud"); p.small("DIMSTYLE", "Dim Style Manager", "dimstyle", "Named dimension styles: arrows, text, units")
        p = t.add_panel("Centerlines")
        p.big("CENTERLINE", "Centerline", "centerline"); p.big("CENTERMARK", "Center Mark", "centermark")
        p = t.add_panel("Leaders")
        p.big("MLEADER", "Multileader", "leader", "MLEADER (MLD): arrowhead, landing, text. Select it and hover the landing grip to Add Leader")
        p.small("LEADER", "Leader", "leader", "QLEADER: leader with several vertices"); p.small("MLEADEREDIT", "Add/Remove Leader", "leader")
        p = t.add_panel("Tables")
        p.big("TABLE", "Table", "table"); p.small("TABLEDIT", "Edit table", "table"); p.small("AREATABLE", "Area Table", "areatable")
        p.small("TABLEEXPORT", "Export Table to Excel", "tableexport"); p.small("BOM", "BOM table", "bom"); p.small("MATLIST", "Material list", "matlist")
        p = t.add_panel("Measure")
        p.big("DIST", "Distance", "dist", "Two points, or [Object] for the length of selected objects")
        p.big("AREA", "Area", "area", "By points, or [Object] for selected closed objects"); p.big("VOLUME", "Volume", "volume", "Volume of solids or outline x height")
        p = t.add_panel("Annotative Scale")
        p.big("ANNOSCALE", "Drawing scale", "annoscale")

        # ---------------------------------------------------------------- Insert
        t = rb.add_tab("Insert")
        p = t.add_panel("Reference")
        p.big("XATTACH", "DWG Reference", "xref", "Attach a DWG / DXF / ACP drawing as external reference")
        p.small("XRELOAD", "Reload references", "regen"); p.small("XLIST", "Reference list", "list")
        p = t.add_panel("Images")
        p.big("IMAGEATTACH", "Attach", "image"); p.big("IMAGEADJUST", "Adjust", "imagefade", "Brightness, contrast and fade with live sliders"); p.big("IMAGECLIP", "Clip", "imageclip")
        p.small("IMAGEFRAME", "Display Image Frame", "rect"); p.small("CALIBRATE", "Calibrate scale", "calibrate"); p.small("DESKEW", "Deskew", "deskew")
        p = t.add_panel("Block")
        p.big("INSERT", "Insert", "insert"); p.big("BLOCK", "Create", "block"); p.big("BEDIT", "Block Editor", "bedit", "Edit a block: geometry, attributes, dynamic options")
        p.big("REFEDIT", "Edit In-place", "refedit", "Edit Block In-place (REFEDIT): change a block directly in the drawing, the rest is faded")
        p.small("BLOCKBASE", "Change Base Point", "id"); p.small("EXPLODE", "Block Break", "explode"); p.small("SYMLIB", "Symbol library", "symlib")
        p = t.add_panel("Block Definition")
        p.big("ATTDEF", "Define Attributes", "attdef"); p.big("ATTEDIT", "Edit Attributes", "attedit", "Attributes and dynamic options of one block")
        p.big("ATTEXT", "Attribute List", "areatable", "Table of all attribute values (then Table to Excel)")
        p = t.add_panel("Import")
        p.big("IMPORT", "Import", "import", "DXF / DWG / STL / OBJ / PDF / image / CSV"); p.small("PDFIMPORT", "PDF Import", "pdfimport")
        p.small("CSVIMPORT", "Points Excel / CSV", "csvimport"); p.small("AUTOTRACE", "Raster to vector", "autotrace")
        p = t.add_panel("Data")
        p.big("MATLIST", "Data Extraction", "matlist", "Material list to Excel"); p.big("TABLEEXPORT", "Table to Excel", "tableexport")

        # ---------------------------------------------------------------- 3D Modeling
        t = rb.add_tab("3D Solid")
        p = t.add_panel("Primitives")
        p.big("BOX", "Box", "box"); p.big("CYLINDER", "Cylinder", "cylinder")
        p.small("CONE", "Cone", "cone"); p.small("SPHERE", "Sphere", "sphere"); p.small("TORUS", "Torus", "torus")
        p.small("WEDGE", "Wedge", "wedge"); p.small("PYRAMID", "Pyramid", "pyramid")
        p = t.add_panel("Solid")
        p.big("EXTRUDE", "Extrude", "extrude"); p.big("REVOLVE", "Revolve", "revolve"); p.big("SWEEP", "Sweep", "sweep"); p.big("LOFT", "Loft", "loft")
        p.small("THICKEN", "Thicken", "thicken"); p.small("SLICE", "Slice", "slice")
        p = t.add_panel("Boolean")
        p.big("UNION", "Union", "union"); p.big("SUBTRACT", "Subtract", "subtract"); p.big("INTERSECT", "Intersect", "intersect")
        p = t.add_panel("3D Modify")
        p.small("ROTATE3D", "3D Rotate", "rotate3d"); p.small("MIRROR3D", "3D Mirror", "mirror3d"); p.small("ALIGN", "Align", "align")
        p = t.add_panel("Viewports")
        p.split("Viewports", "vports", [("Single", "vports", "VPORTS_SINGLE"), ("Two: Vertical", "vports", "VPORTS_2V"),
                                         ("Two: Horizontal", "vports", "VPORTS_2H"), ("Three: Right", "vports", "VPORTS_3R"),
                                         ("Three: Left", "vports", "VPORTS_3L"), ("Four: Equal", "vports", "VPORTS_4")])
        for cfg in ("SINGLE", "2V", "2H", "3R", "3L", "4"):
            self.engine.register("VPORTS_" + cfg, misc.T(lambda c, cfg=cfg: self.set_vports("Single" if cfg == "SINGLE" else cfg)), [], "Viewport configuration")
        p = t.add_panel("Coordinates")
        p.big("UCS", "UCS", "ucs"); p.small("UCSWORLD", "World", "ucsworld"); p.small("UCS", "3 Point / Object", "ucs3p"); p.small("UCSVIEW", "View", "ucsview")
        p.small("UCSTOP", "Top plane", "view_top"); p.small("UCSFRONT", "Front plane", "view_front"); p.small("UCSRIGHT", "Side plane", "view_right")

        # ---------------------------------------------------------------- Surface
        t = rb.add_tab("Surface")          # command names, prompts and options follow Rhinoceros 8 (Surface menu)
        p = t.add_panel("Plane & Points")
        p.big("PLANE", "Plane", "planesurf", "Plane: corner to corner, 3Point, Vertical, Center")
        p.big("SRFPT", "SrfPt", "srfpt", "Surface from 3 or 4 corner points")
        p.big("PLANARSRF", "PlanarSrf", "planarsrf", "Surface from planar closed curves")
        p.big("EDGESRF", "EdgeSrf", "edgesurf", "Surface from 2, 3 or 4 edge curves")
        p = t.add_panel("Extrude")
        p.big("EXTRUDECRV", "ExtrudeCrv", "extsurf", "Extrude curves straight [Direction / BothSides / Solid]")
        p.small("EXTRUDECRVALONGCRV", "Along curve", "extalong", "ExtrudeCrvAlongCrv")
        p.small("EXTRUDECRVTOPOINT", "To point", "exttopt", "ExtrudeCrvToPoint")
        p = t.add_panel("Loft & Sweep")
        p.big("LOFT", "Loft", "loftsurf", "Loft through section curves [Style / Closed / Solid]")
        p.big("SWEEP1", "Sweep1", "sweepsurf", "Sweep cross sections along one rail")
        p.big("SWEEP2", "Sweep2", "sweep2", "Sweep cross sections along two rails")
        p.big("NETWORKSRF", "NetworkSrf", "networksrf", "Surface from a network of crossing curves")
        p.big("PATCH", "Patch", "patch", "Fit a surface through boundary curves and points")
        p = t.add_panel("Revolve")
        p.big("REVOLVE", "Revolve", "revsurf", "Revolve curves about an axis"); p.big("RAILREVOLVE", "RailRevolve", "railrev", "Revolve a profile following a rail")
        p = t.add_panel("Surface tools")
        p.big("OFFSETSRF", "OffsetSrf", "offsetsrf", "Offset surface [FlipAll / Solid / BothSides]")
        p.small("FLIP", "Flip", "flip", "Flip surface normals"); p.small("DUPBORDER", "DupBorder", "dupborder", "Border curves of a surface")
        p.small("THICKEN", "Thicken", "thicken")
        p = t.add_panel("Curve from objects")
        p.big("CONTOUR", "Contour", "contour", "Evenly spaced sections: stations, waterlines, buttocks")
        p.big("SECTION", "Section", "section", "Section curve through surfaces / solids")
        p = t.add_panel("Ship")
        p.big("PLATE3D", "Plate from surface", "platesurf")

        # ---------------------------------------------------------------- Ship structure
        t = rb.add_tab("Ship Structure")
        p = t.add_panel("Frames")
        p.big("FRAMESPACING", "Frame Spacing", "framespacing", "Frame ruler: free numbering (0 1 2 ... or -5 -4 ... 0 1 2 ...) and spacing per segment")
        p = t.add_panel("3D Plate")
        p.big("PLATE3D", "3D Plate", "plate3d", "Plate from closed curves (with openings) or surfaces, thickness + IACS grade")
        p.big("PLATEHOLE", "Opening", "platehole", "Cut manholes / lightening holes / cut-outs")
        p = t.add_panel("3D Profile")
        p.big("PROFILE3D", "3D Profile", "profile3d", "FB, L, HP bulb, T, H, C, pipe, round bar, SHS along a path")
        p = t.add_panel("Frame Connections")
        p.big("BRACKET3D", "3D Bracket", "bracket", "3D bracket sized by the rule formula")
        p.split("Standard details", "detail", [(k, "detail" if "racket" in k else ("slot" if "lot" in k or "collar" in k else ("scallop" if "callop" in k else "snipe")), "DETAIL")
                                               for k in __import__("alief_cadpro.core.details", fromlist=["DETAIL_TYPES"]).DETAIL_TYPES])
        p = t.add_panel("Output")
        p.big("MATLIST", "Material list", "matlist"); p.big("BOM", "BOM table", "bom")
        p.small("COLORTHK", "Colour by thickness", "colorthk"); p.small("FLATTEN", "Flatten plates", "flatten"); p.small("MASSPROP", "Weight / CG", "massprop")

        # ---------------------------------------------------------------- Piping & Electrical
        t = rb.add_tab("Piping & Electrical")
        p = t.add_panel("Symbols 2D")
        p.big("SYMLIB", "Symbol library", "symlib"); p.big("SYMBOL", "Electrical", "sym_elec"); p.big("SYMBOL", "Piping", "sym_pipe")
        p = t.add_panel("Piping 3D")
        p.big("PIPE3D", "Pipe route", "pipe3d", "Pipe along points with automatic bends"); p.big("FITTING", "Fitting / valve", "fitting")
        p.small("FITTING", "Flange", "flange"); p.small("TEXTFIT", "Auto text", "textfit")
        p = t.add_panel("Electrical 3D")
        p.big("CABLETRAY", "Cable tray", "tray"); p.big("CONDUIT", "Conduit", "conduit"); p.big("EQUIPMENT", "Equipment", "equip")
        p = t.add_panel("Lists")
        p.big("BOM", "BOM table", "bom"); p.big("MATLIST", "Material list", "matlist")

        # ---------------------------------------------------------------- Redraw
        t = rb.add_tab("Redraw")
        p = t.add_panel("Import")
        p.big("PDFIMPORT", "PDF import", "pdfimport", "PDF vectors, text and images to CAD objects")
        p.big("IMAGEATTACH", "Attach image", "image", "JPG / PNG / BMP / TIF underlay")
        p.big("CSVIMPORT", "Points Excel / CSV", "csvimport")
        p = t.add_panel("Image")
        p.big("CALIBRATE", "Calibrate scale", "calibrate"); p.big("DESKEW", "Deskew", "deskew")
        p.small("IMAGEADJUST", "Adjust image", "imagefade", "Brightness, contrast and fade"); p.small("IMGSNAP", "Snap to image lines", "imgsnap"); p.small("ALIGN", "Align", "align")
        p = t.add_panel("Vectorize")
        p.big("AUTOTRACE", "Auto trace", "autotrace", "Raster to vector, centre-line, no double lines")
        p.big("PLINE", "Manual trace", "pline")
        p = t.add_panel("Details")
        p.big("DETAILVIEW", "Detail view", "detailview", "Enlarged detail that follows the main drawing and its scale")
        p.big("DETAIL", "Standard detail", "detail")

        # ---------------------------------------------------------------- CAM
        t = rb.add_tab("CAM")
        p = t.add_panel("CNC cutting")
        p.big("CAMCUT", "G-code", "camcut", "Plasma / oxy-fuel / laser toolpath with kerf, lead-in, holes first")
        p.big("NEST", "Nesting", "nest"); p.big("FLATTEN", "Flatten plates", "flatten")

        # ---------------------------------------------------------------- Views
        t = rb.add_tab("Views")
        p = t.add_panel("Observation")
        p.big("REGEN", "Regen", "regen"); p.small("PAN", "Pan", "move"); p.small("ZOOMEXT", "Extents", "zoomext"); p.small("3DORBIT", "Orbit", "rotate3d")
        p.small("ZOOMWIN", "Zoom window", "zoomwin"); p.small("ZOOM", "Zoom ...", "zoomwin"); p.small("PLAN", "Plan (UCS)", "plan")
        p = t.add_panel("Views")
        self.view_combo = QComboBox(); self.view_combo.setMinimumWidth(150); self.view_combo.setToolTip("Standard and named views")
        self.view_combo.activated.connect(self._view_pick); p.widget(self.view_combo)
        p.big("VIEW", "View Manager", "viewmgr", "Save / restore / delete named views")
        p.small("TOP", "Top", "view_top"); p.small("FRONT", "Front", "view_front"); p.small("RIGHT", "Right", "view_right")
        p.small("BOTTOM", "Bottom", "view_bottom"); p.small("BACK", "Back", "view_back"); p.small("LEFT", "Left", "view_left")
        p.split("Isometric", "view_iso", [("SW Isometric", "view_iso", "SWISO"), ("SE Isometric", "view_iso", "SEISO"), ("NE Isometric", "view_iso", "NEISO"),
                                           ("NW Isometric", "view_iso", "NWISO")])
        p = t.add_panel("Coordinates")
        p.big("UCS", "UCS", "ucs"); p.small("UCSWORLD", "World", "ucsworld"); p.small("UCS", "3 Point / Object", "ucs3p"); p.small("UCSVIEW", "View", "ucsview")
        p.small("UCSTOP", "Top plane", "view_top"); p.small("UCSFRONT", "Front plane", "view_front"); p.small("UCSRIGHT", "Side plane", "view_right")
        p = t.add_panel("Visual Styles")
        self.vs_combo = QComboBox(); self.vs_combo.setMinimumWidth(150)
        self._vs_names = [("2D Wireframe", "WIRE"), ("Hidden", "HIDDEN"), ("Shaded", "SHADED"), ("Shaded with edges", "SHADEDEDGES"), ("X-Ray", "XRAY")]
        self.vs_combo.addItems([n for n, _ in self._vs_names]); self.vs_combo.activated.connect(lambda i: self.run_command(self._vs_names[i][1]))
        p.widget(self.vs_combo)
        p.small("PERSPECTIVE", "Perspective", "persp"); p.small("COLORTHK", "Colour by thickness", "colorthk"); p.small("THEME", "Dark / light", "options")
        p = t.add_panel("Palettes")
        p.small("PROPERTIES", "Properties", "props"); p.small("LAYER", "Layers", "layers"); p.small("SYMLIB", "Symbols", "symlib")
        p.small("BROWSER", "Model browser", "list"); p.small("COMMANDLINE", "Command window", "text"); p.small("AUTOHIDE", "Auto-hide all", "props")
        self.engine.register("DSTYLE", misc.T(lambda c: self.dimstyle_manager()), [], "Dimension Style Manager")
        self.refresh_views()

        # ---------------------------------------------------------------- Output / Manage
        t = rb.add_tab("Output")
        p = t.add_panel("Plot")
        p.big("PLOT", "Plot PDF", "plot"); p.big("PNGOUT", "Image PNG", "png")
        p = t.add_panel("Exchange")
        p.big("EXPORT", "Export DXF / STL / OBJ", "export"); p.big("IMPORT", "Import", "import")
        t = rb.add_tab("Manage")
        p = t.add_panel("Application")
        p.big("OPTIONS", "Options", "options"); p.big("UPDATE", "Update", "update"); p.big("GUIDE", "Panduan", "guide"); p.big("HELP", "Commands", "help"); p.big("ABOUT", "About", "about")
        # ---------------------------------------------------------------- contextual: Array
        t = rb.add_tab("Array")
        self.arr_w = {}
        from PySide6.QtWidgets import QLineEdit, QGridLayout, QCheckBox
        p = t.add_panel("Type"); self.arr_type = QLabel("Rectangular"); self.arr_type.setAlignment(Qt.AlignCenter); self.arr_type.setMinimumWidth(96)
        self.arr_type.setStyleSheet("font-weight:700;"); p.widget(self.arr_type)
        def group(title, rows):
            pn = t.add_panel(title); w = QWidget(); g = QGridLayout(w); g.setContentsMargins(4, 0, 4, 0); g.setVerticalSpacing(1)
            for i, (key, lab) in enumerate(rows):
                l = QLabel(lab); e = QLineEdit(); e.setFixedWidth(96); e.setFixedHeight(22)
                e.editingFinished.connect(lambda k=key, e=e: self._array_edit(k, e.text()))
                g.addWidget(l, i, 0); g.addWidget(e, i, 1); self.arr_w[key] = (l, e)
            pn.widget(w); return pn
        self.arr_p1 = group("Columns", [("n1", "Columns:"), ("s1", "Spacing:"), ("t1", "Total:")])
        group("Rows", [("n2", "Rows:"), ("s2", "Spacing:"), ("t2", "Total:")])
        group("Levels", [("n3", "Levels:"), ("s3", "Spacing:"), ("t3", "Total:")])
        p = t.add_panel("Properties")
        p.big("ARRAYBASE", "Base Point", "id", "Move the array base point")
        w = QWidget(); vb = QVBoxLayout(w); vb.setContentsMargins(4, 0, 4, 0)
        self.arr_rot = QCheckBox("Rotate Items"); self.arr_ccw = QCheckBox("Direction CCW"); vb.addWidget(self.arr_rot); vb.addWidget(self.arr_ccw)
        self.arr_rot.clicked.connect(lambda v: self._array_edit("rotate", v)); self.arr_ccw.clicked.connect(lambda v: self._array_edit("ccw", v)); p.widget(w)
        p = t.add_panel("Options")
        p.big("ARRAYSOURCE", "Edit Source", "bedit", "Edit the source objects of the array"); p.big("ARRAYREPLACE", "Replace Items", "copy", "Replace the source objects of the array with other objects")
        p.big("ARRAYRESET", "Reset Array", "undo"); p.big("EXPLODE", "Explode", "explode")
        p = t.add_panel("Close"); p.big("ARRAYCLOSE", "Close Array", "apply")
        self.engine.register("ARRAYCLOSE", misc.T(lambda c: self.clear_selection()), [], "Close the Array tab")
        self.engine.register("ARRAYRESET", misc.T(lambda c: self._array_reset()), [], "Reset the selected array to 4 x 3 / 6 items")
        self.engine.register("ARRAYREPLACE", self._cmd_array_replace, [], "Replace the source objects of the selected array")
        self.engine.register("ARRAYBASE", self._cmd_array_base, [], "Move the base point of the selected array")
        self.engine.register("ARRAYSOURCE", misc.T(lambda c: self._array_source()), [], "Edit the source objects of the selected array")
        # ---------------------------------------------------------------- contextual: Block Editor
        t = rb.add_tab("Block Editor")
        p = t.add_panel("Block"); self.be_name = QLabel(""); self.be_name.setStyleSheet("font-weight:700;"); self.be_name.setMinimumWidth(120)
        self.be_name.setAlignment(Qt.AlignCenter); p.widget(self.be_name)
        p.big("BSAVE", "Save Block", "save"); p.big("BCLOSE", "Close Editor", "apply")
        p = t.add_panel("Attributes"); p.big("ATTDEF", "Define Attribute", "attdef")
        p = t.add_panel("Visibility")
        self.be_state = QComboBox(); self.be_state.setMinimumWidth(130); self.be_state.activated.connect(self._be_state_pick); p.widget(self.be_state)
        p.big("BVSTATE", "States", "layers", "New / rename / delete visibility states"); p.small("BVHIDE", "Hide in this state", "erase")
        p.small("BVSHOW", "Show hidden", "props")
        p = t.add_panel("Parameters")
        p.small("BPPOINT", "Point", "point"); p.small("BPLINEAR", "Linear", "dimlin"); p.small("BPPOLAR", "Polar", "dimang")
        p.small("BPXY", "XY", "rect"); p.small("BPROTATION", "Rotation", "rotate"); p.small("BPFLIP", "Flip", "mirror")
        p = t.add_panel("Actions")
        p.small("BAMOVE", "Move", "move"); p.small("BASTRETCH", "Stretch", "stretch"); p.small("BASCALE", "Scale", "scale")
        p.small("BAROTATE", "Rotate", "rotate"); p.small("BAARRAY", "Array", "array"); p.small("BAFLIP", "Flip", "mirror")
        p = t.add_panel("Parameter Sets")
        p.big("BSLINEARSTRETCH", "Linear Stretch", "stretch", "Linear parameter + stretch action")
        p.small("BSLINEARMOVE", "Linear Move", "move"); p.small("BSLINEARARRAY", "Linear Array", "array"); p.small("BSXYSTRETCH", "XY Stretch", "rect")
        p.small("BSROTATIONSET", "Rotation Set", "rotate"); p.small("BSFLIPSET", "Flip Set", "mirror"); p.small("BSPOLARSTRETCH", "Polar Stretch", "dimang")
        p = t.add_panel("Manage")
        p.big("BPARAMLIST", "Parameters & actions", "list", "List, edit value sets and delete parameters / actions")
        t = rb.add_tab("Edit Reference")
        p = t.add_panel("Edit Reference")
        p.big("REFSAVE", "Save Changes", "save", "Save the edits to the block definition: every reference is updated")
        p.big("REFDISCARD", "Discard Changes", "erase", "Close Edit Block In-place without changing the block")
        p.big("REFSET", "Add / Remove", "refedit", "Add objects of the drawing to the block, or take objects out of it")
        rb.set_tab_visible("Array", False); rb.set_tab_visible("Block Editor", False); rb.set_tab_visible("Edit Reference", False)
        self.engine.register("BROWSER", misc.T(lambda c: self.pal.reveal(self.browser_dock)), [], "Model browser")
        self.engine.register("IMGSNAP", misc.T(lambda c: self._toggle_imgsnap()), [], "Toggle snap to image lines")

    def _build_docks(self):
        self.props = PropertiesPanel(self); self.props.changed.connect(self._props_changed)
        self.layers = LayersPanel(self); self.layers.changed.connect(lambda: (self.view.invalidate(), self._layer_combo_refresh()))
        self.symbols = SymbolPanel(self)
        self.browser = BrowserPanel(self)
        self.pal = PaletteManager(self)
        self.props_dock = self.pal.add("Properties", self.props, Qt.LeftDockWidgetArea)
        self.layers_dock = self.pal.add("Layers", self.layers, Qt.RightDockWidgetArea)
        self.sym_dock = self.pal.add("Symbol library", self.symbols, Qt.RightDockWidgetArea)
        self.browser_dock = self.pal.add("Model browser", self.browser, Qt.RightDockWidgetArea)
        self.cmd_dock = self.pal.add("Command", self.cmdline, Qt.BottomDockWidgetArea, can_autohide=False)
        self.cmd_dock.setAllowedAreas(Qt.BottomDockWidgetArea | Qt.TopDockWidgetArea)
        self.tabifyDockWidget(self.layers_dock, self.sym_dock); self.tabifyDockWidget(self.sym_dock, self.browser_dock)
        self.layers_dock.raise_()
        self.props_dock.setMinimumWidth(180); self.layers_dock.setMinimumWidth(200); self.sym_dock.setMinimumWidth(200)
        self.resizeDocks([self.props_dock, self.layers_dock], [270, 330], Qt.Horizontal)
        self.resizeDocks([self.cmd_dock], [self.cmdline.height_for_lines(self.view.opt.get("cmd_lines", 3))], Qt.Vertical)
        self._default_layout = self.saveState(3)
        self.layers.refresh(); self.props.refresh([]); self._layer_combo_refresh()
        self.engine.register("DSETTINGS", misc.T(lambda c: self.drafting_settings()), ["DS", "SE", "OS", "DDOSNAP", "OSNAPSETTINGS"], "Drafting Settings: snap & grid, polar tracking, object snap, selection")
        self.engine.register("COMMANDLINE", misc.T(lambda c: self.pal.toggle(self.cmd_dock)), ["CLI"], "Show / hide the command window (Ctrl+9)")
        self.engine.register("TEXTSCR", misc.T(lambda c: self.show_text_window()), [], "Command history text window (F2)")
        self.engine.register("PALETTERESET", misc.T(lambda c: self.reset_layout()), [], "Reset palettes and window layout")
        self.engine.register("AUTOHIDE", misc.T(lambda c: self.autohide_all()), [], "Auto-hide / pin all palettes")

    # ------------------------------------------------------------------ layout persistence
    def _restore_layout(self):
        if os.environ.get("CADPRO_NO_RESTORE") or os.environ.get("CADPRO_SELFTEST"):
            return
        try:
            st = self.settings.value("layout/state")
            if st is not None:
                self.restoreState(st, 3)
            self.pal.restore(__import__("json").loads(self.settings.value("layout/autohide_json", "[]") or "[]"))
        except Exception:
            pass

    def _save_layout(self):
        if os.environ.get("CADPRO_NO_RESTORE") or os.environ.get("CADPRO_SELFTEST"):
            return
        try:
            ah = self.pal.state()
            for d in list(self.pal.docks):          # saveState must not record the temporary fly-out windows
                if d.autohide:
                    d.hide()
            self.settings.setValue("layout/autohide_json", __import__("json").dumps(ah))
            self.settings.setValue("layout/state", self.saveState(3))
        except Exception:
            pass

    def reset_layout(self):
        self.pal.unhide_all()
        for d in self.pal.docks:
            d.setFloating(False); d.show()
        self.restoreState(self._default_layout, 3)
        self.ribbon.setVisible(True)
        self.resizeDocks([self.props_dock, self.layers_dock], [270, 330], Qt.Horizontal)
        self.resizeDocks([self.cmd_dock], [self.cmdline.height_for_lines(self.view.opt.get("cmd_lines", 3))], Qt.Vertical)
        self.message("Palettes and window layout reset")

    def autohide_all(self):
        side = [d for d in self.pal.docks if d.can_autohide]
        if all(d.autohide for d in side):
            self.pal.unhide_all(); self.message("Palettes pinned (auto-hide off)")
        else:
            for d in side:
                if d.isVisible() or d.autohide:
                    self.pal.set_autohide(d)
            self.message("Palettes auto-hidden: move the cursor over a tab on the window edge to open one")

    def show_text_window(self):
        d = getattr(self, "_textwin", None)
        if d is not None and d.isVisible():
            d.close(); return
        from PySide6.QtWidgets import QDialog, QPlainTextEdit
        d = QDialog(self); d.setWindowTitle("ALIEF CAD PRO Text Window - command history"); d.resize(900, 560)
        lay = QVBoxLayout(d); t = QPlainTextEdit(); t.setReadOnly(True); t.setObjectName("cmdhist"); t.setFont(self.cmdline.hist.font())
        t.setPlainText(self.cmdline.hist.toPlainText()); lay.addWidget(t); t.verticalScrollBar().setValue(t.verticalScrollBar().maximum())
        d.setModal(False); d.show(); self._textwin = d

    def _build_status(self):
        sb = QStatusBar(); self.setStatusBar(sb)
        self.coord = QLabel("0.000, 0.000, 0.000"); self.coord.setMinimumWidth(240); sb.addWidget(self.coord)
        self.toggles = {}
        for key, attr, tip in (("GRID", "show_grid", "Grid (F7) - right-click for Drafting Settings"), ("SNAP", "snap_on", "Snap (F9) - right-click for the snap spacing"),
                               ("ORTHO", "ortho", "F8"), ("POLAR", "polar_on", "Polar tracking (F10) - right-click for the angle"),
                               ("OSNAP", "osnap_on", "F3"), ("OTRACK", "otrack_on", "Object snap tracking (F11): pause on a snap point to acquire it, then move along the dotted path"),
                               ("DYN", "dyn", "F12"), ("LWT", "lwt", "Lineweight"),
                               ("SC", "sel_cycling", "Selection cycling (Ctrl+W): choose between overlapping objects")):
            b = QToolButton(); b.setObjectName("status"); b.setText(key); b.setCheckable(True); b.setChecked(getattr(self.view, attr)); b.setToolTip(tip)
            b.toggled.connect(lambda v, a=attr: self._set_view_flag(a, v))
            b.setContextMenuPolicy(Qt.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda pos, b=b, k=key: self._toggle_menu(b.mapToGlobal(pos), k))
            if key == "OSNAP":
                b.setToolTip("Object snap (F3) - right-click to choose the snap modes")
            sb.addWidget(b); self.toggles[attr] = b
        osm = QToolButton(); osm.setObjectName("status"); osm.setText("▾"); osm.setPopupMode(QToolButton.InstantPopup); osm.setToolTip("Object snap modes")
        menu = QMenu(osm); menu.aboutToShow.connect(lambda m=menu: self._fill_osnap_menu(m))
        osm.setMenu(menu); sb.addWidget(osm)
        self.style_lbl = QLabel(); sb.addPermanentWidget(self.style_lbl)
        sb.addPermanentWidget(QLabel("Scale"))
        self.scale_combo = QComboBox(); self.scale_combo.setEditable(True); self.scale_combo.setMinimumWidth(92)
        self.scale_combo.addItems(["AUTO"] + [f"1:{s:g}" for s in misc.STD_SCALES]); self.scale_combo.setCurrentText(f"1:{E.Entity.anno_scale:g}")
        self.scale_combo.activated.connect(self._scale_pick); self.scale_combo.lineEdit().returnPressed.connect(self._scale_pick)
        sb.addPermanentWidget(self.scale_combo)
        self.upd_lbl = QToolButton(); self.upd_lbl.setObjectName("status"); self.upd_lbl.setText(f"v{self.version}"); self.upd_lbl.clicked.connect(lambda: self.run_command("UPDATE"))
        sb.addPermanentWidget(self.upd_lbl)
        self.refresh_status()

    def _shortcuts(self):
        for key, cmd in (("Ctrl+Z", "UNDO"), ("Ctrl+Y", "REDO"), ("Ctrl+S", "SAVE"), ("Ctrl+O", "OPEN"), ("Ctrl+N", "NEW"), ("Ctrl+P", "PLOT"),
                         ("Ctrl+A", "SELECTALL"), ("F3", "OSNAP"), ("F7", "GRID"), ("F8", "ORTHO"), ("F9", "SNAP"), ("F10", "POLAR"), ("F11", "OTRACK"), ("F12", "DYNMODE"), ("F1", "HELP"), ("Ctrl+W", "SELECTIONCYCLING"),
                         ("Ctrl+Shift+S", "SAVEAS"), ("Ctrl+1", "PROPERTIES")):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut); sc.activated.connect(lambda c=cmd: self.run_command(c))
        sc = QShortcut(QKeySequence("Ctrl+0"), self); sc.activated.connect(self._clean_screen)
        for key, cmd, txt in (("Ctrl+C", "COPYCLIP", "copy"), ("Ctrl+Shift+C", "COPYBASE", None), ("Ctrl+X", "CUTCLIP", "cut"),
                              ("Ctrl+V", "PASTECLIP", "paste"), ("Ctrl+Shift+V", "PASTEBLOCK", None)):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(lambda c=cmd, t=txt: self._clip_key(c, t))
        for key, fn in (("Ctrl+Tab", lambda: self.tab_next(1)), ("Ctrl+Shift+Tab", lambda: self.tab_next(-1)),
                        ("Ctrl+F4", lambda: self._tab_close(self.doc_tabs.currentIndex()))):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut); sc.activated.connect(fn)
        self.engine.register("CLOSE", misc.T(lambda c: self.after_command(lambda: self._tab_close(self.doc_tabs.currentIndex()))), [], "Close the current drawing tab")
        self.engine.register("CLOSEALL", misc.T(lambda c: self.after_command(self._close_all)), [], "Close all drawing tabs")
        for key, cmd in (("Ctrl+9", "COMMANDLINE"), ("F2", "TEXTSCR"), ("Ctrl+2", "SYMLIB")):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut); sc.activated.connect(lambda c=cmd: self.run_command(c))

    # =============================================================================== theme
    def apply_theme(self):
        th = LIGHT if self.view.light else DARK
        QApplication.instance().setStyleSheet(stylesheet(th))

    def toggle_theme(self):
        self.view.light = not self.view.light; set_light(self.view.light)
        self.view.opt["theme"] = "Light" if self.view.light else "Dark"; OPT.save(self.settings, self.view.opt)
        self.apply_theme(); self.view.invalidate()
        self.message("Theme: " + ("light" if self.view.light else "dark") + " (ribbon icons refresh after restart)")

    def _clean_screen(self):
        vis = not self.ribbon.isVisible()
        self.ribbon.setVisible(vis)
        if vis:
            for d in getattr(self, "_clean_hidden", []):
                d.show()
        else:
            self._clean_hidden = [d for d in self.pal.docks if d.isVisible() and not d.autohide and d is not self.cmd_dock]
            for d in self._clean_hidden:
                d.hide()

    # =============================================================================== controller API (viewport / engine)
    @property
    def req(self):
        return self.engine.req

    def typed_text(self):
        return self.cmdline.edit.text()

    def message(self, s, echo=False):
        self.cmdline.log(s)

    def on_request(self, req):
        self.view.preview = []; self.view.snap_hit = None; self.view.snap_override = None; self._m2p = None
        if req is None:
            for vw in getattr(self, "views", [self.view]):
                vw.acquired = []; vw.otracks = []
            self.cmdline.set_prompt("Command"); self.cmdline.string_mode = False
            self.view.highlight_extra = []
            if QApplication.focusWidget() is self.cmdline.edit and not self.cmdline.edit.text():
                self.view.setFocus()               # command finished: keys (Space = repeat, Delete ...) go to the drawing again
        else:
            self.cmdline.set_prompt(req.prompt, req.options if req.kind != "string" else ()); self.cmdline.string_mode = req.kind == "string"
            if req.kind == "select" and req.picked:
                self.set_selection([e.id for e in req.picked])
            self.view.refresh_preview()
        self.view.update()

    def run_command(self, name, *args):
        if isinstance(name, str) and name.upper() in ("SYMBOL",) and not args and self.engine.busy() is False and False:
            pass
        if name.upper() == "SYMBOL" and not args:
            self.show_symbol_library(); return
        if name.upper() == "FITTING" and args and args[0] is None:
            return
        if name.upper() in ("UNDO", "U") and not args and self.engine.busy():
            # Ctrl+Z / U while a command runs: the command's own Undo option (last segment, last vertex, last point ...)
            r = self.engine.req
            opt = next((o for o in (r.options or []) if o.replace(" ", "").upper() == "UNDO"), None) if r is not None else None
            if opt is not None:
                self.view.setFocus(); self.engine.feed_text(opt); return
            self.message("UNDO is not available in this step - press Esc to end the command first"); return
        self.view.setFocus()
        if self.engine.run(name, *args):
            r = self.engine.resolve(name)
            if r and not getattr(self.engine.cmds.get(r), "transparent", False):
                self.cmdline.note_command(r)

    def _cmd_text(self, t):
        v = self.view
        if v.hot_grip is not None and not self.engine.busy():      # a value typed while a grip is being dragged
            if not t.strip():
                return
            from .viewport import grip_typed_point
            hot = v.hot_grip; e = self.doc.ents.get(hot[1])
            base = v.grips[hot[0]][0] if hot[0] < len(v.grips) else v.mouse_world
            pt = grip_typed_point(e, hot[2], t, v.mouse_world, base, v.ucs, hot[3] if len(hot) > 3 else None) if e is not None else None
            if pt is None:
                self.message(f"Grip: cannot use '{t}' - type a length / radius, x,y or @dx,dy"); return
            self.grip_finish(hot, pt); v.hot_grip = None; v.preview = []; v.update()
            self.message(f"Grip: {t}"); return
        if t.strip().startswith("=") or t.strip().lower().startswith("'cal"):     # geometry calculator inside any prompt
            from ..cmd.v16 import cal_inline
            try:
                val = cal_inline(self, t)
            except Exception as ex:
                self.message(f"{t}  >> Error: {ex}"); return
            if val is not None:
                self.message(f"{t.strip()} = {val}")
                if not self.engine.busy():
                    return
                t = val
        if t.strip().lower() in ("m2p", "mtp", "_m2p", "_mtp") and self.engine.busy() and self.req is not None and self.req.kind in ("point", "distance", "angle", "corner"):
            self.start_m2p(); return
        ov = {"END": "end", "ENDP": "end", "MID": "mid", "CEN": "cen", "GCE": "gcen", "GCEN": "gcen", "QUA": "quad", "QUAD": "quad",
              "INT": "int", "PER": "perp", "PERP": "perp", "TAN": "tan", "NEA": "near", "NEAR": "near", "NOD": "node", "NODE": "node",
              "INS": "ins"}.get(t.strip().upper().lstrip("_"))
        if ov and self.engine.busy() and self.req is not None and self.req.kind in ("point", "distance", "angle", "corner") \
                and not (self.req.options and any(o.upper().startswith(t.strip().upper()) for o in self.req.options)):
            self._snap_override(ov); return                 # typed object snap override (END, MID, CEN, GCEN ...) for the next point
        self.message(f"{self.cmdline.prompt.text()} {t}")
        if not self.engine.busy() and t.strip():
            r = self.engine.resolve(t.strip().split()[0])
            if r and not getattr(self.engine.cmds.get(r), "transparent", False):
                self.cmdline.note_command(r)
        self.engine.feed_text(t)
        self.view.setFocus() if not self.engine.busy() else None

    def feed_point(self, p):
        m = getattr(self, "_m2p", None)
        if m is not None:                                  # M2P / MTP: midpoint between two picked points
            m.append(np.asarray(p, float).copy())
            if len(m) < 2:
                self.message("Second point of mid:"); self.view.update()
                return
            self._m2p = None
            p = (m[0] + m[1]) / 2
            self.message(f"Mid between 2 points = {p[0]:.4f},{p[1]:.4f}" + (f",{p[2]:.4f}" if abs(p[2]) > 1e-9 else ""))
        self.engine.feed_point(p)

    def start_m2p(self):
        r = self.req
        if r is None or r.kind not in ("point", "distance", "angle", "corner"):
            self.message("M2P (mid between 2 points) is used while a command asks for a point"); return
        self._m2p = []
        self.message("_m2p First point of mid:")

    def feed_entity(self, e, p):
        self.engine.feed_entity(e, p)

    def escape(self):
        self.zoom_window_pending = False
        if getattr(self.view, "drag", None) and self.view.drag[0] == "window":
            self.view.drag = None; self.view.update(); return
        if self.view.click_win is not None:
            self.view.click_win = None; self.view.update(); return
        if self.view.hot_grip is not None:
            self.view.hot_grip = None; self.view.hot_multi = []; self.view.preview = []; self.view.update(); return
        if getattr(self, "_m2p", None) is not None:
            self._m2p = None; self.view.snap_override = None; self.message("M2P cancelled"); self.view.update(); return
        if self.view.hot_set:
            self.view.hot_set = set(); self.view.update(); return
        if self.engine.busy():
            self.engine.cancel()
        else:
            self.clear_selection()

    def pick_entity(self, e, shift):
        r = self.req
        if r is not None and r.kind == "select":
            if shift:
                r.picked = [x for x in r.picked if x is not e]
            elif e not in r.picked:
                r.picked.append(e)
            self.set_selection([x.id for x in r.picked]); return
        if shift:
            self.view.selection = [i for i in self.view.selection if i != e.id]
        elif e.id not in self.view.selection:
            self.view.selection.append(e.id)
        self._sel_changed()

    def pick_window(self, ents, shift, rect):
        self.last_window = rect
        r = self.req
        ww = self.view.window_world(rect[0], rect[1]); crossing = rect[1].x() < rect[0].x()
        self.last_window_w = (ww, crossing)
        if r is not None and r.kind == "entity":
            if getattr(r, "window", False):                 # TRIM / EXTEND: every object crossed by the window
                hits = self.view.window_hits(rect[0], rect[1], r.filter)
                if hits:
                    self.engine._step(("window", hits))
            return
        if r is not None and r.kind == "select" and ww is not None:
            r.__dict__.setdefault("windows", []).append((ww, crossing))
        elif r is None and ww is not None:
            self.idle_windows = getattr(self, "idle_windows", []) + [(ww, crossing)]
        if r is not None and r.kind == "select":
            if r.filter:
                ents = [e for e in ents if r.filter(e)]
            if shift:
                ids = {e.id for e in ents}; r.picked = [x for x in r.picked if x.id not in ids]
            else:
                for e in ents:
                    if e not in r.picked:
                        r.picked.append(e)
            self.set_selection([x.id for x in r.picked]); return
        ids = [e.id for e in ents]
        if shift:
            self.view.selection = [i for i in self.view.selection if i not in ids]
        else:
            self.view.selection = list(dict.fromkeys(self.view.selection + ids))
        self._sel_changed()

    def set_selection(self, ids):
        self.view.selection = list(ids); self._sel_changed()

    def clear_selection(self, silent=False):
        self.view.selection = []; self.idle_windows = []
        if not silent:
            self._sel_changed()
        else:
            self.view.update()

    def selected_ents(self):
        return [self.doc.ents[i] for i in self.view.selection if i in self.doc.ents]

    def _sel_changed(self):
        self.props.refresh(self.selected_ents()); self.view.update()
        self._array_tab()

    def after_command(self, fn):
        QTimer.singleShot(0, fn)

    # ------------------------------------------------------------------ associative array (contextual ribbon tab)
    def _sel_array(self):
        s = self.selected_ents()
        return s[0] if len(s) == 1 and s[0].kind == "array" else None

    def _array_tab(self):
        a = self._sel_array()
        self.ribbon.set_tab_visible("Array", a is not None)
        if a is None:
            return
        polar = a.atype == "polar"
        self.arr_type.setText("Polar" if polar else "Rectangular")
        W = self.arr_w
        for k, t in (("n1", "Items:" if polar else "Columns:"), ("s1", "Angle:" if polar else "Spacing:"), ("t1", "Fill:" if polar else "Total:")):
            W[k][0].setText(t)
        f = lambda v: f"{v:.4f}".rstrip("0").rstrip(".")
        if polar:
            n = max(1, a.items); full = abs(abs(a.fill) - 360) < 1e-9
            vals = {"n1": str(a.items), "s1": f(a.fill / (n if full else max(1, n - 1))), "t1": f(a.fill)}
        else:
            vals = {"n1": str(a.cols), "s1": f(a.dx), "t1": f(a.dx * max(0, a.cols - 1))}
        vals.update(n2=str(a.rows), s2=f(a.dy), t2=f(a.dy * max(0, a.rows - 1)), n3=str(a.levels), s3=f(a.dz), t3=f(a.dz * max(0, a.levels - 1)))
        for k, v in vals.items():
            W[k][1].blockSignals(True); W[k][1].setText(v); W[k][1].blockSignals(False)
        self.arr_rot.setVisible(polar); self.arr_ccw.setVisible(polar); self.arr_rot.setChecked(a.rotate); self.arr_ccw.setChecked(a.ccw)

    def _array_edit(self, key, text):
        a = self._sel_array()
        if a is None:
            return
        polar = a.atype == "polar"
        try:
            v = bool(text) if key in ("rotate", "ccw") else float(str(text).replace(",", "."))
        except ValueError:
            self._array_tab(); return
        old = a.to_dict()
        I = lambda x: max(1, int(round(x)))
        if key == "rotate":
            a.rotate = v
        elif key == "ccw":
            a.ccw = v
        elif key == "n1":
            if polar:
                a.items = I(v)
            else:
                a.cols = I(v)
        elif key == "s1":
            if polar:
                n = max(1, a.items); a.fill = max(-360.0, min(360.0, v * (n - 1 if abs(v * n) < 360 - 1e-9 else n)))
            else:
                a.dx = v
        elif key == "t1":
            if polar:
                a.fill = max(-360.0, min(360.0, v))
            elif a.cols > 1:
                a.dx = v / (a.cols - 1)
        elif key == "n2":
            a.rows = I(v)
        elif key == "s2":
            a.dy = v
        elif key == "t2" and a.rows > 1:
            a.dy = v / (a.rows - 1)
        elif key == "n3":
            a.levels = I(v)
        elif key == "s3":
            a.dz = v
        elif key == "t3" and a.levels > 1:
            a.dz = v / (a.levels - 1)
        new = a.to_dict()
        if new == old:
            return
        if a.count() * max(1, len(a.src)) > 20000:
            for k2 in a.PAR:
                setattr(a, k2, old[k2])
            self.message("Array too large (more than 20000 objects) - value ignored"); self._array_tab(); return
        for k2 in a.PAR:                       # record the change for undo
            setattr(a, k2, old[k2])
        self.doc.begin("array"); self.doc.modify(a)
        for k2 in a.PAR:
            setattr(a, k2, new[k2])
        a.touch(); self.doc.end()
        self._array_tab(); self.view.setFocus()

    def _array_reset(self):
        a = self._sel_array()
        if a is None:
            return
        self.doc.begin("array"); self.doc.modify(a)
        a.cols, a.rows, a.levels, a.items, a.fill, a.rotate, a.ccw = 4, 3, 1, 6, 360.0, True, True
        if a.atype == "polar":
            a.rows = 1
        a.touch(); self.doc.end(); self._array_tab()

    def _cmd_array_base(self, c):
        a = self._sel_array()
        if a is None:
            c.msg("Select one array first"); return
        p = yield c.pt("Specify new base point of the array", base=a.base)
        if p is not None:
            from ..core.geom import m_translate
            c.doc.modify(a); d = p - a.base
            if a.atype == "polar":
                a.transform(m_translate(d)); a.center = a.center - d
            else:
                a.transform(m_translate(d))
            a.touch()
            self.after_command(lambda: (self.set_selection([a.id])))

    def _cmd_array_replace(self, c):
        a = self._sel_array()
        if a is None:
            c.msg("Select one array first"); return
        self.clear_selection()
        ents = yield c.sel("ARRAYREPLACE  Select replacement objects", filt=lambda e: e is not a and e.kind != "array")
        if not ents:
            return
        p = yield c.pt("Specify base point of the replacement objects")
        if p is None:
            return
        from ..core.geom import m_translate
        src0 = a.matrices()[0] if hasattr(a, "matrices") else None
        org = np.asarray(a.base, float)
        new = []
        for e in ents:
            k = e.copy(); k.transform(m_translate(org - p)); new.append(k)
        c.doc.modify(a); a.src = new; a.touch()
        for e in ents:
            c.doc.remove(e)
        self.after_command(lambda: self.set_selection([a.id]))
        c.msg(f"{len(new)} object(s) now form the array item")

    def _array_source(self):
        a = self._sel_array()
        if a is None:
            return
        name = f"*ARRAY{a.id}"
        self.doc.blocks[name] = E.Block(name, (0, 0, 0), [e.copy() for e in a.src])
        self.bedit_open(name, array=a)

    # ------------------------------------------------------------------ blocks: attributes, dynamic options, editor
    def dialog_attdef(self):
        d = DL.AttDefDialog(self)
        return d.values() if d.exec() else None

    def dialog_blockprops(self, blk, ins, title):
        d = DL.BlockPropsDialog(self, blk, ins, title)
        return d.values() if d.exec() else None

    def edit_insert(self, ins):
        """Double-click on a block: attributes -> attribute editor (with a Block Editor button), otherwise straight into the Block Editor."""
        blk = self.doc.blocks.get(ins.name)
        if blk is None:
            return
        if not blk.attdefs():
            self.clear_selection(silent=True); self.bedit_open(ins.name); return
        d = DL.BlockPropsDialog(self, blk, ins, f"Edit block {ins.name}")
        if d.exec():
            vals = d.values()
            self.doc.begin("attedit"); self.doc.modify(ins); ins.attribs, ins.dyn = vals; ins.touch(); self.doc.end()
        elif d.bedit_requested:
            self.clear_selection(silent=True); self.bedit_open(ins.name)

    def choose_many(self, title, label, items):
        s, ok = QInputDialog.getItem(self, title, label + "  (pick one, or <all>)", ["<all>"] + list(items), 0, False)
        if not ok:
            return []
        return None if s == "<all>" else [s]

    def refedit_ui(self, on):
        """Banner + contextual buttons while a block is edited in place."""
        r = getattr(self.doc, "refedit", None)
        self.view.overlay_msg = (f"EDIT BLOCK IN-PLACE:  {r['name']}   -   right click > Save Reference Edits / Discard   (REFCLOSE)"
                                 if on and r is not None else "")
        try:
            self.ribbon.set_tab_visible("Edit Reference", bool(on))
        except Exception:
            pass
        self.view.invalidate(); self.view.update(); self._title()

    def bedit_open(self, name, array=None):
        if self.bedit:
            self.message("The Block Editor is already open - save / close it first"); return
        blk = self.doc.blocks.get(name)
        if blk is None:
            return
        if self.engine.busy():
            self.engine.cancel()
        main = self.doc
        d = Document(); d.layers = main.layers; d.blocks = main.blocks; d.settings = dict(main.settings); d.cur_layer = "0"
        top = max([int((e.xd or {}).get("bk", 0)) for e in blk.ents] + [0])
        for e in blk.ents:
            k = e.copy(); k.xd = dict(e.xd) if e.xd else {}
            if "bk" not in k.xd:
                top += 1; k.xd["bk"] = top                 # tag: dynamic actions point at objects through it
            d.add_keep(k)
        d.undo_stack.clear(); d.modified = False
        vis = blk.param("visibility")
        self.bedit = {"name": name, "main": main, "params": [dict(p, states=list(p["states"])) if p["type"] == "visibility" else dict(p) for p in blk.params],
                      "actions": [dict(a, tags=list(a.get("tags") or [])) for a in getattr(blk, "actions", [])],
                      "state": vis[0]["states"][0] if vis and vis[0].get("states") else None, "array": array,
                      "view": (self.view.cam.target.copy(), self.view.cam.R.copy(), self.view.cam.h), "scale": E.Entity.anno_scale}
        be = self.bedit
        base_visible = d.visible_ents
        def visible():
            st = be.get("state")
            return [e for e in base_visible() if st is None or (e.xd or {}).get("vis") is None or st in e.xd["vis"]]
        d.visible_ents = visible
        # parameters, actions and the visibility state are part of undo / redo inside the Block Editor
        def st_get():
            return {"params": be["params"], "actions": be.get("actions", []), "state": be.get("state")}
        def st_set(st):
            import copy
            be["params"][:] = copy.deepcopy(st["params"]); be.setdefault("actions", [])[:] = copy.deepcopy(st["actions"])
            be["state"] = st.get("state")
            QTimer.singleShot(0, self.bedit_refresh)
        d.state_get = st_get; d.state_set = st_set
        self._set_doc(d); E.Entity.anno_scale = be["scale"]
        self.be_name.setText(name if array is None else "Array source")
        self.ribbon.set_tab_visible("Block Editor", True); self.bedit_refresh()
        self._authoring_palette(True)
        self.view.set_view("top"); self.view.zoom_extents()
        self.message(f"BLOCK EDITOR - {name}: draw / modify as usual, then Save Block and Close Editor. The block base point is 0,0.")

    def bedit_refresh(self):
        be = self.bedit
        if not be:
            return
        vis = [p for p in be["params"] if p["type"] == "visibility"]
        self.be_state.blockSignals(True); self.be_state.clear()
        if vis:
            self.be_state.addItems(vis[0]["states"]); self.be_state.setCurrentText(be.get("state") or "")
        else:
            self.be_state.addItem("(no states)")
        self.be_state.blockSignals(False)
        self.view.be_params = be["params"]; self.view.be_actions = be.get("actions", [])
        self.doc.rev += 1; self.view.invalidate(); self._title()

    def _be_state_pick(self, i):
        if self.bedit and self.be_state.itemText(i) and not self.be_state.itemText(i).startswith("("):
            self.bedit["state"] = self.be_state.itemText(i); self.clear_selection(); self.bedit_refresh()
            if self.doc.undo_stack:                       # undo must not jump back to another visibility state
                for t in self.doc.undo_stack:
                    for op in t["ops"]:
                        if op[0] == "state":
                            op[1]["state"] = op[2]["state"] = self.bedit["state"]

    def bedit_list(self):
        be = self.bedit
        if not be:
            self.message("Open the Block Editor first (BEDIT)"); return
        from .dialogs15 import BlockParamsDialog
        own = self.doc._tx is None
        if own:
            self.doc.begin("parameters")                   # deleting parameters in the list can be undone
        d = BlockParamsDialog(self, be)
        d.exec()
        if own and not d.changed:
            self.doc.end(quiet=True)
        if d.changed:
            if not [p for p in be["params"] if p["type"] == "visibility"]:
                be["state"] = None
                for e in self.doc.ents.values():
                    if e.xd and "vis" in e.xd:
                        e.xd = {k: v for k, v in e.xd.items() if k != "vis"}
            self.doc.modified = True
            if own:
                self.doc.end()
            self.bedit_refresh()

    def _authoring_palette(self, show):
        """Block Authoring Palettes (Parameters / Actions / Parameter Sets) - shown while the Block Editor is open."""
        if not show:
            if getattr(self, "_auth_dock", None) is not None:
                self._auth_dock.hide()
            return
        if getattr(self, "_auth_dock", None) is None:
            from .dialogs15 import AuthoringPalette
            self._auth_pal = AuthoringPalette(self)
            self._auth_dock = QDockWidget("Block Authoring Palettes", self); self._auth_dock.setObjectName("auth_dock")
            self._auth_dock.setWidget(self._auth_pal); self.addDockWidget(Qt.LeftDockWidgetArea, self._auth_dock)
        self._auth_dock.show(); self._auth_dock.raise_()

    def bedit_save(self):
        be = self.bedit
        if not be:
            self.message("The Block Editor is not open"); return False
        if self.engine.busy():
            self.engine.cancel()
        main = be["main"]; ents = []
        for e in self.doc.ents.values():
            k = e.copy(); k.xd = dict(e.xd) if e.xd else None; ents.append(k)
        if be.get("array") is not None:
            a = be["array"]; main.begin("array source"); main.modify(a); a.src = ents; a.touch(); main.end()
        else:
            blk = main.blocks[be["name"]]; blk.ents = ents; blk.params = [dict(p) for p in be["params"]]
            alive = {int((e.xd or {}).get("bk", -1)) for e in ents}
            blk.actions = [dict(a, tags=[t for t in a.get("tags", []) if t in alive]) for a in be.get("actions", [])
                           if a.get("all") or any(t in alive for t in a.get("tags", []))]
            for e in main.ents.values():
                e.touch()
            main.rev += 1; main.modified = True
        self.doc.modified = False
        self.message(f"Block {be['name']} saved - every reference in the drawing is updated")
        return True

    def bedit_close(self, ask=True):
        be = self.bedit
        if not be:
            return True
        if ask and self.doc.modified:
            r = QMessageBox.question(self, "Block Editor", f"Save the changes to block {be['name']}?", QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
            if r == QMessageBox.Cancel:
                return False
            if r == QMessageBox.Yes:
                self.bedit_save()
        if self.engine.busy():
            self.engine.cancel()
        main = be["main"]
        if be.get("array") is not None:
            main.blocks.pop(be["name"], None)
        self.bedit = None; self.view.be_params = None; self.view.be_actions = None
        self.ribbon.set_tab_visible("Block Editor", False); self._authoring_palette(False)
        self._set_doc(main); E.Entity.anno_scale = be["scale"]
        t, R, h = be["view"]; self.view.cam.target, self.view.cam.R, self.view.cam.h = t, R, h
        self.view._proj = None; main.rev += 1; self.view.invalidate(); self.refresh_status()
        self.message("Block Editor closed")
        return True

    def _pl_quick(self, op):
        self._plq = op; self.run_command("PLQUICK")

    def right_click(self, gpos):
        r = self.req; o = self.view.opt
        if r is not None:
            if o.get("rclick_cmd", "Enter") == "Enter":
                self.engine.feed_enter(); return
            m = QMenu(self)                                    # AutoCAD command-mode shortcut menu
            m.addAction("Enter", self.engine.feed_enter); m.addAction("Cancel", self.escape)
            if r.options and r.kind != "string":
                m.addSeparator()
                for op in r.options:
                    m.addAction(op, lambda op=op: self._cmd_text(op))
            m.addSeparator()
            sm = m.addMenu("Snap Overrides"); self._fill_osnap_menu(sm, override=True)
            m.addAction(icon("zoomext"), "Zoom extents", self.view.zoom_extents)
            m.exec(gpos); return
        if o.get("rclick_idle", "Shortcut menu") != "Shortcut menu" and not self.view.selection:
            self.engine.feed_enter(); return
        m = QMenu(self)
        if getattr(self.doc, "refedit", None) is not None:
            m.addAction(icon("refedit"), "Save Reference Edits", lambda: self.run_command("REFSAVE"))
            m.addAction("Discard Reference Changes", lambda: self.run_command("REFDISCARD"))
            m.addAction("Add / Remove Objects (REFSET)", lambda: self.run_command("REFSET")); m.addSeparator()
        if self.engine.last_cmd:
            m.addAction(icon("redo"), f"Repeat {self.engine.last_cmd}", lambda: self.run_command(self.engine.last_cmd))
        if self.cmdline.cmd_history:
            rm = m.addMenu("Recent Input")
            for n in self.cmdline.cmd_history[:10]:
                rm.addAction(n, lambda n=n: self.run_command(n))
        if self.view.selection:
            for c, t, ic in (("MOVE", "Move", "move"), ("COPY", "Copy", "copy"), ("ROTATE", "Rotate", "rotate"), ("ERASE", "Erase", "erase"),
                             ("PROPERTIES", "Properties", "props"), ("LIST", "List", "list")):
                m.addAction(icon(ic), t, lambda c=c: self.run_command(c))
            m.addAction(icon("zoomext"), "Zoom to selection", lambda: self.view.zoom_extents(self.selected_ents()))
            m.addAction(icon("selsimilar"), "Select Similar", lambda: self.run_command("SELECTSIMILAR"))
            cm = m.addMenu(icon("copy"), "Clipboard")
            cm.addAction("Copy  (Ctrl+C)", lambda: self.run_command("COPYCLIP")); cm.addAction("Copy with Base Point  (Ctrl+Shift+C)", lambda: self.run_command("COPYBASE"))
            cm.addAction("Cut  (Ctrl+X)", lambda: self.run_command("CUTCLIP"))
            sel = self.selected_ents()
            if len(sel) == 1 and sel[0].kind == "insert":
                m.addAction(icon("bedit"), "Block Editor", lambda n=sel[0].name: (self.clear_selection(silent=True), self.bedit_open(n)))
                if getattr(self.doc, "refedit", None) is None:
                    m.addAction(icon("refedit"), "Edit Block In-place", lambda: self.run_command("REFEDIT"))
            if sel and all(e.kind in ("polyline", "line", "arc") for e in sel):
                pm2 = m.addMenu(icon("pedit"), "Polyline")
                pm2.addAction(icon("pedit"), "Edit Polyline", lambda: self.run_command("PEDIT")); pm2.addSeparator()
                for t, o in (("Close", "Close"), ("Open", "Open"), (None, None), ("Join", "Join"), ("Reverse", "Reverse"), ("Width", "Width"),
                             (None, None), ("Curve Fit", "Fit"), ("Spline Fit", "Spline"), ("Decurve", "Decurve")):
                    if t is None:
                        pm2.addSeparator(); continue
                    a = pm2.addAction(t, lambda o=o: self._pl_quick(o))
                    if o == "Close" and all(e.kind == "polyline" and e.closed for e in sel):
                        a.setEnabled(False)
                    if o == "Open" and not any(e.kind == "polyline" and e.closed for e in sel):
                        a.setEnabled(False)
            m.addAction("Deselect all", self.clear_selection)
        from ..cmd.v15 import clip_get
        if clip_get():
            pm = m.addMenu(icon("paste"), "Paste")
            pm.addAction("Paste  (Ctrl+V)", lambda: self.run_command("PASTECLIP")); pm.addAction("Paste as Block  (Ctrl+Shift+V)", lambda: self.run_command("PASTEBLOCK"))
            pm.addAction("Paste to Original Coordinates", lambda: self.run_command("PASTEORIG"))
        m.addSeparator()
        m.addAction(icon("undo"), "Undo", lambda: self.run_command("UNDO")); m.addAction(icon("redo"), "Redo", lambda: self.run_command("REDO"))
        m.addAction(icon("zoomext"), "Zoom extents", self.view.zoom_extents)
        vm = m.addMenu(icon("view_iso"), "View")
        for v in ("Top", "Front", "Right", "SWISO", "SEISO", "NEISO", "NWISO"):
            vm.addAction(v, lambda v=v: self.run_command(v))
        m.addSeparator()
        m.addAction(icon("options"), "Options ...", lambda: self.run_command("OPTIONS"))
        m.exec(gpos)

    # ------------------------------------------------------------------ object snap menus
    def _fill_osnap_menu(self, m, override=False):
        from .viewport import SNAP_KINDS, SNAP_LABEL
        m.clear()
        if override:
            for k in SNAP_KINDS:
                m.addAction(self._snap_icon(k), SNAP_LABEL[k], lambda k=k: self._snap_override(k))
            m.addSeparator(); m.addAction("Mid Between 2 Points  (M2P)", self.start_m2p)
            m.addAction("None", lambda: self._snap_override(None))
        else:
            for k in SNAP_KINDS:
                a = m.addAction(self._snap_icon(k), SNAP_LABEL[k]); a.setCheckable(True); a.setChecked(k in self.view.snap_modes)
                a.toggled.connect(lambda v, k=k: self._snap_mode(k, v))
            m.addSeparator()
            m.addAction("Select All", lambda: [self._snap_mode(k, True) for k in SNAP_KINDS])
            m.addAction("Clear All", lambda: [self._snap_mode(k, False) for k in SNAP_KINDS])
        m.addSeparator()
        m.addAction(icon("options"), "Object Snap Settings ...", lambda: self.drafting_settings("Object Snap"))

    def _snap_icon(self, kind):
        from PySide6.QtGui import QPixmap, QPainter
        pm = QPixmap(20, 20); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        size = self.view.opt.get("marker_size", 6); self.view.opt["marker_size"] = 6
        try:
            self.view._snap_marker(p, kind, 10, 10)
        finally:
            self.view.opt["marker_size"] = size
        p.end()
        return QIcon(pm)

    def _snap_mode(self, k, on):
        (self.view.snap_modes.add if on else self.view.snap_modes.discard)(k)
        self.view.opt["snap_modes"] = [x for x in __import__("alief_cadpro.ui.viewport", fromlist=["SNAP_KINDS"]).SNAP_KINDS if x in self.view.snap_modes]
        if on and not self.view.osnap_on:
            self.toggles["osnap_on"].setChecked(True)
        OPT.save(self.settings, self.view.opt)

    def _snap_override(self, k):
        self.view.snap_override = k
        if k:
            from .viewport import SNAP_LABEL
            self.message(f"Snap override: {SNAP_LABEL[k]} (next point only)")

    def osnap_menu(self, gpos, override=False):
        m = QMenu(self); self._fill_osnap_menu(m, override and self.req is not None); m.exec(gpos)

    def _toggle_menu(self, gpos, key):
        if key == "OSNAP":
            return self.osnap_menu(gpos)
        m = QMenu(self)
        if key == "POLAR":
            for a in (90, 45, 30, 22.5, 18, 15, 10, 5):
                act = m.addAction(f"{a:g}°"); act.setCheckable(True); act.setChecked(abs(self.view.polar_inc - a) < 1e-9)
                act.triggered.connect(lambda _=False, a=a: self._polar_set(a))
            m.addSeparator()
        tab = {"GRID": "Snap and Grid", "SNAP": "Snap and Grid", "POLAR": "Polar Tracking", "SC": "Selection"}.get(key)
        if tab:
            m.addAction(icon("options"), "Drafting Settings ...", lambda: self.drafting_settings(tab))
        else:
            m.addAction(icon("options"), f"{key} Settings ...", lambda: self.show_options("Display" if key in ("LWT",) else "Drafting"))
        m.exec(gpos)

    def _clip_key(self, cmd, text_action):
        """Ctrl+C / X / V: text boxes keep their normal copy / paste; elsewhere the drawing clipboard commands run."""
        from PySide6.QtWidgets import QLineEdit, QTextEdit, QPlainTextEdit, QAbstractSpinBox
        fw = QApplication.focusWidget()
        edit = fw if isinstance(fw, (QLineEdit, QTextEdit, QPlainTextEdit)) else (fw.lineEdit() if isinstance(fw, QAbstractSpinBox) else None)
        if edit is not None and text_action:
            if edit is self.cmdline.edit and not edit.hasSelectedText() and text_action in ("copy", "cut") and self.view.selection:
                pass                                         # nothing typed / selected in the command line: copy the drawing objects
            elif edit is self.cmdline.edit and text_action == "paste":
                from ..cmd.v15 import clip_get
                if clip_get() is None or edit.text():
                    edit.paste(); return
            else:
                getattr(edit, text_action)(); return
        if fw is not None and fw.window() is not self and not fw.window().isAncestorOf(self):
            from PySide6.QtWidgets import QDockWidget
            if not isinstance(fw.window(), QDockWidget):
                return
        if self.engine.busy() and self.engine.name not in ("COPYCLIP", "COPYBASE", "CUTCLIP", "PASTECLIP", "PASTEBLOCK"):
            if self.req is not None and self.req.kind != "select":
                return
        self.run_command(cmd)

    def drafting_settings(self, tab=None):
        from .dialogs15 import DraftingSettingsDialog
        d = DraftingSettingsDialog(self, tab)
        if d.exec():
            d.apply(); self.refresh_status()
            for vw in self.views:
                vw.invalidate()

    def linetype_manager(self):
        from .dialogs16 import LinetypeDialog
        d = LinetypeDialog(self)
        if d.exec():
            d.apply(); self.doc.rev += 1; self.doc.modified = True
            for vw in self.views:
                vw.update()
            self.props.refresh(self.selected_ents())

    def dimstyle_manager(self):
        from .dialogs15 import DimStyleManager
        d = DimStyleManager(self)
        d.exec()
        n = d.apply()
        if n:
            self.message(f"{n} dimension(s) updated to their style")

    def _polar_set(self, a):
        self.view.opt["polar_inc"] = float(a); self.view.polar_inc = float(a)
        self._set_view_flag("polar_on", True); self._sync_options(); self.message(f"Polar tracking every {a:g}°")

    def _set_view_flag(self, attr, v):
        for vw in self.views:
            setattr(vw, attr, bool(v)); vw.invalidate()
        if attr == "polar_on" and v and self.view.ortho:
            self._set_view_flag("ortho", False)
        elif attr == "ortho" and v and self.view.polar_on:
            self._set_view_flag("polar_on", False)
        self.refresh_status()

    # ------------------------------------------------------------------ tiled viewports (VPORTS)
    VIEW_STATE = ("opt", "aperture", "snap_modes", "show_grid", "osnap_on", "ortho", "snap_on", "dyn", "lwt", "polar_on", "polar_inc", "otrack_on",
                  "sel_cycling", "light", "color_by_thk", "ucs")

    def _sync_views(self, src=None):
        src = src or self.view
        for vw in self.views:
            if vw is src:
                continue
            for a in self.VIEW_STATE:
                val = getattr(src, a)
                setattr(vw, a, dict(val) if isinstance(val, dict) else (set(val) if isinstance(val, set) else val))
            vw.update()

    def activate_view(self, vw):
        if vw is self.view or vw not in self.views:
            return
        old = self.view
        self._sync_views(old)
        for a in ("preview", "click_win", "snap_override"):
            setattr(vw, a, getattr(old, a))
        old.preview = []; old.click_win = None; old.snap_hit = None; old.hover = None; old.hot_grip = None
        self.view = vw
        old.update(); vw.update(); self.refresh_status()

    def _new_view(self, like):
        vw = Viewport(self)
        for a in self.VIEW_STATE:
            val = getattr(like, a)
            setattr(vw, a, dict(val) if isinstance(val, dict) else (set(val) if isinstance(val, set) else val))
        vw.mode = like.mode; vw.cam.persp = like.cam.persp
        vw.cam.target = like.cam.target.copy(); vw.cam.R = like.cam.R.copy(); vw.cam.h = like.cam.h
        vw.mouse_moved.connect(self._coords)
        return vw

    def set_vports(self, config):
        """Single / 2V / 2H / 3R / 3L / 3V / 3H / 4 tiled model viewports (each with its own view; all show the same drawing)."""
        from PySide6.QtWidgets import QSplitter
        act = self.view; cur = self._view0
        if act is not cur:                                   # the current view goes back into the main viewport
            self._sync_views(act)
            cur.cam.target = act.cam.target.copy(); cur.cam.R = act.cam.R.copy(); cur.cam.h = act.cam.h; cur.mode = act.mode; cur._proj = None
        n = {"Single": 1, "2V": 2, "2H": 2, "3R": 3, "3L": 3, "3V": 3, "3H": 3, "4": 4}.get(config)
        if n is None:
            return False
        lay = self.view_host.layout()
        while lay.count():
            it = lay.takeAt(0); w = it.widget()
            if w is not None:
                w.setParent(None)
        for vw in self.views:
            if vw is not cur:
                vw.deleteLater()
        views = [cur] + [self._new_view(cur) for _ in range(n - 1)]
        presets = ["top", "front", "right", "swiso"]
        has3d = any(e.kind == "body" for e in self.doc.ents.values())
        # like AutoCAD / GstarCAD every new viewport starts with the same view as the current one;
        # only a 3D model gets the Top / Front / Right / Isometric set
        for vw, nm in zip(views[1:], presets[1:] if has3d else []):
            try:
                vw.cam.R = R_view(*VIEWS[nm]); vw._proj = None
            except Exception:
                pass
        def sp(orient, ws):
            s_ = QSplitter(orient); s_.setChildrenCollapsible(False); s_.setHandleWidth(4)
            for w in ws:
                s_.addWidget(w)
            s_.setSizes([1000] * len(ws)); return s_
        H, V = Qt.Horizontal, Qt.Vertical
        if n == 1:
            root = cur
        elif config == "2V":
            root = sp(H, views)
        elif config == "2H":
            root = sp(V, views)
        elif config == "3R":
            root = sp(H, [views[0], sp(V, views[1:])])
        elif config == "3L":
            root = sp(H, [sp(V, views[1:]), views[0]])
        elif config == "3V":
            root = sp(H, views)
        elif config == "3H":
            root = sp(V, views)
        else:
            root = sp(V, [sp(H, views[:2]), sp(H, views[2:])])
        lay.addWidget(root)
        self.views = views; self.view = cur
        for vw in views:
            vw.show()
        QTimer.singleShot(60, lambda: [vw.zoom_extents(animate=False) for vw in views[1:]])
        self.doc.settings["vports"] = config
        self.message(f"Viewports: {config}" + ("  - click a viewport to make it current" if n > 1 else ""))
        return True

    # ------------------------------------------------------------------ keyboard goes to the command line from anywhere
    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if ev.type() == QEvent.KeyPress and self._route_key(obj, ev):
            return True
        return False

    def _route_key(self, obj, ev):
        """Typing while a palette, the layer list, a ribbon combo ... has the focus still reaches the command line
        (before, the key was swallowed there and the command had to be typed again)."""
        from PySide6.QtWidgets import QLineEdit, QAbstractSpinBox, QTextEdit, QPlainTextEdit, QAbstractItemView, QAbstractButton
        if QApplication.activePopupWidget() is not None or QApplication.activeModalWidget() is not None:
            return False
        if ev.key() == Qt.Key_Escape and not (ev.modifiers() & (Qt.ControlModifier | Qt.AltModifier | Qt.ShiftModifier)):
            if self._route_escape(obj):
                return True
        fw = QApplication.focusWidget()
        if fw is None or obj is not fw or fw in self.views or fw is self.cmdline.edit:
            return False
        win = fw.window()
        if win is not self and not isinstance(win, QDockWidget):
            return False
        if ev.modifiers() & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier):
            return False
        if isinstance(fw, (QLineEdit, QAbstractSpinBox, QTextEdit)) or (isinstance(fw, QPlainTextEdit) and not fw.isReadOnly()):
            return False
        if isinstance(fw, QComboBox) and fw.isEditable():
            return False
        if isinstance(fw, QAbstractItemView) and fw.state() == QAbstractItemView.EditingState:
            return False
        k = ev.key(); t = ev.text()
        if k in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            if isinstance(fw, (QAbstractButton, QComboBox, QAbstractItemView)):
                return False                              # these use Space / Enter themselves
        elif k not in (Qt.Key_Escape, Qt.Key_Backspace) and not (t and t.isprintable()):
            return False
        self.view.setFocus(); self.viewport_key(ev)
        return True

    def _route_escape(self, obj):
        """Esc always reaches the command / selection, wherever the keyboard focus is in the main window (ribbon, a combo,
        the Properties or Layer panel, no focus at all ...). Before, it was swallowed there and the drawing had to be
        clicked first."""
        from PySide6.QtWidgets import QAbstractItemView, QTextEdit, QPlainTextEdit, QDockWidget
        fw = QApplication.focusWidget() or (obj if isinstance(obj, QWidget) else None)
        target = fw
        if target is None or obj is not target:
            return False
        if fw is not None and (fw in getattr(self, "views", [self.view]) or fw is self.cmdline.edit):
            return False                                   # these handle Esc themselves
        win = (fw or target).window()
        if win is not self and not isinstance(win, QDockWidget):
            return False
        w = fw
        while w is not None:                               # a cell being edited in a table: Esc first cancels that edit
            if isinstance(w, QAbstractItemView) and w.state() == QAbstractItemView.EditingState:
                return False
            w = w.parentWidget()
        if isinstance(fw, (QTextEdit, QPlainTextEdit)) and not fw.isReadOnly():
            return False
        self.view.setFocus(); self.escape()
        return True

    def viewport_key(self, ev):
        k = ev.key()
        if k == Qt.Key_Escape:
            self.escape(); return
        if k in (Qt.Key_Return, Qt.Key_Enter) or (k == Qt.Key_Space and self.view.opt.get("space_enter", True) and not self.cmdline.edit.text()
                                                  and not getattr(self.cmdline, "string_mode", False)):
            if self.cmdline.edit.text():
                self.cmdline._enter()
            else:
                self.engine.feed_enter()
            return
        if k == Qt.Key_Delete and not self.engine.busy() and self.view.selection:
            self.run_command("ERASE"); return
        t = ev.text()
        if t and t.isprintable():
            self.cmdline.edit.setFocus(); self.cmdline.edit.insert(t)
        elif k == Qt.Key_Backspace:
            self.cmdline.edit.backspace()

    def _grip_all(self, hot, p, copy):
        """Applies the grip move to the hot grip and to the other hot / coincident grips. Returns the changed objects."""
        v = self.view; out = {}
        def obj(eid):
            if eid not in out:
                e = self.doc.ents.get(eid)
                if e is None:
                    return None
                if copy:
                    e = e.copy()
                else:
                    self.doc.modify(e)
                out[eid] = e
            return out[eid]
        e = obj(hot[1])
        if e is None:
            return []
        grip_apply(e, hot[2], p, hot[3] if len(hot) > 3 else None)
        if p is not None and getattr(v, "hot_base", None) is not None:
            d = np.asarray(p, float) - v.hot_base
            for gp, eid, gi in getattr(v, "hot_multi", []):
                e2 = obj(eid)
                if e2 is not None:
                    try:
                        grip_apply(e2, gi, gp + d, None)
                    except Exception:
                        pass
        return list(out.values())

    def grip_preview(self, hot, p):
        return self._grip_all(hot, p, True)

    def grip_finish(self, hot, p):
        if self.doc.ents.get(hot[1]) is None:
            return
        self.doc.begin("grip"); self._grip_all(hot, p, False); self.doc.end()
        self.view.hot_multi = []
        self.props.refresh(self.selected_ents())

    def edit_entity(self, e):
        if e.kind == "insert":
            self.edit_insert(e); return
        if e.kind == "table":
            self.edit_table(e); return
        if e.kind == "text":
            r = self.dialog_mtext(e)
            if r is not None and r["text"].strip():
                self.doc.begin("edit"); self.doc.modify(e)
                e.halign, e.valign, e.lsf = r["halign"], (r["valign"] if (e.rich or "\n" in r["text"] or e.valign in (1, 2, 3)) else e.valign), r["lsf"]
                if e.anno:
                    e.anno = r["height"] / (E.Entity.anno_scale or 1.0)      # the editor works with the drawing height
                else:
                    e.hm = r["height"]
                e.width = max(0.0, float(r.get("width", e.width) or 0.0))
                e.set_rich(r["rich"])
                if not e.rich:
                    e.s = r["text"]
                e.touch(); self.doc.end()
        else:
            self.set_selection([e.id]); self.pal.reveal(self.props_dock)

    # =============================================================================== doc events
    def _doc_changed(self):
        for vw in getattr(self, "views", [self.view]):      # the build key (document version) triggers the rebuild
            vw.update()
        self.view.selection = [i for i in self.view.selection if i in self.doc.ents]
        self._title()
        QTimer.singleShot(0, self._deferred_refresh)

    def _deferred_refresh(self):
        self.props.refresh(self.selected_ents())
        if self.layers.table.rowCount() != len(self.doc.layers):
            self.layers.refresh(); self._layer_combo_refresh()
        if self.browser_dock.isVisible() and not self.browser_dock.visibleRegion().isEmpty():
            self.browser.refresh()

    def _props_changed(self):
        self.view.invalidate()

    def _title(self):
        nm = self._doc_name(self.doc)
        if getattr(self, "bedit", None):
            nm = "BLOCK EDITOR: " + self.bedit["name"]
        elif getattr(self, "doc_tabs", None) is not None and self.doc in self.docs:
            i = self.docs.index(self.doc); t = nm + (" *" if self.doc.modified else "")
            if self.doc_tabs.tabText(i) != t:
                self.doc_tabs.setTabText(i, t)
            self.doc_tabs.setTabToolTip(i, self.doc.path or nm)
        self.setWindowTitle(f"ALIEF CAD PRO {self.version} - [{nm}{' *' if self.doc.modified else ''}]")

    def _doc_name(self, d):
        return os.path.basename(d.path) if d.path else getattr(d, "untitled", "Drawing1")

    # ------------------------------------------------------------------ drawing tabs
    def _cam_store(self, d):
        c = self.view.cam
        d._cam = (c.target.copy(), c.R.copy(), c.h, getattr(c, "persp", None))
        d.settings["anno_scale"] = E.Entity.anno_scale

    def _cam_restore(self, d):
        st = getattr(d, "_cam", None)
        if st:
            c = self.view.cam; c.target, c.R, c.h = st[0].copy(), st[1].copy(), st[2]
            if st[3] is not None:
                c.persp = st[3]
            self.view._proj = None; self.view.invalidate()

    def _open_doc(self, d, replace_pristine=True):
        """Show document d in its own tab (an untouched empty 'Drawing1' is reused)."""
        if self.bedit and not self.bedit_close():
            return False
        if self.engine.busy():
            self.engine.cancel()
        cur = self.doc
        pristine = replace_pristine and cur in self.docs and not cur.path and not cur.modified and not cur.ents and not getattr(cur, "src_path", None)
        self._tab_lock = True
        try:
            if pristine:
                i = self.docs.index(cur); self.docs[i] = d
                if not d.path:
                    d.untitled = getattr(cur, "untitled", "Drawing1")
            else:
                self._cam_store(cur)
                if not d.path and not getattr(d, "untitled", None):
                    self._untitled_n += 1; d.untitled = f"Drawing{self._untitled_n}"
                self.docs.append(d); i = len(self.docs) - 1
                self.doc_tabs.addTab(self._doc_name(d))
            self.doc_tabs.setCurrentIndex(i)
        finally:
            self._tab_lock = False
        self._set_doc(d)
        return True

    def _tab_changed(self, i):
        if self._tab_lock or i < 0 or i >= len(self.docs) or self.docs[i] is self.doc:
            return
        if self.bedit and not self.bedit_close():
            self._tab_lock = True
            self.doc_tabs.setCurrentIndex(self.docs.index(self.bedit["main"]) if self.bedit["main"] in self.docs else 0)
            self._tab_lock = False
            return
        if self.engine.busy():
            self.engine.cancel()
        if self.doc in self.docs:
            self._cam_store(self.doc)
        self.clear_selection()
        d = self.docs[i]
        self._set_doc(d); self._cam_restore(d); self.refresh_views() if hasattr(self, "view_combo") else None
        self.message(f"Drawing: {self._doc_name(d)}")

    def _tab_moved(self, a, b):
        d = self.docs.pop(a); self.docs.insert(b, d)

    def _tab_close(self, i):
        if i < 0 or i >= len(self.docs):
            return False
        if self.docs[i] is not self.doc:
            self.doc_tabs.setCurrentIndex(i)
            if self.docs[i] is not self.doc:
                return False
        if not self._confirm_discard():
            return False
        self._tab_lock = True
        try:
            self.docs.pop(i); self.doc_tabs.removeTab(i)
            if not self.docs:
                d = Document(); self._untitled_n += 1; d.untitled = f"Drawing{self._untitled_n}"
                self.docs.append(d); self.doc_tabs.addTab(d.untitled)
            j = min(i, len(self.docs) - 1); self.doc_tabs.setCurrentIndex(j)
        finally:
            self._tab_lock = False
        d = self.docs[j]; self._set_doc(d)
        if getattr(d, "_cam", None):
            self._cam_restore(d)
        else:
            self.view.set_view("top"); self.view.zoom_extents()
        return True

    def _confirm_all(self):
        """Ask about every modified drawing (used when the program closes)."""
        if self.bedit and not self.bedit_close():
            return False
        for d in list(self.docs):
            if d.modified and d.ents:
                self.doc_tabs.setCurrentIndex(self.docs.index(d))
                if not self._confirm_discard():
                    return False
                d.modified = False
        return True

    def _close_all(self):
        while len(self.docs) > 1 or self.docs[0].ents or self.docs[0].path:
            n = len(self.docs)
            if not self._tab_close(self.doc_tabs.currentIndex()):
                break
            if n == 1:
                break

    def tab_next(self, step=1):
        if len(self.docs) > 1:
            self.doc_tabs.setCurrentIndex((self.doc_tabs.currentIndex() + step) % len(self.docs))

    def _coords(self, p):
        q = self.view.ucs.to_local(p)
        self.coord.setText(f"{q[0]:.3f}, {q[1]:.3f}, {q[2]:.3f}")

    def refresh_status(self):
        if len(getattr(self, "views", [])) > 1:
            self._sync_views()
        for attr, b in getattr(self, "toggles", {}).items():
            b.blockSignals(True); b.setChecked(getattr(self.view, attr)); b.blockSignals(False)
        if hasattr(self, "style_lbl"):
            self.style_lbl.setText({"wire": "Wireframe", "hidden": "Hidden", "shaded": "Shaded", "shadededges": "Shaded + edges", "xray": "X-ray"}[self.view.mode]
                                   + ("  |  persp" if self.view.cam.persp else "") + f"  |  {self.doc.settings.get('units', 'mm')}  |  Layer {self.doc.cur_layer}")
            self.scale_combo.blockSignals(True); self.scale_combo.setCurrentText(f"1:{E.Entity.anno_scale:g}"); self.scale_combo.blockSignals(False)

    def _scale_pick(self, *_):
        t = self.scale_combo.currentText().strip().upper()
        class C:
            pass
        c = self.engine.ctx
        if t.startswith("A"):
            n = misc.auto_scale(self.doc, self.doc.settings.get("paper", "A3"))
            self.message(f"Auto drawing scale for {self.doc.settings.get('paper', 'A3')}: 1:{n:g}")
        else:
            try:
                n = float(t.split(":")[-1])
            except ValueError:
                return
        misc.set_anno_scale(c, n)

    def _layer_combo_refresh(self):
        c = self.layer_combo; c.blockSignals(True); c.clear()
        from .panels import color_icon
        for n, L in self.doc.layers.items():
            c.addItem(color_icon(L.color), n)
        c.setCurrentText(self.doc.cur_layer); c.blockSignals(False)

    def _set_cur_layer(self, n):
        if n in self.doc.layers:
            self.doc.cur_layer = n; self.layers.refresh(); self.refresh_status()

    def _toggle_imgsnap(self):
        if "img" in self.view.snap_modes:
            self.view.snap_modes.discard("img"); self.message("Snap to image lines OFF")
        else:
            self.view.snap_modes.add("img"); self.message("Snap to image lines ON (move the cursor over a scanned line)")

    # =============================================================================== dialogs used by commands
    def _dlg(self, cls, key, *a, **kw):
        d = cls(self, *a, **kw)
        if d.exec():
            r = d.result()
            if key:
                self._last[key] = r
            return r
        return None

    def dialog_plate(self):
        return self._dlg(DL.PlateDialog, "plate", self._last.get("plate"))

    def dialog_profile(self):
        return self._dlg(DL.ProfileDialog, "profile", self._last.get("profile"))

    def dialog_detail(self):
        return self._dlg(DL.DetailDialog, "detail", self._last.get("detail"))

    def dialog_array(self, ents):
        return self._dlg(DL.ArrayDialog, None)

    def dialog_hatch(self):
        return self._dlg(DL.HatchDialog, "hatch", self._last.get("hatch"))

    def dialog_matchprop(self, use=None):
        """MATCHPROP Settings: which properties are copied (like the Property Settings of AutoCAD)."""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QCheckBox, QDialogButtonBox, QGroupBox, QGridLayout
        from ..cmd.modify import MATCH_KEYS
        d = QDialog(self); d.setWindowTitle("Property Settings"); v = QVBoxLayout(d)
        g1 = QGroupBox("Basic properties"); l1 = QGridLayout(g1); g2 = QGroupBox("Special properties"); l2 = QGridLayout(g2)
        cur = set(k for k, _ in MATCH_KEYS) if use is None else set(use); boxes = {}
        for i, (k, lab) in enumerate(MATCH_KEYS):
            cb = QCheckBox(lab); cb.setChecked(k in cur); boxes[k] = cb
            (l1 if i < 5 else l2).addWidget(cb, (i if i < 5 else i - 5) // 2, (i if i < 5 else i - 5) % 2)
        v.addWidget(g1); v.addWidget(g2)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); bb.accepted.connect(d.accept); bb.rejected.connect(d.reject); v.addWidget(bb)
        if not d.exec():
            return None
        return [k for k, cb in boxes.items() if cb.isChecked()]

    def dialog_mtext(self, ent=None, height=None, at=None):
        """Text Formatting editor. Returns dict(rich, text, height (drawing units), font, halign, valign, lsf, width,
        annotative) or None. While typing, the text is previewed in the drawing (at = (insertion point, width) for a new one)."""
        from .dialogs16 import MTextEditor
        k = E.Entity.anno_scale or 1.0
        if ent is not None:
            src = ent.rich or ent.s.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}").replace("\n", "\\P")
            proto = ent
            kw = dict(width=ent.width, anno_k=k if ent.anno else None)
            d0 = (src, ent.h, ent.font, ent.halign, ent.valign, ent.lsf)
        else:
            ph = height or self.doc.settings.get("text_paper", 2.5)
            proto = None
            if at is not None:
                proto = E.Text(at[0], "", ph * k, self.view.ucs.x, self.view.ucs.z, 0, 3); proto.anno = ph; proto.width = float(at[1] or 0.0)
            kw = dict(width=float(at[1]) if at is not None else 0.0, anno_k=k)
            d0 = ("", ph * k, "Arial", 0, 3, 1.0)
        def live(r):
            if proto is None:
                return
            t = proto.copy(); t.id = 0
            t.halign, t.valign, t.lsf, t.width = r["halign"], r["valign"], r["lsf"], r["width"]
            if t.anno:
                t.anno = r["height"] / k
            else:
                t.hm = r["height"]
            t.set_rich(r["rich"])
            if not t.rich:
                t.s = r["text"] or " "
            self.view.preview = [t]; self.view.update()
        d = MTextEditor(self, *d0, on_change=live, **kw)
        try:                                               # keep the text visible: the editor goes to the other half of the window
            if proto is not None:
                s2, _ = self.view.cam.project(np.asarray([proto.p], float))
                g = self.geometry(); top = s2[0][1] > self.view.height() / 2
                d.adjustSize(); d.move(g.x() + max(0, (g.width() - d.width()) // 2), g.y() + (90 if top else max(90, g.height() - d.height() - 60)))
        except Exception:
            pass
        try:
            return d.result() if d.exec() else None
        finally:
            self.view.preview = []; self.view.update()

    def dialog_fitting(self, preset=None):
        return self._dlg(DL.FittingDialog, "fitting", preset, self._last.get("fitting"))

    def dialog_pipe(self):
        return self._dlg(DL.PipeDialog, "pipe", self._last.get("pipe"))

    def dialog_tray(self):
        return self._dlg(DL.TrayDialog, None)

    def dialog_equipment(self):
        pre = self.pending_equipment; self.pending_equipment = None
        return self._dlg(DL.EquipmentDialog, None, pre)

    def dialog_trace(self, img):
        return self._dlg(DL.TraceDialog, None, img)

    def dialog_pdf(self, path):
        try:
            from .dialogs16 import PdfImportDialog
            d = PdfImportDialog(self, path)
            return d.result() if d.exec() else None
        except Exception as ex:
            self.message(f"PDF error: {ex}"); return None

    def dialog_nest(self):
        return self._dlg(DL.NestDialog, None)

    def dialog_cam(self, parts, ucs):
        DL.CamDialog(self, parts, ucs).exec()

    def dialog_matlist(self, rows):
        DL.MatListDialog(self, rows).exec()

    def choose(self, title, label, items):
        s, ok = QInputDialog.getItem(self, title, label, items, 0, False)
        return s if ok else None

    def ask_open_many(self, title, filt):
        fns, _ = QFileDialog.getOpenFileNames(self, title, self.settings.value("last_dir", "") or self._dir(), filt)
        if fns:
            self.settings.setValue("last_dir", os.path.dirname(fns[0]))
        return fns

    def ask_open(self, title, filt):
        fn, _ = QFileDialog.getOpenFileName(self, title, self._dir() if not self.settings.value("last_dir", "") else self.settings.value("last_dir", ""), filt)
        if fn:
            self.settings.setValue("last_dir", os.path.dirname(fn))
        return fn

    def dialog_image_adjust(self, e):
        from .dialogs16 import ImageAdjustDialog
        d = ImageAdjustDialog(self, e)
        return d.values() if d.exec() else None

    def dialog_frames(self, opt):
        d = DL.FrameSpacingDialog(self, opt)
        return d.values() if d.exec() else None

    def dialog_table(self):
        d = DL.TableDialog(self)
        return d.values() if d.exec() else None

    def edit_table(self, t):
        d = DL.TableEditDialog(self, t)
        if d.exec():
            rows = d.result_rows(); nc = max(len(r) for r in rows)
            self.doc.begin("table"); self.doc.modify(t)
            w = list(t.widths) + [t.widths[-1] if t.widths else 30.0] * nc
            t.rows = rows; t.widths = w[:nc]; t.title = d.title.text().strip()
            if d.fit.isChecked():
                t.widths = E.Table.fit_widths(rows, [min(x, 12.0) for x in t.widths], t.th)
            t.aligns = (list(t.aligns) + [0] * nc)[:nc] if t.aligns else []
            t.touch(); self.doc.end()

    def export_table(self, t):
        fn, _ = QFileDialog.getSaveFileName(self, "Export table", os.path.join(self._dir(), (t.title or "table").replace(" ", "_") + ".xlsx"),
                                            "Excel (*.xlsx);;CSV (*.csv)")
        if not fn:
            return
        try:
            if fn.lower().endswith(".csv"):
                import csv
                with open(fn, "w", newline="", encoding="utf-8-sig") as f:
                    csv.writer(f).writerows(([[t.title]] if t.title else []) + t.rows)
            else:
                DL.export_table_xlsx(fn if fn.lower().endswith(".xlsx") else fn + ".xlsx", t)
            self.message(f"Table exported: {fn}")
        except Exception as ex:
            QMessageBox.warning(self, "Export table", str(ex))

    def dialog_find(self):
        DL.FindDialog(self, self).exec()

    def _th_pick(self, *_):
        try:
            v = float(self.th_combo.currentText().replace(",", "."))
        except ValueError:
            return
        if v > 0:
            self.doc.settings["text_paper"] = v; self.message(f"Text height on paper = {v:g} mm (model height {v * E.Entity.anno_scale:g} at 1:{E.Entity.anno_scale:g})")

    STD_VIEWS = [("Top", "TOP"), ("Bottom", "BOTTOM"), ("Left", "LEFT"), ("Right", "RIGHT"), ("Front", "FRONT"), ("Back", "BACK"),
                 ("SW Isometric", "SWISO"), ("SE Isometric", "SEISO"), ("NE Isometric", "NEISO"), ("NW Isometric", "NWISO")]

    def refresh_views(self):
        if not hasattr(self, "view_combo"):
            return
        self.view_combo.blockSignals(True); self.view_combo.clear()
        self.view_combo.addItems([n for n, _ in self.STD_VIEWS])
        named = list(self.doc.settings.get("views", {}))
        if named:
            self.view_combo.insertSeparator(len(self.STD_VIEWS)); self.view_combo.addItems(named)
        self.view_combo.blockSignals(False)

    def _view_pick(self, i):
        name = self.view_combo.itemText(i)
        std = dict(self.STD_VIEWS)
        if name in std:
            self.run_command(std[name])
        elif name:
            insview.restore_view(self.engine.ctx, name)

    def show_text(self, title, text):
        DL.TextDialog(self, title, text).exec()

    def show_symbol_library(self):
        self.pal.reveal(self.sym_dock)

    def show_layers(self):
        self.pal.reveal(self.layers_dock)

    def show_props(self):
        self.pal.reveal(self.props_dock)

    def show_options(self, tab=None):
        d = OPT.OptionsDialog(self, tab)
        d.exec()

    def apply_options(self, o, startup=False):
        """Push the option values into the program (called at start-up and from the Options dialog)."""
        v = self.view; v.opt = dict(o)
        v.aperture = int(o["aperture"]); v.snap_modes = set(o["snap_modes"])
        v.polar_inc = float(o.get("polar_inc", 90.0)); v.polar_on = bool(o.get("polar", False)); v.sel_cycling = bool(o.get("sel_cycling", True)); v.otrack_on = bool(o.get("otrack", True))
        v.snap_on = bool(o.get("snap", False))
        for attr, key in (("show_grid", "grid"), ("osnap_on", "osnap"), ("ortho", "ortho"), ("dyn", "dyn"), ("lwt", "lwt")):
            setattr(v, attr, bool(o[key]))
            b = getattr(self, "toggles", {}).get(attr)
            if b is not None and b.isChecked() != bool(o[key]):
                b.blockSignals(True); b.setChecked(bool(o[key])); b.blockSignals(False)
        v.mode = o["vstyle"]; v.cam.persp = bool(o["perspective"])
        if (o["theme"] == "Light") != v.light:
            v.light = o["theme"] == "Light"; set_light(v.light); self.apply_theme()
            if not startup:
                self.message("Theme changed (ribbon icons refresh after restart)")
        self.settings.setValue("auto_update", bool(o["auto_update"]))
        self.engine.noun_verb = bool(o["noun_verb"])
        self.cmdline.set_font_size(o["cmd_font"]); self.cmdline.space_enter = bool(o["space_enter"])
        if not startup and hasattr(self, "cmd_dock") and not self.cmd_dock.isFloating():
            self.resizeDocks([self.cmd_dock], [self.cmdline.height_for_lines(o["cmd_lines"])], Qt.Vertical)
        from ..core import dxfio
        dxfio.ODA_PATH = o.get("oda_path") or None
        if hasattr(self, "autosave"):
            self._autosave_timer()
        if hasattr(self, "recent_menu"):
            self._recent_refresh()
        if hasattr(self, "toggles"):
            self.refresh_status()
        if len(getattr(self, "views", [])) > 1:
            self._sync_views()
        for vw in getattr(self, "views", [v]):
            vw._proj = None; vw.invalidate()

    def _autosave_timer(self):
        o = self.view.opt
        if o.get("autosave_on", True):
            self.autosave.start(max(1, int(o.get("autosave_min", 10))) * 60 * 1000)
        else:
            self.autosave.stop()

    def _sync_options(self):
        """Status-bar toggles and view state changed during the session are kept in the current profile."""
        v = self.view; o = v.opt
        o.update(grid=v.show_grid, osnap=v.osnap_on, ortho=v.ortho, dyn=v.dyn, lwt=v.lwt, vstyle=v.mode, perspective=bool(v.cam.persp),
                 aperture=int(v.aperture), theme="Light" if v.light else "Dark", polar=v.polar_on, polar_inc=v.polar_inc, otrack=v.otrack_on,
                 sel_cycling=v.sel_cycling, snap=v.snap_on)
        from .viewport import SNAP_KINDS
        o["snap_modes"] = [k for k in SNAP_KINDS if k in v.snap_modes]
        OPT.save(self.settings, o)

    def show_about(self):
        QMessageBox.about(self, "About ALIEF CAD PRO", DL.about_html(self.version, self.boot))

    def show_help(self):
        lines = ["ALIEF CAD PRO - commands (type the name or alias, Enter / Space / right-click = Enter, Esc = cancel)", ""]
        inv = {}
        for a, n in self.engine.alias.items():
            inv.setdefault(n, []).append(a)
        for n in sorted(self.engine.cmds):
            lines.append(f"{n:<14} {', '.join(sorted(inv.get(n, []))):<22} {self.engine.desc.get(n, '')}")
        lines += ["", "Coordinates: x,y  x,y,z  @dx,dy  @dist<angle   |  type a number to give a distance in the cursor direction",
                  "Mouse: wheel = zoom, middle drag = pan, right drag / Shift+middle = orbit, double middle = zoom extents",
                  "Keys: F3 osnap, F7 grid, F8 ortho, F9 snap, F12 dynamic input, Ctrl+0 clean screen, Delete = erase selection"]
        self.show_text("Commands", "\n".join(lines))

    def show_guide(self):
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        cands = [os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs", "PANDUAN_ALIEF_CADPRO.pdf"),     # newest, comes with updates
                 os.path.join(self.boot.get("install_dir", ""), "docs", "PANDUAN_ALIEF_CADPRO.pdf"),
                 os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "docs", "PANDUAN_ALIEF_CADPRO.pdf")]
        for c in cands:
            if os.path.exists(c):
                QDesktopServices.openUrl(QUrl.fromLocalFile(c)); return
        self.message("Guide not found - it is installed in the program folder under docs\\")

    # =============================================================================== files
    def _confirm_discard(self):
        if self.bedit and not self.bedit_close():
            return False
        if not self.doc.modified or not self.doc.ents:
            return True
        r = QMessageBox.question(self, "ALIEF CAD PRO", f"Save changes to {self._doc_name(self.doc)}?", QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
        if r == QMessageBox.Save:
            return self.file_save()
        return r == QMessageBox.Discard

    def _set_doc(self, doc):
        self.doc = doc; doc.activate()
        if self._doc_changed not in doc.listeners:
            doc.listeners.append(self._doc_changed)
        E.Entity.anno_scale = doc.settings.get("anno_scale", 1.0)
        self.view.selection = []; self.view.textures = {}; self.view.invalidate()
        self.layers.refresh(); self._layer_combo_refresh(); self.props.refresh([]); self._title(); self.refresh_status()
        if hasattr(self, "ribbon"):
            try:
                self.refedit_ui(getattr(doc, "refedit", None) is not None)
            except Exception:
                pass

    def file_new(self):
        if True:
            tpl = self.view.opt.get("template") or ""
            d = None
            if tpl and os.path.exists(tpl):
                try:
                    d = Document.load(tpl); d.path = None; d.modified = False
                except Exception as ex:
                    self.message(f"Template could not be opened ({ex}) - blank drawing used")
            if self._open_doc(d or Document(), replace_pristine=False):
                self.view.set_view("top"); self.view.zoom_extents()

    def file_open(self):
        fn = self.ask_open_many("Open drawing(s) - several files can be selected", "All supported (*.acp *.dwg *.dxf *.3dm *.pdf *.png *.jpg *.jpeg *.bmp *.tif *.stl *.obj);;"
                                           "ALIEF CAD PRO (*.acp);;DWG (*.dwg);;DXF (*.dxf);;Rhino 3dm (*.3dm);;PDF (*.pdf);;Images (*.png *.jpg *.jpeg *.bmp *.tif);;Mesh (*.stl *.obj)")
        for f in (fn if isinstance(fn, (list, tuple)) else [fn]):
            if f:
                self.open_path(f)

    def open_path(self, fn):
        ext = os.path.splitext(fn)[1].lower()
        if ext in (".acp", ".dxf", ".dwg", ".3dm"):
            for i, d in enumerate(self.docs):                      # already open: just show its tab
                if d.path and os.path.normcase(os.path.abspath(d.path)) == os.path.normcase(os.path.abspath(fn)):
                    self.doc_tabs.setCurrentIndex(i); self.message(f"{os.path.basename(fn)} is already open"); return
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            if ext == ".acp":
                if not self._open_doc(Document.load(fn)):
                    return
                self.view.set_view("top")
            elif ext in (".dxf", ".dwg", ".3dm"):
                d = Document()
                if not self._open_doc(d):
                    return
                ok = self._import_cad(fn)
                d.path = fn if ok else None           # Save writes back to the same DWG / DXF / 3dm file
                d.src_path = fn
                d.modified = False
                if not ok:                                         # nothing could be read: do not leave an empty tab behind
                    QApplication.restoreOverrideCursor(); self._tab_close(self.docs.index(d)); return
                self.view.set_view("top" if ext != ".3dm" else "swiso")
            elif ext == ".pdf":
                QApplication.restoreOverrideCursor(); self.run_command("PDFIMPORT", fn); return
            elif ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".gif"):
                QApplication.restoreOverrideCursor(); self.run_command("IMAGEATTACH", fn); return
            elif ext in (".stl", ".obj"):
                self._import_cad(fn)
            self._recent_add(fn)
            self.view.zoom_extents(); self._title()
        except Exception as ex:
            import traceback; traceback.print_exc()
            QMessageBox.warning(self, "Open", f"Cannot open {fn}:\n{ex}")
        finally:
            QApplication.restoreOverrideCursor()

    def _import_cad(self, fn):
        from ..core import dxfio
        ext = os.path.splitext(fn)[1].lower()
        if ext == ".dwg":
            import tempfile
            try:
                out = dxfio.dwg_convert(fn, tempfile.mkdtemp(prefix="cadpro_dwg_"))
            except RuntimeError as ex:
                QMessageBox.information(self, "DWG", "DWG files are read through the free ODA File Converter.\n"
                                        "Install it from https://www.opendesign.com/guestfiles/oda_file_converter and open the DWG again,\n"
                                        f"or save the drawing as DXF in AutoCAD / ZWCAD / GstarCAD.\n\n({ex})")
                return False
            fn = out; ext = ".dxf"
        if ext == ".3dm":
            from ..core import rhinoio
            try:
                n, st = rhinoio.import_3dm(self.doc, fn)
            except ImportError:
                QMessageBox.information(self, "Rhino 3dm", "The Rhino 3dm module is not installed in this copy of the program.\n"
                                        "Install the latest ALIEF CAD PRO installer to add it."); return False
            msg = f"Rhino 3dm: {n} object(s) imported (file units {st.get('units')}"
            msg += f", scaled x{st['scale']:g} to mm)" if st.get("scale", 1) != 1 else ")"
            if st.get("nomesh"):
                msg += f"; {st['nomesh']} surface(s) without a stored mesh came in as edge curves (in Rhino: shade the model, then save without 'Save small')"
            if st.get("skipped") or st.get("failed"):
                msg += f"; {st.get('skipped', 0) + st.get('failed', 0)} object(s) of unsupported type skipped"
            self.message(msg); self.layers.refresh(); self._layer_combo_refresh(); return True
        if ext == ".dxf":
            n, warn, units = dxfio.import_dxf(self.doc, fn)
            self.message(f"Imported {n} object(s)" + (f"; skipped: {', '.join(f'{k} x{v}' for k, v in warn.items())}" if warn else ""))
            self.layers.refresh(); self._layer_combo_refresh()
        elif ext in (".stl", ".obj"):
            b = dxfio.import_mesh(fn); self.doc.add(b); self.message(f"Mesh imported: {len(b.F)} triangles")
        return True

    def file_import(self):
        fn = self.ask_open("Import", "All (*.dxf *.dwg *.3dm *.stl *.obj *.pdf *.png *.jpg *.jpeg *.bmp *.tif *.csv *.xlsx);;DWG (*.dwg);;DXF (*.dxf);;Rhino 3dm (*.3dm)")
        if not fn:
            return
        ext = os.path.splitext(fn)[1].lower()
        if ext == ".pdf":
            self.run_command("PDFIMPORT", fn)
        elif ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"):
            self.run_command("IMAGEATTACH", fn)
        elif ext in (".csv", ".xlsx", ".txt"):
            self.run_command("CSVIMPORT", fn)
        else:
            self._import_cad(fn); self.view.zoom_extents()

    def file_save(self):
        if self.bedit:
            return self.bedit_save()
        if not self.doc.path:
            return self.file_saveas()
        self.doc.settings["anno_scale"] = E.Entity.anno_scale
        if self.doc.path.lower().endswith((".dxf", ".dwg", ".3dm")):
            if not self._write_foreign(self.doc.path, None):
                return False
            self.doc.modified = False; self._title(); self._recent_add(self.doc.path)
            return True
        if self.view.opt.get("backup", True) and os.path.exists(self.doc.path):
            try:
                import shutil; shutil.copy2(self.doc.path, os.path.splitext(self.doc.path)[0] + ".bak")
            except Exception:
                pass
        self.doc.save(self.doc.path); self._title(); self.message(f"Saved {self.doc.path}"); self._recent_add(self.doc.path)
        return True

    def file_saveas(self):
        if self.bedit and not self.bedit_close():
            return False
        o = self.view.opt; ver = o.get("dxf_version", "R2018")
        filters = ["ALIEF CAD PRO (*.acp)", f"DXF {ver} (*.dxf)", "AutoCAD DWG (*.dwg)", "Rhino 3dm (*.3dm)"]
        sf = o.get("save_format", "")
        fi = 1 if sf.startswith("DXF") else (2 if "DWG" in sf else (3 if "3dm" in sf else 0))
        ext0 = (".acp", ".dxf", ".dwg", ".3dm")[fi]
        start = self.doc.path or getattr(self.doc, "src_path", None)
        start = (os.path.splitext(start)[0] + ext0) if start and not self.doc.path else (start or os.path.join(self._dir(), "Drawing1" + ext0))
        fn, filt = QFileDialog.getSaveFileName(self, "Save drawing as", start, ";;".join(filters), filters[fi])
        if not fn:
            return False
        if not os.path.splitext(fn)[1]:
            fn += (".dxf" if "DXF" in filt else ".dwg" if "DWG" in filt else ".3dm" if "3dm" in filt else ".acp")
        if fn.lower().endswith((".dxf", ".dwg", ".3dm")):
            if not self._write_foreign(fn, None):
                return False
            self.doc.path = fn; self.doc.modified = False; self._title(); self._recent_add(fn)
            return True
        if not fn.lower().endswith(".acp"):
            fn += ".acp"
        self.doc.path = fn
        return self.file_save()

    def _write_foreign(self, fn, ents):
        """Save / export as DWG or Rhino 3dm."""
        ext = os.path.splitext(fn)[1].lower()
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            if ext == ".dxf":
                from ..core import dxfio
                dxfio.export_dxf(self.doc, fn, ents, self.view.opt.get("dxf_version", "R2018")); self.message(f"Saved {fn} (DXF)")
            elif ext == ".3dm":
                from ..core import rhinoio
                if ents is None:
                    n = rhinoio.export_3dm(self.doc, fn)
                else:
                    keep = self.doc.visible_ents; self.doc.visible_ents = lambda: list(ents)
                    try:
                        n = rhinoio.export_3dm(self.doc, fn)
                    finally:
                        self.doc.visible_ents = keep
                self.message(f"Saved {fn} (Rhino 3dm, {n} objects; solids and surfaces are written as meshes)")
            else:
                from ..core import dxfio
                import tempfile
                tmp = os.path.join(tempfile.mkdtemp(prefix="cadpro_dwg_"), os.path.splitext(os.path.basename(fn))[0] + ".dxf")
                dxfio.export_dxf(self.doc, tmp, ents)
                dxfio.dwg_convert(tmp, os.path.dirname(fn), "DWG")
                self.message(f"Saved {fn} (DWG)")
            return True
        except Exception as ex:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Save", f"{fn}\n\n{ex}")
            return False
        finally:
            QApplication.restoreOverrideCursor()

    def file_export(self):
        ver = self.view.opt.get("dxf_version", "R2018")
        fn, filt = QFileDialog.getSaveFileName(self, "Export", self._dir(), f"DXF {ver} (*.dxf);;AutoCAD DWG (*.dwg);;Rhino 3dm (*.3dm);;STL mesh (*.stl);;OBJ mesh (*.obj)")
        if not fn:
            return
        from ..core import dxfio
        ext = os.path.splitext(fn)[1].lower()
        sel = self.selected_ents()
        ents = sel or list(self.doc.ents.values())
        try:
            if ext == ".dxf":
                dxfio.export_dxf(self.doc, fn, ents, ver)
            elif ext in (".dwg", ".3dm"):
                self._write_foreign(fn, ents if sel else None); return
            elif ext in (".stl", ".obj"):
                bodies = [e for e in ents if isinstance(e, E.Body)]
                (dxfio.export_stl if ext == ".stl" else dxfio.export_obj)(fn, bodies)
            self.message(f"Exported {fn}")
        except Exception as ex:
            QMessageBox.warning(self, "Export", str(ex))

    def file_plot(self, state=None):
        """Plot - Model dialog. 'Window<' closes the dialog, asks two corners in the drawing and opens it again."""
        from .plot import PlotDialog
        while True:
            d = PlotDialog(self, self, state)
            r = d.exec()
            if r == PlotDialog.PICK_WINDOW:
                self._plot_state = d.options(); self.run_command("PLOTWINDOW"); return
            if r == 4:                                   # a saved page setup was chosen
                state = d.o; continue
            if r:
                try:
                    fn = d.run()
                except Exception as ex:
                    import traceback; traceback.print_exc()
                    QMessageBox.warning(self, "Plot", f"Plot failed:\n{ex}"); state = d.options(); continue
                if fn:
                    self.message(f"Plotted {fn}")
                    if os.path.isfile(str(fn)):
                        from PySide6.QtGui import QDesktopServices
                        from PySide6.QtCore import QUrl
                        QDesktopServices.openUrl(QUrl.fromLocalFile(fn))
            return

    def file_png(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Save view as PNG", "view.png", "PNG (*.png)")
        if fn:
            self.view.grab_image().save(fn); self.message(f"Saved {fn}")

    def _recent_add(self, fn):
        r = [x for x in (self.settings.value("recent", []) or []) if x != fn]
        r.insert(0, fn); self.settings.setValue("recent", r[:30]); self._recent_refresh()

    def _recent_refresh(self):
        self.recent_menu.clear()
        for f in (self.settings.value("recent", []) or [])[:int(self.view.opt.get("recent_n", 10))]:
            self.recent_menu.addAction(os.path.basename(f), lambda f=f: self.open_path(f))

    def _dir(self):
        d = self.view.opt.get("draw_dir") or ""
        return d if d and os.path.isdir(d) else (self.settings.value("last_dir", "") or "")

    def _autosave(self):
        if self.bedit:
            return
        if self.doc.modified and self.doc.ents:
            from ..core.update import local_root
            try:
                root = self.view.opt.get("autosave_dir") or local_root()
                os.makedirs(root, exist_ok=True)
                d = self.doc; path, mod = d.path, d.modified
                name = (os.path.splitext(os.path.basename(path))[0] if path else "Drawing1") + "_autosave.acp"
                d.save(os.path.join(root, name)); d.path, d.modified = path, mod
            except Exception:
                pass

    def closeEvent(self, ev):
        if self._confirm_all():
            if not (os.environ.get("CADPRO_NO_RESTORE") or os.environ.get("CADPRO_SELFTEST")):
                self._sync_options()
            self._save_layout()
            ev.accept()
        else:
            ev.ignore()

    # =============================================================================== update
    def _boot_ok(self):
        f = self.boot.get("mark_ok")
        if f:
            try:
                f()
            except Exception:
                pass

    def _startup_update(self):
        if self.settings.value("auto_update", True, bool) and not getattr(self, "_upd_busy", False):
            from ..core.update import Checker
            self._upd_busy = True
            Checker(self.version, lambda s, n, i: self.bridge.update_result.emit(s, n, i), True,
                    lambda v, f: self.bridge.update_progress.emit(v, f)).start()

    def _periodic_update(self):
        if getattr(self, "_upd_ready", None) is None:
            self._startup_update()

    def _update_progress(self, v, f):
        self.upd_lbl.setText(f"⬇ {v} {int(f * 100)}%"); self.upd_lbl.setToolTip(f"Downloading update {v} in the background")

    def _whats_new(self):
        """First start after an automatic update: show what changed (once)."""
        try:
            pend = json.loads(self.settings.value("upd/pending", "") or "{}")
        except Exception:
            pend = {}
        if not pend or os.environ.get("CADPRO_SELFTEST") or os.environ.get("TEST_SCRIPT"):
            return
        from ..core.update import vtuple
        if vtuple(self.version) >= vtuple(pend.get("version", "0")):
            self.settings.setValue("upd/pending", "")
            mb = QMessageBox(self); mb.setIcon(QMessageBox.Information); mb.setWindowTitle("ALIEF CAD PRO - updated")
            mb.setText(f"<b>ALIEF CAD PRO has been updated to {self.version}.</b>")
            if pend.get("notes"):
                mb.setInformativeText("What's new:\n" + pend["notes"])
            mb.setModal(False); mb.show(); self._wn_box = mb

    def check_update_manual(self):
        self.update_dialog = DL.UpdateDialog(self, self)
        self.update_dialog.show()
        self.check_update_manual_inner()

    def check_update_manual_inner(self):
        from ..core.update import Checker
        if self.update_dialog:
            self.update_dialog.lbl.setText("Checking aliefen/alief-cadpro-update ...")
        Checker(self.version, lambda s, n, i: self.bridge.update_result.emit(s, n, i), True).start()

    def _update_result(self, status, notice, info):
        self._upd_busy = False
        if self.update_dialog is not None and self.update_dialog.isVisible():
            self.update_dialog.show_status(status, notice, info)
        if status in ("latest", "offline", "badsig"):
            self.upd_lbl.setText(f"v{self.version}"); self.upd_lbl.setToolTip("ALIEF CAD PRO is up to date" if status == "latest" else
                                                                             "Could not check for updates (offline?) - tried again later")
        elif status == "failed":
            self.upd_lbl.setText(f"v{self.version}"); self.upd_lbl.setToolTip(f"Update download failed ({info}) - tried again later")
        if status == "ready":
            v = notice.get("version"); self._upd_ready = v
            try:
                self.settings.setValue("upd/pending", json.dumps({"version": v, "notes": notice.get("notes", "")}))
            except Exception:
                pass
            self.upd_lbl.setText(f"⬆ {v} ready - restart"); self.upd_lbl.setStyleSheet("color:#FFB020; font-weight:600;")
            self.message(f"Update {v} has been installed automatically. It runs after restarting ALIEF CAD PRO.")
            self._notify_update(notice)
        elif status == "available":
            self.upd_lbl.setText(f"⬆ {notice.get('version')} available")

    def _notify_update(self, notice):
        """Pop-up shown once per session when a new version was downloaded and installed in the background."""
        if getattr(self, "_upd_notified", None) == notice.get("version") or os.environ.get("CADPRO_SELFTEST") or os.environ.get("TEST_SCRIPT"):
            return
        if self.update_dialog is not None and self.update_dialog.isVisible():
            return
        self._upd_notified = notice.get("version")
        mb = QMessageBox(self); mb.setIcon(QMessageBox.Information); mb.setWindowTitle("ALIEF CAD PRO - Update")
        mb.setText(f"<b>Update {notice.get('version')} is ready.</b><br>It was downloaded and installed automatically "
                   f"(current version {self.version}). Restart the program to use it.")
        notes = (notice.get("notes") or "").strip()
        if notes:
            mb.setInformativeText(notes)
        b_now = mb.addButton("Restart now", QMessageBox.AcceptRole); mb.addButton("Later", QMessageBox.RejectRole)
        mb.setModal(False)
        mb.finished.connect(lambda _=0: self.restart() if mb.clickedButton() is b_now else None)
        self._upd_box = mb; mb.show()

    def install_update_file(self):
        fn = self.ask_open("Install update from file", "ALIEF CAD PRO update (*.cadpro-update *.zip)")
        if not fn:
            return
        from ..core import update as U
        try:
            n, d = U.install_offline(fn)
            self._upd_notified = n.get("version")
            QMessageBox.information(self, "Update", f"Version {n['version']} installed. Restart ALIEF CAD PRO to use it.")
            self._update_result("ready", n, d)
        except Exception as ex:
            QMessageBox.warning(self, "Update", str(ex))

    def restart(self):
        if not self._confirm_all():
            return
        exe = self.boot.get("restart_cmd")
        import subprocess
        try:
            if exe:
                subprocess.Popen(exe, close_fds=True)
            else:
                subprocess.Popen([sys.executable] + sys.argv, close_fds=True)
        except Exception as ex:
            QMessageBox.warning(self, "Restart", str(ex)); return
        for d in self.docs:
            d.modified = False
        QApplication.quit()
