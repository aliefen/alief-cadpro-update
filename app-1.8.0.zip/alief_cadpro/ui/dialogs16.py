"""Dialogs of version 1.6: Linetype manager, Image Adjust (brightness / contrast / fade), Import PDF, MTEXT editor, Plot."""
import math
import numpy as np
from PySide6.QtCore import Qt, QPointF, QRectF, QSize, QTimer
from PySide6.QtGui import QPainter, QPen, QColor, QFont, QImage, QPixmap, QIcon
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QLabel, QComboBox, QDoubleSpinBox, QSpinBox,
                               QCheckBox, QPushButton, QDialogButtonBox, QListWidget, QListWidgetItem, QLineEdit, QGroupBox, QSlider,
                               QWidget, QRadioButton, QFileDialog, QMessageBox)


class _Dlg(QDialog):
    def __init__(self, parent, title, w=520):
        super().__init__(parent); self.setWindowTitle(title); self.setMinimumWidth(w)
        self.v = QVBoxLayout(self)

    def buttons(self, ok="OK", extra=()):
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText(ok); bb.button(QDialogButtonBox.Ok).setObjectName("primary")
        for text, fn in extra:
            b = bb.addButton(text, QDialogButtonBox.ActionRole); b.clicked.connect(fn)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); self.v.addWidget(bb)
        self.bb = bb
        return bb


def _dspin(v, lo, hi, dec=3, step=1.0):
    s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec); s.setSingleStep(step); s.setValue(float(v)); return s


# =========================================================================================== linetypes
def linetype_icon(pat, w=150, h=16):
    pm = QPixmap(w, h); pm.fill(Qt.transparent)
    p = QPainter(pm); pen = QPen(QColor("#E6EBF2"), 1.6)
    if pat:
        k = 1.6; d = []
        for v in pat:
            d.append(max(abs(v) * k / 1.6, 0.8) if v != 0 else 0.8)
        if len(d) % 2:
            d.append(2.0)
        pen.setDashPattern(d)
    p.setPen(pen); p.drawLine(4, h // 2, w - 4, h // 2); p.end()
    return QIcon(pm)


class LinetypeDialog(_Dlg):
    """Linetype manager: the linetypes, current linetype, global scale factor (LTSCALE) and current object scale (CELTSCALE)."""
    def __init__(self, app):
        from ..core.document import LINETYPES
        super().__init__(app, "Linetype Manager", 520); self.app = app; doc = app.doc
        self.lst = QListWidget(); self.lst.setIconSize(QSize(150, 16))
        from ..core.document import LT_DESC
        for name in ["ByLayer"] + list(LINETYPES):
            it = QListWidgetItem(linetype_icon(LINETYPES.get(name)), f"{name:<12}{LT_DESC.get(name, '')}"); it.setData(Qt.UserRole, name)
            f = it.font(); f.setFamily("Consolas"); it.setFont(f); self.lst.addItem(it)
            if name == (doc.cur_ltype or "ByLayer"):
                self.lst.setCurrentItem(it)
        self.v.addWidget(QLabel("Linetype of new objects (current):")); self.v.addWidget(self.lst, 1)
        g = QGroupBox("Details"); f = QFormLayout(g)
        self.gs = _dspin(doc.settings.get("ltscale", 1.0), 1e-6, 1e9, 4, 0.5); f.addRow("Global scale factor (LTSCALE)", self.gs)
        self.cs = _dspin(getattr(doc, "cur_lts", 1.0), 1e-6, 1e9, 4, 0.1); f.addRow("Current object scale (CELTSCALE)", self.cs)
        sel = app.selected_ents()
        self.os = None
        if sel:
            self.os = _dspin(sel[0].lts, 1e-6, 1e9, 4, 0.1); f.addRow(f"Linetype scale of the {len(sel)} selected object(s)", self.os)
        f.addRow(QLabel("Dash lengths are in drawing units: a DASHED line is 12.7 on / 6.35 off, multiplied by the scale.\n"
                        "Dashes too small or too large for an object are drawn as a continuous line."))
        self.v.addWidget(g)
        self.buttons("OK")

    def apply(self):
        doc = self.app.doc
        doc.settings["ltscale"] = float(self.gs.value()); doc.cur_lts = float(self.cs.value())
        it = self.lst.currentItem()
        if it is not None:
            doc.cur_ltype = it.data(Qt.UserRole) or it.text().split()[0]
        if self.os is not None:
            sel = self.app.selected_ents(); v = float(self.os.value())
            if any(abs(e.lts - v) > 1e-12 for e in sel):
                doc.begin("linetype scale")
                for e in sel:
                    doc.modify(e); e.lts = v; e.touch()
                doc.end()


# =========================================================================================== image adjust
class ImageAdjustDialog(_Dlg):
    """Image Adjust like AutoCAD / GstarCAD: Brightness (Dark - Tint), Contrast (Low - High), Fade (Min - Max), each 0 - 100,
    with a preview; the drawing follows the sliders."""
    def __init__(self, app, e):
        super().__init__(app, "Image Adjust", 560); self.app = app; self.e = e
        self.before = (e.brightness, e.contrast, e.fade)
        h = QHBoxLayout(); self.v.addLayout(h)
        left = QVBoxLayout(); h.addLayout(left, 1)
        self.sl = {}; self.sp = {}
        for key, title, lo, hi, val in (("b", "Brightness", "Dark", "Tint", 50 + e.brightness / 2.0), ("c", "Contrast", "Low", "High", 50 + e.contrast / 2.0),
                                        ("f", "Fade", "Min", "Max", e.fade * 100.0)):
            g = QGroupBox(title); r = QHBoxLayout(g)
            s = QSlider(Qt.Horizontal); s.setRange(0, 100); s.setTickPosition(QSlider.TicksAbove); s.setTickInterval(10); s.setValue(int(round(val))); s.setMinimumWidth(170)
            sp = QSpinBox(); sp.setRange(0, 100); sp.setValue(int(round(val)))
            s.valueChanged.connect(sp.setValue); sp.valueChanged.connect(s.setValue); s.valueChanged.connect(self._changed)
            r.addWidget(QLabel(lo)); r.addWidget(s, 1); r.addWidget(QLabel(hi)); r.addWidget(sp)
            left.addWidget(g); self.sl[key] = s; self.sp[key] = sp
        g = QGroupBox(getattr(e, "name", "image")[:28]); gv = QVBoxLayout(g)
        self.prev = QLabel(); self.prev.setFixedSize(190, 190); self.prev.setAlignment(Qt.AlignCenter); self.prev.setStyleSheet("background:#222831;")
        gv.addWidget(self.prev); h.addWidget(g)
        img = QImage.fromData(e.data)
        self.thumb = None
        if not img.isNull():
            self.thumb = img.scaled(186, 186, Qt.KeepAspectRatio, Qt.SmoothTransformation).convertToFormat(QImage.Format_RGBA8888)
        self.timer = QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(140); self.timer.timeout.connect(self._live)
        self.buttons("OK", extra=[("Reset", self._reset)])
        self._preview()

    def _reset(self):
        self.sl["b"].setValue(50); self.sl["c"].setValue(50); self.sl["f"].setValue(0)

    def values(self):
        """(brightness -100..100, contrast -100..100, fade 0..0.97) as stored in the image."""
        return (float(self.sl["b"].value() - 50) * 2.0, float(self.sl["c"].value() - 50) * 2.0, min(0.97, self.sl["f"].value() / 100.0))

    def _changed(self, *a):
        self._preview(); self.timer.start()

    def _preview(self):
        if self.thumb is None:
            return
        from .viewport import adjust_rgba
        b, c, f = self.values(); t = self.thumb
        buf = np.frombuffer(t.constBits(), np.uint8, t.sizeInBytes()).reshape(t.height(), t.bytesPerLine())[:, :t.width() * 4].reshape(t.height(), t.width(), 4)
        out = adjust_rgba(buf, b, c).astype(np.float32)
        bg = np.array([34, 40, 49], np.float32)
        out[..., :3] = out[..., :3] * (1 - f) + bg * f
        out = np.ascontiguousarray(out.astype(np.uint8))
        q = QImage(out.data, t.width(), t.height(), t.width() * 4, QImage.Format_RGBA8888).copy()
        self.prev.setPixmap(QPixmap.fromImage(q))

    def _live(self):
        self.e.brightness, self.e.contrast, self.e.fade = self.values()
        self.e.touch(); self.app.doc.rev += 1
        for vw in getattr(self.app, "views", [self.app.view]):
            vw.update()


# =========================================================================================== Import PDF
class PdfImportDialog(_Dlg):
    """Import PDF: page, location, data to import, layers and import options (import as block, join segments ...)."""
    def __init__(self, app, path):
        from ..core import pdfimport as PI
        super().__init__(app, "Import PDF", 820); self.PI = PI; self.app = app; self.path = path
        o = app.view.opt.get("pdf_import", {}) or {}
        top = QHBoxLayout(); self.v.addLayout(top)
        top.addWidget(QLabel("File name:")); self.fn = QLineEdit(path); self.fn.setReadOnly(True); top.addWidget(self.fn, 1)
        b = QPushButton("Browse..."); b.clicked.connect(self._browse); top.addWidget(b)
        h = QHBoxLayout(); self.v.addLayout(h)
        # ---- left: page
        g = QGroupBox("Page to import"); gv = QVBoxLayout(g); h.addWidget(g, 1)
        r = QHBoxLayout(); gv.addLayout(r)
        self.page = QSpinBox(); self.page.setRange(1, 1); r.addWidget(QLabel("Page:")); r.addWidget(self.page)
        self.total = QLabel("Total: 1"); r.addWidget(self.total); r.addStretch(1)
        self.thumb = QLabel(); self.thumb.setMinimumSize(380, 400); self.thumb.setAlignment(Qt.AlignCenter); self.thumb.setStyleSheet("background:#808080;")
        gv.addWidget(self.thumb, 1)
        self.info = QLabel(); gv.addWidget(self.info)
        # ---- right
        right = QVBoxLayout(); h.addLayout(right)
        g = QGroupBox("Location"); f = QFormLayout(g); right.addWidget(g)
        self.onscreen = QCheckBox("Specify insertion point on-screen"); self.onscreen.setChecked(bool(o.get("onscreen", True))); f.addRow(self.onscreen)
        self.scale = QComboBox(); self.scale.setEditable(True)
        self.scale.addItems(["1:1", "1:2", "1:5", "1:10", "1:20", "1:25", "1:50", "1:75", "1:100", "1:125", "1:150", "1:200", "1:250", "1:500", "1:1000"])
        self.scale.setCurrentText(o.get("scale_txt", "1:1")); self.scale.setToolTip("Drawing scale printed on the PDF: 1:100 makes 1 mm on paper = 100 units")
        f.addRow("Scale:", self.scale)
        self.rot = _dspin(o.get("rotation", 0.0), -360, 360, 4, 90); f.addRow("Rotation:", self.rot)
        rr = QHBoxLayout(); right.addLayout(rr)
        g = QGroupBox("PDF data to import"); gv2 = QVBoxLayout(g); rr.addWidget(g)
        self.vec = QCheckBox("Vector geometry"); self.vec.setChecked(bool(o.get("vectors", True)))
        self.fill = QCheckBox("    Solid fills"); self.fill.setChecked(bool(o.get("fills", False)))
        self.txt = QCheckBox("TrueType text"); self.txt.setChecked(bool(o.get("texts", True)))
        self.img = QCheckBox("Raster images"); self.img.setChecked(bool(o.get("images", False)))
        self.ras = QCheckBox("Whole page as one image"); self.ras.setChecked(False); self.ras.setToolTip("For a scanned PDF: the page becomes an underlay image (then use AUTOTRACE or redraw over it)")
        for wdg in (self.vec, self.fill, self.txt, self.img, self.ras):
            gv2.addWidget(wdg)
        g = QGroupBox("Layers"); gv3 = QVBoxLayout(g); rr.addWidget(g)
        self.lay = {}
        for key, text in (("pdf", "Use PDF layers"), ("object", "Create object layers"), ("current", "Current layer")):
            rb = QRadioButton(text); gv3.addWidget(rb); self.lay[key] = rb
        self.lay.get(o.get("layers", "pdf"), self.lay["pdf"]).setChecked(True)
        self.lay["pdf"].setToolTip("PDF_<colour / weight> layers as found in the file"); self.lay["object"].setToolTip("PDF_Geometry, PDF_Text, PDF_Solid Fills, PDF_Images")
        gv3.addStretch(1)
        g = QGroupBox("Import options"); gv4 = QVBoxLayout(g); right.addWidget(g)
        self.blk = QCheckBox("Import as block"); self.blk.setChecked(bool(o.get("as_block", True)))
        self.blk.setToolTip("The page becomes one block reference: light to work with and easy to select, move or erase as a whole.\nEXPLODE it when you need the single lines.")
        self.join = QCheckBox("Join line and arc segments"); self.join.setChecked(bool(o.get("join", True)))
        self.hatch = QCheckBox("Convert solid fills to hatches"); self.hatch.setChecked(bool(o.get("hatch", True)))
        self.lw = QCheckBox("Apply lineweight properties"); self.lw.setChecked(bool(o.get("lw", True)))
        self.infer = QCheckBox("Infer linetypes from collinear dashes"); self.infer.setChecked(bool(o.get("infer", False)))
        for wdg in (self.blk, self.join, self.hatch, self.lw, self.infer):
            gv4.addWidget(wdg)
        f2 = QFormLayout(); gv4.addLayout(f2)
        self.dpi = QSpinBox(); self.dpi.setRange(72, 600); self.dpi.setValue(int(o.get("dpi", 200))); f2.addRow("Raster resolution (dpi)", self.dpi)
        right.addStretch(1)
        self.fill.setEnabled(self.vec.isChecked()); self.vec.toggled.connect(self.fill.setEnabled)
        self.page.valueChanged.connect(self._thumb)
        self._load()
        self.buttons("OK")

    def _browse(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Import PDF", self.path, "PDF (*.pdf)")
        if fn:
            self.path = fn; self.fn.setText(fn); self._load()

    def _load(self):
        try:
            n = self.PI.page_count(self.path)
        except Exception as ex:
            self.info.setText(str(ex)); n = 1
        self.page.blockSignals(True); self.page.setRange(1, max(1, n)); self.page.setValue(1); self.page.blockSignals(False)
        self.total.setText(f"Total: {n}"); self._thumb()

    def _thumb(self):
        try:
            png, (w, h) = self.PI.page_thumb(self.path, self.page.value() - 1, 380)
            pm = QPixmap(); pm.loadFromData(png); self.thumb.setPixmap(pm.scaled(380, 400, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            self.info.setText(f"Page size:  {w:.0f} x {h:.0f} mm          PDF scale:  {self.scale.currentText()}")
        except Exception as ex:
            self.info.setText(str(ex))

    def result(self):
        t = self.scale.currentText().strip().replace(" ", "")
        try:
            if ":" in t:
                a, b = t.split(":"); sc = float(b) / float(a)
            else:
                sc = float(t)
        except Exception:
            sc = 1.0
        lay = next((k for k, rb in self.lay.items() if rb.isChecked()), "pdf")
        r = dict(path=self.path, page=self.page.value() - 1, scale=sc, scale_txt=t, vectors=self.vec.isChecked(), texts=self.txt.isChecked(),
                 fills=self.vec.isChecked() and self.fill.isChecked(), images=self.img.isChecked(), raster=self.ras.isChecked(),
                 dpi=self.dpi.value(), onscreen=self.onscreen.isChecked(), rotation=float(self.rot.value()), layers=lay,
                 as_block=self.blk.isChecked(), join=self.join.isChecked(), hatch=self.hatch.isChecked(), lw=self.lw.isChecked(),
                 infer=self.infer.isChecked())
        self.app.view.opt["pdf_import"] = {k: v for k, v in r.items() if k not in ("path", "page", "raster")}
        try:
            from . import options as OPT
            OPT.save(self.app.settings, self.app.view.opt)
        except Exception:
            pass
        return r


# =========================================================================================== MTEXT editor
_BASEPT = 16.0
_P_OBL = 0x100000 + 1          # QTextFormat.UserProperty + n
_P_STACK = 0x100000 + 2


class MTextEditor(_Dlg):
    """Multiline text editor with the Text Formatting toolbar: font, height, bold / italic / underline / overline / strike,
    colour, stack, justification, paragraph alignment, line spacing, numbering, case, super / subscript, symbols,
    oblique angle, tracking and width factor.  The text is stored with the standard MTEXT formatting codes."""
    ATTACH = [("Top Left", "TL", 0, 3), ("Top Center", "TC", 1, 3), ("Top Right", "TR", 2, 3), ("Middle Left", "ML", 0, 2),
              ("Middle Center", "MC", 1, 2), ("Middle Right", "MR", 2, 2), ("Bottom Left", "BL", 0, 1), ("Bottom Center", "BC", 1, 1),
              ("Bottom Right", "BR", 2, 1)]
    SYMBOLS = [("Degrees  %%d", "°"), ("Plus / Minus  %%p", "±"), ("Diameter  %%c", "Ø"), ("Almost equal", "≈"), ("Angle", "∠"),
               ("Delta", "Δ"), ("Omega", "Ω"), ("Center line", "℄"), ("Not equal", "≠"), ("Squared", "²"), ("Cubed", "³"),
               ("Less or equal", "≤"), ("Greater or equal", "≥"), ("Non-breaking space", " ")]

    def __init__(self, app, rich="", height=2.5, font="Arial", halign=0, valign=3, lsf=1.0, title="Text Formatting", width=0.0,
                 anno_k=None, on_change=None):
        """height = text height in drawing units (the same value as Height in Properties); anno_k = drawing scale of an
        annotative text (the paper height is height / anno_k); width = mtext box width (0 = no wrap);
        on_change(result) is called while typing (live preview in the drawing)."""
        from PySide6.QtWidgets import QTextEdit, QFontComboBox, QToolButton, QMenu, QToolBar
        from PySide6.QtGui import QTextCharFormat, QTextCursor, QAction, QKeySequence
        super().__init__(app, title, 880); self.app = app
        self.base_h = float(height) if height and height > 0 else 2.5; self.base_font = font or "Arial"
        self.halign, self.valign = int(halign), int(valign if valign in (1, 2, 3) else 3)
        self.ed = QTextEdit(); self.ed.setAcceptRichText(False); self.ed.setMinimumHeight(260)
        self.ed.setStyleSheet("QTextEdit{background:#262d38; color:#ffffff; border:1px solid #4a5568; selection-background-color:#2E86C1;}")
        bf = QFont(self.base_font); bf.setPointSizeF(_BASEPT); self.ed.document().setDefaultFont(bf); self.ed.setFont(bf)
        tb1 = QToolBar(); tb2 = QToolBar(); self.v.addWidget(tb1); self.v.addWidget(tb2); self.v.addWidget(self.ed, 1)
        def tbtn(bar, text, tip, fn, checkable=False, bold=False, italic=False, under=False, width=30):
            b = QToolButton(); b.setText(text); b.setToolTip(tip); b.setCheckable(checkable); b.setMinimumWidth(width); b.setFocusPolicy(Qt.NoFocus)
            f = b.font(); f.setBold(bold); f.setItalic(italic); f.setUnderline(under); f.setPointSize(10); b.setFont(f)
            (b.toggled if checkable else b.clicked).connect(fn); bar.addWidget(b); return b
        # ---- row 1
        self.fontbox = QFontComboBox(); self.fontbox.setCurrentFont(QFont(self.base_font)); self.fontbox.setMaximumWidth(190)
        self.fontbox.currentFontChanged.connect(lambda f: self._fmt(lambda c: c.setFontFamilies([f.family()])))
        tb1.addWidget(self.fontbox)
        self.anno_k = float(anno_k) if anno_k else None
        self.hbox = QComboBox(); self.hbox.setEditable(True); self.hbox.setMinimumWidth(92)
        self.hbox.setToolTip("Text height in drawing units - the same value as Height in Properties"
                             + (f"\nAnnotative: paper height x drawing scale 1:{self.anno_k:g}" if self.anno_k else ""))
        k_ = self.anno_k or 1.0
        hs = sorted({round(x * k_, 6) for x in (1.8, 2.5, 3.5, 5.0, 7.0, 10.0, 14.0, 20.0)} | {round(self.base_h, 6)})
        self.hbox.addItems([f"{x:g}" for x in hs]); self.hbox.setCurrentText(f"{self.base_h:g}")
        self.hbox.activated.connect(self._height); self.hbox.lineEdit().editingFinished.connect(self._height)
        tb1.addWidget(self.hbox)
        self.paper_lbl = QLabel(""); self.paper_lbl.setStyleSheet("color:#9AA6B6; padding:0 6px"); tb1.addWidget(self.paper_lbl)
        self.bB = tbtn(tb1, "B", "Bold (Ctrl+B)", lambda v: self._fmt(lambda c: c.setFontWeight(QFont.Bold if v else QFont.Normal)), True, bold=True)
        self.bI = tbtn(tb1, "I", "Italic (Ctrl+I)", lambda v: self._fmt(lambda c: c.setFontItalic(v)), True, italic=True)
        self.bK = tbtn(tb1, "abc", "Strikethrough", lambda v: self._fmt(lambda c: c.setFontStrikeOut(v)), True, width=38)
        f_ = self.bK.font(); f_.setStrikeOut(True); self.bK.setFont(f_)
        self.bU = tbtn(tb1, "U", "Underline (Ctrl+U)", lambda v: self._fmt(lambda c: c.setFontUnderline(v)), True, under=True)
        self.bO = tbtn(tb1, "O", "Overline", lambda v: self._fmt(lambda c: c.setFontOverline(v)), True)
        f_ = self.bO.font(); f_.setOverline(True); self.bO.setFont(f_)
        self.cbtn = QToolButton(); self.cbtn.setText("Color"); self.cbtn.setPopupMode(QToolButton.InstantPopup); self.cbtn.setToolTip("Text colour")
        cm = QMenu(self.cbtn)
        from .viewport import resolve_rgb
        from ..core.aci import aci_rgb
        cm.addAction("ByLayer", lambda: self._color(None))
        for idx, nm in ((1, "Red"), (2, "Yellow"), (3, "Green"), (4, "Cyan"), (5, "Blue"), (6, "Magenta"), (7, "White"), (8, "Gray"), (30, "Orange")):
            pm = QPixmap(14, 14); r_, g_, b_ = resolve_rgb(idx, False); pm.fill(QColor(int(r_ * 255), int(g_ * 255), int(b_ * 255)))
            cm.addAction(QIcon(pm), nm, lambda idx=idx: self._color(idx))
        cm.addAction("Select colour ...", self._pick_color)
        self.cbtn.setMenu(cm); tb1.addWidget(self.cbtn)
        tb1.addSeparator()
        tbtn(tb1, "↶", "Undo (Ctrl+Z)", self.ed.undo); tbtn(tb1, "↷", "Redo (Ctrl+Y)", self.ed.redo)
        tbtn(tb1, "a/b", "Stack / unstack the selected text:  1/2 fraction,  1#2 diagonal,  +0.1^-0.2 tolerance", self._stack, width=36)
        tb1.addSeparator()
        ok = QToolButton(); ok.setText("  OK  "); ok.setObjectName("primary"); ok.clicked.connect(self.accept); ok.setToolTip("Save the text and close (Ctrl+Enter)")
        tb1.addWidget(ok)
        # ---- row 2
        self.jbtn = QToolButton(); self.jbtn.setPopupMode(QToolButton.InstantPopup); self.jbtn.setToolTip("MText justification (attachment point)")
        jm = QMenu(self.jbtn); self.jacts = []
        for name, code, ha, va in self.ATTACH:
            a = jm.addAction(f"{name}\t{code}"); a.setCheckable(True); a.triggered.connect(lambda _=False, ha=ha, va=va: self._attach(ha, va)); self.jacts.append((a, ha, va, code))
        self.jbtn.setMenu(jm); tb2.addWidget(self.jbtn)
        self.pal = []
        for txt, tip, al in (("≡L", "Left", Qt.AlignLeft), ("≡C", "Center", Qt.AlignHCenter), ("≡R", "Right", Qt.AlignRight), ("≡J", "Justify", Qt.AlignJustify)):
            self.pal.append((tbtn(tb2, txt, f"Paragraph: {tip}", lambda _=False, al=al: self._palign(al), width=36), al))
        self.lsbox = QComboBox(); self.lsbox.setToolTip("Line spacing"); self.lsbox.setEditable(True)
        self.lsbox.addItems(["1.0x", "1.5x", "2.0x", "2.5x"]); self.lsbox.setCurrentText(f"{float(lsf):g}x" if float(lsf) not in (1.0, 1.5, 2.0, 2.5) else f"{float(lsf):.1f}x")
        tb2.addWidget(QLabel(" Line spacing ")); tb2.addWidget(self.lsbox)
        nb = QToolButton(); nb.setText("1. •"); nb.setPopupMode(QToolButton.InstantPopup); nb.setToolTip("Numbering and bullets for the selected paragraphs")
        nm_ = QMenu(nb)
        for label, kind in (("Numbered  1. 2. 3.", "num"), ("Lettered  a. b. c.", "low"), ("Uppercase  A. B. C.", "up"), ("Bulleted  •", "bul"), ("Off", "off")):
            nm_.addAction(label, lambda kind=kind: self._number(kind))
        nb.setMenu(nm_); tb2.addWidget(nb)
        tb2.addSeparator()
        tbtn(tb2, "aA", "UPPERCASE", lambda: self._case(True)); tbtn(tb2, "Aa", "lowercase", lambda: self._case(False))
        tbtn(tb2, "X²", "Superscript", lambda: self._valign(1)); tbtn(tb2, "X₂", "Subscript", lambda: self._valign(2))
        sb = QToolButton(); sb.setText("@"); sb.setPopupMode(QToolButton.InstantPopup); sb.setToolTip("Symbol")
        sm = QMenu(sb)
        for label, ch in self.SYMBOLS:
            sm.addAction(f"{ch}    {label}", lambda ch=ch: self.ed.insertPlainText(ch))
        sb.setMenu(sm); tb2.addWidget(sb)
        tb2.addSeparator()
        self.obl = _dspin(0, -85, 85, 1, 5); self.obl.setToolTip("Oblique angle"); self.obl.setPrefix("0/ ")
        self.obl.valueChanged.connect(lambda v: self._fmt(lambda c: c.setProperty(_P_OBL, float(v))))
        self.trk = _dspin(1, 0.75, 4, 2, 0.1); self.trk.setToolTip("Tracking (letter spacing)"); self.trk.setPrefix("a-b ")
        self.trk.valueChanged.connect(lambda v: self._fmt(lambda c: (c.setFontLetterSpacingType(QFont.PercentageSpacing), c.setFontLetterSpacing(v * 100.0))))
        self.wfs = _dspin(1, 0.1, 10, 2, 0.1); self.wfs.setToolTip("Width factor"); self.wfs.setPrefix("O ")
        self.wfs.valueChanged.connect(lambda v: self._fmt(lambda c: c.setFontStretch(int(round(v * 100)))))
        for wdg in (self.obl, self.trk, self.wfs):
            wdg.setMaximumWidth(108); tb2.addWidget(wdg)
        tb2.addSeparator()
        self.wbox = _dspin(max(0.0, float(width or 0.0)), 0.0, 1.0e9, 3, max(1.0, self.base_h)); self.wbox.setPrefix("Width ")
        self.wbox.setToolTip("Width of the MTEXT box in drawing units (word wrap); 0 = no wrapping.\nIn the drawing: select the text and drag its width grip.")
        self.wbox.setSpecialValueText("Width: no wrap"); self.wbox.setMinimumWidth(150); tb2.addWidget(self.wbox)
        self.wbox.valueChanged.connect(lambda _v: self._changed())
        self.hint = QLabel("Enter = new line  |  Ctrl+Enter = OK  |  select text, then use the toolbar  |  type 1/2 and press a/b to stack")
        self.hint.setStyleSheet("color:#9AA6B6"); self.v.addWidget(self.hint)
        self.buttons("OK")
        for seq, btn in (("Ctrl+B", self.bB), ("Ctrl+I", self.bI), ("Ctrl+U", self.bU)):
            a = QAction(self); a.setShortcut(QKeySequence(seq)); a.triggered.connect(btn.toggle); self.addAction(a)
        a = QAction(self); a.setShortcuts([QKeySequence("Ctrl+Return"), QKeySequence("Ctrl+Enter")]); a.triggered.connect(self.accept); self.addAction(a)
        self.on_change = on_change
        self._load(rich)
        self._attach(self.halign, self.valign, apply=False)
        self.ed.cursorPositionChanged.connect(self._sync); self._sync()
        self.ed.textChanged.connect(self._changed); self._paper_label()
        self.ed.setFocus()

    def _paper_label(self):
        if self.anno_k:
            self.paper_lbl.setText(f"= {self.base_h / self.anno_k:g} mm on paper (1:{self.anno_k:g})")
        else:
            self.paper_lbl.setText("")

    def _changed(self):
        """Live preview of the text in the drawing while it is typed."""
        if self.on_change is None or getattr(self, "_busy", False):
            return
        try:
            self.on_change(self.result())
        except Exception:
            pass

    # ---------------------------------------------------------------- formatting actions
    def _fmt(self, fn):
        from PySide6.QtGui import QTextCharFormat
        if getattr(self, "_busy", False):
            return
        c = QTextCharFormat(); fn(c)
        self.ed.mergeCurrentCharFormat(c); self.ed.setFocus()

    def _height(self, *a):
        try:
            h = float(self.hbox.currentText().replace(",", "."))
        except ValueError:
            return
        if h <= 0:
            return
        cur = self.ed.textCursor()
        if not cur.hasSelection() and self.ed.document().isEmpty():
            self.base_h = h; self._paper_label(); self._changed(); return
        if not cur.hasSelection() and abs(h - self.base_h) > 1e-9 and self._all_default_size():
            self.base_h = h; self._paper_label(); self._changed(); return      # nothing selected, no mixed sizes: height of the whole text
        self._fmt(lambda c: c.setFontPointSize(_BASEPT * min(12.0, max(0.12, h / self.base_h))))

    def _all_default_size(self):
        b = self.ed.document().begin()
        while b.isValid():
            it = b.begin()
            while not it.atEnd():
                ps = it.fragment().charFormat().fontPointSize()
                if ps and abs(ps - _BASEPT) > 0.01:
                    return False
                it += 1
            b = b.next()
        return True

    def _color(self, c):
        from PySide6.QtGui import QTextCharFormat, QBrush
        from .viewport import resolve_rgb
        f = QTextCharFormat()
        if c is None:
            f.setForeground(QBrush(QColor("#ffffff"))); f.setProperty(_P_STACK + 5, "bylayer")
        else:
            if isinstance(c, str):
                col = QColor(c)
            else:
                r, g, b = resolve_rgb(c, False); col = QColor(int(r * 255), int(g * 255), int(b * 255))
            f.setForeground(QBrush(col)); f.setProperty(_P_STACK + 5, c if isinstance(c, str) else int(c))
        self.ed.mergeCurrentCharFormat(f); self.ed.setFocus()

    def _pick_color(self):
        from PySide6.QtWidgets import QColorDialog
        col = QColorDialog.getColor(QColor("white"), self)
        if col.isValid():
            self._color(col.name())

    def _stack(self):
        import re
        from PySide6.QtGui import QTextCharFormat
        cur = self.ed.textCursor()
        if not cur.hasSelection():
            return
        f = cur.charFormat(); st = f.property(_P_STACK)
        if st:                                              # unstack
            top, bot, kind = str(st).split("\x1f"); g = QTextCharFormat(f); g.clearProperty(_P_STACK); g.setFontPointSize(f.fontPointSize() or _BASEPT)
            cur.insertText(top + ("^" if kind == "^" else kind) + bot, g); return
        t = cur.selectedText()
        m = re.match(r"^(.*?)([/#^])(.*)$", t)
        if not m:
            return
        g = QTextCharFormat(f); g.setProperty(_P_STACK, "\x1f".join([m.group(1), m.group(3), m.group(2)]))
        g.setBackground(QColor(60, 80, 110))
        cur.insertText(m.group(1) + ("/" if m.group(2) != "^" else "^") + m.group(3), g)
        n = QTextCharFormat(f); n.clearProperty(_P_STACK); n.clearBackground()      # what is typed next is ordinary text again
        self.ed.setTextCursor(cur); self.ed.setCurrentCharFormat(n)

    def _valign(self, v):
        from PySide6.QtGui import QTextCharFormat
        cur = self.ed.textCursor().charFormat().verticalAlignment()
        want = QTextCharFormat.AlignSuperScript if v == 1 else QTextCharFormat.AlignSubScript
        self._fmt(lambda c: c.setVerticalAlignment(QTextCharFormat.AlignNormal if cur == want else want))

    def _case(self, up):
        cur = self.ed.textCursor()
        if not cur.hasSelection():
            return
        a, b = cur.selectionStart(), cur.selectionEnd(); doc = self.ed.document()
        cur.beginEditBlock()
        for pos in range(a, b):
            c2 = self.ed.textCursor(); c2.setPosition(pos); c2.setPosition(pos + 1, c2.MoveMode.KeepAnchor)
            ch = c2.selectedText()
            if ch and ch not in (" ", " "):
                n = ch.upper() if up else ch.lower()
                if n != ch and len(n) == 1:
                    c2.insertText(n, c2.charFormat())
        cur.endEditBlock()

    def _palign(self, al):
        self.ed.setAlignment(al); self._sync(); self.ed.setFocus()

    def _attach(self, ha, va, apply=True):
        self.halign, self.valign = ha, va
        for a, h, v, code in self.jacts:
            a.setChecked(h == ha and v == va)
            if h == ha and v == va:
                self.jbtn.setText(f"Justify: {code}")
        if apply:
            self._changed()

    def _number(self, kind):
        import re
        cur = self.ed.textCursor(); doc = self.ed.document()
        b0 = doc.findBlock(cur.selectionStart()); b1 = doc.findBlock(cur.selectionEnd())
        cur.beginEditBlock(); n = 0; b = b0
        while b.isValid():
            n += 1
            c2 = self.ed.textCursor(); c2.setPosition(b.position())
            m = re.match(r"^(\d+\.|[A-Za-z]\.|•)\s+", b.text())
            if m:
                c2.setPosition(b.position() + len(m.group(0)), c2.MoveMode.KeepAnchor); c2.removeSelectedText()
            pre = {"num": f"{n}. ", "low": f"{chr(96 + min(n, 26))}. ", "up": f"{chr(64 + min(n, 26))}. ", "bul": "• ", "off": ""}[kind]
            if pre:
                c2.insertText(pre)
            if b == b1:
                break
            b = b.next()
        cur.endEditBlock()

    def _sync(self):
        """Toolbar shows the format at the cursor."""
        from PySide6.QtGui import QTextCharFormat
        self._busy = True
        try:
            f = self.ed.currentCharFormat()
            if f.property(_P_STACK) and not self.ed.textCursor().hasSelection():
                n = QTextCharFormat(f); n.clearProperty(_P_STACK); n.clearBackground()   # typing next to stacked text gives ordinary text
                self.ed.setCurrentCharFormat(n); f = n
            for btn, v in ((self.bB, f.fontWeight() >= QFont.Bold), (self.bI, f.fontItalic()), (self.bU, f.fontUnderline()), (self.bO, f.fontOverline()),
                           (self.bK, f.fontStrikeOut())):
                btn.blockSignals(True); btn.setChecked(bool(v)); btn.blockSignals(False)
            fam = (f.fontFamilies() or [self.base_font]); fam = fam[0] if isinstance(fam, (list, tuple)) and fam else self.base_font
            self.fontbox.blockSignals(True); self.fontbox.setCurrentFont(QFont(fam)); self.fontbox.blockSignals(False)
            ps = f.fontPointSize() or _BASEPT
            self.hbox.blockSignals(True); self.hbox.setCurrentText(f"{self.base_h * ps / _BASEPT:g}"); self.hbox.blockSignals(False)
            for sp, v in ((self.obl, float(f.property(_P_OBL) or 0.0)), (self.trk, (f.fontLetterSpacing() or 100.0) / 100.0), (self.wfs, (f.fontStretch() or 100) / 100.0)):
                sp.blockSignals(True); sp.setValue(v); sp.blockSignals(False)
            al = self.ed.alignment()
            for btn, a in self.pal:
                btn.setDown(bool(al & a))
        finally:
            self._busy = False

    # ---------------------------------------------------------------- MTEXT codes <-> document
    def _load(self, rich):
        from PySide6.QtGui import QTextCharFormat, QTextCursor, QTextBlockFormat, QBrush
        from ..core import mtext as MT
        from .viewport import resolve_rgb
        doc = self.ed.document(); doc.clear()
        cur = QTextCursor(doc); first = True
        for para in MT.parse(rich or "", None):
            bf = QTextBlockFormat()
            al = para.align if para.align is not None else self.halign
            bf.setAlignment({0: Qt.AlignLeft, 1: Qt.AlignHCenter, 2: Qt.AlignRight, 3: Qt.AlignJustify}.get(al, Qt.AlignLeft))
            if first:
                cur.setBlockFormat(bf); first = False
            else:
                cur.insertBlock(bf)
            for r in para.runs:
                f = r.fmt; c = QTextCharFormat()
                c.setFontFamilies([f.font or self.base_font]); c.setFontWeight(QFont.Bold if f.bold else QFont.Normal); c.setFontItalic(f.italic)
                c.setFontUnderline(f.under); c.setFontOverline(f.over); c.setFontStrikeOut(f.strike)
                hf = (f.habs / self.base_h) if f.habs else f.hf
                c.setFontPointSize(_BASEPT * hf)
                if f.color is not None:
                    if isinstance(f.color, str):
                        col = QColor(f.color)
                    else:
                        rr, gg, bb = resolve_rgb(f.color, False); col = QColor(int(rr * 255), int(gg * 255), int(bb * 255))
                    c.setForeground(QBrush(col)); c.setProperty(_P_STACK + 5, f.color)
                if abs(f.wf - 1) > 1e-6:
                    c.setFontStretch(int(round(f.wf * 100)))
                if abs(f.track - 1) > 1e-6:
                    c.setFontLetterSpacingType(QFont.PercentageSpacing); c.setFontLetterSpacing(f.track * 100.0)
                if abs(f.obl) > 1e-6:
                    c.setProperty(_P_OBL, float(f.obl))
                if r.stack is not None:
                    top, bot, kind = r.stack
                    if kind == "^" and not bot:
                        c.setVerticalAlignment(QTextCharFormat.AlignSuperScript); cur.insertText(top, c); continue
                    if kind == "^" and not top:
                        c.setVerticalAlignment(QTextCharFormat.AlignSubScript); cur.insertText(bot, c); continue
                    c.setProperty(_P_STACK, "\x1f".join([top, bot, kind])); c.setBackground(QColor(60, 80, 110))
                    cur.insertText(top + ("^" if kind == "^" else "/") + bot, c); continue
                cur.insertText(r.text, c)
        self.ed.moveCursor(QTextCursor.End)

    def rich(self):
        """The document as an MTEXT string."""
        from PySide6.QtGui import QTextCharFormat
        from ..core import mtext as MT
        paras = []; b = self.ed.document().begin()
        while b.isValid():
            al = b.blockFormat().alignment()
            a = 1 if al & Qt.AlignHCenter else (2 if al & Qt.AlignRight else (3 if al & Qt.AlignJustify else 0))
            p = MT.Para(a if a != self.halign else None)
            it = b.begin()
            while not it.atEnd():
                fr = it.fragment(); it += 1
                if not fr.isValid() or not fr.text():
                    continue
                c = fr.charFormat(); f = MT.Fmt()
                fam = c.fontFamilies()
                fam = fam[0] if isinstance(fam, (list, tuple)) and fam else (fam if isinstance(fam, str) else None)
                f.font = fam if fam and fam != self.base_font else None
                f.bold = c.fontWeight() >= QFont.Bold; f.italic = c.fontItalic(); f.under = c.fontUnderline(); f.over = c.fontOverline(); f.strike = c.fontStrikeOut()
                ps = c.fontPointSize() or _BASEPT; f.hf = round(ps / _BASEPT, 4)
                cc = c.property(_P_STACK + 5)
                f.color = None if cc in (None, "bylayer") else (int(cc) if not isinstance(cc, str) else cc)
                st_ = c.fontStretch(); f.wf = round(st_ / 100.0, 3) if st_ and st_ != 100 else 1.0
                ls = c.fontLetterSpacing(); f.track = round(ls / 100.0, 3) if ls and c.fontLetterSpacingType() == QFont.PercentageSpacing and abs(ls - 100) > 0.5 else 1.0
                f.obl = float(c.property(_P_OBL) or 0.0)
                text = fr.text().replace(" ", " ")
                st = c.property(_P_STACK)
                if st:
                    top, bot, kind = str(st).split("\x1f"); shown = top + ("^" if kind == "^" else "/") + bot
                    k = text.find(shown)
                    if k < 0:
                        st = None                                      # the stacked text was edited: ordinary text
                    else:
                        if text[:k]:
                            p.runs.append(MT.Run(text[:k], f))
                        p.runs.append(MT.Run(shown, f, (top, bot, kind)))
                        if text[k + len(shown):]:
                            p.runs.append(MT.Run(text[k + len(shown):], f))
                if st:
                    pass
                elif c.verticalAlignment() == QTextCharFormat.AlignSuperScript:
                    p.runs.append(MT.Run(text, f, (text, "", "^")))
                elif c.verticalAlignment() == QTextCharFormat.AlignSubScript:
                    p.runs.append(MT.Run(text, f, ("", text, "^")))
                else:
                    p.runs.append(MT.Run(text, f))
            paras.append(p); b = b.next()
        return MT.encode(paras)

    def result(self):
        from ..core import mtext as MT
        self._height() if False else None
        try:
            lsf = float(self.lsbox.currentText().lower().replace("x", "").replace(",", "."))
        except ValueError:
            lsf = 1.0
        r = self.rich()
        return dict(rich=r, text=MT.plain(r), height=self.base_h, font=self.base_font, halign=self.halign, valign=self.valign,
                    lsf=min(4.0, max(0.25, lsf)), width=float(self.wbox.value()), annotative=bool(self.anno_k))
