"""Text -> filled triangles (Qt font outlines triangulated with manifold3d), cached per string."""
import numpy as np
from PySide6.QtGui import QFont, QFontMetricsF, QPainterPath
from PySide6.QtCore import QPointF

_cache = {}
_fonts = {}
BASE = 100.0


def _font(name):
    f = _fonts.get(name)
    if f is None:
        f = QFont(name or "Arial"); f.setPixelSize(int(BASE)); f.setStyleStrategy(QFont.PreferOutline)
        fm = QFontMetricsF(f)
        _fonts[name] = f = (f, fm, fm.capHeight() or BASE * 0.7)
    return f


def local_tris(s, font, halign, valign, wf):
    key = (s, font, halign, valign, round(wf, 4))
    r = _cache.get(key)
    if r is not None:
        return r
    import manifold3d as m3
    f, fm, cap = _font(font)
    lines = s.split("\n")
    sp = 1.666 * cap
    polys = []
    widths = [fm.horizontalAdvance(l) for l in lines]
    Wmax = max(widths) if widths else 0
    for i, line in enumerate(lines):
        if not line.strip():
            continue
        path = QPainterPath(); path.addText(QPointF(0, 0), f, line)
        dx = [0.0, -widths[i] / 2, -widths[i]][halign]
        for poly in path.toSubpathPolygons():
            pts = np.array([[p.x(), p.y()] for p in poly], float)
            if len(pts) < 3:
                continue
            pts[:, 0] = (pts[:, 0] + dx) * wf
            pts[:, 1] = -pts[:, 1] - i * sp
            polys.append(pts / cap)
    if not polys:
        _cache[key] = None
        return None
    total_h = (len(lines) - 1) * sp / cap
    oy = [0.0, fm.descent() / cap, -0.5 + total_h / 2 - 0.0, -1.0][valign]
    if valign == 2:
        oy = -0.5 + total_h / 2
    elif valign == 3:
        oy = -1.0
    cs = m3.CrossSection(polys, m3.FillRule.NonZero)
    P = [np.asarray(p, float) for p in cs.to_polygons()]
    if not P:
        _cache[key] = None
        return None
    F = np.asarray(m3.triangulate(P), np.int32)
    V = np.vstack(P); V[:, 1] += oy
    r = (V, F)
    if len(_cache) > 20000:
        _cache.clear()
    _cache[key] = r
    return r


# ---------------------------------------------------------------------------------------------- MTEXT (formatting codes)
_rfonts = {}
_rcache = {}


def _rfont(name, bold, italic):
    k = (name or "Arial", bool(bold), bool(italic))
    f = _rfonts.get(k)
    if f is None:
        q = QFont(k[0]); q.setPixelSize(int(BASE)); q.setStyleStrategy(QFont.PreferOutline); q.setBold(k[1]); q.setItalic(k[2])
        fm = QFontMetricsF(q)
        _rfonts[k] = f = (q, fm, _font(k[0])[2])          # cap height of the regular face keeps bold / italic at the same size
    return f


def rich_layout(rich, font, halign, valign, wf, box_w, lsf):
    """Lays out MTEXT content. Units = text height (cap height). Returns (items, W, H):
    items = [(x, baseline_y, token)] with token = dict(text, fmt, stack, w, hf); the first line starts at y = 0 going down."""
    import re
    from ..core import mtext as MT
    lines = []                                             # (paragraph align, [tokens], last line of the paragraph)
    for para in MT.parse(rich, font):
        toks = []
        for r in para.runs:
            f = r.fmt; hf = f.hf
            q, fm, cap = _rfont(f.font or font, f.bold, f.italic)
            if r.stack is not None:
                top, bot, kind = r.stack
                w = max(fm.horizontalAdvance(top), fm.horizontalAdvance(bot)) / cap * 0.62 * hf * f.wf * wf
                if kind == "#":
                    w = (fm.horizontalAdvance(top) + fm.horizontalAdvance(bot) + fm.horizontalAdvance("/")) / cap * 0.62 * hf * f.wf * wf
                toks.append(dict(text=r.text, fmt=f, stack=r.stack, w=w + 0.08 * hf, hf=hf, sp=False)); continue
            for piece in re.findall(r"[ \t\u00a0]+|[^ \t\u00a0]+", r.text):
                w = fm.horizontalAdvance(piece) / cap * hf * f.wf * wf * f.track
                toks.append(dict(text=piece, fmt=f, stack=None, w=w, hf=hf, sp=piece.strip(" \t\u00a0") == ""))
        cur = []; cw = 0.0
        if not toks:
            lines.append((para.align, [], True)); continue
        for t in toks:
            if box_w > 0 and cur and not t["sp"] and cw + t["w"] > box_w + 1e-9:
                while cur and cur[-1]["sp"]:
                    cur.pop()
                lines.append((para.align, cur, False)); cur = []; cw = 0.0
            if t["sp"] and not cur and box_w > 0 and lines and not lines[-1][2]:
                continue                                    # no leading blanks on a wrapped line
            cur.append(t); cw += t["w"]
        lines.append((para.align, cur, True))
    widths = [sum(t["w"] for t in ln[1]) for ln in lines]
    W = box_w if box_w > 0 else (max(widths) if widths else 0.0)
    items = []; y = 0.0; first = True
    for (al, toks, last), lw in zip(lines, widths):
        hmax = max([t["hf"] for t in toks] or [1.0])
        y -= hmax if first else 1.6666 * lsf * hmax
        first = False
        al = halign if al is None else al
        extra = 0.0; x = 0.0
        if al == 1:
            x = (W - lw) / 2
        elif al == 2:
            x = W - lw
        elif al == 3 and not last and box_w > 0:
            ns = sum(1 for t in toks if t["sp"])
            extra = (W - lw) / ns if ns else 0.0
        for t in toks:
            items.append((x, y, t)); x += t["w"] + (extra if t["sp"] else 0.0)
    H = -y + 0.0
    return items, W, H


def rich_local(rich, font, halign, valign, wf, box_w, lsf):
    key = (rich, font, halign, valign, round(wf, 4), round(box_w, 4), round(lsf, 4))
    r = _rcache.get(key)
    if r is not None:
        return r
    import math
    import manifold3d as m3
    items, W, H = rich_layout(rich, font, halign, valign, wf, box_w, lsf)
    ox = [0.0, -W / 2, -W][halign]
    oy = {3: 0.0, 2: H / 2, 1: H, 0: H}.get(valign, 0.0)
    groups = {}
    def add_text(col, s, q, cap, x, y, sx, sy, shear):
        path = QPainterPath(); path.addText(QPointF(0, 0), q, s)
        for poly in path.toSubpathPolygons():
            pts = np.array([[p.x(), p.y()] for p in poly], float)
            if len(pts) < 3:
                continue
            px = pts[:, 0] - pts[:, 1] * shear
            groups.setdefault(col, []).append(np.column_stack([px / cap * sx + x + ox, -pts[:, 1] / cap * sy + y + oy]))
    def add_rect(col, x0, y0, x1, y1):
        groups.setdefault(col, []).append(np.array([[x0 + ox, y0 + oy], [x1 + ox, y0 + oy], [x1 + ox, y1 + oy], [x0 + ox, y1 + oy]]))
    for x, y, t in items:
        f = t["fmt"]; hf = t["hf"]; q, fm, cap = _rfont(f.font or font, f.bold, f.italic)
        col = f.color; shear = math.tan(math.radians(f.obl)) if f.obl else 0.0
        if t["stack"] is not None:
            top, bot, kind = t["stack"]; k = 0.62 * hf
            if kind == "#":
                add_text(col, top + "/" + bot, q, cap, x, y + 0.2 * hf, k * f.wf * wf, k, shear)
            else:
                wt = fm.horizontalAdvance(top) / cap * k * f.wf * wf; wb = fm.horizontalAdvance(bot) / cap * k * f.wf * wf; ww = max(wt, wb)
                if top:
                    add_text(col, top, q, cap, x + (ww - wt) / 2, y + 0.5 * hf, k * f.wf * wf, k, shear)
                if bot:
                    add_text(col, bot, q, cap, x + (ww - wb) / 2, y - 0.22 * hf, k * f.wf * wf, k, shear)
                if kind == "/":
                    add_rect(col, x, y + 0.40 * hf, x + ww, y + 0.45 * hf)
        elif not t["sp"]:
            if abs(f.track - 1.0) > 1e-6:
                xx = x
                for chx in t["text"]:
                    add_text(col, chx, q, cap, xx, y, hf * f.wf * wf, hf, shear)
                    xx += fm.horizontalAdvance(chx) / cap * hf * f.wf * wf * f.track
            else:
                add_text(col, t["text"], q, cap, x, y, hf * f.wf * wf, hf, shear)
        th = 0.06 * hf
        if f.under:
            add_rect(col, x, y - 0.22 * hf, x + t["w"], y - 0.22 * hf + th)
        if f.over:
            add_rect(col, x, y + 1.18 * hf, x + t["w"], y + 1.18 * hf + th)
        if f.strike:
            add_rect(col, x, y + 0.42 * hf, x + t["w"], y + 0.42 * hf + th)
    out = []
    for col, polys in groups.items():
        try:
            cs = m3.CrossSection(polys, m3.FillRule.NonZero)
            P = [np.asarray(p, float) for p in cs.to_polygons()]
            if not P:
                continue
            F = np.asarray(m3.triangulate(P), np.int32)
            out.append((np.vstack(P), F, col))
        except Exception:
            continue
    if len(_rcache) > 4000:
        _rcache.clear()
    _rcache[key] = out
    return out


def rich_groups(t):
    """World-space triangles of a formatted MTEXT entity, one group per colour: [(V, F, colour or None)]."""
    h = t.h
    box = (t.width / h) if (t.width and h > 0) else 0.0
    x = t.xdir; y = t.ydir(); out = []
    src = t.rich_src() if hasattr(t, "rich_src") else t.rich
    for V2, F, col in rich_local(src, t.font, t.halign, t.valign, t.wf, box, t.lsf):
        out.append((t.p + (V2[:, :1] * h) * x + (V2[:, 1:2] * h) * y, F, col))
    return out


def text_tris(t):
    r = local_tris(t.s, t.font, t.halign, t.valign, t.wf)
    if r is None:
        return None
    V2, F = r
    x = t.xdir; y = t.ydir(); h = t.h
    V = t.p + (V2[:, :1] * h) * x + (V2[:, 1:2] * h) * y
    return V, F


def text_width(s, font="Arial"):
    """Advance width of the longest line in units of the text height (cap height)."""
    f, fm, cap = _font(font)
    return max((fm.horizontalAdvance(l) for l in str(s).split("\n")), default=0.0) / cap


def install():
    from ..core.entities import Entity
    Entity.text_tess = staticmethod(text_tris)
    Entity.text_measure = staticmethod(text_width)
    Entity.text_rich = staticmethod(rich_groups)
