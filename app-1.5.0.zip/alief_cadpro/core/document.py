"""Drawing document: entities, layers, blocks, settings, undo/redo, native .acp file."""
import json
import zipfile
import numpy as np
from .entities import from_dict, Insert, Block, Entity, DetailView
from . import entities2  # noqa: F401  (registers attribute definitions and associative arrays)
from .geom import bbox_union

APP_VERSION = "1.5.0"
LINETYPES = {"Continuous": None, "Dashed": 0x00FF, "Hidden": 0x0F0F, "Center": 0x3F3F if False else 0xFF18,
             "Phantom": 0xFE38, "Dot": 0x3333, "DashDot": 0xFF0C}
LINEWEIGHTS = [0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211]


class Layer:
    def __init__(self, name, color=7, ltype="Continuous", lw=25, on=True, frozen=False, locked=False, plot=True):
        self.name = name; self.color = color; self.ltype = ltype; self.lw = lw
        self.on = on; self.frozen = frozen; self.locked = locked; self.plot = plot

    def to_dict(self):
        return dict(name=self.name, color=self.color, ltype=self.ltype, lw=self.lw, on=self.on, frozen=self.frozen,
                    locked=self.locked, plot=self.plot)

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: d[k] for k in ("name", "color", "ltype", "lw", "on", "frozen", "locked", "plot") if k in d})

    @property
    def visible(self):
        return self.on and not self.frozen


DEFAULT_LAYERS = [("0", 7), ("DEFPOINTS", 8), ("DIMENSION", 3), ("TEXT", 2), ("HATCH", 9),
                  ("PLATE", "#5b8fd6"), ("PROFILE", "#e0a040"), ("PIPING", 4), ("ELECTRICAL", "#ff6b6b"), ("CAM", 6), ("DETAIL", 7)]


class Document:
    def __init__(self):
        self.ents = {}
        self.layers = {n: Layer(n, c) for n, c in DEFAULT_LAYERS}
        self.layers["DEFPOINTS"].plot = False
        self.blocks = {}
        Insert.blocks = self.blocks; DetailView.doc = self
        self.cur_layer = "0"; self.cur_color = 256; self.cur_ltype = "ByLayer"; self.cur_lw = -1
        self.settings = {"units": "mm", "text_h": 2.5, "dim": {"th": 2.5, "asz": 2.5, "exo": 1.25, "exe": 1.25, "gap": 0.8, "dec": 0},
                         "ltscale": 1.0, "sym_scale": 1.0, "hatch_scale": 1.0, "pdmode": 3, "auto_anno": True, "paper": "A3",
                         "text_paper": 2.5}
        self.next_id = 1
        self.version = 0
        self.rev = 0            # bumped on every add / remove / modify so the view redraws while a command is running
        self.path = None
        self.modified = False
        self.undo_stack = []; self.redo_stack = []
        self._tx = None
        self.listeners = []

    # ------------------------------------------------------------------ change tracking
    def changed(self):
        self.version += 1; self.modified = True
        for f in self.listeners:
            try:
                f()
            except Exception:
                pass

    def begin(self, name="command"):
        if self._tx is None:
            self._tx = {"name": name, "ops": [], "mod": {}}

    def end(self):
        tx = self._tx; self._tx = None
        if not tx:
            return
        # capture after-states of modified entities
        for eid, before in tx["mod"].items():
            e = self.ents.get(eid)
            tx["ops"].append(("mod", eid, before, e.to_dict() if e is not None else None))
        tx["mod"] = {}
        if tx["ops"]:
            self.undo_stack.append(tx); self.redo_stack.clear()
            if len(self.undo_stack) > 200:
                self.undo_stack.pop(0)
        self.changed()

    def _auto(self):
        return self._tx is None

    def add(self, e, layer=None):
        auto = self._auto()
        if auto:
            self.begin("add")
        if e.id == 0 or e.id in self.ents:
            e.id = self.next_id; self.next_id += 1
        else:
            self.next_id = max(self.next_id, e.id + 1)
        if layer is not None:
            e.layer = layer
        elif e.layer == "0" and self.cur_layer != "0" and not getattr(e, "_keep_layer", False):
            e.layer = self.cur_layer
        if e.layer not in self.layers:
            self.layers[e.layer] = Layer(e.layer)
        if getattr(e, "_new", True) and e.color == 256 and self.cur_color != 256 and not getattr(e, "_keep_color", False):
            e.color = self.cur_color
        self.ents[e.id] = e; self.rev += 1
        self._tx["ops"].append(("add", e.id, e.to_dict()))
        if auto:
            self.end()
        return e

    def add_keep(self, e):
        """Add with the entity's own layer/colour (used by import / paste)."""
        e._keep_layer = True; e._keep_color = True
        r = self.add(e)
        del e._keep_layer, e._keep_color
        return r

    def remove(self, e):
        auto = self._auto()
        if auto:
            self.begin("erase")
        self.rev += 1
        if e.id in self.ents:
            if e.id in self._tx["mod"]:
                before = self._tx["mod"].pop(e.id)
                self._tx["ops"].append(("mod", e.id, before, self.ents[e.id].to_dict()))
            self._tx["ops"].append(("del", e.id, self.ents[e.id].to_dict()))
            del self.ents[e.id]
        if auto:
            self.end()

    def modify(self, e):
        """Call BEFORE changing an entity in place."""
        auto = self._auto()
        if auto:
            self.begin("modify")
        if e.id in self.ents and e.id not in self._tx["mod"]:
            self._tx["mod"][e.id] = e.to_dict()
        e.touch(); self.rev += 1
        if auto:
            self.end()

    def replace(self, old, new_ents):
        self.remove(old)
        return [self.add_keep(n) for n in new_ents]

    def undo(self):
        if self._tx is not None:
            self.end()
        if not self.undo_stack:
            return None
        tx = self.undo_stack.pop()
        for op in reversed(tx["ops"]):
            if op[0] == "add":
                self.ents.pop(op[1], None)
            elif op[0] == "del":
                e = from_dict(op[2]); self.ents[op[1]] = e
            elif op[0] == "mod":
                e = from_dict(op[2]); self.ents[op[1]] = e
        self._reorder()
        self.redo_stack.append(tx); self.changed()
        return tx["name"]

    def redo(self):
        if not self.redo_stack:
            return None
        tx = self.redo_stack.pop()
        for op in tx["ops"]:
            if op[0] == "add":
                self.ents[op[1]] = from_dict(op[2])
            elif op[0] == "del":
                self.ents.pop(op[1], None)
            elif op[0] == "mod":
                if op[3] is not None:
                    self.ents[op[1]] = from_dict(op[3])
        self._reorder()
        self.undo_stack.append(tx); self.changed()
        return tx["name"]

    def _reorder(self):
        self.ents = dict(sorted(self.ents.items()))

    # ------------------------------------------------------------------ queries
    def layer_of(self, e):
        return self.layers.get(e.layer) or self.layers["0"]

    def visible_ents(self):
        L = self.layers
        return [e for e in self.ents.values() if (L.get(e.layer) is None or L[e.layer].visible)]

    def selectable(self, e):
        l = self.layers.get(e.layer)
        return l is None or (l.visible and not l.locked)

    def extents(self, ents=None):
        bb = None
        for e in (ents if ents is not None else self.visible_ents()):
            if ents is None and e.kind == "line" and ((e.xd and e.xd.get("inf")) or abs(e.p1 - e.p0).max() > 4.0e6):
                continue                               # construction lines (XLINE / RAY, also trimmed ones) do not count for the extents
            try:
                b = e.bbox()
            except Exception:
                b = None
            if b is not None:
                bb = bbox_union(bb, b)
        return bb

    def color_of(self, e):
        c = e.color
        if c == 256 or c is None:
            c = self.layer_of(e).color
        return c

    def ltype_of(self, e):
        return self.layer_of(e).ltype if e.ltype in ("ByLayer", None, "") else e.ltype

    def lw_of(self, e):
        return self.layer_of(e).lw if e.lw is None or e.lw < 0 else e.lw

    def ensure_layer(self, name, color=7):
        if name not in self.layers:
            self.layers[name] = Layer(name, color)
        return self.layers[name]

    def add_block(self, blk):
        self.blocks[blk.name] = blk
        Insert.blocks = self.blocks; DetailView.doc = self
        for e in self.ents.values():
            if isinstance(e, Insert) and e.name == blk.name:
                e.touch()

    # ------------------------------------------------------------------ file
    def to_json(self):
        return {"app": "ALIEF CAD PRO", "version": APP_VERSION, "settings": self.settings,
                "layers": [l.to_dict() for l in self.layers.values()], "cur_layer": self.cur_layer,
                "blocks": [b.to_dict() for b in self.blocks.values()],
                "ents": [e.to_dict() for e in self.ents.values()]}

    def save(self, path):
        data = json.dumps(self.to_json(), separators=(",", ":"))
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("drawing.json", data)
        self.path = path; self.modified = False

    @classmethod
    def load(cls, path):
        with zipfile.ZipFile(path) as z:
            d = json.loads(z.read("drawing.json"))
        doc = cls()
        doc.settings.update(d.get("settings", {}))
        doc.layers = {}
        for l in d.get("layers", []):
            L = Layer.from_dict(l); doc.layers[L.name] = L
        if "0" not in doc.layers:
            doc.layers["0"] = Layer("0")
        doc.cur_layer = d.get("cur_layer", "0") if d.get("cur_layer", "0") in doc.layers else "0"
        for b in d.get("blocks", []):
            doc.blocks[b["name"]] = Block.from_dict(b)
        Insert.blocks = doc.blocks; DetailView.doc = doc
        for ed in d.get("ents", []):
            try:
                e = from_dict(ed)
            except Exception:
                continue
            doc.ents[e.id] = e
            doc.next_id = max(doc.next_id, e.id + 1)
        doc.path = path; doc.modified = False
        return doc

    def activate(self):
        Insert.blocks = self.blocks; DetailView.doc = self
