"""PDF import with PDFium (pypdfium2, Apache-2.0 / BSD): vector paths -> lines / polylines, text -> text,
fills -> solid hatch, embedded images or the whole rendered page -> raster underlay. Loaded only when used."""
import ctypes
import math
import numpy as np
from . import entities as E
from .geom import norm

PT_MM = 25.4 / 72.0


def _qimage_png(arr):
    from PySide6.QtGui import QImage
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice
    a = np.ascontiguousarray(arr)
    h, w = a.shape[:2]
    fmt = QImage.Format_RGB888 if a.shape[2] == 3 else QImage.Format_RGBA8888
    img = QImage(a.data, w, h, a.strides[0], fmt).copy()
    ba = QByteArray(); buf = QBuffer(ba); buf.open(QIODevice.WriteOnly); img.save(buf, "PNG")
    return bytes(ba), w, h


def page_count(path):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path)
    n = len(pdf); pdf.close()
    return n


def page_thumb(path, i, width=220):
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(path); pg = pdf[i]
    W, H = pg.get_size()
    bm = pg.render(scale=width / W, rev_byteorder=True)
    png = _qimage_png(bm.to_numpy())[0]
    pdf.close()
    return png, (W * PT_MM, H * PT_MM)


def _mat(obj):
    import pypdfium2.raw as R
    m = R.FS_MATRIX()
    R.FPDFPageObj_GetMatrix(obj, ctypes.byref(m))
    return np.array([[m.a, m.c, m.e], [m.b, m.d, m.f], [0, 0, 1.0]])


def _color(fn, obj):
    r, g, b, a = (ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint())
    if not fn(obj, ctypes.byref(r), ctypes.byref(g), ctypes.byref(b), ctypes.byref(a)):
        return None
    if a.value == 0:
        return None
    if r.value < 40 and g.value < 40 and b.value < 40:
        return 7
    if r.value > 235 and g.value > 235 and b.value > 235:
        return "#ffffff"
    return "#%02x%02x%02x" % (r.value, g.value, b.value)


def import_pdf(path, page=0, scale=1.0, origin=(0, 0, 0), vectors=True, texts=True, fills=False, images=True,
               raster_page=False, dpi=200, layer_prefix="PDF", join=True, progress=None, cancel=None):
    """Return list of entities. scale = model units per paper mm (e.g. 100 for a 1:100 drawing in mm).
    progress(fraction, text) is called now and then; cancel() -> True stops the import (raises KeyboardInterrupt)."""
    import pypdfium2 as pdfium
    import pypdfium2.raw as R
    out = []
    o = np.asarray(origin, float)
    pdf = pdfium.PdfDocument(path)
    pg = pdf[page]
    Wp, Hp = pg.get_size()
    k = PT_MM * scale
    if raster_page:
        bm = pg.render(scale=dpi / 72.0, rev_byteorder=True)
        png, w, h = _qimage_png(bm.to_numpy())
        img = E.ImageE(png, o, (Wp * k, 0, 0), (0, Hp * k, 0), w, h, f"page {page + 1}")
        img.layer = layer_prefix + "_IMAGE"; out.append(img)
    tp = pg.get_textpage() if texts else None
    lw_thick = 0.45
    runs = []
    fx, fy = ctypes.c_float(), ctypes.c_float()
    fm, st = ctypes.c_int(), ctypes.c_int()
    wd = ctypes.c_float()
    l_, b_, r_, t_ = ctypes.c_float(), ctypes.c_float(), ctypes.c_float(), ctypes.c_float()
    SEG_MOVE, SEG_LINE, SEG_BEZ = R.FPDF_SEGMENT_MOVETO, R.FPDF_SEGMENT_LINETO, R.FPDF_SEGMENT_BEZIERTO
    counter = [0]
    nobj = R.FPDFPage_CountObjects(pg.raw)
    GetSeg, GetPt, GetTyp, GetCl = R.FPDFPath_GetPathSegment, R.FPDFPathSegment_GetPoint, R.FPDFPathSegment_GetType, R.FPDFPathSegment_GetClose
    ObjType, Count = R.FPDFPageObj_GetType, R.FPDFPath_CountSegments
    T_FORM, T_PATH, T_TEXT, T_IMAGE = R.FPDF_PAGEOBJ_FORM, R.FPDF_PAGEOBJ_PATH, R.FPDF_PAGEOBJ_TEXT, R.FPDF_PAGEOBJ_IMAGE
    bx, by = ctypes.byref(fx), ctypes.byref(fy)
    ox, oy, oz = float(o[0]), float(o[1]), float(o[2])

    def tick():
        counter[0] += 1
        if counter[0] % 2000 == 0:
            if cancel is not None and cancel():
                raise KeyboardInterrupt("cancelled")
            if progress is not None:
                progress(min(0.9, counter[0] / max(1, nobj) * 0.85), f"{counter[0]:,} PDF objects read")

    def emit_path(obj, Mo):
        R.FPDFPath_GetDrawMode(obj, ctypes.byref(fm), ctypes.byref(st))
        col = _color(R.FPDFPageObj_GetStrokeColor, obj) or 7
        fcol = _color(R.FPDFPageObj_GetFillColor, obj)
        R.FPDFPageObj_GetStrokeWidth(obj, ctypes.byref(wd))
        n = Count(obj)
        if not n:
            return
        # raw segment list first (one pass of ctypes calls), then the transform
        typ = [0] * n; cl = [False] * n; P = [None] * n
        a, b_, c, d, e_, f = Mo[0, 0], Mo[0, 1], Mo[0, 2], Mo[1, 0], Mo[1, 1], Mo[1, 2]
        for i in range(n):
            sg = GetSeg(obj, i)
            GetPt(sg, bx, by)
            x = fx.value; y = fy.value
            P[i] = np.array((ox + (a * x + b_ * y + c) * k, oy + (d * x + e_ * y + f) * k, oz))
            typ[i] = GetTyp(sg); cl[i] = GetCl(sg)
        polys = []; cur = []; i = 0
        while i < n:
            t = typ[i]
            if t == SEG_MOVE:
                if len(cur) >= 2:
                    polys.append((cur, False))
                cur = [P[i]]
            elif t == SEG_LINE:
                cur.append(P[i])
            elif t == SEG_BEZ and i + 2 < n:
                p0 = cur[-1] if cur else P[i]; c1, c2, p3 = P[i], P[i + 1], P[i + 2]
                size = norm(c1 - p0) + norm(c2 - c1) + norm(p3 - c2)
                m = int(min(16, max(2, size / max(k, 1e-12) / 1.5)))         # about one segment per 1.5 mm of curve on paper
                u = np.linspace(0, 1, m + 1)[1:, None]
                cur.extend(list((1 - u) ** 3 * p0 + 3 * (1 - u) ** 2 * u * c1 + 3 * (1 - u) * u * u * c2 + u ** 3 * p3))
                i += 2
                if cl[i] and len(cur) >= 2:
                    polys.append((cur, True)); cur = [cur[0]]
                i += 1
                continue
            if cl[i] and len(cur) >= 2:
                polys.append((cur, True)); cur = [cur[0]]
            i += 1
        if len(cur) >= 2:
            polys.append((cur, False))
        thick = wd.value * math.sqrt(abs(Mo[0, 0] * Mo[1, 1] - Mo[0, 1] * Mo[1, 0])) * PT_MM >= lw_thick
        for pp, closed in polys:
            pp = np.asarray(pp)
            if len(pp) >= 2 and norm(pp[0] - pp[-1]) < 1e-9 * max(1, k):
                closed = True; pp = pp[:-1]
            if fills and fm.value and fcol not in (None, "#ffffff") and closed and len(pp) >= 3:
                hh = E.Hatch([pp], (0, 0, 1), "SOLID"); hh.color = fcol; hh.layer = layer_prefix + "_FILL"; out.append(hh)
            if not vectors or len(pp) < 2:
                continue
            lay = layer_prefix + "_GEOMETRY"; cc = col
            if not st.value:
                if not fm.value or fcol in (None, "#ffffff"):
                    continue
                lay = layer_prefix + "_OUTLINE"; cc = fcol
            e = E.Line(pp[0], pp[1]) if len(pp) == 2 and not closed else E.Polyline(pp, closed)
            e.color = cc; e.layer = lay
            if thick:
                e.lw = 50
            out.append(e)

    def walk(obj, M):
        tick()
        t = ObjType(obj)
        Mo = M @ _mat(obj)
        if t == T_FORM:
            for i in range(R.FPDFFormObj_CountObjects(obj)):
                walk(R.FPDFFormObj_GetObject(obj, i), Mo)
            return
        if t == T_PATH and (vectors or fills):
            emit_path(obj, Mo)
        elif t == T_TEXT and tp is not None:
            nch = R.FPDFTextObj_GetText(obj, tp.raw, None, 0)
            if nch <= 2:
                return
            buf = ctypes.create_string_buffer(nch * 2)
            R.FPDFTextObj_GetText(obj, tp.raw, ctypes.cast(buf, ctypes.POINTER(ctypes.c_ushort)), nch * 2)
            s_ = buf.raw[:nch * 2 - 2].decode("utf-16-le", errors="ignore").strip()
            if not s_:
                return
            if not R.FPDFPageObj_GetBounds(obj, ctypes.byref(l_), ctypes.byref(b_), ctypes.byref(r_), ctypes.byref(t_)):
                return
            q = M @ np.array([[l_.value, r_.value], [b_.value, t_.value], [1.0, 1.0]])
            l, r = sorted(q[0]); b, tt = sorted(q[1])
            ang = math.atan2(Mo[1, 0], Mo[0, 0])
            runs.append([l, b, r, tt, s_, ang])
        elif t == T_IMAGE and images and not raster_page:
            try:
                im = pdfium.PdfImage(obj, pg, pdf) if hasattr(pdfium, "PdfImage") else None
                bm = im.get_bitmap(render=True)
                arr_ = bm.to_numpy()
                png, w, h = _qimage_png(arr_[..., ::-1] if arr_.shape[2] == 3 else arr_)
                cpt = Mo @ np.array([[0, 1, 1, 0], [0, 0, 1, 1], [1, 1, 1, 1.0]])
                x0, y0 = cpt[0].min(), cpt[1].min(); x1, y1 = cpt[0].max(), cpt[1].max()
                img = E.ImageE(png, o + np.array([x0 * k, y0 * k, 0]), ((x1 - x0) * k, 0, 0), (0, (y1 - y0) * k, 0), w, h, "pdf image")
                img.layer = layer_prefix + "_IMAGE"; out.append(img)
            except Exception:
                pass

    try:
        for i in range(nobj):
            walk(R.FPDFPage_GetObject(pg.raw, i), np.eye(3))
        if tp is not None:
            if not runs:                                   # PDFs without text objects in the page tree: read the text page instead
                for i in range(tp.count_rects()):
                    try:
                        l, b, r, t2 = tp.get_rect(i)
                        s_ = tp.get_text_bounded(l, b, r, t2).strip()
                    except Exception:
                        continue
                    if s_:
                        runs.append([l, b, r, t2, s_, 0.0])
            out += _text_runs(runs, o, k, scale, layer_prefix)
            tp.close()
    finally:
        pdf.close()
    if progress is not None:
        progress(0.92, f"{len(out):,} objects - joining line segments")
    if join:
        out = merge_segments(out)
    return out


def _text_runs(runs, o, k, scale, layer_prefix):
    """Merge text pieces that sit on one line into one text each."""
    out = []
    hor = [q for q in runs if abs(q[5]) < 0.3 or abs(abs(q[5]) - math.pi) < 0.3]
    other = [q for q in runs if q not in hor] if len(hor) != len(runs) else []
    hor.sort(key=lambda q: (round(q[1], 0), q[0]))
    merged = []
    for q in hor:
        if merged:
            m = merged[-1]; h = max(m[3] - m[1], q[3] - q[1])
            if abs(m[1] - q[1]) < 0.25 * h and -0.2 * h < q[0] - m[2] < 0.9 * h:
                gap = q[0] - m[2]
                m[4] += (" " if gap > 0.22 * h else "") + q[4]; m[2] = max(m[2], q[2]); m[3] = max(m[3], q[3]); continue
        merged.append(list(q))
    W = lambda x, y: o + np.array([x * k, y * k, 0.0])
    for l, b, r, t_, st, ang in merged:
        hh = t_ - b
        tx = E.Text(W(l, b + hh * 0.2), st, hh * 0.72 * PT_MM * scale, (1, 0, 0), (0, 0, 1), 0, 0)
        tx.color = 7; tx.layer = layer_prefix + "_TEXT"; out.append(tx)
    for l, b, r, t_, st, ang in other:
        hh = t_ - b; ww = r - l
        vertical = abs(abs(ang) - math.pi / 2) < 0.3
        if vertical:
            tx = E.Text(W(r - ww * 0.2, b), st, ww * 0.72 * PT_MM * scale, (0, 1, 0), (0, 0, 1), 0, 0)
        else:
            h0 = min(hh, ww) * 0.72
            tx = E.Text(W(l, b), st, h0 * PT_MM * scale, (math.cos(ang), math.sin(ang), 0), (0, 0, 1), 0, 0)
        tx.color = 7; tx.layer = layer_prefix + "_TEXT"; out.append(tx)
    return out


def merge_segments(ents, tol_rel=1e-6):
    """Chain PDF line segments that meet end to end (same colour / layer / weight, only two at a point) into polylines - O(n)."""
    lines = [e for e in ents if e.kind == "line"]
    others = [e for e in ents if e.kind != "line"]
    if len(lines) < 2:
        return ents
    span = 1.0
    try:
        P = np.array([[l.p0[0], l.p0[1]] for l in lines[:2000]])
        span = max(float(np.ptp(P, axis=0).max()), 1.0)
    except Exception:
        pass
    q = span * tol_rel
    key = lambda p: (round(float(p[0]) / q), round(float(p[1]) / q))
    groups = {}
    for l in lines:
        groups.setdefault((l.layer, str(l.color), l.lw), []).append(l)
    res = []
    for g, ls in groups.items():
        at = {}
        for i, l in enumerate(ls):
            at.setdefault(key(l.p0), []).append((i, 0)); at.setdefault(key(l.p1), []).append((i, 1))
        used = [False] * len(ls)
        def nxt(pk, i):
            c = at.get(pk, [])
            if len(c) != 2:
                return None
            for j, end in c:
                if j != i and not used[j]:
                    return j, end
            return None
        for i, l in enumerate(ls):
            if used[i]:
                continue
            used[i] = True
            chain = [l.p0.copy(), l.p1.copy()]
            # grow forward from p1
            cur, pk = i, key(l.p1)
            while True:
                r = nxt(pk, cur)
                if r is None:
                    break
                j, end = r; used[j] = True; m = ls[j]
                pnew = m.p1 if end == 0 else m.p0
                chain.append(pnew.copy()); cur, pk = j, key(pnew)
            # grow backward from p0
            cur, pk = i, key(l.p0)
            while True:
                r = nxt(pk, cur)
                if r is None:
                    break
                j, end = r; used[j] = True; m = ls[j]
                pnew = m.p1 if end == 0 else m.p0
                chain.insert(0, pnew.copy()); cur, pk = j, key(pnew)
            if len(chain) == 2:
                res.append(l); continue
            closed = key(chain[0]) == key(chain[-1])
            pl = E.Polyline(np.array(chain[:-1] if closed else chain), closed)
            pl.layer, pl.color, pl.lw = l.layer, l.color, l.lw
            res.append(pl)
    return others + res
