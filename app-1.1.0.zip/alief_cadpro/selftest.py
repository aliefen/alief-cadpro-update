"""Self test used by the installer build (CADPRO_SELFTEST=<result file>)."""
import os
import sys
import tempfile
import traceback
import numpy as np


def run(w, out):
    from PySide6.QtWidgets import QApplication
    lines = []
    ok = True
    def step(name, fn):
        nonlocal ok
        try:
            r = fn(); lines.append(f"OK   {name} {r if r is not None else ''}")
        except Exception:
            ok = False; lines.append(f"FAIL {name}\n" + traceback.format_exc())
    eng = w.engine; doc = w.doc
    def feed(cmd, *inp):
        eng.run(cmd)
        for i in inp:
            if not eng.busy():
                break
            if isinstance(i, str):
                eng.feed_text(i)
            elif i is None:
                eng.feed_enter()
            else:
                eng.feed_point(np.array(i, float))
        if eng.busy():
            eng.cancel()
        return len(doc.ents)
    step("line", lambda: feed("LINE", (0, 0), (1000, 0), (1000, 500), None))
    step("circle", lambda: feed("CIRCLE", (500, 250), "100"))
    step("box", lambda: feed("BOX", (1500, 0), "@600,400", "300"))
    from .core import ship as SH, fittings3d as F, entities as E, details as D
    def plate():
        r = E.Polyline([[0, 1000, 0], [2000, 1000, 0], [2000, 2000, 0], [0, 2000, 0]], True); doc.add(r)
        w.dialog_plate = lambda: {"thk": 10, "grade": "AH36", "side": "+", "prefix": "P", "mark": "", "layer": "PLATE", "delete_src": False}
        eng.run("PLATE3D"); eng.feed_selection_done([r])
        return [e.role for e in doc.ents.values() if e.kind == "body"]
    step("plate", plate)
    def prof():
        l = E.Line((0, 1500, 0), (2000, 1500, 0)); doc.add(l)
        w.dialog_profile = lambda: {"ptype": "BP", "dims": SH.CATALOGUE["BP"]["HP 160x8"], "size": "", "grade": "A (NS)", "align": 0, "flip": False,
                                    "rot": 0, "web_dir": "UCS Z", "reverse_web": False, "prefix": "S", "mark": "", "layer": "PROFILE", "delete_src": False}
        eng.run("PROFILE3D"); eng.feed_selection_done([l])
    step("profile", prof)
    def pipe():
        w.dialog_pipe = lambda: {"dn": 80, "pipe_std": F.PIPE_STANDARDS[0], "R": None, "flanges": "both", "std": "JIS B2220 10K"}
        return feed("PIPE3D", (0, 3000, 0), (1500, 3000, 0), (1500, 4000, 0), None)
    step("pipe", pipe)
    step("symbol", lambda: (eng.run("SYMBOL", "Gate valve"), eng.feed_point(np.array([0, -500, 0.])), eng.feed_text("0"), eng.cancel()) and None)
    def det():
        w.dialog_detail = lambda: {"kind": D.DETAIL_TYPES[0], "ptype": "BP", "dims": SH.CATALOGUE["BP"]["HP 200x10"], "grade": "A (NS)", "plate_t": 10,
                                   "web_t": 10, "t_br": None, "flanged": None, "rule": "BKI", "ds": 10}
        return feed("DETAIL", (4000, 0))
    step("detail", det)
    step("bom", lambda: feed("BOM", None, (6000, 0)))
    tmp = tempfile.mkdtemp(prefix="cadpro_selftest_")
    step("save", lambda: doc.save(os.path.join(tmp, "t.acp")))
    from .core import dxfio
    step("dxf", lambda: dxfio.export_dxf(doc, os.path.join(tmp, "t.dxf")))
    def pdf():
        from .core import pdfimport as PI
        from .ui.plot import plot_pdf
        fn = os.path.join(tmp, "plot.pdf"); plot_pdf(w, fn)
        return len(PI.import_pdf(fn, 0, 1.0))
    step("plot+pdfimport", pdf)
    def xlsx():
        from .ui.dialogs import export_bom_xlsx
        from .cmd.ship import collect_bom, bom_table_rows
        rows = collect_bom(doc); export_bom_xlsx(os.path.join(tmp, "bom.xlsx"), bom_table_rows(rows), rows)
    step("excel", xlsx)
    def upd():
        from .core import update as U
        return U.notice_valid({"product": "X"})
    step("update module", upd)
    def shot():
        w.view.zoom_extents(animate=False)
        for _ in range(30):
            QApplication.processEvents()
        img = w.grab(); img.save(os.path.splitext(out)[0] + ".png")
        import OpenGL.GL as gl
        return w.view.context().format().majorVersion(), w.view.context().format().minorVersion()
    step("screenshot", shot)
    with open(out, "w", encoding="utf-8") as f:
        f.write(("SELFTEST OK\n" if ok else "SELFTEST FAILED\n") + f"version {w.version}  app {w.boot.get('app_dir', '')}\n" + "\n".join(lines) + "\n")
    doc.modified = False
    QApplication.quit()
