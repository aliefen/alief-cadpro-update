"""DXF import / export (ezdxf, loaded only when used), DWG via the free ODA File Converter, STL / OBJ export."""
import math
import os
import shutil
import subprocess
import tempfile
import numpy as np
from .geom import v3, unit, norm, arbitrary_x, Plane
from . import entities as E
from .document import Layer


def _color(e):
    try:
        if e.dxf.hasattr("true_color"):
            r, g, b = e.rgb
            return "#%02x%02x%02x" % (r, g, b)
    except Exception:
        pass
    return int(e.dxf.get("color", 256))


def _base(src, dst):
    dst.layer = src.dxf.get("layer", "0") or "0"
    dst.color = _color(src)
    lt = src.dxf.get("linetype", "BYLAYER")
    dst.ltype = "ByLayer" if lt.upper() == "BYLAYER" else _lt_name(lt)
    dst.lw = int(src.dxf.get("lineweight", -1)) if src.dxf.get("lineweight", -1) >= 0 else -1
    return dst


def _lt_name(n):
    u = n.upper()
    for k in ("DASHDOT", "DASHED", "HIDDEN", "CENTER", "PHANTOM", "DOT"):
        if k in u:
            return {"DASHDOT": "DashDot", "DASHED": "Dashed", "HIDDEN": "Hidden", "CENTER": "Center", "PHANTOM": "Phantom", "DOT": "Dot"}[k]
    return "Continuous"


def convert_entity(e, warn):
    """ezdxf entity -> list of our entities."""
    t = e.dxftype()
    ext = v3(e.dxf.get("extrusion", (0, 0, 1))) if e.dxf.hasattr("extrusion") else np.array([0, 0, 1.0])
    try:
        if t == "LINE":
            return [_base(e, E.Line(e.dxf.start, e.dxf.end))]
        if t == "POINT":
            return [_base(e, E.PointE(e.dxf.location))]
        if t == "CIRCLE":
            c = e.ocs().to_wcs(e.dxf.center)
            return [_base(e, E.Circle(c, e.dxf.radius, ext))]
        if t == "ARC":
            c = e.ocs().to_wcs(e.dxf.center)
            return [_base(e, E.Arc(c, e.dxf.radius, math.radians(e.dxf.start_angle), math.radians(e.dxf.end_angle), ext))]
        if t == "ELLIPSE":
            return [_base(e, E.Ellipse(e.dxf.center, e.dxf.major_axis, e.dxf.ratio, e.dxf.extrusion, e.dxf.start_param, e.dxf.end_param))]
        if t == "LWPOLYLINE":
            ocs = e.ocs(); elev = e.dxf.get("elevation", 0.0)
            pts = []; bul = []
            for x, y, s, ee, b in e.get_points("xyseb"):
                pts.append(ocs.to_wcs((x, y, elev))); bul.append(b)
            return [_base(e, E.Polyline(np.array(pts), e.closed, bul, ext))]
        if t == "POLYLINE":
            if e.is_polygon_mesh or e.is_poly_face_mesh:
                return _mesh_from(e)
            ocs = e.ocs()
            pts = []; bul = []
            for v in e.vertices:
                p = v.dxf.location
                pts.append(p if e.is_3d_polyline else ocs.to_wcs(p)); bul.append(v.dxf.get("bulge", 0.0))
            return [_base(e, E.Polyline(np.array(pts), e.is_closed, bul, ext, is3d=e.is_3d_polyline))]
        if t == "SPLINE":
            ctrl = np.array(e.control_points) if len(e.control_points) else None
            if ctrl is None or len(ctrl) < 2:
                fit = np.array(e.fit_points)
                return [_base(e, E.Spline.through(fit))]
            w = list(e.weights) if len(e.weights) else None
            return [_base(e, E.Spline(ctrl, list(e.knots), e.dxf.degree, w, None, e.closed))]
        if t in ("TEXT", "ATTRIB"):
            ha = {0: 0, 1: 1, 2: 2, 4: 1}.get(e.dxf.get("halign", 0), 0)
            va = e.dxf.get("valign", 0)
            p = e.dxf.align_point if (ha or va) and e.dxf.hasattr("align_point") else e.dxf.insert
            ocs = e.ocs(); p = ocs.to_wcs(p)
            rot = math.radians(e.dxf.get("rotation", 0))
            ax = arbitrary_x(ext); ay = np.cross(ext, ax)
            x = math.cos(rot) * ax + math.sin(rot) * ay
            return [_base(e, E.Text(p, e.dxf.text, e.dxf.get("height", 2.5), x, ext, ha, min(va, 3), wf=e.dxf.get("width", 1.0)))]
        if t == "MTEXT":
            s = e.plain_text()
            ap = e.dxf.get("attachment_point", 1)
            ha = (ap - 1) % 3; va = {0: 3, 1: 2, 2: 1}[(ap - 1) // 3]
            x = v3(e.dxf.get("text_direction", (1, 0, 0)))
            if e.dxf.hasattr("rotation") and not e.dxf.hasattr("text_direction"):
                r = math.radians(e.dxf.rotation); x = np.array([math.cos(r), math.sin(r), 0])
            tx = E.Text(e.dxf.insert, s, e.dxf.get("char_height", 2.5), x, ext, ha, va)
            tx.width = e.dxf.get("width", 0.0)
            return [_base(e, tx)]
        if t in ("SOLID", "TRACE", "3DFACE"):
            pts = [v3(e.dxf.get(f"vtx{i}")) for i in range(4)]
            if t == "3DFACE":
                F = [[0, 1, 2]] + ([[0, 2, 3]] if norm(pts[3] - pts[2]) > 1e-12 else [])
                return [_base(e, E.Body(np.array(pts), np.array(F), "mesh"))]
            pts = [e.ocs().to_wcs(p) for p in pts]
            loop = [pts[0], pts[1], pts[3], pts[2]] if norm(pts[3] - pts[2]) > 1e-12 else pts[:3]
            return [_base(e, E.Hatch([np.array(loop)], ext, "SOLID"))]
        if t == "HATCH":
            loops = []
            for path in e.paths:
                try:
                    from ezdxf.path import from_hatch_boundary_path
                    pp = from_hatch_boundary_path(path, e.ocs(), e.dxf.elevation.z)
                    pts = np.array(list(pp.flattening(0.01 * max(1.0, 1.0))))
                except Exception:
                    continue
                if len(pts) >= 3:
                    loops.append(pts)
            if not loops:
                return []
            pat = "SOLID" if e.dxf.solid_fill else (e.dxf.pattern_name.upper() if e.dxf.pattern_name.upper() in E.HATCH_PATTERNS else "ANSI31")
            return [_base(e, E.Hatch(loops, ext, pat, e.dxf.get("pattern_scale", 1.0), e.dxf.get("pattern_angle", 0.0)))]
        if t == "MESH":
            V = np.array(e.vertices); F = []
            for f in e.faces:
                f = list(f)
                for k in range(1, len(f) - 1):
                    F.append([f[0], f[k], f[k + 1]])
            return [_base(e, E.Body(V, np.array(F), "mesh"))]
        if t == "INSERT":
            M = np.array([list(r) for r in e.matrix44().rows()], float).T
            ins = _base(e, E.Insert(e.dxf.name, M))
            out = [ins]
            for a in e.attribs:
                out += convert_entity(a, warn)
            return out
        if t in ("DIMENSION", "LEADER", "MLEADER", "MULTILEADER", "ARC_DIMENSION", "ACAD_TABLE"):
            out = []
            for v in e.virtual_entities():
                out += convert_entity(v, warn)
            for o in out:
                if o.layer == "0":
                    o.layer = e.dxf.get("layer", "0")
            return out
        if t in ("3DSOLID", "BODY", "REGION", "SURFACE"):
            warn[t] = warn.get(t, 0) + 1
            return []
        warn[t] = warn.get(t, 0) + 1
    except Exception as ex:
        warn["error " + t] = warn.get("error " + t, 0) + 1
    return []


def _mesh_from(e):
    V = []; F = []
    try:
        from ezdxf.render import MeshBuilder
        mb = MeshBuilder.from_polyface(e)
        V = np.array(mb.vertices)
        for f in mb.faces:
            for k in range(1, len(f) - 1):
                F.append([f[0], f[k], f[k + 1]])
    except Exception:
        return []
    return [_base(e, E.Body(V, np.array(F), "mesh"))] if len(F) else []


def import_dxf(doc, path):
    import ezdxf
    from ezdxf import recover
    try:
        d = ezdxf.readfile(path)
    except Exception:
        d, auditor = recover.readfile(path)
    warn = {}
    for L in d.layers:
        n = L.dxf.name
        if n not in doc.layers:
            doc.layers[n] = Layer(n, abs(L.color) if L.color else 7, _lt_name(L.dxf.get("linetype", "Continuous")),
                                  L.dxf.get("lineweight", 25) if L.dxf.get("lineweight", 25) >= 0 else 25, on=L.color >= 0,
                                  frozen=L.is_frozen(), locked=L.is_locked())
            if L.rgb:
                doc.layers[n].color = "#%02x%02x%02x" % L.rgb
    for b in d.blocks:
        if b.name.startswith("*") and not b.name.upper().startswith("*U"):
            continue
        if b.is_any_layout:
            continue
        ents = []
        for be in b:
            ents += convert_entity(be, warn)
        doc.blocks[b.name] = E.Block(b.name, b.block.dxf.base_point, ents)
    E.Insert.blocks = doc.blocks
    count = 0
    doc.begin("import")
    for e in d.modelspace():
        for o in convert_entity(e, warn):
            if o.layer not in doc.layers:
                doc.layers[o.layer] = Layer(o.layer)
            doc.add_keep(o); count += 1
    doc.end()
    units = d.header.get("$INSUNITS", 4)
    return count, warn, units


# ------------------------------------------------------------------------------------------------ export
def _aci_or_rgb(c):
    if isinstance(c, str) and c.startswith("#"):
        return {"true_color": int(c[1:], 16)}
    return {"color": int(c)}


def export_dxf(doc, path, ents=None, version="R2018"):
    import ezdxf
    d = ezdxf.new(version, setup=True)
    msp = d.modelspace()
    for L in doc.layers.values():
        if L.name in d.layers:
            lay = d.layers.get(L.name)
        else:
            lay = d.layers.add(L.name)
        if isinstance(L.color, str):
            lay.rgb = tuple(int(L.color[i:i + 2], 16) for i in (1, 3, 5))
        else:
            lay.color = int(L.color)
        lt = {"Continuous": "CONTINUOUS", "Dashed": "DASHED", "Hidden": "HIDDEN", "Center": "CENTER", "Phantom": "PHANTOM",
              "Dot": "DOT", "DashDot": "DASHDOT"}.get(L.ltype, "CONTINUOUS")
        if lt in d.linetypes:
            lay.dxf.linetype = lt
        lay.dxf.lineweight = int(L.lw) if L.lw in (0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211) else 25
        if not L.on:
            lay.off()
        if L.frozen:
            lay.freeze()
    for b in doc.blocks.values():
        if b.name in d.blocks:
            continue
        blk = d.blocks.new(b.name, base_point=tuple(b.base))
        for e in b.ents:
            _write(blk, e, d)
    for e in (ents if ents is not None else doc.ents.values()):
        _write(msp, e, d)
    d.header["$INSUNITS"] = {"mm": 4, "cm": 5, "m": 6, "in": 1, "ft": 2}.get(doc.settings.get("units", "mm"), 4)
    d.saveas(path)


def _attrs(e, d):
    a = {"layer": e.layer}
    a.update(_aci_or_rgb(e.color))
    if e.ltype not in ("ByLayer", None):
        lt = {"Dashed": "DASHED", "Hidden": "HIDDEN", "Center": "CENTER", "Phantom": "PHANTOM", "Dot": "DOT",
              "DashDot": "DASHDOT", "Continuous": "CONTINUOUS"}.get(e.ltype)
        if lt and lt in d.linetypes:
            a["linetype"] = lt
    if e.lw is not None and e.lw >= 0:
        a["lineweight"] = int(e.lw)
    return a


def _write(space, e, d):
    a = _attrs(e, d)
    k = e.kind
    try:
        if k == "line":
            space.add_line(tuple(e.p0), tuple(e.p1), dxfattribs=a)
        elif k == "point":
            space.add_point(tuple(e.p), dxfattribs=a)
        elif k == "circle":
            pl = Plane.from_normal(e.c, e.n)
            from ezdxf.math import OCS
            ocs = OCS(tuple(e.n))
            a["extrusion"] = tuple(e.n)
            space.add_circle(ocs.from_wcs(tuple(e.c)), e.r, dxfattribs=a)
        elif k == "arc":
            from ezdxf.math import OCS
            ocs = OCS(tuple(e.n)); a["extrusion"] = tuple(e.n)
            space.add_arc(ocs.from_wcs(tuple(e.c)), e.r, math.degrees(e.a0), math.degrees(e.a1), dxfattribs=a)
        elif k == "ellipse":
            a["extrusion"] = tuple(e.n)
            space.add_ellipse(tuple(e.c), tuple(e.major), e.ratio, e.t0, e.t1, dxfattribs=a)
        elif k == "polyline":
            if e.is3d:
                space.add_polyline3d([tuple(p) for p in e.pts], close=e.closed, dxfattribs=a)
            else:
                from ezdxf.math import OCS
                ocs = OCS(tuple(e.n)); q = [ocs.from_wcs(tuple(p)) for p in e.pts]
                a["extrusion"] = tuple(e.n); a["elevation"] = q[0][2] if q else 0
                pts = [(p[0], p[1], 0, 0, b) for p, b in zip(q, e.bulges)]
                pl = space.add_lwpolyline(pts, format="xyseb", close=e.closed, dxfattribs=a)
        elif k == "spline":
            if e.fit is not None and len(e.fit) >= 2 and e.weights is None:
                space.add_spline(fit_points=[tuple(p) for p in e.fit], degree=3, dxfattribs=a)
            else:
                s = space.add_spline(dxfattribs=a)
                s.dxf.degree = e.deg
                s.control_points = [tuple(p) for p in e.ctrl]; s.knots = list(e.knots)
                if e.weights:
                    s.weights = list(e.weights)
        elif k == "text":
            from ezdxf.enums import TextEntityAlignment
            if "\n" in e.s or e.width > 0:
                ap = (3 - e.valign if e.valign else 3) * 3 - 2 + e.halign if e.valign else 7 + e.halign
                ap = {3: 1, 2: 4, 1: 7, 0: 7}.get(e.valign, 7) + e.halign
                mt = space.add_mtext(e.s.replace("\n", "\\P"), dxfattribs=dict(a, char_height=e.h, insert=tuple(e.p),
                                                                                 text_direction=tuple(e.xdir), attachment_point=ap,
                                                                                 extrusion=tuple(e.n)))
                if e.width > 0:
                    mt.dxf.width = e.width
            else:
                from ezdxf.math import OCS
                ocs = OCS(tuple(e.n))
                a.update(height=e.h, rotation=math.degrees(e.rotation()), extrusion=tuple(e.n), width=e.wf)
                t = space.add_text(e.s, dxfattribs=a)
                al = {(0, 0): "LEFT", (1, 0): "CENTER", (2, 0): "RIGHT", (0, 1): "BOTTOM_LEFT", (1, 1): "BOTTOM_CENTER",
                      (2, 1): "BOTTOM_RIGHT", (0, 2): "MIDDLE_LEFT", (1, 2): "MIDDLE_CENTER", (2, 2): "MIDDLE_RIGHT",
                      (0, 3): "TOP_LEFT", (1, 3): "TOP_CENTER", (2, 3): "TOP_RIGHT"}[(e.halign, e.valign)]
                t.set_placement(ocs.from_wcs(tuple(e.p)), align=TextEntityAlignment[al])
        elif k == "hatch":
            from ezdxf.math import OCS
            ocs = OCS(tuple(e.n))
            h = space.add_hatch(dxfattribs=dict(a, extrusion=tuple(e.n)))
            if e.pattern == "SOLID":
                h.set_solid_fill(color=a.get("color", 256) if "color" in a else 256)
            else:
                h.set_pattern_fill(e.pattern if e.pattern in ("ANSI31", "ANSI32", "ANSI37", "NET", "LINE", "STEEL", "DASH", "BRICK", "CROSS") else "ANSI31",
                                   scale=e.scale, angle=e.angle)
            for i, l in enumerate(e.loops):
                q = [ocs.from_wcs(tuple(p)) for p in l]
                h.paths.add_polyline_path([(p[0], p[1]) for p in q], is_closed=True, flags=1 if i == 0 else 0)
                h.dxf.elevation = (0, 0, q[0][2])
        elif k == "insert":
            M = e.M
            from ezdxf.math import Matrix44
            if e.name not in d.blocks:
                return
            ref = space.add_blockref(e.name, (0, 0, 0), dxfattribs=a)
            ref.transform(Matrix44(M.T.ravel().tolist()))
        elif k in ("dimension", "leader", "table"):
            for x in e.explode():
                x.layer = e.layer; x.color = e.color
                _write(space, x, d)
        elif k == "body":
            V = e.V; F = e.F
            if len(F) > 32000:
                for f in F:
                    space.add_3dface([tuple(V[i]) for i in f] + [tuple(V[f[2]])], dxfattribs=a)
            else:
                pf = space.add_polyface(dxfattribs=a)
                pf.append_faces([[tuple(V[i]) for i in f] for f in F], dxfattribs={"layer": e.layer})
                pf.optimize()
    except Exception:
        pass


def export_stl(path, bodies):
    with open(path, "w") as f:
        f.write("solid ALIEF_CADPRO\n")
        for b in bodies:
            fn = b.normals()
            for (i, j, k), n in zip(b.F, fn):
                f.write(f"facet normal {n[0]:.6g} {n[1]:.6g} {n[2]:.6g}\n outer loop\n")
                for v in (b.V[i], b.V[j], b.V[k]):
                    f.write(f"  vertex {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
                f.write(" endloop\nendfacet\n")
        f.write("endsolid ALIEF_CADPRO\n")


def export_obj(path, bodies):
    with open(path, "w") as f:
        f.write("# ALIEF CAD PRO\n")
        off = 1
        for n, b in enumerate(bodies):
            f.write(f"o {b.label.replace(' ', '_')}_{n + 1}\n")
            for v in b.V:
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            for t in b.F:
                f.write(f"f {t[0] + off} {t[1] + off} {t[2] + off}\n")
            off += len(b.V)


def import_mesh(path):
    """STL (ascii / binary) or OBJ -> Body."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".obj":
        V = []; F = []
        for line in open(path, errors="ignore"):
            p = line.split()
            if not p:
                continue
            if p[0] == "v":
                V.append([float(x) for x in p[1:4]])
            elif p[0] == "f":
                idx = [int(x.split("/")[0]) for x in p[1:]]
                idx = [i - 1 if i > 0 else len(V) + i for i in idx]
                for k in range(1, len(idx) - 1):
                    F.append([idx[0], idx[k], idx[k + 1]])
        return E.Body(np.array(V), np.array(F), "mesh")
    data = open(path, "rb").read()
    if data[:5] == b"solid" and b"facet" in data[:400]:
        P = []
        for line in data.decode(errors="ignore").splitlines():
            s = line.strip().split()
            if s and s[0] == "vertex":
                P.append([float(x) for x in s[1:4]])
        P = np.array(P)
    else:
        n = int.from_bytes(data[80:84], "little")
        rec = np.frombuffer(data[84:84 + n * 50], dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
        P = rec["v"].reshape(-1, 3).astype(float)
    key = np.round(P, 6)
    V, inv = np.unique(key, axis=0, return_inverse=True)
    return E.Body(V, inv.reshape(-1, 3), "mesh")


# ------------------------------------------------------------------------------------------------ DWG
ODA_PATH = None          # set from Options > Files


def find_oda():
    if ODA_PATH and os.path.exists(ODA_PATH):
        return ODA_PATH
    cands = []
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        d = os.path.join(root, "ODA")
        if os.path.isdir(d):
            for sub in sorted(os.listdir(d), reverse=True):
                exe = os.path.join(d, sub, "ODAFileConverter.exe")
                if os.path.exists(exe):
                    cands.append(exe)
    w = shutil.which("ODAFileConverter")
    if w:
        cands.append(w)
    return cands[0] if cands else None


def dwg_convert(src, out_dir, to_fmt="DXF", ver="ACAD2018"):
    exe = find_oda()
    if not exe:
        raise RuntimeError("ODA File Converter is not installed")
    in_dir = tempfile.mkdtemp(prefix="cadpro_in_")
    shutil.copy(src, in_dir)
    args = [exe, in_dir, out_dir, ver, to_fmt, "0", "1", "*." + os.path.splitext(src)[1][1:].upper()]
    subprocess.run(args, check=False, timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    base = os.path.splitext(os.path.basename(src))[0]
    out = os.path.join(out_dir, base + "." + to_fmt.lower())
    if not os.path.exists(out):
        raise RuntimeError("ODA File Converter produced no output")
    return out
