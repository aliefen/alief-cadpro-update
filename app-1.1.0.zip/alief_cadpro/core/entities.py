"""Drawing entities (all coordinates in world space, float64)."""
import math
import numpy as np
from .geom import (EPS, TAU, Plane, unit, norm, v3, arbitrary_x, arc_pt, arc_pts, bulge_arc, arc_from_3p,
                   ang_in_plane, prim_tess, prim_ends, prims_tess, prims_length, xform_pt, xform_vec, m_det,
                   m_scale_factor, bspline_eval, poly_area2, poly_centroid2, point_in_poly, fmt)

REGISTRY = {}


def register(cls):
    REGISTRY[cls.kind] = cls
    return cls


def arr(a):
    return np.asarray(a, float).tolist()


class Entity:
    kind = "base"
    label = "Entity"
    text_tess = None        # set by the UI: f(text_entity) -> (V, F) triangles in world space
    text_measure = None     # set by the UI: f(string, font) -> width in units of the text height

    @staticmethod
    def measure(s, font="Arial"):
        if Entity.text_measure is not None:
            try:
                return Entity.text_measure(s, font)
            except Exception:
                pass
        return 0.92 * max((len(l) for l in str(s).split("\n")), default=0)
    anno_scale = 1.0        # drawing scale (1:N) used by annotative text / dimensions / symbols / tables

    def __init__(self):
        self.id = 0
        self.layer = "0"
        self.color = 256          # 256 = ByLayer, 0 = ByBlock, 1..255 ACI, or "#rrggbb"
        self.ltype = "ByLayer"
        self.lw = -1              # 1/100 mm; -1 ByLayer
        self._cache = {}

    # ---------------------------------------------------------------- common
    def touch(self):
        self._cache = {}

    def cached(self, key, fn):
        v = self._cache.get(key)
        if v is None:
            v = fn()
            self._cache[key] = v
        return v

    def copy(self):
        e = from_dict(self.to_dict())
        e.id = 0
        return e

    def base_dict(self):
        return {"kind": self.kind, "id": self.id, "layer": self.layer, "color": self.color, "ltype": self.ltype,
                "lw": self.lw}

    def load_base(self, d):
        self.id = d.get("id", 0); self.layer = d.get("layer", "0"); self.color = d.get("color", 256)
        self.ltype = d.get("ltype", "ByLayer"); self.lw = d.get("lw", -1)

    # ---------------------------------------------------------------- geometry interface
    def prims(self):
        return []

    def wire(self):
        """List of polylines (Nx3) for display."""
        def mk():
            out = []; cur = None
            for pr in self.prims():
                pts = prim_tess(pr)
                if cur is not None and norm(cur[-1] - pts[0]) < 1e-9:
                    cur = np.vstack([cur, pts[1:]])
                    out[-1] = cur
                else:
                    cur = pts; out.append(cur)
            return out
        return self.cached("wire", mk)

    def tris(self):
        return None

    def snaps(self):
        return {}

    def bbox(self):
        def mk():
            pts = [w for w in self.wire() if len(w)]
            t = self.tris()
            if t is not None and len(t[0]):
                pts.append(t[0])
            if not pts:
                return None
            P = np.vstack(pts)
            return P.min(axis=0), P.max(axis=0)
        return self.cached("bbox", mk)

    def transform(self, M):
        raise NotImplementedError

    def explode(self):
        return None

    def info(self):
        """[(name, value_text)] for LIST and the properties panel."""
        return []

    def props(self):
        """Editable geometry properties [(name, value, setter)]."""
        return []

    is_curve = False
    closed = False

    def length(self):
        return prims_length(self.prims())

    def plane(self):
        return None


# ===================================================================================================== POINT
@register
class PointE(Entity):
    kind = "point"; label = "Point"

    def __init__(self, p=(0, 0, 0)):
        super().__init__(); self.p = v3(p)

    def to_dict(self):
        d = self.base_dict(); d["p"] = arr(self.p); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"]); e.load_base(d); return e

    def wire(self):
        return self.cached("wire", lambda: [])

    def bbox(self):
        return self.p.copy(), self.p.copy()

    def snaps(self):
        return {"node": [self.p]}

    def transform(self, M):
        self.p = xform_pt(M, self.p); self.touch()

    def info(self):
        return [("Position", self.p)]

    def props(self):
        return [("Position X", self.p[0], lambda v: self._set(0, v)), ("Position Y", self.p[1], lambda v: self._set(1, v)),
                ("Position Z", self.p[2], lambda v: self._set(2, v))]

    def _set(self, i, v):
        self.p[i] = v; self.touch()


# ===================================================================================================== LINE
@register
class Line(Entity):
    kind = "line"; label = "Line"; is_curve = True

    def __init__(self, p0=(0, 0, 0), p1=(1, 0, 0)):
        super().__init__(); self.p0 = v3(p0); self.p1 = v3(p1)

    def to_dict(self):
        d = self.base_dict(); d.update(p0=arr(self.p0), p1=arr(self.p1)); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p0"], d["p1"]); e.load_base(d); return e

    def prims(self):
        return [("L", self.p0, self.p1)]

    def snaps(self):
        return {"end": [self.p0, self.p1], "mid": [(self.p0 + self.p1) / 2]}

    def transform(self, M):
        self.p0 = xform_pt(M, self.p0); self.p1 = xform_pt(M, self.p1); self.touch()

    def info(self):
        d = self.p1 - self.p0
        return [("Start", self.p0), ("End", self.p1), ("Length", norm(d)),
                ("Angle in XY", math.degrees(math.atan2(d[1], d[0])) % 360), ("Delta", d)]

    def props(self):
        r = []
        for nm, attr in (("Start", "p0"), ("End", "p1")):
            for i, ax in enumerate("XYZ"):
                r.append((f"{nm} {ax}", getattr(self, attr)[i], (lambda a, k: lambda v: self._set(a, k, v))(attr, i)))
        r.append(("Length", norm(self.p1 - self.p0), self._set_len))
        return r

    def _set(self, a, i, v):
        getattr(self, a)[i] = v; self.touch()

    def _set_len(self, L):
        d = unit(self.p1 - self.p0)
        if norm(d) > 0:
            self.p1 = self.p0 + d * L; self.touch()


# ===================================================================================================== CIRCLE / ARC
@register
class Circle(Entity):
    kind = "circle"; label = "Circle"; is_curve = True; closed = True

    def __init__(self, c=(0, 0, 0), r=1.0, n=(0, 0, 1)):
        super().__init__(); self.c = v3(c); self.r = float(r); self.n = unit(v3(n))

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), r=self.r, n=arr(self.n)); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["r"], d.get("n", (0, 0, 1))); e.load_base(d); return e

    def u(self):
        return arbitrary_x(self.n)

    def prims(self):
        return [("A", self.c, self.r, self.n, self.u(), 0.0, TAU)]

    def plane(self):
        return Plane.from_normal(self.c, self.n)

    def snaps(self):
        u = self.u(); v = np.cross(self.n, u)
        return {"cen": [self.c], "quad": [self.c + self.r * u, self.c + self.r * v, self.c - self.r * u, self.c - self.r * v]}

    def transform(self, M):
        self.c = xform_pt(M, self.c); self.n = unit(xform_vec(M, self.n)); self.r *= m_scale_factor(M); self.touch()

    def area(self):
        return math.pi * self.r ** 2

    def info(self):
        return [("Center", self.c), ("Radius", self.r), ("Diameter", 2 * self.r), ("Circumference", TAU * self.r),
                ("Area", self.area()), ("Normal", self.n)]

    def props(self):
        r = [(f"Center {ax}", self.c[i], (lambda k: lambda v: self._setc(k, v))(i)) for i, ax in enumerate("XYZ")]
        r += [("Radius", self.r, self._setr), ("Diameter", 2 * self.r, lambda v: self._setr(v / 2)),
              ("Area", self.area(), lambda v: self._setr(math.sqrt(max(v, 0) / math.pi)))]
        return r

    def _setc(self, i, v):
        self.c[i] = v; self.touch()

    def _setr(self, v):
        if v > 0:
            self.r = float(v); self.touch()


@register
class Arc(Entity):
    kind = "arc"; label = "Arc"; is_curve = True

    def __init__(self, c=(0, 0, 0), r=1.0, a0=0.0, a1=math.pi / 2, n=(0, 0, 1)):
        super().__init__(); self.c = v3(c); self.r = float(r); self.n = unit(v3(n))
        self.a0 = float(a0) % TAU; self.a1 = float(a1) % TAU
        if self.a1 <= self.a0 + 1e-12:
            self.a1 += TAU

    @classmethod
    def through(cls, p1, p2, p3):
        """Arc from p1 through p2 to p3."""
        r = arc_from_3p(p1, p2, p3)
        if r is None:
            return None
        c, rad, n = r
        u = arbitrary_x(n)
        a1 = ang_in_plane(c, n, u, p1); a2 = ang_in_plane(c, n, u, p2); a3 = ang_in_plane(c, n, u, p3)
        if (a2 - a1) % TAU < (a3 - a1) % TAU:
            return cls(c, rad, a1, a3, n)
        n = -n; u = arbitrary_x(n)
        return cls(c, rad, ang_in_plane(c, n, u, p1), ang_in_plane(c, n, u, p3), n)

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), r=self.r, a0=self.a0, a1=self.a1, n=arr(self.n)); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["r"], d["a0"], d["a1"], d.get("n", (0, 0, 1))); e.load_base(d); return e

    def u(self):
        return arbitrary_x(self.n)

    def prims(self):
        return [("A", self.c, self.r, self.n, self.u(), self.a0, self.a1)]

    def plane(self):
        return Plane.from_normal(self.c, self.n)

    def ends(self):
        u = self.u()
        return arc_pt(self.c, self.r, self.n, u, self.a0), arc_pt(self.c, self.r, self.n, u, self.a1)

    def snaps(self):
        u = self.u(); p0, p1 = self.ends()
        q = [arc_pt(self.c, self.r, self.n, u, k * math.pi / 2) for k in range(4)
             if (k * math.pi / 2 - self.a0) % TAU <= self.a1 - self.a0 + 1e-12]
        return {"end": [p0, p1], "mid": [arc_pt(self.c, self.r, self.n, u, (self.a0 + self.a1) / 2)], "cen": [self.c], "quad": q}

    def transform(self, M):
        u = self.u()
        p1 = xform_pt(M, arc_pt(self.c, self.r, self.n, u, self.a0))
        p2 = xform_pt(M, arc_pt(self.c, self.r, self.n, u, (self.a0 + self.a1) / 2))
        p3 = xform_pt(M, arc_pt(self.c, self.r, self.n, u, self.a1))
        if self.a1 - self.a0 > math.pi * 1.999:
            self.c = xform_pt(M, self.c); self.r *= m_scale_factor(M); self.n = unit(xform_vec(M, self.n)) * (1 if m_det(M) > 0 else -1)
            self.touch(); return
        a = Arc.through(p1, p2, p3)
        if a is not None:
            self.c, self.r, self.n, self.a0, self.a1 = a.c, a.r, a.n, a.a0, a.a1
        self.touch()

    def sweep(self):
        return self.a1 - self.a0

    def info(self):
        p0, p1 = self.ends()
        return [("Center", self.c), ("Radius", self.r), ("Start angle", math.degrees(self.a0)),
                ("End angle", math.degrees(self.a1) % 360), ("Included angle", math.degrees(self.sweep())),
                ("Arc length", self.r * self.sweep()), ("Start", p0), ("End", p1)]

    def props(self):
        r = [(f"Center {ax}", self.c[i], (lambda k: lambda v: self._setc(k, v))(i)) for i, ax in enumerate("XYZ")]
        r += [("Radius", self.r, self._setr), ("Start angle", math.degrees(self.a0), lambda v: self._seta(v, None)),
              ("End angle", math.degrees(self.a1) % 360, lambda v: self._seta(None, v))]
        return r

    def _setc(self, i, v):
        self.c[i] = v; self.touch()

    def _setr(self, v):
        if v > 0:
            self.r = float(v); self.touch()

    def _seta(self, a0, a1):
        a0 = math.radians(a0) % TAU if a0 is not None else self.a0
        a1 = math.radians(a1) % TAU if a1 is not None else self.a1 % TAU
        if a1 <= a0:
            a1 += TAU
        self.a0, self.a1 = a0, a1; self.touch()


# ===================================================================================================== ELLIPSE
@register
class Ellipse(Entity):
    kind = "ellipse"; label = "Ellipse"; is_curve = True

    def __init__(self, c=(0, 0, 0), major=(1, 0, 0), ratio=0.5, n=(0, 0, 1), t0=0.0, t1=TAU):
        super().__init__(); self.c = v3(c); self.major = v3(major); self.ratio = float(ratio); self.n = unit(v3(n))
        self.t0 = float(t0); self.t1 = float(t1)
        if self.t1 <= self.t0:
            self.t1 += TAU

    @property
    def closed(self):
        return self.t1 - self.t0 >= TAU - 1e-9

    def to_dict(self):
        d = self.base_dict(); d.update(c=arr(self.c), major=arr(self.major), ratio=self.ratio, n=arr(self.n), t0=self.t0, t1=self.t1)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["c"], d["major"], d["ratio"], d["n"], d["t0"], d["t1"]); e.load_base(d); return e

    def pts(self, seg=96):
        t = np.linspace(self.t0, self.t1, max(8, int(seg * (self.t1 - self.t0) / TAU)) + 1)
        a = self.major; b = np.cross(self.n, a) * self.ratio
        return self.c + np.cos(t)[:, None] * a + np.sin(t)[:, None] * b

    def prims(self):
        def mk():
            P = self.pts()
            return [("L", P[i], P[i + 1]) for i in range(len(P) - 1)]
        return self.cached("prims", mk)

    def wire(self):
        return self.cached("wire", lambda: [self.pts()])

    def plane(self):
        return Plane(self.c, self.major, np.cross(self.n, self.major))

    def snaps(self):
        a = self.major; b = np.cross(self.n, a) * self.ratio
        s = {"cen": [self.c], "quad": [self.c + a, self.c + b, self.c - a, self.c - b]}
        if not self.closed:
            P = self.pts(); s["end"] = [P[0], P[-1]]
        return s

    def transform(self, M):
        self.c = xform_pt(M, self.c)
        b = np.cross(self.n, self.major) * self.ratio
        self.major = xform_vec(M, self.major); b2 = xform_vec(M, b)
        n2 = unit(np.cross(self.major, b2))
        self.n = n2; self.ratio = norm(b2) / max(norm(self.major), EPS); self.touch()

    def area(self):
        return math.pi * norm(self.major) ** 2 * self.ratio if self.closed else 0.0

    def info(self):
        return [("Center", self.c), ("Major radius", norm(self.major)), ("Minor radius", norm(self.major) * self.ratio),
                ("Ratio", self.ratio), ("Area", self.area())]


# ===================================================================================================== POLYLINE
@register
class Polyline(Entity):
    kind = "polyline"; label = "Polyline"; is_curve = True

    def __init__(self, pts=(), closed=False, bulges=None, n=(0, 0, 1), is3d=False):
        super().__init__()
        self.pts = np.asarray(pts, float).reshape(-1, 3).copy() if len(pts) else np.zeros((0, 3))
        self.bulges = np.zeros(len(self.pts)) if bulges is None else np.asarray(bulges, float).copy()
        self.closed = bool(closed); self.n = unit(v3(n)); self.is3d = bool(is3d)
        self.width = 0.0

    def to_dict(self):
        d = self.base_dict(); d.update(pts=arr(self.pts), bulges=arr(self.bulges), closed=self.closed, n=arr(self.n), is3d=self.is3d)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["pts"], d["closed"], d.get("bulges"), d.get("n", (0, 0, 1)), d.get("is3d", False)); e.load_base(d)
        return e

    def seg_count(self):
        n = len(self.pts)
        return n if self.closed else n - 1

    def prims(self):
        def mk():
            out = []; n = len(self.pts)
            for i in range(self.seg_count()):
                p0, p1 = self.pts[i], self.pts[(i + 1) % n]
                if norm(p1 - p0) < 1e-12:
                    continue
                b = self.bulges[i] if i < len(self.bulges) else 0.0
                a = bulge_arc(p0, p1, b, self.n) if abs(b) > 1e-12 and not self.is3d else None
                out.append(("A",) + a if a else ("L", p0.copy(), p1.copy()))
            return out
        return self.cached("prims", mk)

    def plane(self):
        if self.is3d or len(self.pts) == 0:
            return None
        return Plane.from_normal(self.pts[0], self.n)

    def snaps(self):
        s = {"end": list(self.pts), "mid": [], "cen": []}
        from .geom import prim_point, prim_len
        for pr in self.prims():
            s["mid"].append(prim_point(pr, prim_len(pr) / 2))
            if pr[0] == "A":
                s["cen"].append(pr[1])
        return s

    def transform(self, M):
        self.pts = xform_pt(M, self.pts)
        self.n = unit(xform_vec(M, self.n))
        if m_det(M) < 0:
            self.bulges = -self.bulges
        self.touch()

    def explode(self):
        out = []
        for pr in self.prims():
            if pr[0] == "L":
                out.append(Line(pr[1], pr[2]))
            else:
                c, r, n, u, a0, a1 = pr[1:]
                p0, p1 = prim_ends(pr); pm = arc_pt(c, r, n, u, (a0 + a1) / 2)
                a = Arc.through(p0, pm, p1)
                if a:
                    out.append(a)
        return out

    def area(self):
        if not self.closed or self.is3d:
            return 0.0
        P = prims_tess(self.prims())
        pl = Plane.from_normal(self.pts[0], self.n)
        return abs(poly_area2(pl.to_local(P)[:, :2]))

    def info(self):
        r = [("Vertices", len(self.pts)), ("Closed", "Yes" if self.closed else "No"), ("Length", self.length())]
        if self.closed:
            r.append(("Area", self.area()))
        return r

    def props(self):
        r = [("Closed (1/0)", 1 if self.closed else 0, self._setclosed)]
        for i, p in enumerate(self.pts[:40]):
            for k, ax in enumerate("XYZ"):
                r.append((f"Vertex {i + 1} {ax}", p[k], (lambda j, kk: lambda v: self._setv(j, kk, v))(i, k)))
        return r

    def _setclosed(self, v):
        self.closed = bool(round(v)); self.touch()

    def _setv(self, i, k, v):
        self.pts[i, k] = v; self.touch()


def polyline_from_prims(prims, n=None, closed=None):
    """Build a planar polyline (with bulges) from connected primitives."""
    if not prims:
        return None
    pts = []; bul = []
    for pr in prims:
        a, b = prim_ends(pr)
        pts.append(a)
        if pr[0] == "A":
            sw = pr[6] - pr[5]
            sgn = 1.0
            if n is not None and np.dot(pr[3], n) < 0:
                sgn = -1.0
            bul.append(sgn * math.tan(sw / 4))
            if n is None:
                n = pr[3]
        else:
            bul.append(0.0)
    end = prim_ends(prims[-1])[1]
    if closed is None:
        closed = norm(end - pts[0]) < 1e-7
    if not closed:
        pts.append(end); bul.append(0.0)
    if n is None:
        from .geom import plane_of_points
        r = plane_of_points(np.vstack([pts, [end]]))
        n = r[1] if r else np.array([0, 0, 1.0])
        if np.dot(n, [0, 0, 1]) < 0 and abs(n[2]) > 0.5:
            n = -n
    return Polyline(np.array(pts), closed, bul, n)


# ===================================================================================================== SPLINE
@register
class Spline(Entity):
    kind = "spline"; label = "Spline"; is_curve = True

    def __init__(self, ctrl=(), knots=None, deg=3, weights=None, fit=None, closed=False):
        super().__init__()
        self.ctrl = np.asarray(ctrl, float).reshape(-1, 3)
        self.deg = int(deg)
        if knots is None:
            n = len(self.ctrl); p = min(self.deg, n - 1)
            self.deg = p
            knots = [0] * (p + 1) + list(np.linspace(0, 1, n - p + 1)[1:-1]) + [1] * (p + 1)
        self.knots = [float(k) for k in knots]
        self.weights = None if weights is None else [float(w) for w in weights]
        self.fit = None if fit is None else np.asarray(fit, float).reshape(-1, 3)
        self.closed = bool(closed)

    @classmethod
    def through(cls, pts):
        from .geom import bspline_interp
        P = np.asarray(pts, float)
        ctrl, U = bspline_interp(P, 3)
        s = cls(ctrl, U, min(3, len(P) - 1)); s.fit = P.copy()
        s.closed = norm(P[0] - P[-1]) < 1e-9
        return s

    def to_dict(self):
        d = self.base_dict()
        d.update(ctrl=arr(self.ctrl), knots=self.knots, deg=self.deg, weights=self.weights,
                 fit=None if self.fit is None else arr(self.fit), closed=self.closed)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["ctrl"], d["knots"], d["deg"], d.get("weights"), d.get("fit"), d.get("closed", False)); e.load_base(d)
        return e

    def pts(self, n=None):
        n = n or max(32, 12 * len(self.ctrl))
        U = self.knots
        t = np.linspace(U[self.deg], U[-self.deg - 1], n + 1)
        return bspline_eval(self.ctrl, U, self.deg, t, self.weights)

    def prims(self):
        def mk():
            P = self.pts()
            return [("L", P[i], P[i + 1]) for i in range(len(P) - 1) if norm(P[i + 1] - P[i]) > 1e-12]
        return self.cached("prims", mk)

    def wire(self):
        return self.cached("wire", lambda: [self.pts()])

    def plane(self):
        from .geom import plane_of_points
        r = plane_of_points(self.ctrl)
        if r is None or r[2] > 1e-6:
            return None
        return Plane.from_normal(r[0], r[1])

    def snaps(self):
        P = self.pts(8)
        s = {"end": [P[0], P[-1]]}
        if self.fit is not None:
            s["node"] = list(self.fit)
        return s

    def transform(self, M):
        self.ctrl = xform_pt(M, self.ctrl)
        if self.fit is not None:
            self.fit = xform_pt(M, self.fit)
        self.touch()

    def info(self):
        return [("Degree", self.deg), ("Control points", len(self.ctrl)),
                ("Fit points", 0 if self.fit is None else len(self.fit)), ("Length", self.length())]


# ===================================================================================================== TEXT
@register
class Text(Entity):
    kind = "text"; label = "Text"
    HALIGN = ["Left", "Center", "Right"]
    VALIGN = ["Baseline", "Bottom", "Middle", "Top"]

    def __init__(self, p=(0, 0, 0), s="Text", h=2.5, xdir=(1, 0, 0), n=(0, 0, 1), halign=0, valign=0, font="Arial", wf=1.0):
        super().__init__(); self.p = v3(p); self.s = str(s); self.anno = 0.0; self.hm = float(h); self.n = unit(v3(n))
        x = v3(xdir); x = x - np.dot(x, self.n) * self.n
        self.xdir = unit(x) if norm(x) > EPS else arbitrary_x(self.n)
        self.halign = int(halign); self.valign = int(valign); self.font = font; self.wf = float(wf)
        self.width = 0.0      # mtext box width (0 = no wrap)

    @property
    def h(self):
        return self.anno * Entity.anno_scale if self.anno else self.hm

    @h.setter
    def h(self, v):
        if self.anno:
            self.anno = float(v) / Entity.anno_scale
        else:
            self.hm = float(v)

    def ydir(self):
        return np.cross(self.n, self.xdir)

    def rotation(self):
        ax = arbitrary_x(self.n); ay = np.cross(self.n, ax)
        return math.atan2(np.dot(self.xdir, ay), np.dot(self.xdir, ax))

    def to_dict(self):
        d = self.base_dict()
        d.update(p=arr(self.p), s=self.s, h=self.hm, anno=self.anno, xdir=arr(self.xdir), n=arr(self.n), halign=self.halign,
                 valign=self.valign, font=self.font, wf=self.wf, width=self.width)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"], d["s"], d["h"], d["xdir"], d["n"], d.get("halign", 0), d.get("valign", 0), d.get("font", "Arial"),
                d.get("wf", 1.0))
        e.width = d.get("width", 0.0); e.anno = d.get("anno", 0.0); e.load_base(d); return e

    def tris(self):
        def mk():
            if Entity.text_tess is not None:
                try:
                    return Entity.text_tess(self)
                except Exception:
                    pass
            return None
        return self.cached("tris", mk)

    def box_local(self):
        lines = self.s.split("\n")
        w = max(len(l) for l in lines) * self.h * 0.62 * self.wf
        H = self.h * (1 + 1.6 * (len(lines) - 1))
        return w, H

    def wire(self):
        def mk():
            if self.tris() is not None:
                return []
            w, H = self.box_local()
            x, y = self.xdir, self.ydir()
            dx = [0, -w / 2, -w][self.halign]
            o = self.p + dx * x
            return [np.array([o, o + w * x, o + w * x + self.h * y, o + self.h * y, o])]
        return self.cached("wire", mk)

    def snaps(self):
        return {"ins": [self.p]}

    def plane(self):
        return Plane(self.p, self.xdir, self.ydir())

    def transform(self, M):
        sf = m_scale_factor(M)
        y = self.ydir(); x0 = self.xdir.copy()
        self.p = xform_pt(M, self.p); x2 = unit(xform_vec(M, self.xdir)); y2 = unit(xform_vec(M, y))
        if m_det(M) < 0:      # mirrored text stays readable (MIRRTEXT = 0)
            if np.dot(-x2, x0) >= np.dot(x2, x0):
                x2 = -x2
                if self.halign in (0, 2) and "\n" not in self.s:
                    w = self.box_local()[0]
                    self.p = self.p - x2 * w * (1 if self.halign == 0 else -1)
            else:
                y2 = -y2
        self.n = unit(np.cross(x2, y2)); self.xdir = x2
        if not self.anno:
            self.hm *= sf
        self.touch()

    def info(self):
        return [("Text", self.s), ("Height", self.h), ("Annotative (paper mm)", self.anno or "No"),
                ("Rotation", math.degrees(self.rotation())), ("Insertion", self.p), ("Font", self.font)]

    def props(self):
        return [("Text", self.s, self._sets), ("Height", self.h, self._seth), ("Paper height (0=off)", self.anno, self._setanno),
                ("Rotation", math.degrees(self.rotation()), self._setrot), ("Width factor", self.wf, self._setwf),
                ("Insert X", self.p[0], lambda v: self._setp(0, v)), ("Insert Y", self.p[1], lambda v: self._setp(1, v)),
                ("Insert Z", self.p[2], lambda v: self._setp(2, v))]

    def _sets(self, v):
        self.s = str(v); self.touch()

    def _seth(self, v):
        if v > 0:
            self.h = float(v); self.touch()

    def _setwf(self, v):
        if v > 0:
            self.wf = float(v); self.touch()

    def _setanno(self, v):
        v = float(v)
        if v > 0:
            self.anno = v
        else:
            self.hm = self.h; self.anno = 0.0
        self.touch()

    def _setrot(self, deg):
        ax = arbitrary_x(self.n); ay = np.cross(self.n, ax); a = math.radians(deg)
        self.xdir = math.cos(a) * ax + math.sin(a) * ay; self.touch()

    def _setp(self, i, v):
        self.p[i] = v; self.touch()


# ===================================================================================================== HATCH
HATCH_PATTERNS = {   # name: list of (angle deg, spacing factor, dash) line families
    "SOLID": [], "ANSI31": [(45, 3.175, None)], "ANSI32": [(45, 9.525, None), (45, 9.525, "off")],
    "ANSI37": [(45, 3.175, None), (135, 3.175, None)], "NET": [(0, 3.175, None), (90, 3.175, None)],
    "LINE": [(0, 3.175, None)], "STEEL": [(45, 3.175, None), (45, 3.175, "off2")], "DASH": [(0, 3.175, "dash")],
    "BRICK": [(0, 6.35, None)], "CROSS": [(0, 6.35, None), (90, 6.35, None)],
}


@register
class Hatch(Entity):
    kind = "hatch"; label = "Hatch"

    def __init__(self, loops=(), n=(0, 0, 1), pattern="SOLID", scale=1.0, angle=0.0):
        super().__init__(); self.loops = [np.asarray(l, float).reshape(-1, 3) for l in loops]
        self.n = unit(v3(n)); self.pattern = pattern; self.scale = float(scale); self.angle = float(angle)

    def to_dict(self):
        d = self.base_dict(); d.update(loops=[arr(l) for l in self.loops], n=arr(self.n), pattern=self.pattern, scale=self.scale,
                                       angle=self.angle)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["loops"], d["n"], d["pattern"], d["scale"], d.get("angle", 0)); e.load_base(d); return e

    def plane(self):
        o = self.loops[0][0] if self.loops else np.zeros(3)
        return Plane.from_normal(o, self.n)

    def local_loops(self):
        pl = self.plane()
        return pl, [pl.to_local(l)[:, :2] for l in self.loops if len(l) >= 3]

    def tris(self):
        def mk():
            if self.pattern != "SOLID":
                return None
            pl, L = self.local_loops()
            return triangulate_loops(pl, L)
        return self.cached("tris", mk)

    def wire(self):
        def mk():
            if self.pattern == "SOLID":
                return []
            pl, L = self.local_loops()
            out = []
            for ang, sp, dash in HATCH_PATTERNS.get(self.pattern, [(45, 3.175, None)]):
                if dash == "off" or dash == "off2":
                    continue
                for seg in hatch_lines(L, math.radians(ang + self.angle), sp * self.scale):
                    out.append(pl.to_world(np.array(seg)))
                if len(out) > 20000:
                    break
            return out
        return self.cached("wire", mk)

    def transform(self, M):
        self.loops = [xform_pt(M, l) for l in self.loops]; self.n = unit(xform_vec(M, self.n)) if m_det(M) > 0 else unit(-xform_vec(M, -self.n))
        self.scale *= m_scale_factor(M); self.touch()

    def area(self):
        pl, L = self.local_loops()
        return area_evenodd(L)

    def info(self):
        return [("Pattern", self.pattern), ("Scale", self.scale), ("Angle", self.angle), ("Loops", len(self.loops)),
                ("Area", self.area())]

    def props(self):
        return [("Pattern scale", self.scale, self._setsc), ("Pattern angle", self.angle, self._setang)]

    def _setsc(self, v):
        if v > 0:
            self.scale = v; self.touch()

    def _setang(self, v):
        self.angle = v; self.touch()


def area_evenodd(loops2):
    A = 0.0
    for i, l in enumerate(loops2):
        a = abs(poly_area2(l)); depth = sum(1 for j, m in enumerate(loops2) if j != i and point_in_poly(l[0], m))
        A += a if depth % 2 == 0 else -a
    return A


def triangulate_loops(pl, loops2, fill="EvenOdd"):
    """Triangulate 2D loops (even-odd) with manifold3d; returns (V world, F)."""
    import manifold3d as m3
    loops2 = [np.asarray(l, float) for l in loops2 if len(l) >= 3]
    if not loops2:
        return None
    cs = m3.CrossSection([l for l in loops2], getattr(m3.FillRule, fill))
    polys = [np.asarray(p, float) for p in cs.to_polygons()]
    if not polys:
        return None
    F = np.asarray(m3.triangulate(polys), np.int32)
    V2 = np.vstack(polys)
    return pl.to_world(V2), F


def hatch_lines(loops2, ang, spacing):
    """Parallel hatch line segments clipped (even-odd) to 2D loops."""
    if spacing <= 0:
        return []
    ca, sa = math.cos(ang), math.sin(ang)
    R = np.array([[ca, sa], [-sa, ca]])          # rotate world->hatch frame (lines along x')
    segs = []
    for l in loops2:
        q = l @ R.T
        segs.append(np.stack([q, np.roll(q, -1, axis=0)], axis=1))
    if not segs:
        return []
    S = np.vstack(segs)
    y0, y1 = S[:, :, 1].min(), S[:, :, 1].max()
    if (y1 - y0) / spacing > 4000:
        spacing = (y1 - y0) / 4000
    ys = np.arange(math.floor(y0 / spacing) * spacing, y1, spacing)
    out = []
    Ri = R
    a = S[:, 0]; b = S[:, 1]
    for y in ys:
        m = (a[:, 1] > y) != (b[:, 1] > y)
        if not m.any():
            continue
        aa, bb = a[m], b[m]
        xs = np.sort(aa[:, 0] + (y - aa[:, 1]) * (bb[:, 0] - aa[:, 0]) / (bb[:, 1] - aa[:, 1]))
        for i in range(0, len(xs) - 1, 2):
            out.append([np.array([xs[i], y]) @ Ri, np.array([xs[i + 1], y]) @ Ri])
    return out


# ===================================================================================================== DIMENSION
@register
class Dimension(Entity):
    kind = "dimension"; label = "Dimension"

    def __init__(self, dtype="aligned", pts=(), n=(0, 0, 1), xdir=(1, 0, 0), style=None):
        super().__init__(); self.dtype = dtype; self.dpts = [v3(p) for p in pts]; self.n = unit(v3(n))
        self.xdir = unit(v3(xdir)); self.style = dict(DIMSTYLE_DEFAULT, **(style or {}))
        self.override = ""

    def to_dict(self):
        d = self.base_dict(); d.update(dtype=self.dtype, pts=[arr(p) for p in self.dpts], n=arr(self.n), xdir=arr(self.xdir),
                                       style=self.style, override=self.override)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["dtype"], d["pts"], d["n"], d.get("xdir", (1, 0, 0)), d.get("style")); e.override = d.get("override", "")
        e.load_base(d); return e

    def plane(self):
        x = self.xdir - np.dot(self.xdir, self.n) * self.n
        if norm(x) < EPS:
            x = arbitrary_x(self.n)
        return Plane(self.dpts[0], x, np.cross(self.n, unit(x)))

    def measure(self):
        P = self.dpts; pl = self.plane()
        if self.dtype == "linear":
            q = pl.to_local(np.array(P))
            return abs(q[1, 0] - q[0, 0]) if self.style.get("rot", 0) == 0 else abs(q[1, 1] - q[0, 1])
        if self.dtype == "aligned":
            return norm(P[1] - P[0])
        if self.dtype == "radius":
            return norm(P[1] - P[0])
        if self.dtype == "diameter":
            return 2 * norm(P[1] - P[0])
        if self.dtype == "angular":
            a = unit(P[1] - P[0]); b = unit(P[2] - P[0])
            return math.degrees(math.acos(max(-1, min(1, np.dot(a, b)))))
        return 0.0

    def text(self):
        if self.override:
            return self.override.replace("<>", self._num())
        pre = {"radius": "R", "diameter": "Ø"}.get(self.dtype, "")
        suf = "°" if self.dtype == "angular" else ""
        return pre + self._num() + suf

    def _num(self):
        v = self.measure() * (1 if self.dtype == "angular" else self.style.get("lfac", 1.0))
        return f"{v:.{int(self.style.get('dec', 0 if self.dtype != 'angular' else 1))}f}"

    def geometry(self):
        """(lines [Nx3 polylines], arrows [(tip, dir)], text (pos, xdir, height, string))."""
        def mk():
            return _dim_geometry(self)
        return self.cached("geom", mk)

    def wire(self):
        return self.cached("wire", lambda: self.geometry()[0])

    def tris(self):
        def mk():
            lines, arrows, txt = self.geometry()
            Vs, Fs, off = [], [], 0
            asz = eff_style(self.style)["asz"]
            for tip, d in arrows:
                d = unit(d); s = np.cross(self.n, d)
                V = np.array([tip, tip - d * asz + s * asz / 6, tip - d * asz - s * asz / 6])
                Vs.append(V); Fs.append(np.array([[off, off + 1, off + 2]])); off += 3
            if txt:
                t = Text(txt[0], txt[3], txt[2], txt[1], self.n, 1, 1)
                tt = t.tris()
                if tt is not None:
                    Vs.append(tt[0]); Fs.append(tt[1] + off); off += len(tt[0])
            if not Vs:
                return None
            return np.vstack(Vs), np.vstack(Fs).astype(np.int32)
        return self.cached("tris", mk)

    def snaps(self):
        return {"node": list(self.dpts)}

    def transform(self, M):
        self.dpts = [xform_pt(M, p) for p in self.dpts]; self.n = unit(xform_vec(M, self.n)); self.xdir = unit(xform_vec(M, self.xdir))
        self.touch()

    def explode(self):
        out = [Line(l[i], l[i + 1]) for l in self.geometry()[0] for i in range(len(l) - 1)]
        txt = self.geometry()[2]
        if txt:
            out.append(Text(txt[0], txt[3], txt[2], txt[1], self.n, 1, 1))
        return out

    def info(self):
        return [("Type", self.dtype), ("Measurement", self.measure()), ("Text", self.text())]

    def props(self):
        return [("Text height", self.style["th"], lambda v: self._st("th", v)), ("Arrow size", self.style["asz"], lambda v: self._st("asz", v)),
                ("Decimals", self.style["dec"], lambda v: self._st("dec", int(v))), ("Text override", self.override, self._ov)]

    def _st(self, k, v):
        self.style[k] = v; self.touch()

    def _ov(self, v):
        self.override = str(v) if v not in (None, 0, 0.0) else ""; self.touch()


DIMSTYLE_DEFAULT = {"th": 2.5, "asz": 2.5, "exo": 1.25, "exe": 1.25, "gap": 0.8, "dec": 0, "lfac": 1.0, "rot": 0, "anno": False}


def eff_style(style):
    if not style.get("anno"):
        return style
    k = Entity.anno_scale
    return dict(style, **{x: style[x] * k for x in ("th", "asz", "exo", "exe", "gap")})


def _dim_geometry(d):
    st = eff_style(d.style); pl = d.plane(); n = d.n
    P = d.dpts
    lines, arrows = [], []
    th = st["th"]; gap = st["gap"]
    txt = None
    if d.dtype in ("linear", "aligned") and len(P) >= 3:
        if d.dtype == "linear":
            ang = math.radians(st.get("rot", 0) or 0)
            dx = math.cos(ang) * pl.x + math.sin(ang) * pl.y
        else:
            dx = unit(P[1] - P[0]) if norm(P[1] - P[0]) > EPS else pl.x
        dy = np.cross(n, dx)
        off = np.dot(P[2] - P[0], dy)
        a = P[0] + dy * (off - np.dot(P[0] - P[0], dy)); b = P[1] + dy * (off - np.dot(P[1] - P[0], dy))
        # extension lines
        for p, q in ((P[0], a), (P[1], b)):
            v = q - p; L = norm(v)
            if L > EPS:
                u = v / L
                lines.append(np.array([p + u * min(st["exo"], L), q + u * st["exe"]]))
        lines.append(np.array([a, b]))
        if norm(b - a) > EPS:
            arrows += [(a, a - b), (b, b - a)]
        mid = (a + b) / 2
        tx = dx if np.dot(dx, pl.x) >= -1e-9 else -dx
        ty = np.cross(n, tx)
        txt = (mid + ty * (th / 2 + gap), tx, th, d.text())
    elif d.dtype in ("radius", "diameter") and len(P) >= 2:
        c, p = P[0], P[1]
        u = unit(p - c); r = norm(p - c)
        q = P[2] if len(P) > 2 else p + u * th * 3
        if d.dtype == "diameter":
            lines.append(np.array([c - u * r, p])); arrows += [(p, u), (c - u * r, -u)]
        else:
            lines.append(np.array([c, p])); arrows.append((p, u))
        if norm(q - p) > EPS and np.dot(q - p, u) > 0:
            lines.append(np.array([p, q]))
        tx = pl.x if np.dot(u, pl.x) >= 0 else -pl.x
        ty = np.cross(n, tx)
        txt = (q + tx * (th * 0.62 * len(d.text()) / 2 + gap) * (1 if np.dot(u, pl.x) >= 0 else 1) + ty * 0, tx, th, d.text())
        txt = (txt[0] + ty * (th / 2 + gap), tx, th, txt[3])
    elif d.dtype == "angular" and len(P) >= 4:
        c, p1, p2, loc = P[:4]
        r = norm(loc - c)
        u = unit(p1 - c); w = unit(p2 - c)
        nn = unit(np.cross(u, w))
        if norm(nn) < EPS:
            nn = n
        a1 = math.acos(max(-1, min(1, np.dot(u, w))))
        pts = arc_pts(c, r, nn, u, 0, a1, 32)
        lines.append(pts)
        for e, p in ((pts[0], p1), (pts[-1], p2)):
            if norm(e - c) > norm(p - c):
                lines.append(np.array([p, e + unit(e - c) * st["exe"]]))
        t0 = np.cross(nn, u); t1 = -np.cross(nn, w)
        arrows += [(pts[0], -t0), (pts[-1], -t1)]
        m = arc_pt(c, r + th * 0.8, nn, u, a1 / 2)
        tx = unit(np.cross(nn, m - c)) * -1
        if np.dot(tx, pl.x) < 0:
            tx = -tx
        txt = (m, tx, th, d.text())
    return lines, arrows, txt


# ===================================================================================================== LEADER
@register
class Leader(Entity):
    kind = "leader"; label = "Leader"

    def __init__(self, pts=(), s="", h=2.5, n=(0, 0, 1), asz=2.5):
        super().__init__(); self.pts = np.asarray(pts, float).reshape(-1, 3); self.s = s; self.hm = float(h)
        self.n = unit(v3(n)); self.asz0 = float(asz); self.anno = False

    @property
    def h(self):
        return self.hm * (Entity.anno_scale if self.anno else 1.0)

    @property
    def asz(self):
        return self.asz0 * (Entity.anno_scale if self.anno else 1.0)

    def to_dict(self):
        d = self.base_dict(); d.update(pts=arr(self.pts), s=self.s, h=self.hm, n=arr(self.n), asz=self.asz0, anno=self.anno); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["pts"], d["s"], d["h"], d["n"], d.get("asz", 2.5)); e.anno = d.get("anno", False); e.load_base(d); return e

    def _txt(self):
        if not self.s or len(self.pts) < 2:
            return None
        pl = Plane.from_normal(self.pts[-1], self.n)
        right = np.dot(self.pts[-1] - self.pts[-2], pl.x) >= 0
        p = self.pts[-1] + pl.x * (self.h * 0.5 if right else -self.h * 0.5) - pl.y * self.h / 2
        return Text(p, self.s, self.h, pl.x, self.n, 0 if right else 2, 0)

    def wire(self):
        return self.cached("wire", lambda: [self.pts.copy()] if len(self.pts) >= 2 else [])

    def tris(self):
        def mk():
            if len(self.pts) < 2:
                return None
            tip = self.pts[0]; d = unit(self.pts[0] - self.pts[1]); s = np.cross(self.n, d); a = self.asz
            V = [np.array([tip, tip - d * a + s * a / 6, tip - d * a - s * a / 6])]; F = [np.array([[0, 1, 2]])]
            t = self._txt()
            tt = t.tris() if t else None
            if tt is not None:
                V.append(tt[0]); F.append(tt[1] + 3)
            return np.vstack(V), np.vstack(F).astype(np.int32)
        return self.cached("tris", mk)

    def snaps(self):
        return {"end": [self.pts[0], self.pts[-1]]} if len(self.pts) else {}

    def transform(self, M):
        self.pts = xform_pt(M, self.pts); self.n = unit(xform_vec(M, self.n))
        if not self.anno:
            self.hm *= m_scale_factor(M); self.asz0 *= m_scale_factor(M)
        self.touch()

    def explode(self):
        out = [Line(self.pts[i], self.pts[i + 1]) for i in range(len(self.pts) - 1)]
        t = self._txt()
        return out + ([t] if t else [])

    def info(self):
        return [("Text", self.s), ("Vertices", len(self.pts))]

    def props(self):
        return [("Text", self.s, self._sets), ("Text height", self.h, self._seth)]

    def _sets(self, v):
        self.s = str(v); self.touch()

    def _seth(self, v):
        if v > 0:
            self.hm = v / (Entity.anno_scale if self.anno else 1.0); self.touch()


# ===================================================================================================== BLOCK INSERT
class Block:
    def __init__(self, name, base=(0, 0, 0), ents=()):
        self.name = name; self.base = v3(base); self.ents = list(ents)

    def to_dict(self):
        return {"name": self.name, "base": arr(self.base), "ents": [e.to_dict() for e in self.ents]}

    @classmethod
    def from_dict(cls, d):
        return cls(d["name"], d["base"], [from_dict(x) for x in d["ents"]])


@register
class Insert(Entity):
    kind = "insert"; label = "Block reference"
    blocks = {}       # shared with the document (set by Document)

    def __init__(self, name="", M=None):
        super().__init__(); self.name = name; self.M = np.eye(4) if M is None else np.asarray(M, float); self.anno = False

    def Meff(self):
        if not self.anno:
            return self.M
        b = Insert.blocks.get(self.name); base = b.base if b is not None else np.zeros(3)
        k = Entity.anno_scale; S = np.eye(4) * k; S[3, 3] = 1; S[:3, 3] = base - k * base
        return self.M @ S

    @classmethod
    def make(cls, name, p, sx=1, sy=1, sz=1, rot=0.0, n=(0, 0, 1)):
        pl = Plane.from_normal(p, n)
        R = np.eye(4); c, s = math.cos(rot), math.sin(rot)
        R[:2, :2] = [[c, -s], [s, c]]
        S = np.diag([sx, sy, sz, 1.0])
        b = cls.blocks.get(name)
        T = np.eye(4)
        if b is not None:
            T[:3, 3] = -b.base
        return cls(name, pl.matrix() @ R @ S @ T)

    def to_dict(self):
        d = self.base_dict(); d.update(name=self.name, M=self.M.tolist(), anno=self.anno); return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["name"], d["M"]); e.anno = d.get("anno", False); e.load_base(d); return e

    def children(self):
        def mk():
            b = Insert.blocks.get(self.name)
            if b is None:
                return []
            out = []
            M = self.Meff(); sf = m_scale_factor(M)
            for e in b.ents:
                c = e.copy(); c.transform(M)
                if isinstance(c, Dimension) and abs(sf - 1) > 1e-12:
                    c.style["lfac"] = c.style.get("lfac", 1.0) / sf
                    if not c.style.get("anno"):
                        for k in ("th", "asz", "exo", "exe", "gap"):
                            c.style[k] = c.style.get(k, DIMSTYLE_DEFAULT[k]) * sf
                    c.touch()
                c.layer = e.layer if e.layer != "0" else self.layer
                if e.color == 0:
                    c.color = self.color
                out.append(c)
            return out
        return self.cached("children", mk)

    def wire(self):
        return self.cached("wire", lambda: [w for c in self.children() for w in c.wire()])

    def tris(self):
        def mk():
            V, F, off = [], [], 0
            for c in self.children():
                t = c.tris()
                if t is not None and len(t[0]):
                    V.append(t[0]); F.append(t[1] + off); off += len(t[0])
            return (np.vstack(V), np.vstack(F)) if V else None
        return self.cached("tris", mk)

    def prims(self):
        return self.cached("prims", lambda: [p for c in self.children() for p in c.prims()])

    def snaps(self):
        s = {"ins": [xform_pt(self.M, Insert.blocks[self.name].base) if self.name in Insert.blocks else self.M[:3, 3].copy()]}
        for c in self.children():
            for k, v in c.snaps().items():
                s.setdefault(k, []).extend(v)
        return s

    def transform(self, M):
        self.M = M @ self.M; self.touch()

    def explode(self):
        return [c.copy() for c in self.children()]

    def info(self):
        return [("Block", self.name), ("Insertion", xform_pt(self.M, Insert.blocks[self.name].base) if self.name in Insert.blocks else self.M[:3, 3]),
                ("Scale", m_scale_factor(self.M)), ("Annotative", "Yes" if self.anno else "No")]


# ===================================================================================================== MESH BODIES
@register
class Body(Entity):
    """Triangle-mesh body: role = solid | surface | mesh | plate | profile."""
    kind = "body"; label = "3D Solid"
    LABELS = {"solid": "3D Solid", "surface": "Surface", "mesh": "Mesh", "plate": "3D Plate", "profile": "3D Profile",
              "pipe": "3D Pipe", "fitting": "Pipe fitting", "equipment": "Equipment"}

    def __init__(self, V=(), F=(), role="solid", meta=None, iso=None):
        super().__init__()
        self.V = np.asarray(V, float).reshape(-1, 3); self.F = np.asarray(F, np.int64).reshape(-1, 3)
        self.role = role; self.meta = dict(meta or {}); self.iso = iso   # iso: list of Nx3 isolines for surfaces

    @property
    def label(self):
        return Body.LABELS.get(self.role, "Body")

    def to_dict(self):
        import base64
        d = self.base_dict()
        d.update(role=self.role, meta=_jsonable(self.meta),
                 V=base64.b64encode(self.V.astype("<f8").tobytes()).decode(),
                 F=base64.b64encode(self.F.astype("<i4").tobytes()).decode(),
                 iso=None if self.iso is None else [arr(i) for i in self.iso])
        return d

    @classmethod
    def from_dict(cls, d):
        import base64
        V = np.frombuffer(base64.b64decode(d["V"]), "<f8").reshape(-1, 3) if isinstance(d["V"], str) else d["V"]
        F = np.frombuffer(base64.b64decode(d["F"]), "<i4").reshape(-1, 3) if isinstance(d["F"], str) else d["F"]
        e = cls(V.copy(), F.astype(np.int64), d.get("role", "solid"), d.get("meta"), d.get("iso")); e.load_base(d)
        if e.iso is not None:
            e.iso = [np.asarray(i, float) for i in e.iso]
        return e

    def tris(self):
        return self.V, self.F

    def normals(self):
        def mk():
            a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
            fn = np.cross(b - a, c - a)
            ln = np.linalg.norm(fn, axis=1, keepdims=True); ln[ln == 0] = 1
            return fn / ln
        return self.cached("fn", mk)

    def edges(self, ang=25.0):
        """Feature edges (crease > ang deg) + boundary edges as (K,2,3) array."""
        def mk():
            F = self.F
            if len(F) == 0:
                return np.zeros((0, 2, 3))
            fn = self.normals()
            e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
            fi = np.tile(np.arange(len(F)), 3)
            # merge coincident vertices for topology
            key = np.round(self.V / max(1e-9, self.scale() * 1e-9)).astype(np.int64)
            _, inv = np.unique(key, axis=0, return_inverse=True)
            inv = inv.ravel()
            ee = np.sort(inv[e], axis=1)
            order = np.lexsort((ee[:, 1], ee[:, 0]))
            ee, fi, e = ee[order], fi[order], e[order]
            same = np.all(ee[1:] == ee[:-1], axis=1)
            keep = []
            i = 0; n = len(ee)
            while i < n:
                j = i + 1
                while j < n and same[j - 1]:
                    j += 1
                if j - i == 1:
                    keep.append(i)
                else:
                    c = abs(float(np.dot(fn[fi[i]], fn[fi[i + 1]])))
                    if np.dot(fn[fi[i]], fn[fi[i + 1]]) < math.cos(math.radians(ang)) or j - i > 2:
                        keep.append(i)
                i = j
            k = np.array(keep, int)
            if not len(k):
                return np.zeros((0, 2, 3))
            return np.stack([self.V[e[k, 0]], self.V[e[k, 1]]], axis=1)
        return self.cached("edges", mk)

    def scale(self):
        if len(self.V) == 0:
            return 1.0
        return max(1e-6, float(np.max(self.V.max(axis=0) - self.V.min(axis=0))))

    def wire(self):
        def mk():
            E = self.edges()
            out = [E[i] for i in range(len(E))]
            if self.iso is not None:
                out += list(self.iso)
            return out
        return self.cached("wire", mk)

    def prims(self):
        return self.cached("prims", lambda: [("L", e[0], e[1]) for e in self.edges()])

    def snaps(self):
        def mk():
            E = self.edges()
            if not len(E):
                return {}
            P = E.reshape(-1, 3)
            P = np.unique(np.round(P, 9), axis=0)
            s = {"end": list(P[:4000]), "mid": list(((E[:, 0] + E[:, 1]) / 2)[:4000])}
            if self.role == "profile" and "path" in self.meta:
                s["node"] = [np.asarray(p) for p in self.meta["path"]]
            return s
        return self.cached("snaps", mk)

    def transform(self, M):
        self.V = xform_pt(M, self.V)
        if m_det(M) < 0:
            self.F = self.F[:, ::-1].copy()
        if self.iso is not None:
            self.iso = [xform_pt(M, i) for i in self.iso]
        if "plane" in self.meta:
            pl = Plane.from_dict(self.meta["plane"]).transformed(M)
            self.meta["plane"] = pl.to_dict()
        if "path" in self.meta:
            self.meta["path"] = arr(xform_pt(M, np.asarray(self.meta["path"], float)))
        self.touch()

    def volume(self):
        a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
        return float(np.einsum("ij,ij->i", a, np.cross(b, c)).sum() / 6.0)

    def centroid(self):
        a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
        v = np.einsum("ij,ij->i", a, np.cross(b, c)) / 6.0
        V = v.sum()
        if abs(V) < 1e-18:
            return self.V.mean(axis=0) if len(self.V) else np.zeros(3)
        return ((a + b + c) / 4 * v[:, None]).sum(axis=0) / V

    def area(self):
        a = self.V[self.F[:, 0]]; b = self.V[self.F[:, 1]]; c = self.V[self.F[:, 2]]
        return float(np.linalg.norm(np.cross(b - a, c - a), axis=1).sum() / 2)

    def info(self):
        r = [("Type", self.label), ("Triangles", len(self.F))]
        if self.role in ("solid", "plate", "profile", "mesh"):
            r += [("Volume", abs(self.volume())), ("Centroid", self.centroid())]
        r.append(("Surface area", self.area()))
        m = self.meta
        if self.role == "plate":
            r += [("Mark", m.get("mark", "")), ("Thickness", m.get("thk")), ("Grade", m.get("grade")),
                  ("Plate area (one side)", m.get("area", 0))]
        if self.role == "profile":
            r += [("Mark", m.get("mark", "")), ("Profile", m.get("size")), ("Grade", m.get("grade")), ("Length", m.get("length"))]
        if self.role in ("pipe", "fitting", "equipment"):
            r += [("Item", m.get("ftype", "")), ("Size", m.get("size", ""))] + ([("Length", m["length"])] if "length" in m else [])
        return r

    def props(self):
        r = []
        if self.role in ("plate", "profile"):
            r.append(("Mark", self.meta.get("mark", ""), lambda v: self._meta("mark", str(v))))
            r.append(("Grade", self.meta.get("grade", ""), lambda v: self._meta("grade", str(v))))
        return r

    def _meta(self, k, v):
        self.meta[k] = v; self.touch()


# ===================================================================================================== IMAGE UNDERLAY
@register
class ImageE(Entity):
    """Raster underlay: origin o (lower-left), u = full width vector, v = full height vector."""
    kind = "image"; label = "Raster image"

    def __init__(self, data=b"", o=(0, 0, 0), u=(100, 0, 0), v=(0, 100, 0), wpx=1, hpx=1, name="image"):
        super().__init__(); self.data = data; self.o = v3(o); self.u = v3(u); self.v = v3(v)
        self.wpx = int(wpx); self.hpx = int(hpx); self.name = name; self.fade = 0.25; self.show_frame = True

    def to_dict(self):
        import base64
        d = self.base_dict(); d.update(data=base64.b64encode(self.data).decode(), o=arr(self.o), u=arr(self.u), v=arr(self.v),
                                       wpx=self.wpx, hpx=self.hpx, name=self.name, fade=self.fade, frame=self.show_frame)
        return d

    @classmethod
    def from_dict(cls, d):
        import base64
        e = cls(base64.b64decode(d["data"]), d["o"], d["u"], d["v"], d["wpx"], d["hpx"], d.get("name", "image"))
        e.fade = d.get("fade", 0.25); e.show_frame = d.get("frame", True); e.load_base(d); return e

    def corners(self):
        o, u, v = self.o, self.u, self.v
        return np.array([o, o + u, o + u + v, o + v])

    def wire(self):
        return self.cached("wire", lambda: [np.vstack([self.corners(), self.corners()[:1]])] if self.show_frame else [])

    def bbox(self):
        c = self.corners(); return c.min(axis=0), c.max(axis=0)

    def prims(self):
        c = self.corners()
        return [("L", c[i], c[(i + 1) % 4]) for i in range(4)]

    def snaps(self):
        return {"end": list(self.corners())}

    def pixel_to_world(self, px, py):
        """Pixel (x right, y down) -> world point."""
        return self.o + self.u * (px / self.wpx) + self.v * (1 - py / self.hpx)

    def world_to_pixel(self, p):
        pl = Plane(self.o, self.u, self.v)
        q = pl.to_local(p)
        return q[..., 0] / norm(self.u) * self.wpx, (1 - q[..., 1] / norm(self.v)) * self.hpx

    def transform(self, M):
        p0 = xform_pt(M, self.o); pu = xform_pt(M, self.o + self.u); pv = xform_pt(M, self.o + self.v)
        self.o, self.u, self.v = p0, pu - p0, pv - p0; self.touch()

    def info(self):
        return [("Image", self.name), ("Pixels", f"{self.wpx} x {self.hpx}"), ("Width", norm(self.u)), ("Height", norm(self.v)),
                ("Pixel size", norm(self.u) / max(1, self.wpx)), ("Fade", self.fade)]

    def props(self):
        return [("Fade (0-0.9)", self.fade, self._setfade), ("Frame (1/0)", 1 if self.show_frame else 0, self._setframe)]

    def _setfade(self, v):
        self.fade = min(0.9, max(0.0, float(v))); self.touch()

    def _setframe(self, v):
        self.show_frame = bool(round(v)); self.touch()


# ===================================================================================================== TABLE (BOM)
@register
class Table(Entity):
    """Table with annotative sizes (paper mm x drawing scale). Origin = top-left corner."""
    kind = "table"; label = "Table"

    @staticmethod
    def fit_widths(rows, mins, th=2.5, maxw=None):
        """Column widths (paper mm) wide enough for the longest cell of each column."""
        out = []
        for c, m in enumerate(mins):
            need = max((Entity.measure(r[c]) for r in rows if c < len(r)), default=0) * th + 1.6 * th
            w = max(float(m), round(need + 0.49))
            if maxw and c < len(maxw) and maxw[c]:
                w = min(w, maxw[c])
            out.append(w)
        return out

    def __init__(self, p=(0, 0, 0), rows=(), widths=(), title="", th=2.5, rh=7.0, xdir=(1, 0, 0), n=(0, 0, 1)):
        super().__init__(); self.p = v3(p); self.rows = [list(map(str, r)) for r in rows]; self.widths = [float(w) for w in widths]
        self.title = title; self.th = float(th); self.rh = float(rh); self.xdir = unit(v3(xdir)); self.n = unit(v3(n)); self.anno = True
        self.aligns = []

    def k(self):
        return Entity.anno_scale if self.anno else 1.0

    def to_dict(self):
        d = self.base_dict(); d.update(p=arr(self.p), rows=self.rows, widths=self.widths, title=self.title, th=self.th, rh=self.rh,
                                       xdir=arr(self.xdir), n=arr(self.n), anno=self.anno, aligns=self.aligns)
        return d

    @classmethod
    def from_dict(cls, d):
        e = cls(d["p"], d["rows"], d["widths"], d.get("title", ""), d["th"], d["rh"], d["xdir"], d["n"])
        e.anno = d.get("anno", True); e.aligns = d.get("aligns", []); e.load_base(d); return e

    def parts(self):
        def mk():
            k = self.k(); x = self.xdir; y = np.cross(self.n, x); rh = self.rh * k; th = self.th * k
            W = sum(self.widths) * k
            lines = []; texts = []
            yy = 0.0
            if self.title:
                texts.append(Text(self.p + x * W / 2 - y * rh * 0.6, self.title, th * 1.4, x, self.n, 1, 2))
                lines.append(np.array([self.p, self.p + x * W]))
                yy = rh * 1.2
            nrow = len(self.rows)
            for r in range(nrow + 1):
                o = self.p - y * (yy + r * rh)
                lines.append(np.array([o, o + x * W]))
            xs = np.concatenate([[0], np.cumsum(self.widths)]) * k
            bot = self.p - y * (yy + nrow * rh)
            for i, cx in enumerate(xs):          # inner column lines stop below the title row
                top = self.p if (i == 0 or i == len(xs) - 1) else self.p - y * yy
                lines.append(np.array([top + x * cx, bot + x * cx]))
            for r, row in enumerate(self.rows):
                for c, cell in enumerate(row[:len(self.widths)]):
                    al = self.aligns[c] if c < len(self.aligns) else (1 if r == 0 else 0)
                    if r == 0:
                        al = 1
                    cx0, cx1 = xs[c], xs[c + 1]
                    px = cx0 + 0.25 * th * 2 if al == 0 else ((cx0 + cx1) / 2 if al == 1 else cx1 - 0.5 * th)
                    pos = self.p + x * px - y * (yy + (r + 0.5) * rh)
                    room = (cx1 - cx0) - 1.0 * th; need = Entity.measure(cell) * th
                    wf = 1.0 if need <= room or need <= 0 else max(0.45, room / need)     # squeeze over-long cells
                    t = Text(pos, cell, th, x, self.n, al, 2, wf=wf)
                    texts.append(t)
            return lines, texts
        return self.cached("parts", mk)

    def wire(self):
        return self.cached("wire", lambda: list(self.parts()[0]))

    def tris(self):
        def mk():
            V, F, off = [], [], 0
            for t in self.parts()[1]:
                tt = t.tris()
                if tt is not None and len(tt[0]):
                    V.append(tt[0]); F.append(tt[1] + off); off += len(tt[0])
            return (np.vstack(V), np.vstack(F)) if V else None
        return self.cached("tris", mk)

    def snaps(self):
        L = self.parts()[0]
        return {"end": [L[0][0], L[0][1]]} if L else {}

    def transform(self, M):
        self.p = xform_pt(M, self.p); self.xdir = unit(xform_vec(M, self.xdir)); self.n = unit(xform_vec(M, self.n))
        if not self.anno:
            sf = m_scale_factor(M); self.th *= sf; self.rh *= sf; self.widths = [w * sf for w in self.widths]
        self.touch()

    def explode(self):
        L, T = self.parts()
        return [Line(l[0], l[1]) for l in L] + [Text(t.p, t.s, t.h, t.xdir, t.n, t.halign, t.valign, wf=t.wf) for t in T]

    def info(self):
        return [("Rows", len(self.rows)), ("Columns", len(self.widths)), ("Title", self.title)]


def _jsonable(o):
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    return o


def from_dict(d):
    return REGISTRY[d["kind"]].from_dict(d)
