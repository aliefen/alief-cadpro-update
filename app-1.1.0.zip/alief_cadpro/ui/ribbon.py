"""Modern ribbon: application button, quick access toolbar, tabs, panels with large / small / split buttons."""
from PySide6.QtCore import Qt, QSize, Signal
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QToolButton, QStackedWidget, QFrame, QLabel, QMenu,
                               QGridLayout, QSizePolicy, QButtonGroup, QLineEdit, QCompleter)
from PySide6.QtGui import QAction
from .icons import icon


def _wrap(text):
    if len(text) <= 9 or " " not in text:
        return text
    words = text.split(" "); best = None
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        m = max(len(a), len(b))
        if best is None or m < best[0]:
            best = (m, a + "\n" + b)
    return best[1]


class RibbonPanel(QFrame):
    def __init__(self, title, ribbon):
        super().__init__(); self.setObjectName("rpanel"); self.ribbon = ribbon
        v = QVBoxLayout(self); v.setContentsMargins(4, 3, 4, 1); v.setSpacing(0)
        self.body = QHBoxLayout(); self.body.setSpacing(1); self.body.setContentsMargins(0, 0, 0, 0)
        v.addLayout(self.body, 1)
        t = QLabel(title); t.setObjectName("rpanelTitle"); t.setAlignment(Qt.AlignCenter); v.addWidget(t)
        self._col = None; self._col_n = 0

    def _btn(self, cmd, text, ic, tip, big):
        b = QToolButton(); b.setObjectName("rbig" if big else "rsmall")
        b.setIcon(icon(ic or cmd.lower())); b.setAutoRaise(True)
        if big:
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon); b.setIconSize(QSize(30, 30)); b.setText(_wrap(text))
            fm = b.fontMetrics(); tw = max(fm.horizontalAdvance(x) for x in _wrap(text).split("\n"))
            b.setMinimumWidth(max(56, int(tw * 1.25) + 18)); b.setFixedHeight(72); b.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        else:
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon); b.setIconSize(QSize(16, 16)); b.setText(text); b.setFixedHeight(23)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        cmdname = cmd.split()[0] if cmd else ""
        b.setToolTip(f"<b>{text.replace(chr(10), ' ')}</b><br>{tip or ''}<br><span style='color:#7FB8D8'>Command: {cmdname.upper()}</span>")
        if cmd:
            b.clicked.connect(lambda _=False, c=cmd: self.ribbon.command.emit(c))
        self.ribbon.buttons[cmdname.upper()] = b
        return b

    def big(self, cmd, text, ic=None, tip=""):
        self._col = None
        b = self._btn(cmd, text, ic, tip, True); self.body.addWidget(b)
        return b

    def small(self, cmd, text, ic=None, tip=""):
        if self._col is None or self._col_n >= 3:
            w = QWidget(); lay = QVBoxLayout(w); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(1)
            self.body.addWidget(w); self._col = lay; self._col_n = 0
        b = self._btn(cmd, text, ic, tip, False); self._col.addWidget(b); self._col_n += 1
        if self._col_n == 3:
            pass
        return b

    def end_column(self):
        if self._col is not None:
            self._col.addStretch(1)
        self._col = None

    def split(self, text, ic, items, tip="", big=True):
        """Split button: first item is the default action, arrow shows all."""
        self._col = None if big else self._col
        b = self._btn(items[0][2], text, ic, tip, big)
        m = QMenu(b)
        for it in items:
            t, i2, c = it[:3]
            a = m.addAction(icon(i2), t); a.triggered.connect(lambda _=False, c=c: self.ribbon.command.emit(c))
            if len(it) > 3:
                a.setToolTip(it[3])
        b.setMenu(m); b.setPopupMode(QToolButton.MenuButtonPopup)
        if big:
            self.body.addWidget(b)
        else:
            if self._col is None or self._col_n >= 3:
                w = QWidget(); lay = QVBoxLayout(w); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(1)
                self.body.addWidget(w); self._col = lay; self._col_n = 0
            self._col.addWidget(b); self._col_n += 1
        return b

    def widget(self, w):
        self._col = None; self.body.addWidget(w)


class RibbonTab(QWidget):
    def __init__(self, ribbon):
        super().__init__(); self.ribbon = ribbon
        self.h = QHBoxLayout(self); self.h.setContentsMargins(4, 2, 4, 2); self.h.setSpacing(2)
        self.h.addStretch(1)

    def add_panel(self, title):
        p = RibbonPanel(title, self.ribbon)
        self.h.insertWidget(self.h.count() - 1, p)
        return p


class Ribbon(QWidget):
    command = Signal(str)

    def __init__(self, app_icon, commands_for_search=()):
        super().__init__(); self.setObjectName("ribbon")
        self.buttons = {}
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        top = QWidget(); top.setObjectName("ribbonTop"); th = QHBoxLayout(top); th.setContentsMargins(6, 3, 6, 0); th.setSpacing(2)
        self.app_btn = QToolButton(); self.app_btn.setObjectName("appbtn"); self.app_btn.setIcon(app_icon)
        self.app_btn.setIconSize(QSize(34, 34)); self.app_btn.setPopupMode(QToolButton.InstantPopup); self.app_btn.setToolTip("Application menu")
        self.app_menu = QMenu(self.app_btn); self.app_btn.setMenu(self.app_menu)
        th.addWidget(self.app_btn)
        self.qat = QHBoxLayout(); self.qat.setSpacing(0); th.addLayout(self.qat)
        th.addSpacing(10)
        self.tabbar = QHBoxLayout(); self.tabbar.setSpacing(0); th.addLayout(self.tabbar)
        th.addStretch(1)
        self.search = QLineEdit(); self.search.setPlaceholderText("\U0001F50D  Search command ..."); self.search.setFixedWidth(200)
        self.search.setClearButtonEnabled(True)
        if commands_for_search:
            comp = QCompleter(sorted(commands_for_search)); comp.setCaseSensitivity(Qt.CaseInsensitive); comp.setFilterMode(Qt.MatchContains)
            self.search.setCompleter(comp)
        self.search.returnPressed.connect(self._search)
        th.addWidget(self.search)
        v.addWidget(top)
        self.stack = QStackedWidget(); self.stack.setObjectName("ribbonBody"); self.stack.setFixedHeight(100)
        v.addWidget(self.stack)
        self.group = QButtonGroup(self); self.group.setExclusive(True)
        self.tabs = []

    def _search(self):
        t = self.search.text().strip()
        if t:
            self.command.emit(t.split()[0] if " " not in t or t.upper().split()[0] in self.buttons else t)
            self.search.clear()

    def add_qat(self, cmd, ic, tip):
        b = QToolButton(); b.setObjectName("qat"); b.setIcon(icon(ic)); b.setIconSize(QSize(18, 18)); b.setToolTip(tip); b.setAutoRaise(True)
        b.clicked.connect(lambda _=False, c=cmd: self.command.emit(c)); self.qat.addWidget(b)
        return b

    def add_tab(self, title):
        page = RibbonTab(self)
        idx = self.stack.addWidget(page)
        b = QToolButton(); b.setObjectName("rtab"); b.setText(title.replace("&", "&&")); b.setCheckable(True)
        b.clicked.connect(lambda _=False, i=idx: self._select(i))
        b.mouseDoubleClickEvent = lambda e: self.toggle_collapse()
        self.group.addButton(b); self.tabbar.addWidget(b); self.tabs.append(b)
        if idx == 0:
            b.setChecked(True)
        return page

    def _select(self, i):
        self.stack.setCurrentIndex(i)
        if not self.stack.isVisible():
            self.stack.setVisible(True)

    def select_tab(self, title):
        for i, b in enumerate(self.tabs):
            if b.text().replace("&&", "&") == title:
                b.setChecked(True); self._select(i)

    def toggle_collapse(self):
        self.stack.setVisible(not self.stack.isVisible())
