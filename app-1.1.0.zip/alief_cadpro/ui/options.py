"""User options: defaults, storage (QSettings, named profiles) and the AutoCAD-style OPTIONS dialog with the tabs
Files, Display, Open and Save, Plot and Publish, System, User Preferences, Drafting, 3D Modeling, Selection, Profiles."""
import json
import os
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QTabWidget, QWidget, QGroupBox, QLabel,
                               QLineEdit, QPushButton, QCheckBox, QComboBox, QSpinBox, QDoubleSpinBox, QSlider, QColorDialog,
                               QFileDialog, QListWidget, QInputDialog, QMessageBox, QDialogButtonBox)

DEFAULTS = {
    # Files
    "template": "", "draw_dir": "", "autosave_dir": "", "oda_path": "",
    # Display
    "theme": "Dark", "bg_top": "", "bg_bot": "", "crosshair_color": "", "crosshair_size": 100, "cmd_font": 10, "cmd_lines": 3,
    "viewcube": True, "ucsicon": True, "grid": True, "lwt": False,
    # Open and Save
    "save_format": "ALIEF CAD PRO (*.acp)", "dxf_version": "R2018", "autosave_on": True, "autosave_min": 10, "backup": True, "recent_n": 10,
    # Plot and Publish
    "plot_paper": "A3", "plot_orient": "Landscape", "plot_scale": "Fit to paper", "plot_mono": True, "plot_lw": True, "plot_title": True,
    "plot_company": "PT. ALIEF ENERGY UTAMA", "plot_dno": "AEU-DWG-001",
    # System
    "auto_update": True, "anim": True, "anim_ms": 280, "msaa": 4,
    # User Preferences
    "rclick_idle": "Shortcut menu", "rclick_cmd": "Enter", "dblclick_edit": True, "space_enter": True, "wheel_reverse": False, "zoom_factor": 60,
    # Drafting
    "snap_marker": True, "snap_tooltip": True, "marker_size": 6, "marker_color": "#FFC400", "aperture": 12,
    "snap_modes": ["end", "mid", "cen", "quad", "int", "perp", "node", "ins", "img"], "osnap": True, "ortho": False, "dyn": True, "snap_step": 10.0,
    # 3D Modeling
    "vstyle": "shadededges", "perspective": False, "delobj": True, "orbit_sel": True,
    # Selection
    "pickbox": 5, "grips": True, "grip_size": 4, "grip_color": "#2F80ED", "grip_hot": "#FF4D4F", "hover": True, "noun_verb": True,
}
DOC_KEYS = ("units", "text_paper", "sym_scale", "paper")          # stored in the drawing (plus the "dim" block)


# ------------------------------------------------------------------------------------------------- storage
def load(settings):
    """-> (options dict, current profile name). Unknown keys are dropped, missing keys take their default."""
    name = settings.value("opt/current", "Default") or "Default"
    o = dict(DEFAULTS)
    try:
        allp = json.loads(settings.value("opt/profiles", "{}") or "{}")
        o.update({k: v for k, v in (allp.get(name) or {}).items() if k in DEFAULTS})
    except Exception:
        pass
    return o, name


def profiles(settings):
    try:
        p = json.loads(settings.value("opt/profiles", "{}") or "{}")
    except Exception:
        p = {}
    if not p:
        p = {"Default": {}}
    return p


def save(settings, opt, name=None):
    name = name or settings.value("opt/current", "Default") or "Default"
    p = profiles(settings); p[name] = {k: opt[k] for k in DEFAULTS if k in opt}
    settings.setValue("opt/profiles", json.dumps(p)); settings.setValue("opt/current", name)


# ------------------------------------------------------------------------------------------------- widgets
class ColorButton(QPushButton):
    """Colour swatch; an empty value means 'automatic / follow the theme'."""
    def __init__(self, value="", auto_text="Automatic (theme)"):
        super().__init__(); self.auto_text = auto_text; self.value = value or ""; self.clicked.connect(self._pick); self._show()
        self.setMinimumWidth(150)

    def _show(self):
        if self.value:
            c = QColor(self.value); fg = "#000" if c.lightness() > 140 else "#fff"
            self.setText(self.value.upper()); self.setStyleSheet(f"background:{self.value}; color:{fg};")
        else:
            self.setText(self.auto_text); self.setStyleSheet("")

    def _pick(self):
        c = QColorDialog.getColor(QColor(self.value or "#202833"), self, "Select colour")
        if c.isValid():
            self.value = c.name(); self._show()

    def reset(self):
        self.value = ""; self._show()


class PathEdit(QWidget):
    def __init__(self, value="", folder=False, filt="All files (*.*)", placeholder=""):
        super().__init__(); self.folder = folder; self.filt = filt
        h = QHBoxLayout(self); h.setContentsMargins(0, 0, 0, 0)
        self.edit = QLineEdit(value or ""); self.edit.setPlaceholderText(placeholder); h.addWidget(self.edit, 1)
        b = QPushButton("Browse ..."); b.clicked.connect(self._browse); h.addWidget(b)

    def _browse(self):
        if self.folder:
            fn = QFileDialog.getExistingDirectory(self, "Select folder", self.edit.text())
        else:
            fn, _ = QFileDialog.getOpenFileName(self, "Select file", self.edit.text(), self.filt)
        if fn:
            self.edit.setText(os.path.normpath(fn))

    def text(self):
        return self.edit.text().strip()


def _ispin(v, lo, hi, suffix=""):
    s = QSpinBox(); s.setRange(lo, hi); s.setValue(int(v)); s.setMinimumWidth(96)
    if suffix:
        s.setSuffix(" " + suffix)
    return s


def _dspin(v, lo, hi, dec=2, step=0.5, suffix=""):
    s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec); s.setSingleStep(step); s.setValue(float(v)); s.setMinimumWidth(96)
    if suffix:
        s.setSuffix(" " + suffix)
    return s


def _combo(items, cur):
    c = QComboBox(); c.addItems(items)
    if cur in items:
        c.setCurrentText(cur)
    return c


def _check(text, v):
    c = QCheckBox(text); c.setChecked(bool(v)); return c


def _slider(v, lo, hi):
    w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
    s = QSlider(Qt.Horizontal); s.setRange(lo, hi); s.setValue(int(v)); lab = QLabel(str(int(v))); lab.setMinimumWidth(30)
    s.valueChanged.connect(lambda x: lab.setText(str(x))); h.addWidget(s, 1); h.addWidget(lab)
    w.value = s.value; w.setValue = s.setValue
    return w


def _group(title, layout_cls=QFormLayout):
    g = QGroupBox(title); lay = layout_cls(g)
    return g, lay


class OptionsDialog(QDialog):
    TABS = ["Files", "Display", "Open and Save", "Plot and Publish", "System", "User Preferences", "Drafting", "3D Modeling", "Selection", "Profiles"]

    def __init__(self, app, tab=None):
        super().__init__(app); self.app = app
        self.setWindowTitle("Options"); self.resize(980, 640)
        self.o, self.profile = load(app.settings)
        self.o.update({k: app.view.opt.get(k, v) for k, v in self.o.items()})
        self.w = {}                                   # option key -> (getter, setter)
        v = QVBoxLayout(self)
        top = QHBoxLayout(); v.addLayout(top)
        self.lbl_prof = QLabel(); top.addWidget(self.lbl_prof); top.addStretch(1)
        self.lbl_dwg = QLabel(); top.addWidget(self.lbl_dwg)
        self.tabs = QTabWidget(); v.addWidget(self.tabs, 1)
        for name, fn in zip(self.TABS, (self._files, self._display, self._opensave, self._plot, self._system, self._user, self._drafting,
                                        self._model3d, self._selection, self._profiles)):
            page = QWidget(); fn(page); self.tabs.addTab(page, name)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel | QDialogButtonBox.Apply | QDialogButtonBox.RestoreDefaults)
        bb.accepted.connect(self._ok); bb.rejected.connect(self.reject)
        bb.button(QDialogButtonBox.Apply).clicked.connect(self.apply)
        bb.button(QDialogButtonBox.RestoreDefaults).clicked.connect(self._defaults)
        v.addWidget(bb)
        self._head()
        if tab in self.TABS:
            self.tabs.setCurrentIndex(self.TABS.index(tab))

    def _head(self):
        self.lbl_prof.setText(f"Current profile:  <b>{self.profile}</b>")
        self.lbl_dwg.setText("Current drawing:  <b>" + (os.path.basename(self.app.doc.path) if self.app.doc.path else "Drawing1.acp") + "</b>")

    # ------------------------------------------------------------------ binding helpers
    def bind(self, key, widget):
        if isinstance(widget, QCheckBox):
            self.w[key] = (widget.isChecked, widget.setChecked)
        elif isinstance(widget, QComboBox):
            self.w[key] = (widget.currentText, widget.setCurrentText)
        elif isinstance(widget, (QSpinBox, QDoubleSpinBox)):
            self.w[key] = (widget.value, widget.setValue)
        elif isinstance(widget, QLineEdit):
            self.w[key] = (widget.text, widget.setText)
        elif isinstance(widget, PathEdit):
            self.w[key] = (widget.text, widget.edit.setText)
        elif isinstance(widget, ColorButton):
            self.w[key] = (lambda w=widget: w.value, lambda val, w=widget: (setattr(w, "value", val or ""), w._show()))
        else:
            self.w[key] = (widget.value, widget.setValue)
        return widget

    # ------------------------------------------------------------------ tabs
    def _files(self, page):
        v = QVBoxLayout(page)
        g, f = _group("Search paths, file names and file locations"); v.addWidget(g)
        f.addRow("Drawing template (.acp) for NEW", self.bind("template", PathEdit(self.o["template"], False, "ALIEF CAD PRO (*.acp)", "empty = blank drawing")))
        f.addRow("Default drawing folder", self.bind("draw_dir", PathEdit(self.o["draw_dir"], True, placeholder="empty = last used folder")))
        f.addRow("Automatic save file location", self.bind("autosave_dir", PathEdit(self.o["autosave_dir"], True, placeholder="empty = user data folder")))
        f.addRow("ODA File Converter (for DWG)", self.bind("oda_path", PathEdit(self.o["oda_path"], False, "ODAFileConverter (*.exe);;All files (*.*)", "empty = find automatically")))
        from ..core.update import local_root
        g, f = _group("Program locations (information)"); v.addWidget(g)
        for t, pth in (("User data, autosave, updates", local_root()), ("Log file", os.path.join(local_root(), "log.txt")),
                       ("Program folder", self.app.boot.get("install_dir", "") or os.path.dirname(os.path.dirname(os.path.dirname(__file__))))):
            e = QLineEdit(pth); e.setReadOnly(True); f.addRow(t, e)
        v.addStretch(1)

    def _display(self, page):
        grid = QGridLayout(page)
        g, f = _group("Window elements"); grid.addWidget(g, 0, 0)
        f.addRow("Color theme", self.bind("theme", _combo(["Dark", "Light"], self.o["theme"])))
        f.addRow(self.bind("viewcube", _check("Display the ViewCube", self.o["viewcube"])))
        f.addRow(self.bind("ucsicon", _check("Display the UCS icon", self.o["ucsicon"])))
        f.addRow(self.bind("grid", _check("Display the grid (F7)", self.o["grid"])))
        f.addRow(self.bind("lwt", _check("Display lineweights (LWT)", self.o["lwt"])))
        g, f = _group("Colors"); grid.addWidget(g, 0, 1)
        self.c_top = self.bind("bg_top", ColorButton(self.o["bg_top"])); self.c_bot = self.bind("bg_bot", ColorButton(self.o["bg_bot"]))
        self.c_cross = self.bind("crosshair_color", ColorButton(self.o["crosshair_color"]))
        f.addRow("Model background - top", self.c_top); f.addRow("Model background - bottom", self.c_bot); f.addRow("Crosshair", self.c_cross)
        h = QHBoxLayout()
        b = QPushButton("Black background"); b.clicked.connect(lambda: [self.w[k][1]("#000000") for k in ("bg_top", "bg_bot")]); h.addWidget(b)
        b = QPushButton("Restore theme colors"); b.clicked.connect(lambda: [self.w[k][1]("") for k in ("bg_top", "bg_bot", "crosshair_color")]); h.addWidget(b)
        f.addRow(h)
        g, f = _group("Crosshair size (percent of screen, 100 = full screen)"); grid.addWidget(g, 1, 0)
        f.addRow(self.bind("crosshair_size", _slider(self.o["crosshair_size"], 1, 100)))
        g, f = _group("Command window"); grid.addWidget(g, 1, 1)
        f.addRow("Font size", self.bind("cmd_font", _ispin(self.o["cmd_font"], 8, 20, "pt")))
        f.addRow("History lines shown when docked", self.bind("cmd_lines", _ispin(self.o["cmd_lines"], 1, 20)))
        grid.setRowStretch(2, 1)

    def _opensave(self, page):
        grid = QGridLayout(page)
        g, f = _group("File Save"); grid.addWidget(g, 0, 0)
        f.addRow("Save as", self.bind("save_format", _combo(["ALIEF CAD PRO (*.acp)", "DXF (*.dxf)"], self.o["save_format"])))
        f.addRow("DXF version for Save / Export", self.bind("dxf_version", _combo(["R12", "R2000", "R2004", "R2007", "R2010", "R2013", "R2018"], self.o["dxf_version"])))
        g, f = _group("File Safety Precautions"); grid.addWidget(g, 0, 1)
        f.addRow(self.bind("autosave_on", _check("Automatic save", self.o["autosave_on"])))
        f.addRow("Minutes between saves", self.bind("autosave_min", _ispin(self.o["autosave_min"], 1, 120)))
        f.addRow(self.bind("backup", _check("Create backup copy with each save (.bak)", self.o["backup"])))
        g, f = _group("File Open"); grid.addWidget(g, 1, 0)
        f.addRow("Number of recently-used files", self.bind("recent_n", _ispin(self.o["recent_n"], 0, 30)))
        grid.setRowStretch(2, 1)

    def _plot(self, page):
        from ..cmd.misc import PAPERS
        grid = QGridLayout(page)
        g, f = _group("Default plot settings for new plots"); grid.addWidget(g, 0, 0)
        f.addRow("Paper size", self.bind("plot_paper", _combo(list(PAPERS), self.o["plot_paper"])))
        f.addRow("Drawing orientation", self.bind("plot_orient", _combo(["Landscape", "Portrait"], self.o["plot_orient"])))
        f.addRow("Plot scale", self.bind("plot_scale", _combo(["Fit to paper", "Drawing scale 1:N"], self.o["plot_scale"])))
        g, f = _group("Plot style"); grid.addWidget(g, 0, 1)
        f.addRow(self.bind("plot_mono", _check("Monochrome (all colors plot black)", self.o["plot_mono"])))
        f.addRow(self.bind("plot_lw", _check("Plot object lineweights", self.o["plot_lw"])))
        g, f = _group("Border and title block"); grid.addWidget(g, 1, 0, 1, 2)
        f.addRow(self.bind("plot_title", _check("Plot border + title block", self.o["plot_title"])))
        f.addRow("Company name in the title block", self.bind("plot_company", QLineEdit(self.o["plot_company"])))
        f.addRow("Default drawing number", self.bind("plot_dno", QLineEdit(self.o["plot_dno"])))
        grid.setRowStretch(2, 1)

    def _system(self, page):
        grid = QGridLayout(page)
        g, f = _group("Graphics performance"); grid.addWidget(g, 0, 0)
        f.addRow("Anti-aliasing (MSAA samples, after restart)", self.bind("msaa", _combo(["0", "2", "4", "8"], str(self.o["msaa"]))))
        f.addRow(self.bind("anim", _check("Smooth view transitions", self.o["anim"])))
        f.addRow("Transition speed", self.bind("anim_ms", _ispin(self.o["anim_ms"], 0, 2000, "ms")))
        g, f = _group("General options"); grid.addWidget(g, 0, 1)
        f.addRow(self.bind("auto_update", _check("Check for and install updates automatically at start-up", self.o["auto_update"])))
        b = QPushButton("Reset palettes and window layout"); b.clicked.connect(self.app.reset_layout); f.addRow(b)
        grid.setRowStretch(1, 1)

    def _user(self, page):
        s = self.app.doc.settings; dim = s.get("dim", {})
        grid = QGridLayout(page)
        g, f = _group("Windows Standard Behavior"); grid.addWidget(g, 0, 0)
        f.addRow(self.bind("dblclick_edit", _check("Double click editing", self.o["dblclick_edit"])))
        f.addRow(self.bind("space_enter", _check("Space bar works as Enter", self.o["space_enter"])))
        g, f = _group("Right-Click Customization"); grid.addWidget(g, 1, 0)
        f.addRow("Default mode (no command active)", self.bind("rclick_idle", _combo(["Shortcut menu", "Repeat last command"], self.o["rclick_idle"])))
        f.addRow("Command mode (command in progress)", self.bind("rclick_cmd", _combo(["Enter", "Shortcut menu"], self.o["rclick_cmd"])))
        g, f = _group("Mouse wheel zoom"); grid.addWidget(g, 2, 0)
        f.addRow("Zoom factor (3 - 100)", self.bind("zoom_factor", _ispin(self.o["zoom_factor"], 3, 100)))
        f.addRow(self.bind("wheel_reverse", _check("Reverse mouse wheel zoom", self.o["wheel_reverse"])))
        g, f = _group("Insertion scale and annotation (saved in the drawing)"); grid.addWidget(g, 0, 1, 3, 1)
        self.d_units = _combo(["mm", "cm", "m", "in", "ft"], s.get("units", "mm")); f.addRow("Drawing units", self.d_units)
        self.d_txt = _dspin(s.get("text_paper", 2.5), 0.5, 50, 1, 0.5, "mm"); f.addRow("Text height on paper", self.d_txt)
        self.d_dth = _dspin(dim.get("th", 2.5), 0.5, 50, 1, 0.5, "mm"); f.addRow("Dimension text on paper", self.d_dth)
        self.d_asz = _dspin(dim.get("asz", 2.5), 0.5, 50, 1, 0.5, "mm"); f.addRow("Dimension arrow size on paper", self.d_asz)
        self.d_dec = _ispin(dim.get("dec", 0), 0, 6); f.addRow("Dimension decimals", self.d_dec)
        self.d_sym = _dspin(s.get("sym_scale", 1.0), 0.01, 100, 2, 0.25); f.addRow("Symbol size factor", self.d_sym)
        self.d_paper = _combo(["A4", "A3", "A2", "A1", "A0"], s.get("paper", "A3")); f.addRow("Paper for AUTO annotation scale", self.d_paper)
        self.d_auto = _check("Pick the annotation scale automatically (AUTO)", s.get("auto_anno", True)); f.addRow(self.d_auto)
        grid.setRowStretch(3, 1)

    def _drafting(self, page):
        from .viewport import SNAP_KINDS, SNAP_LABEL
        grid = QGridLayout(page)
        g, f = _group("AutoSnap Settings"); grid.addWidget(g, 0, 0)
        f.addRow(self.bind("snap_marker", _check("Marker", self.o["snap_marker"])))
        f.addRow(self.bind("snap_tooltip", _check("Display AutoSnap tooltip", self.o["snap_tooltip"])))
        f.addRow("Marker color", self.bind("marker_color", ColorButton(self.o["marker_color"], "Default")))
        g, f = _group("AutoSnap Marker Size"); grid.addWidget(g, 1, 0)
        f.addRow(self.bind("marker_size", _slider(self.o["marker_size"], 3, 16)))
        g, f = _group("Aperture Size"); grid.addWidget(g, 2, 0)
        f.addRow(self.bind("aperture", _slider(self.o["aperture"], 4, 40)))
        g = QGroupBox("Object Snap modes"); gl = QGridLayout(g); grid.addWidget(g, 0, 1, 2, 1)
        self.snaps = {}
        for i, k in enumerate(SNAP_KINDS):
            cb = _check(SNAP_LABEL[k], k in self.o["snap_modes"]); gl.addWidget(cb, i // 2, i % 2); self.snaps[k] = cb
        h = QHBoxLayout(); gl.addLayout(h, len(SNAP_KINDS) // 2 + 1, 0, 1, 2)
        b = QPushButton("Select All"); b.clicked.connect(lambda: [c.setChecked(True) for c in self.snaps.values()]); h.addWidget(b)
        b = QPushButton("Clear All"); b.clicked.connect(lambda: [c.setChecked(False) for c in self.snaps.values()]); h.addWidget(b)
        g, f = _group("Drafting aids"); grid.addWidget(g, 2, 1)
        f.addRow(self.bind("osnap", _check("Object Snap On (F3)", self.o["osnap"])))
        f.addRow(self.bind("ortho", _check("Ortho mode (F8)", self.o["ortho"])))
        f.addRow(self.bind("dyn", _check("Dynamic Input (F12)", self.o["dyn"])))
        f.addRow("Snap spacing (F9)", self.bind("snap_step", _dspin(self.o["snap_step"], 0.001, 100000, 3, 1.0)))
        grid.setRowStretch(3, 1)

    def _model3d(self, page):
        grid = QGridLayout(page)
        g, f = _group("3D display"); grid.addWidget(g, 0, 0)
        self.vs_names = {"2D Wireframe": "wire", "Hidden": "hidden", "Shaded": "shaded", "Shaded with edges": "shadededges", "X-Ray": "xray"}
        inv = {v: k for k, v in self.vs_names.items()}
        self.vs = _combo(list(self.vs_names), inv.get(self.o["vstyle"], "Shaded with edges")); f.addRow("Visual style", self.vs)
        f.addRow(self.bind("perspective", _check("Perspective projection", self.o["perspective"])))
        g, f = _group("3D Navigation"); grid.addWidget(g, 0, 1)
        f.addRow(self.bind("orbit_sel", _check("Orbit about the selected objects", self.o["orbit_sel"])))
        g, f = _group("3D Objects"); grid.addWidget(g, 1, 0)
        f.addRow(self.bind("delobj", _check("Delete the defining curves after EXTRUDE (DELOBJ)", self.o["delobj"])))
        grid.setRowStretch(2, 1)

    def _selection(self, page):
        grid = QGridLayout(page)
        g, f = _group("Pickbox size"); grid.addWidget(g, 0, 0)
        f.addRow(self.bind("pickbox", _slider(self.o["pickbox"], 2, 20)))
        g, f = _group("Selection modes"); grid.addWidget(g, 1, 0)
        f.addRow(self.bind("noun_verb", _check("Noun/verb selection (select first, then start the command)", self.o["noun_verb"])))
        f.addRow(self.bind("hover", _check("Selection preview when the cursor rolls over objects", self.o["hover"])))
        g, f = _group("Grip size"); grid.addWidget(g, 0, 1)
        f.addRow(self.bind("grip_size", _slider(self.o["grip_size"], 2, 12)))
        g, f = _group("Grips"); grid.addWidget(g, 1, 1)
        f.addRow(self.bind("grips", _check("Show grips", self.o["grips"])))
        f.addRow("Unselected grip color", self.bind("grip_color", ColorButton(self.o["grip_color"], "Default")))
        f.addRow("Hover / selected grip color", self.bind("grip_hot", ColorButton(self.o["grip_hot"], "Default")))
        grid.setRowStretch(2, 1)

    def _profiles(self, page):
        h = QHBoxLayout(page)
        left = QVBoxLayout(); h.addLayout(left, 1)
        left.addWidget(QLabel("Available profiles:"))
        self.plist = QListWidget(); left.addWidget(self.plist, 1)
        right = QVBoxLayout(); h.addLayout(right)
        for text, fn in (("Set Current", self._p_set), ("Add to List ...", self._p_add), ("Rename ...", self._p_rename), ("Delete", self._p_delete),
                         ("Export ...", self._p_export), ("Import ...", self._p_import), ("Reset", self._p_reset)):
            b = QPushButton(text); b.clicked.connect(fn); right.addWidget(b)
        right.addStretch(1)
        self._p_refresh()

    # ------------------------------------------------------------------ values
    def collect(self):
        o = dict(self.o)
        for k, (get, _set) in self.w.items():
            o[k] = get()
        o["msaa"] = int(o["msaa"]); o["vstyle"] = self.vs_names[self.vs.currentText()]
        o["snap_modes"] = [k for k, cb in self.snaps.items() if cb.isChecked()]
        return o

    def show_values(self, o):
        for k, (_get, setv) in self.w.items():
            v = o.get(k, DEFAULTS.get(k))
            setv(str(v) if k == "msaa" else v)
        inv = {v: k for k, v in self.vs_names.items()}; self.vs.setCurrentText(inv.get(o.get("vstyle"), "Shaded with edges"))
        for k, cb in self.snaps.items():
            cb.setChecked(k in o.get("snap_modes", []))

    def apply(self):
        self.o = self.collect()
        save(self.app.settings, self.o, self.profile)
        s = self.app.doc.settings
        s["units"] = self.d_units.currentText(); s["text_paper"] = self.d_txt.value(); s["sym_scale"] = self.d_sym.value()
        s["paper"] = self.d_paper.currentText(); s["auto_anno"] = self.d_auto.isChecked()
        s["dim"] = dict(s.get("dim", {}), th=self.d_dth.value(), asz=self.d_asz.value(), dec=self.d_dec.value())
        self.app.apply_options(self.o)

    def _ok(self):
        self.apply(); self.accept()

    def _defaults(self):
        if QMessageBox.question(self, "Options", "Restore the default values on all tabs?") == QMessageBox.Yes:
            self.show_values(DEFAULTS)

    # ------------------------------------------------------------------ profiles
    def _p_refresh(self):
        self.plist.clear()
        for n in sorted(profiles(self.app.settings)):
            self.plist.addItem(n + ("   (current)" if n == self.profile else ""))

    def _p_sel(self):
        it = self.plist.currentItem()
        return it.text().replace("   (current)", "") if it else None

    def _p_set(self):
        n = self._p_sel()
        if not n:
            return
        self.app.settings.setValue("opt/current", n); self.profile = n
        self.o, _ = load(self.app.settings); self.show_values(self.o); self.app.apply_options(self.o); self._p_refresh(); self._head()

    def _p_add(self):
        n, ok = QInputDialog.getText(self, "Add Profile", "Profile name (the current settings are copied):")
        if ok and n.strip():
            p = profiles(self.app.settings); p[n.strip()] = self.collect()
            self.app.settings.setValue("opt/profiles", json.dumps(p)); self._p_refresh()

    def _p_rename(self):
        old = self._p_sel()
        if not old:
            return
        n, ok = QInputDialog.getText(self, "Rename Profile", "New name:", text=old)
        if ok and n.strip() and n.strip() != old:
            p = profiles(self.app.settings); p[n.strip()] = p.pop(old, {})
            self.app.settings.setValue("opt/profiles", json.dumps(p))
            if self.profile == old:
                self.profile = n.strip(); self.app.settings.setValue("opt/current", self.profile)
            self._p_refresh(); self._head()

    def _p_delete(self):
        n = self._p_sel()
        if not n or n == self.profile:
            QMessageBox.information(self, "Profiles", "The current profile cannot be deleted. Set another profile current first."); return
        p = profiles(self.app.settings); p.pop(n, None); self.app.settings.setValue("opt/profiles", json.dumps(p)); self._p_refresh()

    def _p_export(self):
        n = self._p_sel() or self.profile
        fn, _ = QFileDialog.getSaveFileName(self, "Export Profile", n + ".cadprofile", "ALIEF CAD PRO profile (*.cadprofile)")
        if fn:
            p = profiles(self.app.settings); d = dict(DEFAULTS); d.update(p.get(n) or {})
            if n == self.profile:
                d = self.collect()
            json.dump({"profile": n, "options": d}, open(fn, "w"), indent=1)

    def _p_import(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Import Profile", "", "ALIEF CAD PRO profile (*.cadprofile);;All files (*.*)")
        if not fn:
            return
        try:
            d = json.load(open(fn)); n = str(d.get("profile") or os.path.splitext(os.path.basename(fn))[0])
            p = profiles(self.app.settings); p[n] = {k: v for k, v in d.get("options", {}).items() if k in DEFAULTS}
            self.app.settings.setValue("opt/profiles", json.dumps(p)); self._p_refresh()
        except Exception as ex:
            QMessageBox.warning(self, "Import Profile", f"Not a valid profile file:\n{ex}")

    def _p_reset(self):
        n = self._p_sel()
        if n and QMessageBox.question(self, "Profiles", f'Reset profile "{n}" to the default settings?') == QMessageBox.Yes:
            p = profiles(self.app.settings); p[n] = dict(DEFAULTS); self.app.settings.setValue("opt/profiles", json.dumps(p))
            if n == self.profile:
                self.o = dict(DEFAULTS); self.show_values(self.o); self.app.apply_options(self.o)
