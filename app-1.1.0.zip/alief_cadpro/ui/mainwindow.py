"""Main window / controller."""
import os
import sys
import time
import numpy as np
from PySide6.QtCore import Qt, QTimer, QSettings, Signal, QObject, QSize, QPoint
from PySide6.QtGui import QKeySequence, QShortcut, QAction, QIcon
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QDockWidget, QLabel, QToolButton, QStatusBar,
                               QFileDialog, QMessageBox, QMenu, QComboBox, QInputDialog, QApplication, QTabWidget)
from ..core.document import Document, APP_VERSION
from ..core import entities as E
from ..core.geom import Plane, fmt
from ..cmd.engine import Engine, Req
from ..cmd import draw2d, modify, solid3d, rhinosrf, ship, piping, cam_redraw, misc
from .viewport import Viewport, grip_apply
from .ribbon import Ribbon
from .panels import CommandLine, PropertiesPanel, LayersPanel, SymbolPanel, BrowserPanel
from . import dialogs as DL
from .icons import icon, set_light
from .brand import app_icon
from .theme import DARK, LIGHT, stylesheet
from . import options as OPT
from .docks import PaletteManager


class _Bridge(QObject):
    update_result = Signal(str, object, str)


class MainWindow(QMainWindow):
    def __init__(self, boot=None, files=()):
        super().__init__()
        self.boot = boot or {}
        self.version = APP_VERSION
        self.settings = QSettings("AliefEnergy", "ALIEF_CADPRO")
        self.doc = Document(); self.doc.listeners.append(self._doc_changed)
        E.Entity.anno_scale = self.doc.settings.get("anno_scale", 1.0)
        self.engine = Engine(self)
        for mod in (draw2d, modify, solid3d, rhinosrf, ship, piping, cam_redraw, misc):
            mod.register(self.engine)
        self.ucs_prev = None; self.last_window = None; self.zoom_window_pending = False; self.pending_equipment = None
        self._last = {}
        self.setWindowTitle("ALIEF CAD PRO"); self.setWindowIcon(app_icon())
        self.view = Viewport(self)
        self.view.opt, self.profile = OPT.load(self.settings)
        if self.settings.contains("light") and not self.settings.contains("opt/profiles"):        # setting of version 1.0
            self.view.opt["theme"] = "Light" if self.settings.value("light", False, bool) else "Dark"
        self.view.light = self.view.opt["theme"] == "Light"; set_light(self.view.light)
        self._build_ui()
        self.apply_theme()
        self.apply_options(self.view.opt, startup=True)
        self._restore_layout()
        self.message(f"ALIEF CAD PRO {self.version} ready. Type a command or use the ribbon. HELP lists all commands.")
        self.bridge = _Bridge(); self.bridge.update_result.connect(self._update_result)
        self.update_dialog = None
        self.autosave = QTimer(self); self.autosave.timeout.connect(self._autosave)
        self._autosave_timer()
        for f in files:
            self.open_path(f)
        QTimer.singleShot(1500, self._startup_update)
        QTimer.singleShot(4000, self._boot_ok)

    # =============================================================================== UI construction
    def _build_ui(self):
        central = QWidget(); v = QVBoxLayout(central); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        self.ribbon = Ribbon(app_icon(), list(self.engine.cmds) + list(self.engine.alias))
        self.ribbon.command.connect(self.run_command)
        self.setMenuWidget(self.ribbon)            # full-width ribbon above the palettes
        v.addWidget(self.view, 1)
        self.cmdline = CommandLine(list(self.engine.cmds) + list(self.engine.alias))
        self.cmdline.submitted.connect(self._cmd_text); self.cmdline.escape.connect(self.escape)
        self.setCentralWidget(central)
        self.setDockNestingEnabled(True)
        self.setCorner(Qt.BottomLeftCorner, Qt.LeftDockWidgetArea); self.setCorner(Qt.BottomRightCorner, Qt.RightDockWidgetArea)
        self._build_ribbon()
        self._build_docks()
        self._build_status()
        self._shortcuts()
        self.view.mouse_moved.connect(self._coords)

    def _build_ribbon(self):
        rb = self.ribbon
        for cmd, ic, tip in (("NEW", "new", "New (Ctrl+N)"), ("OPEN", "open", "Open (Ctrl+O)"), ("SAVE", "save", "Save (Ctrl+S)"),
                             ("UNDO", "undo", "Undo (Ctrl+Z)"), ("REDO", "redo", "Redo (Ctrl+Y)"), ("PLOT", "plot", "Plot to PDF (Ctrl+P)")):
            rb.add_qat(cmd, ic, tip)
        m = rb.app_menu
        for t, c, ic in (("New", "NEW", "new"), ("Open ...", "OPEN", "open"), ("Save", "SAVE", "save"), ("Save As ...", "SAVEAS", "saveas"),
                         (None, None, None), ("Import (DXF / DWG / STL / OBJ / PDF / image) ...", "IMPORT", "import"),
                         ("Export (DXF / STL / OBJ) ...", "EXPORT", "export"), ("Plot to PDF ...", "PLOT", "plot"), ("Save image (PNG) ...", "PNGOUT", "png"),
                         (None, None, None), ("Options ...", "OPTIONS", "options"), ("Check for updates ...", "UPDATE", "update"),
                         ("User guide (Panduan)", "GUIDE", "guide"), ("About", "ABOUT", "about"), (None, None, None), ("Exit", "QUIT", "erase")):
            if t is None:
                m.addSeparator(); continue
            a = m.addAction(icon(ic), t); a.triggered.connect(lambda _=False, c=c: self.run_command(c))
        self.recent_menu = m.addMenu(icon("open"), "Recent files"); self._recent_refresh()

        # ---------------------------------------------------------------- Home
        t = rb.add_tab("Home")
        p = t.add_panel("Draw")
        p.big("LINE", "Line", "line", "Straight segments (L)")
        p.big("PLINE", "Polyline", "pline", "Lines and arcs as one object (PL)")
        p.split("Circle", "circle", [("Center, radius", "circle", "CIRCLE"), ("2 points", "circle2p", "CIRCLE"), ("3 points", "circle3p", "CIRCLE")])
        p.split("Arc", "arc", [("3 points", "arc", "ARC"), ("Start, center, end", "arcsce", "ARC")])
        p.small("RECTANG", "Rectangle", "rect"); p.small("POLYGON", "Polygon", "polygon"); p.small("ELLIPSE", "Ellipse", "ellipse")
        p.small("SPLINE", "Spline", "spline"); p.small("HATCH", "Hatch", "hatch"); p.small("POINT", "Point", "point")
        p = t.add_panel("Modify")
        p.small("MOVE", "Move", "move"); p.small("COPY", "Copy", "copy"); p.small("STRETCH", "Stretch", "stretch")
        p.small("ROTATE", "Rotate", "rotate"); p.small("MIRROR", "Mirror", "mirror"); p.small("SCALE", "Scale", "scale")
        p.small("TRIM", "Trim", "trim"); p.small("EXTEND", "Extend", "extend"); p.small("OFFSET", "Offset", "offset")
        p.small("FILLET", "Fillet", "fillet"); p.small("CHAMFER", "Chamfer", "chamfer"); p.small("ARRAY", "Array", "array")
        p.small("ERASE", "Erase", "erase"); p.small("EXPLODE", "Explode", "explode"); p.small("JOIN", "Join", "join")
        p.small("BREAK", "Break", "break"); p.small("ALIGN", "Align", "align"); p.small("MATCHPROP", "Match prop.", "matchprop")
        p = t.add_panel("Annotation")
        p.big("TEXT", "Text", "text"); p.big("MTEXT", "Mtext", "mtext")
        p.split("Dimension", "dimlin", [("Linear", "dimlin", "DIMLINEAR"), ("Aligned", "dimali", "DIMALIGNED"), ("Radius", "dimrad", "DIMRADIUS"),
                                         ("Diameter", "dimdia", "DIMDIAMETER"), ("Angular", "dimang", "DIMANGULAR")])
        p.small("LEADER", "Leader", "leader"); p.small("BOM", "BOM table", "bom"); p.small("ANNOSCALE", "Scale 1:N", "annoscale")
        p = t.add_panel("Layers & Properties")
        p.big("LAYER", "Layers", "layers"); p.big("PROPERTIES", "Properties", "props")
        self.layer_combo = QComboBox(); self.layer_combo.setMinimumWidth(130); self.layer_combo.currentTextChanged.connect(self._set_cur_layer)
        p.widget(self.layer_combo)
        p = t.add_panel("Utilities")
        p.small("DIST", "Distance", "dist"); p.small("AREA", "Area / CG", "area"); p.small("ID", "ID point", "id")
        p.small("LIST", "List", "list"); p.small("MASSPROP", "Mass prop.", "massprop"); p.small("SELECTALL", "Select all", "selectall")
        p = t.add_panel("Block")
        p.big("INSERT", "Insert", "insert"); p.small("BLOCK", "Create", "block"); p.small("SYMLIB", "Symbols", "symlib")

        # ---------------------------------------------------------------- 3D Modeling
        t = rb.add_tab("3D Solid")
        p = t.add_panel("Primitives")
        p.big("BOX", "Box", "box"); p.big("CYLINDER", "Cylinder", "cylinder")
        p.small("CONE", "Cone", "cone"); p.small("SPHERE", "Sphere", "sphere"); p.small("TORUS", "Torus", "torus")
        p.small("WEDGE", "Wedge", "wedge"); p.small("PYRAMID", "Pyramid", "pyramid")
        p = t.add_panel("Solid")
        p.big("EXTRUDE", "Extrude", "extrude"); p.big("REVOLVE", "Revolve", "revolve"); p.big("SWEEP", "Sweep", "sweep"); p.big("LOFT", "Loft", "loft")
        p.small("THICKEN", "Thicken", "thicken"); p.small("SLICE", "Slice", "slice")
        p = t.add_panel("Boolean")
        p.big("UNION", "Union", "union"); p.big("SUBTRACT", "Subtract", "subtract"); p.big("INTERSECT", "Intersect", "intersect")
        p = t.add_panel("3D Modify")
        p.small("ROTATE3D", "3D Rotate", "rotate3d"); p.small("MIRROR3D", "3D Mirror", "mirror3d"); p.small("ALIGN", "Align", "align")
        p = t.add_panel("Coordinates")
        p.big("UCS", "UCS", "ucs"); p.small("UCSWORLD", "World", "ucsworld"); p.small("UCS", "3 Point / Object", "ucs3p"); p.small("UCSVIEW", "View", "ucsview")
        p.small("UCSTOP", "Top plane", "view_top"); p.small("UCSFRONT", "Front plane", "view_front"); p.small("UCSRIGHT", "Side plane", "view_right")

        # ---------------------------------------------------------------- Surface
        t = rb.add_tab("Surface")          # command names, prompts and options follow Rhinoceros 8 (Surface menu)
        p = t.add_panel("Plane & Points")
        p.big("PLANE", "Plane", "planesurf", "Plane: corner to corner, 3Point, Vertical, Center")
        p.big("SRFPT", "SrfPt", "srfpt", "Surface from 3 or 4 corner points")
        p.big("PLANARSRF", "PlanarSrf", "planarsrf", "Surface from planar closed curves")
        p.big("EDGESRF", "EdgeSrf", "edgesurf", "Surface from 2, 3 or 4 edge curves")
        p = t.add_panel("Extrude")
        p.big("EXTRUDECRV", "ExtrudeCrv", "extsurf", "Extrude curves straight [Direction / BothSides / Solid]")
        p.small("EXTRUDECRVALONGCRV", "Along curve", "extalong", "ExtrudeCrvAlongCrv")
        p.small("EXTRUDECRVTOPOINT", "To point", "exttopt", "ExtrudeCrvToPoint")
        p = t.add_panel("Loft & Sweep")
        p.big("LOFT", "Loft", "loftsurf", "Loft through section curves [Style / Closed / Solid]")
        p.big("SWEEP1", "Sweep1", "sweepsurf", "Sweep cross sections along one rail")
        p.big("SWEEP2", "Sweep2", "sweep2", "Sweep cross sections along two rails")
        p.big("NETWORKSRF", "NetworkSrf", "networksrf", "Surface from a network of crossing curves")
        p.big("PATCH", "Patch", "patch", "Fit a surface through boundary curves and points")
        p = t.add_panel("Revolve")
        p.big("REVOLVE", "Revolve", "revsurf", "Revolve curves about an axis"); p.big("RAILREVOLVE", "RailRevolve", "railrev", "Revolve a profile following a rail")
        p = t.add_panel("Surface tools")
        p.big("OFFSETSRF", "OffsetSrf", "offsetsrf", "Offset surface [FlipAll / Solid / BothSides]")
        p.small("FLIP", "Flip", "flip", "Flip surface normals"); p.small("DUPBORDER", "DupBorder", "dupborder", "Border curves of a surface")
        p.small("THICKEN", "Thicken", "thicken")
        p = t.add_panel("Curve from objects")
        p.big("CONTOUR", "Contour", "contour", "Evenly spaced sections: stations, waterlines, buttocks")
        p.big("SECTION", "Section", "section", "Section curve through surfaces / solids")
        p = t.add_panel("Ship")
        p.big("PLATE3D", "Plate from surface", "platesurf")

        # ---------------------------------------------------------------- Ship structure
        t = rb.add_tab("Ship Structure")
        p = t.add_panel("3D Plate")
        p.big("PLATE3D", "3D Plate", "plate3d", "Plate from closed curves (with openings) or surfaces, thickness + IACS grade")
        p.big("PLATEHOLE", "Opening", "platehole", "Cut manholes / lightening holes / cut-outs")
        p = t.add_panel("3D Profile")
        p.big("PROFILE3D", "3D Profile", "profile3d", "FB, L, HP bulb, T, H, C, pipe, round bar, SHS along a path")
        p = t.add_panel("Frame Connections")
        p.big("BRACKET3D", "3D Bracket", "bracket", "3D bracket sized by the rule formula")
        p.split("Standard details", "detail", [(k, "detail" if "racket" in k else ("slot" if "lot" in k or "collar" in k else ("scallop" if "callop" in k else "snipe")), "DETAIL")
                                               for k in __import__("alief_cadpro.core.details", fromlist=["DETAIL_TYPES"]).DETAIL_TYPES])
        p = t.add_panel("Output")
        p.big("MATLIST", "Material list", "matlist"); p.big("BOM", "BOM table", "bom")
        p.small("COLORTHK", "Colour by thickness", "colorthk"); p.small("FLATTEN", "Flatten plates", "flatten"); p.small("MASSPROP", "Weight / CG", "massprop")

        # ---------------------------------------------------------------- Piping & Electrical
        t = rb.add_tab("Piping & Electrical")
        p = t.add_panel("Symbols 2D")
        p.big("SYMLIB", "Symbol library", "symlib"); p.big("SYMBOL", "Electrical", "sym_elec"); p.big("SYMBOL", "Piping", "sym_pipe")
        p = t.add_panel("Piping 3D")
        p.big("PIPE3D", "Pipe route", "pipe3d", "Pipe along points with automatic bends"); p.big("FITTING", "Fitting / valve", "fitting")
        p.small("FITTING", "Flange", "flange"); p.small("TEXTFIT", "Auto text", "textfit")
        p = t.add_panel("Electrical 3D")
        p.big("CABLETRAY", "Cable tray", "tray"); p.big("CONDUIT", "Conduit", "conduit"); p.big("EQUIPMENT", "Equipment", "equip")
        p = t.add_panel("Lists")
        p.big("BOM", "BOM table", "bom"); p.big("MATLIST", "Material list", "matlist")

        # ---------------------------------------------------------------- Redraw
        t = rb.add_tab("Redraw")
        p = t.add_panel("Import")
        p.big("PDFIMPORT", "PDF import", "pdfimport", "PDF vectors, text and images to CAD objects")
        p.big("IMAGEATTACH", "Attach image", "image", "JPG / PNG / BMP / TIF underlay")
        p.big("CSVIMPORT", "Points Excel / CSV", "csvimport")
        p = t.add_panel("Image")
        p.big("CALIBRATE", "Calibrate scale", "calibrate"); p.big("DESKEW", "Deskew", "deskew")
        p.small("IMAGEFADE", "Fade", "imagefade"); p.small("IMGSNAP", "Snap to image lines", "imgsnap"); p.small("ALIGN", "Align", "align")
        p = t.add_panel("Vectorize")
        p.big("AUTOTRACE", "Auto trace", "autotrace", "Raster to vector, centre-line, no double lines")
        p.big("PLINE", "Manual trace", "pline")

        # ---------------------------------------------------------------- CAM
        t = rb.add_tab("CAM")
        p = t.add_panel("CNC cutting")
        p.big("CAMCUT", "G-code", "camcut", "Plasma / oxy-fuel / laser toolpath with kerf, lead-in, holes first")
        p.big("NEST", "Nesting", "nest"); p.big("FLATTEN", "Flatten plates", "flatten")

        # ---------------------------------------------------------------- Annotate
        t = rb.add_tab("Annotate")
        p = t.add_panel("Text")
        p.big("TEXT", "Text", "text"); p.big("MTEXT", "Mtext", "mtext"); p.big("TEXTFIT", "Auto text height", "textfit")
        p = t.add_panel("Dimensions")
        p.big("DIMLINEAR", "Linear", "dimlin"); p.small("DIMALIGNED", "Aligned", "dimali"); p.small("DIMRADIUS", "Radius", "dimrad"); p.small("DIMDIAMETER", "Diameter", "dimdia")
        p.small("DIMANGULAR", "Angular", "dimang"); p.small("LEADER", "Leader", "leader")
        p = t.add_panel("Tables")
        p.big("BOM", "BOM", "bom")
        p = t.add_panel("Annotation scale")
        p.big("ANNOSCALE", "Drawing scale", "annoscale")

        # ---------------------------------------------------------------- View
        t = rb.add_tab("View")
        p = t.add_panel("Views")
        p.big("TOP", "Top", "view_top"); p.big("FRONT", "Front", "view_front"); p.big("RIGHT", "Right", "view_right")
        p.split("Isometric", "view_iso", [("SW Isometric", "view_iso", "SWISO"), ("SE Isometric", "view_iso", "SEISO"), ("NE Isometric", "view_iso", "NEISO"),
                                           ("NW Isometric", "view_iso", "NWISO"), ("Bottom", "view_bottom", "BOTTOM"), ("Back", "view_back", "BACK"), ("Left", "view_left", "LEFT")])
        p.small("PLAN", "Plan (UCS)", "plan")
        p = t.add_panel("Navigate")
        p.big("ZOOMEXT", "Zoom extents", "zoomext"); p.small("ZOOMWIN", "Zoom window", "zoomwin"); p.small("ZOOM", "Zoom ...", "zoomwin")
        p.small("REGEN", "Regen", "regen")
        p = t.add_panel("Visual styles")
        p.small("WIRE", "Wireframe", "wire"); p.small("HIDDEN", "Hidden", "wire"); p.small("SHADED", "Shaded", "shaded")
        p.small("SHADEDEDGES", "Shaded + edges", "shadededges"); p.small("XRAY", "X-ray", "xray"); p.small("PERSPECTIVE", "Perspective", "persp")
        p = t.add_panel("Palettes")
        p.small("PROPERTIES", "Properties", "props"); p.small("LAYER", "Layers", "layers"); p.small("SYMLIB", "Symbols", "symlib")
        p.small("BROWSER", "Model browser", "list"); p.small("THEME", "Dark / light", "options")

        # ---------------------------------------------------------------- Output / Manage
        t = rb.add_tab("Output")
        p = t.add_panel("Plot")
        p.big("PLOT", "Plot PDF", "plot"); p.big("PNGOUT", "Image PNG", "png")
        p = t.add_panel("Exchange")
        p.big("EXPORT", "Export DXF / STL / OBJ", "export"); p.big("IMPORT", "Import", "import")
        t = rb.add_tab("Manage")
        p = t.add_panel("Application")
        p.big("OPTIONS", "Options", "options"); p.big("UPDATE", "Update", "update"); p.big("GUIDE", "Panduan", "guide"); p.big("HELP", "Commands", "help"); p.big("ABOUT", "About", "about")
        self.engine.register("BROWSER", misc.T(lambda c: self.pal.reveal(self.browser_dock)), [], "Model browser")
        self.engine.register("IMGSNAP", misc.T(lambda c: self._toggle_imgsnap()), [], "Toggle snap to image lines")

    def _build_docks(self):
        self.props = PropertiesPanel(self); self.props.changed.connect(self._props_changed)
        self.layers = LayersPanel(self); self.layers.changed.connect(lambda: (self.view.invalidate(), self._layer_combo_refresh()))
        self.symbols = SymbolPanel(self)
        self.browser = BrowserPanel(self)
        self.pal = PaletteManager(self)
        self.props_dock = self.pal.add("Properties", self.props, Qt.LeftDockWidgetArea)
        self.layers_dock = self.pal.add("Layers", self.layers, Qt.RightDockWidgetArea)
        self.sym_dock = self.pal.add("Symbol library", self.symbols, Qt.RightDockWidgetArea)
        self.browser_dock = self.pal.add("Model browser", self.browser, Qt.RightDockWidgetArea)
        self.cmd_dock = self.pal.add("Command", self.cmdline, Qt.BottomDockWidgetArea, can_autohide=False)
        self.cmd_dock.setAllowedAreas(Qt.BottomDockWidgetArea | Qt.TopDockWidgetArea)
        self.tabifyDockWidget(self.layers_dock, self.sym_dock); self.tabifyDockWidget(self.sym_dock, self.browser_dock)
        self.layers_dock.raise_()
        self.props_dock.setMinimumWidth(180); self.layers_dock.setMinimumWidth(200); self.sym_dock.setMinimumWidth(200)
        self.resizeDocks([self.props_dock, self.layers_dock], [270, 330], Qt.Horizontal)
        self.resizeDocks([self.cmd_dock], [self.cmdline.height_for_lines(self.view.opt.get("cmd_lines", 3))], Qt.Vertical)
        self._default_layout = self.saveState(3)
        self.layers.refresh(); self.props.refresh([]); self._layer_combo_refresh()
        self.engine.register("DSETTINGS", misc.T(lambda c: self.show_options("Drafting")), ["DS", "SE", "OS", "DDOSNAP"], "Drafting settings: object snap modes, AutoSnap, aperture")
        self.engine.register("COMMANDLINE", misc.T(lambda c: self.pal.toggle(self.cmd_dock)), ["CLI"], "Show / hide the command window (Ctrl+9)")
        self.engine.register("TEXTSCR", misc.T(lambda c: self.show_text_window()), [], "Command history text window (F2)")
        self.engine.register("PALETTERESET", misc.T(lambda c: self.reset_layout()), [], "Reset palettes and window layout")
        self.engine.register("AUTOHIDE", misc.T(lambda c: self.autohide_all()), [], "Auto-hide / pin all palettes")

    # ------------------------------------------------------------------ layout persistence
    def _restore_layout(self):
        if os.environ.get("CADPRO_NO_RESTORE") or os.environ.get("CADPRO_SELFTEST"):
            return
        try:
            st = self.settings.value("layout/state")
            if st is not None:
                self.restoreState(st, 3)
            self.pal.restore(__import__("json").loads(self.settings.value("layout/autohide_json", "[]") or "[]"))
        except Exception:
            pass

    def _save_layout(self):
        if os.environ.get("CADPRO_NO_RESTORE") or os.environ.get("CADPRO_SELFTEST"):
            return
        try:
            ah = self.pal.state()
            for d in list(self.pal.docks):          # saveState must not record the temporary fly-out windows
                if d.autohide:
                    d.hide()
            self.settings.setValue("layout/autohide_json", __import__("json").dumps(ah))
            self.settings.setValue("layout/state", self.saveState(3))
        except Exception:
            pass

    def reset_layout(self):
        self.pal.unhide_all()
        for d in self.pal.docks:
            d.setFloating(False); d.show()
        self.restoreState(self._default_layout, 3)
        self.ribbon.setVisible(True)
        self.resizeDocks([self.props_dock, self.layers_dock], [270, 330], Qt.Horizontal)
        self.resizeDocks([self.cmd_dock], [self.cmdline.height_for_lines(self.view.opt.get("cmd_lines", 3))], Qt.Vertical)
        self.message("Palettes and window layout reset")

    def autohide_all(self):
        side = [d for d in self.pal.docks if d.can_autohide]
        if all(d.autohide for d in side):
            self.pal.unhide_all(); self.message("Palettes pinned (auto-hide off)")
        else:
            for d in side:
                if d.isVisible() or d.autohide:
                    self.pal.set_autohide(d)
            self.message("Palettes auto-hidden: move the cursor over a tab on the window edge to open one")

    def show_text_window(self):
        d = getattr(self, "_textwin", None)
        if d is not None and d.isVisible():
            d.close(); return
        from PySide6.QtWidgets import QDialog, QPlainTextEdit
        d = QDialog(self); d.setWindowTitle("ALIEF CAD PRO Text Window - command history"); d.resize(900, 560)
        lay = QVBoxLayout(d); t = QPlainTextEdit(); t.setReadOnly(True); t.setObjectName("cmdhist"); t.setFont(self.cmdline.hist.font())
        t.setPlainText(self.cmdline.hist.toPlainText()); lay.addWidget(t); t.verticalScrollBar().setValue(t.verticalScrollBar().maximum())
        d.setModal(False); d.show(); self._textwin = d

    def _build_status(self):
        sb = QStatusBar(); self.setStatusBar(sb)
        self.coord = QLabel("0.000, 0.000, 0.000"); self.coord.setMinimumWidth(240); sb.addWidget(self.coord)
        self.toggles = {}
        for key, attr, tip in (("GRID", "show_grid", "F7"), ("SNAP", "snap_on", "F9"), ("ORTHO", "ortho", "F8"), ("OSNAP", "osnap_on", "F3"),
                               ("DYN", "dyn", "F12"), ("LWT", "lwt", "Lineweight")):
            b = QToolButton(); b.setObjectName("status"); b.setText(key); b.setCheckable(True); b.setChecked(getattr(self.view, attr)); b.setToolTip(tip)
            b.toggled.connect(lambda v, a=attr: (setattr(self.view, a, v), self.view.invalidate()))
            b.setContextMenuPolicy(Qt.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda pos, b=b, k=key: self._toggle_menu(b.mapToGlobal(pos), k))
            if key == "OSNAP":
                b.setToolTip("Object snap (F3) - right-click to choose the snap modes")
            sb.addWidget(b); self.toggles[attr] = b
        osm = QToolButton(); osm.setObjectName("status"); osm.setText("▾"); osm.setPopupMode(QToolButton.InstantPopup); osm.setToolTip("Object snap modes")
        menu = QMenu(osm); menu.aboutToShow.connect(lambda m=menu: self._fill_osnap_menu(m))
        osm.setMenu(menu); sb.addWidget(osm)
        self.style_lbl = QLabel(); sb.addPermanentWidget(self.style_lbl)
        sb.addPermanentWidget(QLabel("Scale"))
        self.scale_combo = QComboBox(); self.scale_combo.setEditable(True); self.scale_combo.setMinimumWidth(92)
        self.scale_combo.addItems(["AUTO"] + [f"1:{s:g}" for s in misc.STD_SCALES]); self.scale_combo.setCurrentText(f"1:{E.Entity.anno_scale:g}")
        self.scale_combo.activated.connect(self._scale_pick); self.scale_combo.lineEdit().returnPressed.connect(self._scale_pick)
        sb.addPermanentWidget(self.scale_combo)
        self.upd_lbl = QToolButton(); self.upd_lbl.setObjectName("status"); self.upd_lbl.setText(f"v{self.version}"); self.upd_lbl.clicked.connect(lambda: self.run_command("UPDATE"))
        sb.addPermanentWidget(self.upd_lbl)
        self.refresh_status()

    def _shortcuts(self):
        for key, cmd in (("Ctrl+Z", "UNDO"), ("Ctrl+Y", "REDO"), ("Ctrl+S", "SAVE"), ("Ctrl+O", "OPEN"), ("Ctrl+N", "NEW"), ("Ctrl+P", "PLOT"),
                         ("Ctrl+A", "SELECTALL"), ("F3", "OSNAP"), ("F7", "GRID"), ("F8", "ORTHO"), ("F9", "SNAP"), ("F12", "DYNMODE"), ("F1", "HELP"),
                         ("Ctrl+Shift+S", "SAVEAS"), ("Ctrl+1", "PROPERTIES")):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut); sc.activated.connect(lambda c=cmd: self.run_command(c))
        sc = QShortcut(QKeySequence("Ctrl+0"), self); sc.activated.connect(self._clean_screen)
        for key, cmd in (("Ctrl+9", "COMMANDLINE"), ("F2", "TEXTSCR"), ("Ctrl+2", "SYMLIB")):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.ApplicationShortcut); sc.activated.connect(lambda c=cmd: self.run_command(c))

    # =============================================================================== theme
    def apply_theme(self):
        th = LIGHT if self.view.light else DARK
        QApplication.instance().setStyleSheet(stylesheet(th))

    def toggle_theme(self):
        self.view.light = not self.view.light; set_light(self.view.light)
        self.view.opt["theme"] = "Light" if self.view.light else "Dark"; OPT.save(self.settings, self.view.opt)
        self.apply_theme(); self.view.invalidate()
        self.message("Theme: " + ("light" if self.view.light else "dark") + " (ribbon icons refresh after restart)")

    def _clean_screen(self):
        vis = not self.ribbon.isVisible()
        self.ribbon.setVisible(vis)
        if vis:
            for d in getattr(self, "_clean_hidden", []):
                d.show()
        else:
            self._clean_hidden = [d for d in self.pal.docks if d.isVisible() and not d.autohide and d is not self.cmd_dock]
            for d in self._clean_hidden:
                d.hide()

    # =============================================================================== controller API (viewport / engine)
    @property
    def req(self):
        return self.engine.req

    def typed_text(self):
        return self.cmdline.edit.text()

    def message(self, s, echo=False):
        self.cmdline.log(s)

    def on_request(self, req):
        self.view.preview = []; self.view.snap_hit = None; self.view.snap_override = None
        if req is None:
            self.cmdline.set_prompt("Command"); self.cmdline.string_mode = False
            self.view.highlight_extra = []
        else:
            self.cmdline.set_prompt(req.prompt, req.options if req.kind != "string" else ()); self.cmdline.string_mode = req.kind == "string"
            if req.kind == "select" and req.picked:
                self.set_selection([e.id for e in req.picked])
            self.view.refresh_preview()
        self.view.update()

    def run_command(self, name, *args):
        if isinstance(name, str) and name.upper() in ("SYMBOL",) and not args and self.engine.busy() is False and False:
            pass
        if name.upper() == "SYMBOL" and not args:
            self.show_symbol_library(); return
        if name.upper() == "FITTING" and args and args[0] is None:
            return
        self.view.setFocus()
        if self.engine.run(name, *args):
            r = self.engine.resolve(name)
            if r and not getattr(self.engine.cmds.get(r), "transparent", False):
                self.cmdline.note_command(r)

    def _cmd_text(self, t):
        self.message(f"{self.cmdline.prompt.text()} {t}")
        if not self.engine.busy() and t.strip():
            r = self.engine.resolve(t.strip().split()[0])
            if r and not getattr(self.engine.cmds.get(r), "transparent", False):
                self.cmdline.note_command(r)
        self.engine.feed_text(t)
        self.view.setFocus() if not self.engine.busy() else None

    def feed_point(self, p):
        self.engine.feed_point(p)

    def feed_entity(self, e, p):
        self.engine.feed_entity(e, p)

    def escape(self):
        self.zoom_window_pending = False
        if self.view.hot_grip is not None:
            self.view.hot_grip = None; self.view.preview = []; self.view.update(); return
        if self.engine.busy():
            self.engine.cancel()
        else:
            self.clear_selection()

    def pick_entity(self, e, shift):
        r = self.req
        if r is not None and r.kind == "select":
            if shift:
                r.picked = [x for x in r.picked if x is not e]
            elif e not in r.picked:
                r.picked.append(e)
            self.set_selection([x.id for x in r.picked]); return
        if shift:
            self.view.selection = [i for i in self.view.selection if i != e.id]
        elif e.id not in self.view.selection:
            self.view.selection.append(e.id)
        self._sel_changed()

    def pick_window(self, ents, shift, rect):
        self.last_window = rect
        r = self.req
        if r is not None and r.kind == "select":
            if r.filter:
                ents = [e for e in ents if r.filter(e)]
            if shift:
                ids = {e.id for e in ents}; r.picked = [x for x in r.picked if x.id not in ids]
            else:
                for e in ents:
                    if e not in r.picked:
                        r.picked.append(e)
            self.set_selection([x.id for x in r.picked]); return
        ids = [e.id for e in ents]
        if shift:
            self.view.selection = [i for i in self.view.selection if i not in ids]
        else:
            self.view.selection = list(dict.fromkeys(self.view.selection + ids))
        self._sel_changed()

    def set_selection(self, ids):
        self.view.selection = list(ids); self._sel_changed()

    def clear_selection(self, silent=False):
        self.view.selection = []
        if not silent:
            self._sel_changed()
        else:
            self.view.update()

    def selected_ents(self):
        return [self.doc.ents[i] for i in self.view.selection if i in self.doc.ents]

    def _sel_changed(self):
        self.props.refresh(self.selected_ents()); self.view.update()

    def right_click(self, gpos):
        r = self.req; o = self.view.opt
        if r is not None:
            if o.get("rclick_cmd", "Enter") == "Enter":
                self.engine.feed_enter(); return
            m = QMenu(self)                                    # AutoCAD command-mode shortcut menu
            m.addAction("Enter", self.engine.feed_enter); m.addAction("Cancel", self.escape)
            if r.options and r.kind != "string":
                m.addSeparator()
                for op in r.options:
                    m.addAction(op, lambda op=op: self._cmd_text(op))
            m.addSeparator()
            sm = m.addMenu("Snap Overrides"); self._fill_osnap_menu(sm, override=True)
            m.addAction(icon("zoomext"), "Zoom extents", self.view.zoom_extents)
            m.exec(gpos); return
        if o.get("rclick_idle", "Shortcut menu") != "Shortcut menu" and not self.view.selection:
            self.engine.feed_enter(); return
        m = QMenu(self)
        if self.engine.last_cmd:
            m.addAction(icon("redo"), f"Repeat {self.engine.last_cmd}", lambda: self.run_command(self.engine.last_cmd))
        if self.cmdline.cmd_history:
            rm = m.addMenu("Recent Input")
            for n in self.cmdline.cmd_history[:10]:
                rm.addAction(n, lambda n=n: self.run_command(n))
        if self.view.selection:
            for c, t, ic in (("MOVE", "Move", "move"), ("COPY", "Copy", "copy"), ("ROTATE", "Rotate", "rotate"), ("ERASE", "Erase", "erase"),
                             ("PROPERTIES", "Properties", "props"), ("LIST", "List", "list")):
                m.addAction(icon(ic), t, lambda c=c: self.run_command(c))
            m.addAction(icon("zoomext"), "Zoom to selection", lambda: self.view.zoom_extents(self.selected_ents()))
            m.addAction("Deselect all", self.clear_selection)
        m.addSeparator()
        m.addAction(icon("undo"), "Undo", lambda: self.run_command("UNDO")); m.addAction(icon("redo"), "Redo", lambda: self.run_command("REDO"))
        m.addAction(icon("zoomext"), "Zoom extents", self.view.zoom_extents)
        vm = m.addMenu(icon("view_iso"), "View")
        for v in ("Top", "Front", "Right", "SWISO", "SEISO", "NEISO", "NWISO"):
            vm.addAction(v, lambda v=v: self.run_command(v))
        m.addSeparator()
        m.addAction(icon("options"), "Options ...", lambda: self.run_command("OPTIONS"))
        m.exec(gpos)

    # ------------------------------------------------------------------ object snap menus
    def _fill_osnap_menu(self, m, override=False):
        from .viewport import SNAP_KINDS, SNAP_LABEL
        m.clear()
        if override:
            for k in SNAP_KINDS:
                m.addAction(self._snap_icon(k), SNAP_LABEL[k], lambda k=k: self._snap_override(k))
            m.addSeparator(); m.addAction("None", lambda: self._snap_override(None))
        else:
            for k in SNAP_KINDS:
                a = m.addAction(self._snap_icon(k), SNAP_LABEL[k]); a.setCheckable(True); a.setChecked(k in self.view.snap_modes)
                a.toggled.connect(lambda v, k=k: self._snap_mode(k, v))
            m.addSeparator()
            m.addAction("Select All", lambda: [self._snap_mode(k, True) for k in SNAP_KINDS])
            m.addAction("Clear All", lambda: [self._snap_mode(k, False) for k in SNAP_KINDS])
        m.addSeparator()
        m.addAction(icon("options"), "Object Snap Settings ...", lambda: self.show_options("Drafting"))

    def _snap_icon(self, kind):
        from PySide6.QtGui import QPixmap, QPainter
        pm = QPixmap(20, 20); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        size = self.view.opt.get("marker_size", 6); self.view.opt["marker_size"] = 6
        try:
            self.view._snap_marker(p, kind, 10, 10)
        finally:
            self.view.opt["marker_size"] = size
        p.end()
        return QIcon(pm)

    def _snap_mode(self, k, on):
        (self.view.snap_modes.add if on else self.view.snap_modes.discard)(k)
        self.view.opt["snap_modes"] = [x for x in __import__("alief_cadpro.ui.viewport", fromlist=["SNAP_KINDS"]).SNAP_KINDS if x in self.view.snap_modes]
        if on and not self.view.osnap_on:
            self.toggles["osnap_on"].setChecked(True)
        OPT.save(self.settings, self.view.opt)

    def _snap_override(self, k):
        self.view.snap_override = k
        if k:
            from .viewport import SNAP_LABEL
            self.message(f"Snap override: {SNAP_LABEL[k]} (next point only)")

    def osnap_menu(self, gpos, override=False):
        m = QMenu(self); self._fill_osnap_menu(m, override and self.req is not None); m.exec(gpos)

    def _toggle_menu(self, gpos, key):
        if key == "OSNAP":
            return self.osnap_menu(gpos)
        m = QMenu(self)
        m.addAction(icon("options"), f"{key} Settings ...", lambda: self.show_options("Display" if key in ("GRID", "LWT") else "Drafting"))
        m.exec(gpos)

    def viewport_key(self, ev):
        k = ev.key()
        if k == Qt.Key_Escape:
            self.escape(); return
        if k in (Qt.Key_Return, Qt.Key_Enter) or (k == Qt.Key_Space and self.view.opt.get("space_enter", True) and not self.cmdline.edit.text()
                                                  and not getattr(self.cmdline, "string_mode", False)):
            if self.cmdline.edit.text():
                self.cmdline._enter()
            else:
                self.engine.feed_enter()
            return
        if k == Qt.Key_Delete and not self.engine.busy() and self.view.selection:
            self.run_command("ERASE"); return
        t = ev.text()
        if t and t.isprintable():
            self.cmdline.edit.setFocus(); self.cmdline.edit.insert(t)
        elif k == Qt.Key_Backspace:
            self.cmdline.edit.backspace()

    def grip_preview(self, hot, p):
        e = self.doc.ents.get(hot[1])
        if e is None:
            return []
        c = e.copy(); grip_apply(c, hot[2], p)
        return [c]

    def grip_finish(self, hot, p):
        e = self.doc.ents.get(hot[1])
        if e is None:
            return
        self.doc.begin("grip"); self.doc.modify(e); grip_apply(e, hot[2], p); self.doc.end()
        self.props.refresh(self.selected_ents())

    def edit_entity(self, e):
        if e.kind == "text":
            s, ok = QInputDialog.getMultiLineText(self, "Edit text", "Text", e.s)
            if ok:
                self.doc.begin("edit"); self.doc.modify(e); e.s = s; e.touch(); self.doc.end()
        else:
            self.set_selection([e.id]); self.pal.reveal(self.props_dock)

    # =============================================================================== doc events
    def _doc_changed(self):
        self.view.invalidate()
        self.view.selection = [i for i in self.view.selection if i in self.doc.ents]
        self._title()
        QTimer.singleShot(0, self._deferred_refresh)

    def _deferred_refresh(self):
        self.props.refresh(self.selected_ents())
        if self.layers.table.rowCount() != len(self.doc.layers):
            self.layers.refresh(); self._layer_combo_refresh()
        if self.browser_dock.isVisible() and not self.browser_dock.visibleRegion().isEmpty():
            self.browser.refresh()

    def _props_changed(self):
        self.view.invalidate()

    def _title(self):
        nm = os.path.basename(self.doc.path) if self.doc.path else "Drawing1"
        self.setWindowTitle(f"ALIEF CAD PRO {self.version} - [{nm}{' *' if self.doc.modified else ''}]")

    def _coords(self, p):
        q = self.view.ucs.to_local(p)
        self.coord.setText(f"{q[0]:.3f}, {q[1]:.3f}, {q[2]:.3f}")

    def refresh_status(self):
        for attr, b in getattr(self, "toggles", {}).items():
            b.blockSignals(True); b.setChecked(getattr(self.view, attr)); b.blockSignals(False)
        if hasattr(self, "style_lbl"):
            self.style_lbl.setText({"wire": "Wireframe", "hidden": "Hidden", "shaded": "Shaded", "shadededges": "Shaded + edges", "xray": "X-ray"}[self.view.mode]
                                   + ("  |  persp" if self.view.cam.persp else "") + f"  |  {self.doc.settings.get('units', 'mm')}  |  Layer {self.doc.cur_layer}")
            self.scale_combo.blockSignals(True); self.scale_combo.setCurrentText(f"1:{E.Entity.anno_scale:g}"); self.scale_combo.blockSignals(False)

    def _scale_pick(self, *_):
        t = self.scale_combo.currentText().strip().upper()
        class C:
            pass
        c = self.engine.ctx
        if t.startswith("A"):
            n = misc.auto_scale(self.doc, self.doc.settings.get("paper", "A3"))
            self.message(f"Auto drawing scale for {self.doc.settings.get('paper', 'A3')}: 1:{n:g}")
        else:
            try:
                n = float(t.split(":")[-1])
            except ValueError:
                return
        misc.set_anno_scale(c, n)

    def _layer_combo_refresh(self):
        c = self.layer_combo; c.blockSignals(True); c.clear()
        from .panels import color_icon
        for n, L in self.doc.layers.items():
            c.addItem(color_icon(L.color), n)
        c.setCurrentText(self.doc.cur_layer); c.blockSignals(False)

    def _set_cur_layer(self, n):
        if n in self.doc.layers:
            self.doc.cur_layer = n; self.layers.refresh(); self.refresh_status()

    def _toggle_imgsnap(self):
        if "img" in self.view.snap_modes:
            self.view.snap_modes.discard("img"); self.message("Snap to image lines OFF")
        else:
            self.view.snap_modes.add("img"); self.message("Snap to image lines ON (move the cursor over a scanned line)")

    # =============================================================================== dialogs used by commands
    def _dlg(self, cls, key, *a, **kw):
        d = cls(self, *a, **kw)
        if d.exec():
            r = d.result()
            if key:
                self._last[key] = r
            return r
        return None

    def dialog_plate(self):
        return self._dlg(DL.PlateDialog, "plate", self._last.get("plate"))

    def dialog_profile(self):
        return self._dlg(DL.ProfileDialog, "profile", self._last.get("profile"))

    def dialog_detail(self):
        return self._dlg(DL.DetailDialog, "detail", self._last.get("detail"))

    def dialog_array(self, ents):
        return self._dlg(DL.ArrayDialog, None)

    def dialog_hatch(self):
        return self._dlg(DL.HatchDialog, "hatch", self._last.get("hatch"))

    def dialog_mtext(self):
        return self._dlg(DL.MTextDialog, None, self.doc.settings.get("text_paper", 2.5))

    def dialog_fitting(self, preset=None):
        return self._dlg(DL.FittingDialog, "fitting", preset, self._last.get("fitting"))

    def dialog_pipe(self):
        return self._dlg(DL.PipeDialog, "pipe", self._last.get("pipe"))

    def dialog_tray(self):
        return self._dlg(DL.TrayDialog, None)

    def dialog_equipment(self):
        pre = self.pending_equipment; self.pending_equipment = None
        return self._dlg(DL.EquipmentDialog, None, pre)

    def dialog_trace(self, img):
        return self._dlg(DL.TraceDialog, None, img)

    def dialog_pdf(self, path):
        try:
            return self._dlg(DL.PdfDialog, None, path)
        except Exception as ex:
            self.message(f"PDF error: {ex}"); return None

    def dialog_nest(self):
        return self._dlg(DL.NestDialog, None)

    def dialog_cam(self, parts, ucs):
        DL.CamDialog(self, parts, ucs).exec()

    def dialog_matlist(self, rows):
        DL.MatListDialog(self, rows).exec()

    def choose(self, title, label, items):
        s, ok = QInputDialog.getItem(self, title, label, items, 0, False)
        return s if ok else None

    def ask_open(self, title, filt):
        fn, _ = QFileDialog.getOpenFileName(self, title, self._dir() if not self.settings.value("last_dir", "") else self.settings.value("last_dir", ""), filt)
        if fn:
            self.settings.setValue("last_dir", os.path.dirname(fn))
        return fn

    def show_text(self, title, text):
        DL.TextDialog(self, title, text).exec()

    def show_symbol_library(self):
        self.pal.reveal(self.sym_dock)

    def show_layers(self):
        self.pal.reveal(self.layers_dock)

    def show_props(self):
        self.pal.reveal(self.props_dock)

    def show_options(self, tab=None):
        d = OPT.OptionsDialog(self, tab)
        d.exec()

    def apply_options(self, o, startup=False):
        """Push the option values into the program (called at start-up and from the Options dialog)."""
        v = self.view; v.opt = dict(o)
        v.aperture = int(o["aperture"]); v.snap_modes = set(o["snap_modes"]); v.grid_step = float(o.get("snap_step", 10.0))
        for attr, key in (("show_grid", "grid"), ("osnap_on", "osnap"), ("ortho", "ortho"), ("dyn", "dyn"), ("lwt", "lwt")):
            setattr(v, attr, bool(o[key]))
            b = getattr(self, "toggles", {}).get(attr)
            if b is not None and b.isChecked() != bool(o[key]):
                b.blockSignals(True); b.setChecked(bool(o[key])); b.blockSignals(False)
        v.mode = o["vstyle"]; v.cam.persp = bool(o["perspective"])
        if (o["theme"] == "Light") != v.light:
            v.light = o["theme"] == "Light"; set_light(v.light); self.apply_theme()
            if not startup:
                self.message("Theme changed (ribbon icons refresh after restart)")
        self.settings.setValue("auto_update", bool(o["auto_update"]))
        self.engine.noun_verb = bool(o["noun_verb"])
        self.cmdline.set_font_size(o["cmd_font"]); self.cmdline.space_enter = bool(o["space_enter"])
        if not startup and hasattr(self, "cmd_dock") and not self.cmd_dock.isFloating():
            self.resizeDocks([self.cmd_dock], [self.cmdline.height_for_lines(o["cmd_lines"])], Qt.Vertical)
        from ..core import dxfio
        dxfio.ODA_PATH = o.get("oda_path") or None
        if hasattr(self, "autosave"):
            self._autosave_timer()
        if hasattr(self, "recent_menu"):
            self._recent_refresh()
        if hasattr(self, "toggles"):
            self.refresh_status()
        v._proj = None; v.invalidate()

    def _autosave_timer(self):
        o = self.view.opt
        if o.get("autosave_on", True):
            self.autosave.start(max(1, int(o.get("autosave_min", 10))) * 60 * 1000)
        else:
            self.autosave.stop()

    def _sync_options(self):
        """Status-bar toggles and view state changed during the session are kept in the current profile."""
        v = self.view; o = v.opt
        o.update(grid=v.show_grid, osnap=v.osnap_on, ortho=v.ortho, dyn=v.dyn, lwt=v.lwt, vstyle=v.mode, perspective=bool(v.cam.persp),
                 aperture=int(v.aperture), theme="Light" if v.light else "Dark")
        from .viewport import SNAP_KINDS
        o["snap_modes"] = [k for k in SNAP_KINDS if k in v.snap_modes]
        OPT.save(self.settings, o)

    def show_about(self):
        QMessageBox.about(self, "About ALIEF CAD PRO", DL.about_html(self.version, self.boot))

    def show_help(self):
        lines = ["ALIEF CAD PRO - commands (type the name or alias, Enter / Space / right-click = Enter, Esc = cancel)", ""]
        inv = {}
        for a, n in self.engine.alias.items():
            inv.setdefault(n, []).append(a)
        for n in sorted(self.engine.cmds):
            lines.append(f"{n:<14} {', '.join(sorted(inv.get(n, []))):<22} {self.engine.desc.get(n, '')}")
        lines += ["", "Coordinates: x,y  x,y,z  @dx,dy  @dist<angle   |  type a number to give a distance in the cursor direction",
                  "Mouse: wheel = zoom, middle drag = pan, right drag / Shift+middle = orbit, double middle = zoom extents",
                  "Keys: F3 osnap, F7 grid, F8 ortho, F9 snap, F12 dynamic input, Ctrl+0 clean screen, Delete = erase selection"]
        self.show_text("Commands", "\n".join(lines))

    def show_guide(self):
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        cands = [os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs", "PANDUAN_ALIEF_CADPRO.pdf"),     # newest, comes with updates
                 os.path.join(self.boot.get("install_dir", ""), "docs", "PANDUAN_ALIEF_CADPRO.pdf"),
                 os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "docs", "PANDUAN_ALIEF_CADPRO.pdf")]
        for c in cands:
            if os.path.exists(c):
                QDesktopServices.openUrl(QUrl.fromLocalFile(c)); return
        self.message("Guide not found - it is installed in the program folder under docs\\")

    # =============================================================================== files
    def _confirm_discard(self):
        if not self.doc.modified or not self.doc.ents:
            return True
        r = QMessageBox.question(self, "ALIEF CAD PRO", "Save changes to the current drawing?", QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
        if r == QMessageBox.Save:
            return self.file_save()
        return r == QMessageBox.Discard

    def _set_doc(self, doc):
        self.doc = doc; doc.listeners.append(self._doc_changed); doc.activate()
        E.Entity.anno_scale = doc.settings.get("anno_scale", 1.0)
        self.view.selection = []; self.view.textures = {}; self.view.invalidate()
        self.layers.refresh(); self._layer_combo_refresh(); self.props.refresh([]); self._title(); self.refresh_status()

    def file_new(self):
        if self._confirm_discard():
            tpl = self.view.opt.get("template") or ""
            d = None
            if tpl and os.path.exists(tpl):
                try:
                    d = Document.load(tpl); d.path = None; d.modified = False
                except Exception as ex:
                    self.message(f"Template could not be opened ({ex}) - blank drawing used")
            self._set_doc(d or Document()); self.view.set_view("top"); self.view.zoom_extents()

    def file_open(self):
        if not self._confirm_discard():
            return
        fn = self.ask_open("Open drawing", "All supported (*.acp *.dxf *.dwg *.pdf *.png *.jpg *.jpeg *.bmp *.tif *.stl *.obj);;"
                                           "ALIEF CAD PRO (*.acp);;DXF (*.dxf);;DWG (*.dwg);;PDF (*.pdf);;Images (*.png *.jpg *.jpeg *.bmp *.tif);;Mesh (*.stl *.obj)")
        if fn:
            self.open_path(fn)

    def open_path(self, fn):
        ext = os.path.splitext(fn)[1].lower()
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            if ext == ".acp":
                self._set_doc(Document.load(fn))
            elif ext in (".dxf", ".dwg"):
                d = Document(); self._set_doc(d)
                self._import_cad(fn); d.path = None if ext == ".dwg" else None
                d.modified = False
            elif ext == ".pdf":
                QApplication.restoreOverrideCursor(); self.run_command("PDFIMPORT", fn); return
            elif ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".gif"):
                QApplication.restoreOverrideCursor(); self.run_command("IMAGEATTACH", fn); return
            elif ext in (".stl", ".obj"):
                self._import_cad(fn)
            self._recent_add(fn)
            self.view.zoom_extents()
        except Exception as ex:
            import traceback; traceback.print_exc()
            QMessageBox.warning(self, "Open", f"Cannot open {fn}:\n{ex}")
        finally:
            QApplication.restoreOverrideCursor()

    def _import_cad(self, fn):
        from ..core import dxfio
        ext = os.path.splitext(fn)[1].lower()
        if ext == ".dwg":
            import tempfile
            try:
                out = dxfio.dwg_convert(fn, tempfile.mkdtemp(prefix="cadpro_dwg_"))
            except RuntimeError as ex:
                QMessageBox.information(self, "DWG", "DWG files are read through the free ODA File Converter.\n"
                                        "Install it from https://www.opendesign.com/guestfiles/oda_file_converter and open the DWG again,\n"
                                        f"or save the drawing as DXF in AutoCAD / ZWCAD / GstarCAD.\n\n({ex})")
                return
            fn = out; ext = ".dxf"
        if ext == ".dxf":
            n, warn, units = dxfio.import_dxf(self.doc, fn)
            self.message(f"Imported {n} object(s)" + (f"; skipped: {', '.join(f'{k} x{v}' for k, v in warn.items())}" if warn else ""))
            self.layers.refresh(); self._layer_combo_refresh()
        elif ext in (".stl", ".obj"):
            b = dxfio.import_mesh(fn); self.doc.add(b); self.message(f"Mesh imported: {len(b.F)} triangles")

    def file_import(self):
        fn = self.ask_open("Import", "All (*.dxf *.dwg *.stl *.obj *.pdf *.png *.jpg *.jpeg *.bmp *.tif *.csv *.xlsx);;DXF (*.dxf);;DWG (*.dwg)")
        if not fn:
            return
        ext = os.path.splitext(fn)[1].lower()
        if ext == ".pdf":
            self.run_command("PDFIMPORT", fn)
        elif ext in (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"):
            self.run_command("IMAGEATTACH", fn)
        elif ext in (".csv", ".xlsx", ".txt"):
            self.run_command("CSVIMPORT", fn)
        else:
            self._import_cad(fn); self.view.zoom_extents()

    def file_save(self):
        if not self.doc.path:
            return self.file_saveas()
        self.doc.settings["anno_scale"] = E.Entity.anno_scale
        if self.view.opt.get("backup", True) and os.path.exists(self.doc.path):
            try:
                import shutil; shutil.copy2(self.doc.path, os.path.splitext(self.doc.path)[0] + ".bak")
            except Exception:
                pass
        self.doc.save(self.doc.path); self._title(); self.message(f"Saved {self.doc.path}"); self._recent_add(self.doc.path)
        return True

    def file_saveas(self):
        o = self.view.opt; ver = o.get("dxf_version", "R2018")
        filters = ["ALIEF CAD PRO (*.acp)", f"DXF {ver} (*.dxf)"]
        dxf_first = o.get("save_format", "").startswith("DXF")
        fn, filt = QFileDialog.getSaveFileName(self, "Save drawing as", self.doc.path or os.path.join(self._dir(), "Drawing1" + (".dxf" if dxf_first else ".acp")),
                                               ";;".join(filters), filters[1] if dxf_first else filters[0])
        if not fn:
            return False
        if fn.lower().endswith(".dxf"):
            from ..core import dxfio
            dxfio.export_dxf(self.doc, fn, None, ver); self.message(f"Saved {fn} (DXF {ver})"); return True
        if not fn.lower().endswith(".acp"):
            fn += ".acp"
        self.doc.path = fn
        return self.file_save()

    def file_export(self):
        ver = self.view.opt.get("dxf_version", "R2018")
        fn, filt = QFileDialog.getSaveFileName(self, "Export", self._dir(), f"DXF {ver} (*.dxf);;DWG via ODA (*.dwg);;STL mesh (*.stl);;OBJ mesh (*.obj)")
        if not fn:
            return
        from ..core import dxfio
        ext = os.path.splitext(fn)[1].lower()
        sel = self.selected_ents()
        ents = sel or list(self.doc.ents.values())
        try:
            if ext == ".dxf":
                dxfio.export_dxf(self.doc, fn, ents, ver)
            elif ext == ".dwg":
                import tempfile
                tmp = os.path.join(tempfile.mkdtemp(), os.path.splitext(os.path.basename(fn))[0] + ".dxf")
                dxfio.export_dxf(self.doc, tmp, ents)
                out = dxfio.dwg_convert(tmp, os.path.dirname(fn), "DWG")
            elif ext in (".stl", ".obj"):
                bodies = [e for e in ents if isinstance(e, E.Body)]
                (dxfio.export_stl if ext == ".stl" else dxfio.export_obj)(fn, bodies)
            self.message(f"Exported {fn}")
        except Exception as ex:
            QMessageBox.warning(self, "Export", str(ex))

    def file_plot(self):
        from .plot import PlotDialog
        d = PlotDialog(self, self)
        if d.exec():
            fn = d.run()
            if fn:
                self.message(f"Plotted {fn}")
                from PySide6.QtGui import QDesktopServices
                from PySide6.QtCore import QUrl
                QDesktopServices.openUrl(QUrl.fromLocalFile(fn))

    def file_png(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Save view as PNG", "view.png", "PNG (*.png)")
        if fn:
            self.view.grab_image().save(fn); self.message(f"Saved {fn}")

    def _recent_add(self, fn):
        r = [x for x in (self.settings.value("recent", []) or []) if x != fn]
        r.insert(0, fn); self.settings.setValue("recent", r[:30]); self._recent_refresh()

    def _recent_refresh(self):
        self.recent_menu.clear()
        for f in (self.settings.value("recent", []) or [])[:int(self.view.opt.get("recent_n", 10))]:
            self.recent_menu.addAction(os.path.basename(f), lambda f=f: self._confirm_discard() and self.open_path(f))

    def _dir(self):
        d = self.view.opt.get("draw_dir") or ""
        return d if d and os.path.isdir(d) else (self.settings.value("last_dir", "") or "")

    def _autosave(self):
        if self.doc.modified and self.doc.ents:
            from ..core.update import local_root
            try:
                root = self.view.opt.get("autosave_dir") or local_root()
                os.makedirs(root, exist_ok=True)
                d = self.doc; path, mod = d.path, d.modified
                name = (os.path.splitext(os.path.basename(path))[0] if path else "Drawing1") + "_autosave.acp"
                d.save(os.path.join(root, name)); d.path, d.modified = path, mod
            except Exception:
                pass

    def closeEvent(self, ev):
        if self._confirm_discard():
            if not (os.environ.get("CADPRO_NO_RESTORE") or os.environ.get("CADPRO_SELFTEST")):
                self._sync_options()
            self._save_layout()
            ev.accept()
        else:
            ev.ignore()

    # =============================================================================== update
    def _boot_ok(self):
        f = self.boot.get("mark_ok")
        if f:
            try:
                f()
            except Exception:
                pass

    def _startup_update(self):
        if self.settings.value("auto_update", True, bool):
            from ..core.update import Checker
            Checker(self.version, lambda s, n, i: self.bridge.update_result.emit(s, n, i), True).start()

    def check_update_manual(self):
        self.update_dialog = DL.UpdateDialog(self, self)
        self.update_dialog.show()
        self.check_update_manual_inner()

    def check_update_manual_inner(self):
        from ..core.update import Checker
        if self.update_dialog:
            self.update_dialog.lbl.setText("Checking aliefen/alief-cadpro-update ...")
        Checker(self.version, lambda s, n, i: self.bridge.update_result.emit(s, n, i), True).start()

    def _update_result(self, status, notice, info):
        if self.update_dialog is not None and self.update_dialog.isVisible():
            self.update_dialog.show_status(status, notice, info)
        if status == "ready":
            v = notice.get("version")
            self.upd_lbl.setText(f"⬆ {v} ready - restart"); self.upd_lbl.setStyleSheet("color:#FFB020; font-weight:600;")
            self.message(f"Update {v} has been installed automatically. It runs after restarting ALIEF CAD PRO.")
        elif status == "available":
            self.upd_lbl.setText(f"⬆ {notice.get('version')} available")

    def install_update_file(self):
        fn = self.ask_open("Install update from file", "ALIEF CAD PRO update (*.cadpro-update *.zip)")
        if not fn:
            return
        from ..core import update as U
        try:
            n, d = U.install_offline(fn)
            QMessageBox.information(self, "Update", f"Version {n['version']} installed. Restart ALIEF CAD PRO to use it.")
            self._update_result("ready", n, d)
        except Exception as ex:
            QMessageBox.warning(self, "Update", str(ex))

    def restart(self):
        if not self._confirm_discard():
            return
        exe = self.boot.get("restart_cmd")
        import subprocess
        try:
            if exe:
                subprocess.Popen(exe, close_fds=True)
            else:
                subprocess.Popen([sys.executable] + sys.argv, close_fds=True)
        except Exception as ex:
            QMessageBox.warning(self, "Restart", str(ex)); return
        self.doc.modified = False
        QApplication.quit()
